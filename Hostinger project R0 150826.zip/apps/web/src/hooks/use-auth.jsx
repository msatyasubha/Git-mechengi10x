import { useCallback, useEffect, useState } from 'react';
import pb from '@/lib/pocketbaseClient';

export function useAuth() {
    const [user, setUser] = useState(pb.authStore.record);

    useEffect(() => {
        const unsub = pb.authStore.onChange((_t, record) => setUser(record));
        return unsub;
    }, []);

    useEffect(() => {
        const refresh = () => {
            if (pb.authStore.isValid) {
                pb.collection('users').authRefresh().catch(() => {});
            }
        };
        refresh();
        window.addEventListener('focus', refresh);
        return () => window.removeEventListener('focus', refresh);
    }, []);

    const login = useCallback(
        (email, password) => pb.collection('users').authWithPassword(email, password),
        [],
    );

    const signup = useCallback(async (email, password, name) => {
        await pb.collection('users').create({ email, password, passwordConfirm: password, name });
        return pb.collection('users').authWithPassword(email, password);
    }, []);

    const logout = useCallback(() => pb.authStore.clear(), []);

    return { user, isAuthed: pb.authStore.isValid && !!user, login, signup, logout };
}

export default useAuth;
