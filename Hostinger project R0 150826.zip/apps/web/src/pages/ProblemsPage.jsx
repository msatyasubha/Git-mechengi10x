import Helmet from 'react-helmet';
import { Link } from 'react-router-dom';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { problems } from '@/data/curriculum';

const ProblemsPage = () => (
    <div className="min-h-screen bg-background">
        <Helmet>
            <title>Worked Mechanical Engineering Problem Sets — TorqueLab</title>
            <meta name="description" content="Practice mechanical engineering problems on beams, cycles, gear trains, pipe networks, vibration isolation and bolted joints — each solvable step by step with the AI tutor." />
        </Helmet>
        <SiteHeader />
        <section className="mx-auto max-w-[72rem] px-5 py-20">
            <p className="font-tech text-xs uppercase tracking-[0.35em] text-accent">Problem sets</p>
            <h1 className="mt-5 max-w-2xl font-display text-4xl font-bold tracking-tight sm:text-5xl">
                Attempt it first. Then have the tutor mark your method.
            </h1>
            <div className="mt-14 divide-y divide-border border-y border-border">
                {problems.map((p) => (
                    <div key={p.title} className="grid gap-4 py-7 md:grid-cols-[1fr_auto] md:items-start md:gap-10">
                        <div>
                            <div className="flex flex-wrap items-center gap-3">
                                <h2 className="font-display text-lg font-semibold">{p.title}</h2>
                                <span className="border border-border px-2 py-0.5 font-tech text-[10px] uppercase tracking-widest text-muted-foreground">
                                    {p.topic}
                                </span>
                                <span className="font-tech text-[10px] uppercase tracking-widest text-primary">{p.difficulty}</span>
                            </div>
                            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">{p.prompt}</p>
                        </div>
                        <Link
                            to={`/tutor?q=${encodeURIComponent(p.prompt)}`}
                            className="inline-flex min-h-[44px] items-center rounded-sm border border-border px-4 font-tech text-xs uppercase tracking-widest hover:border-accent hover:text-accent"
                        >
                            Solve with tutor
                        </Link>
                    </div>
                ))}
            </div>
        </section>
        <SiteFooter />
    </div>
);

export default ProblemsPage;
