import { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { Briefcase, MapPin, Clock, ExternalLink, Search, Building2, DollarSign } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

const jobListings = [
  {
    id: 1,
    title: 'Senior Mechanical Design Engineer',
    company: 'SpaceX',
    location: 'Hawthorne, CA',
    type: 'Full-time',
    category: 'cad',
    salary: '$120k–$160k',
    tags: ['SOLIDWORKS', 'GD&T', 'FEA', 'Aerospace'],
    description: 'Design and develop mechanical systems for launch vehicles. Hands-on work from concept through flight hardware. Strong CAD and FEA skills required.',
    posted: '2 days ago',
    url: 'https://www.spacex.com/careers/',
    featured: true,
  },
  {
    id: 2,
    title: 'FEA / Simulation Engineer',
    company: 'Tesla',
    location: 'Fremont, CA',
    type: 'Full-time',
    category: 'simulation',
    salary: '$110k–$150k',
    tags: ['ANSYS', 'Nonlinear FEA', 'Python', 'Structural'],
    description: 'Conduct advanced structural and thermal simulations for electric vehicle components. Collaborate with design engineers to optimize parts for performance and manufacturability.',
    posted: '3 days ago',
    url: 'https://www.tesla.com/careers/',
    featured: true,
  },
  {
    id: 3,
    title: 'Robotics Automation Engineer',
    company: 'Boston Dynamics',
    location: 'Waltham, MA',
    type: 'Full-time',
    category: 'automation',
    salary: '$115k–$155k',
    tags: ['ROS', 'Python', 'Motion Planning', 'Control Systems'],
    description: 'Develop automation pipelines and motion planning algorithms for advanced robotic systems. Experience with simulation environments and real hardware deployment required.',
    posted: '5 days ago',
    url: 'https://bostondynamics.com/careers/',
    featured: true,
  },
  {
    id: 4,
    title: 'AI/ML Engineer — Engineering Applications',
    company: 'Autodesk',
    location: 'San Francisco, CA (Hybrid)',
    type: 'Full-time',
    category: 'ai',
    salary: '$130k–$175k',
    tags: ['Machine Learning', 'Generative Design', 'Python', 'CAD'],
    description: 'Apply AI and ML to engineering design workflows. Work on generative design, design automation, and intelligent recommendation systems inside Fusion 360.',
    posted: '1 week ago',
    url: 'https://www.autodesk.com/careers/',
    featured: false,
  },
  {
    id: 5,
    title: 'CFD Engineer — Thermal Management',
    company: 'Apple',
    location: 'Cupertino, CA',
    type: 'Full-time',
    category: 'simulation',
    salary: '$130k–$170k',
    tags: ['ANSYS Fluent', 'CFD', 'Thermal', 'Python'],
    description: 'Design and validate thermal management solutions for Apple silicon and product enclosures. Deep expertise in CFD and thermal simulation required.',
    posted: '1 week ago',
    url: 'https://www.apple.com/careers/',
    featured: false,
  },
  {
    id: 6,
    title: 'Manufacturing Process Engineer',
    company: 'General Motors',
    location: 'Detroit, MI',
    type: 'Full-time',
    category: 'automation',
    salary: '$90k–$120k',
    tags: ['Lean Manufacturing', 'Six Sigma', 'AutoCAD', 'PLC'],
    description: 'Optimize manufacturing processes for electric vehicle production lines. Implement automation and continuous improvement initiatives.',
    posted: '1 week ago',
    url: 'https://www.gm.com/careers/',
    featured: false,
  },
  {
    id: 7,
    title: 'Structural Analysis Engineer',
    company: 'Lockheed Martin',
    location: 'Fort Worth, TX',
    type: 'Full-time',
    category: 'simulation',
    salary: '$100k–$140k',
    tags: ['NASTRAN', 'CATIA', 'Aerospace', 'Fatigue Analysis'],
    description: 'Perform structural analysis on defense and aerospace structures from preliminary design through certification. Clearance eligibility required.',
    posted: '2 weeks ago',
    url: 'https://www.lockheedmartin.com/careers/',
    featured: false,
  },
  {
    id: 8,
    title: 'CAD Designer — Medical Devices',
    company: 'Medtronic',
    location: 'Minneapolis, MN (Hybrid)',
    type: 'Full-time',
    category: 'cad',
    salary: '$80k–$110k',
    tags: ['SOLIDWORKS', 'GD&T', 'FDA', 'Medical Device'],
    description: 'Design and develop mechanical components for implantable and surgical devices. ISO 13485 and FDA design control experience is a plus.',
    posted: '2 weeks ago',
    url: 'https://www.medtronic.com/careers/',
    featured: false,
  },
  {
    id: 9,
    title: 'Engineering Program Manager',
    company: 'Amazon',
    location: 'Seattle, WA (Hybrid)',
    type: 'Full-time',
    category: 'management',
    salary: '$130k–$180k',
    tags: ['Project Management', 'Agile', 'Cross-functional', 'Hardware'],
    description: "Lead technical programs from concept through production for Amazon's devices and robotics hardware. Strong engineering background required alongside PM skills.",
    posted: '2 weeks ago',
    url: 'https://www.amazon.jobs/',
    featured: false,
  },
  {
    id: 10,
    title: 'Mechanical Engineer — Onshape Admin',
    company: 'PTC Inc.',
    location: 'Boston, MA (Remote)',
    type: 'Full-time',
    category: 'cad',
    salary: '$95k–$130k',
    tags: ['Onshape', 'FeatureScript', 'Cloud CAD', 'PLM'],
    description: 'Work with enterprise customers to deploy and optimize Onshape implementations. Build custom FeatureScript features and develop CAD automation workflows.',
    posted: '3 weeks ago',
    url: 'https://www.ptc.com/careers/',
    featured: false,
  },
  {
    id: 11,
    title: 'Junior Simulation Engineer',
    company: 'SimScale GmbH',
    location: 'Munich, Germany (Remote)',
    type: 'Full-time',
    category: 'simulation',
    salary: '€60k–€80k',
    tags: ['CFD', 'FEA', 'OpenFOAM', 'Python'],
    description: 'Support customers running structural and fluid simulations on the SimScale platform. Develop validation benchmarks and create technical content.',
    posted: '3 weeks ago',
    url: 'https://www.simscale.com/careers/',
    featured: false,
  },
  {
    id: 12,
    title: 'Automation Developer — Engineering Workflows',
    company: 'Siemens',
    location: 'Plano, TX (Hybrid)',
    type: 'Full-time',
    category: 'automation',
    salary: '$100k–$135k',
    tags: ['Python', 'NX API', 'Teamcenter', 'PLM Integration'],
    description: 'Develop automation tools and integrations for CAD/PLM engineering workflows using Siemens NX, Teamcenter, and Python scripting.',
    posted: '3 weeks ago',
    url: 'https://jobs.siemens.com/',
    featured: false,
  },
  {
    id: 13,
    title: 'Technical Learning Designer — Engineering',
    company: 'Coursera',
    location: 'Remote',
    type: 'Full-time',
    category: 'learning',
    salary: '$90k–$120k',
    tags: ['Instructional Design', 'Engineering Education', 'E-learning', 'STEM'],
    description: 'Design and develop technical engineering courses in partnership with university instructors. Background in mechanical or civil engineering preferred.',
    posted: '1 month ago',
    url: 'https://careers.coursera.org/',
    featured: false,
  },
  {
    id: 14,
    title: 'Engineering AI Product Manager',
    company: 'Ansys',
    location: 'Canonsburg, PA (Hybrid)',
    type: 'Full-time',
    category: 'ai',
    salary: '$120k–$155k',
    tags: ['AI', 'Product Management', 'Simulation', 'ML'],
    description: 'Define and drive AI features for ANSYS simulation products. Partner with engineering and data science teams to bring ML-powered simulation capabilities to market.',
    posted: '1 month ago',
    url: 'https://www.ansys.com/careers/',
    featured: false,
  },
  {
    id: 15,
    title: 'Mechanical Engineer — Consumer Products',
    company: 'Dyson',
    location: 'Chicago, IL',
    type: 'Full-time',
    category: 'cad',
    salary: '$85k–$115k',
    tags: ['Fusion 360', 'Consumer Products', 'Prototyping', 'DFM'],
    description: 'Design and develop mechanisms for next-generation Dyson products. Ownership from concept through DFM, rapid prototyping, and mass production.',
    posted: '1 month ago',
    url: 'https://www.dyson.com/careers/',
    featured: false,
  },
];

const categoryOptions = [
  { id: 'all', label: 'All Categories' },
  { id: 'ai', label: 'AI Tools' },
  { id: 'cad', label: 'CAD & Design' },
  { id: 'simulation', label: 'Simulation' },
  { id: 'automation', label: 'Automation' },
  { id: 'management', label: 'Management' },
  { id: 'learning', label: 'Learning' },
];

const typeOptions = ['All Types', 'Full-time', 'Part-time', 'Contract', 'Remote'];

const jobBoards = [
  { name: 'LinkedIn Engineering Jobs', url: 'https://www.linkedin.com/jobs/mechanical-engineer-jobs/', description: 'Largest professional network with thousands of ME job listings' },
  { name: 'Indeed — Mechanical Engineering', url: 'https://www.indeed.com/q-mechanical-engineer-jobs.html', description: 'Aggregate of all major job boards — best for volume searching' },
  { name: 'EngineerJobs.com', url: 'https://www.engineerjobs.com/', description: 'Specialized engineering job board across all disciplines' },
  { name: 'ASME Career Center', url: 'https://jobs.asme.org/', description: "American Society of Mechanical Engineers' official job board" },
  { name: 'Glassdoor Engineering', url: 'https://www.glassdoor.com/Job/mechanical-engineer-jobs-SRCH_KO0,20.htm', description: 'Jobs with salary data and company reviews' },
  { name: 'AngelList / Wellfound', url: 'https://wellfound.com/jobs', description: 'Best for startup engineering roles and equity-compensated positions' },
];

function JobCard({ job }) {
  return (
    <div className={`flex flex-col rounded-xl border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 ${job.featured ? 'border-primary/20 bg-primary/[0.03]' : 'border-border'}`}>
      {job.featured && (
        <div className="mb-3 flex items-center gap-1.5">
          <span className="rounded-full bg-accent/15 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-accent">Featured</span>
        </div>
      )}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-display text-lg font-bold leading-snug">{job.title}</h3>
          <div className="mt-1 flex flex-wrap items-center gap-3 font-mono text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><Building2 className="h-3 w-3" />{job.company}</span>
            <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{job.location}</span>
            <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{job.posted}</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1.5">
          <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${job.category}`}>
            {categoryOptions.find(c => c.id === job.category)?.label || job.category}
          </span>
          {job.salary && (
            <span className="flex items-center gap-1 font-mono text-xs text-green-400">
              <DollarSign className="h-3 w-3" />{job.salary}
            </span>
          )}
        </div>
      </div>

      <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{job.description}</p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {job.tags.map(tag => (
          <span key={tag} className="rounded-full border border-border bg-muted/40 px-2.5 py-0.5 font-mono text-[10px] text-muted-foreground">
            {tag}
          </span>
        ))}
      </div>

      <div className="mt-4 flex items-center justify-between">
        <span className={`rounded-full border px-3 py-0.5 font-mono text-[10px] ${
          job.type === 'Full-time' ? 'border-blue-500/30 text-blue-400' : 'border-border text-muted-foreground'
        }`}>{job.type}</span>
        <a
          href={job.url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
        >
          Apply Now <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>
    </div>
  );
}

export default function JobsPage() {
  const [query, setQuery] = useState('');
  const [activeCat, setActiveCat] = useState('all');

  const filtered = useMemo(() => {
    let list = jobListings;
    if (activeCat !== 'all') list = list.filter(j => j.category === activeCat);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(j =>
        j.title.toLowerCase().includes(q) ||
        j.company.toLowerCase().includes(q) ||
        j.location.toLowerCase().includes(q) ||
        j.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    return list;
  }, [activeCat, query]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Jobs — Mechanical Engineering, CAD, Simulation & AI Careers | MechEngi 10X</title>
        <meta name="description" content="Browse mechanical engineering job listings across CAD, simulation, automation, AI, and management. Find roles at top engineering companies and link to major job boards." />
      </Helmet>

      <SiteHeader />

      {/* Header */}
      <div className="relative border-b border-border bg-card/30 py-14">
        <div className="pointer-events-none absolute inset-0 opacity-30">
          <div className="dot-grid h-full w-full" />
        </div>
        <div className="relative mx-auto max-w-[72rem] px-5">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Briefcase className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Career Opportunities</p>
          </div>
          <h1 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Engineering Jobs</h1>
          <p className="mt-2 text-muted-foreground max-w-xl">
            Curated job listings for mechanical engineers, simulation specialists, CAD designers, and automation engineers at top companies.
          </p>

          {/* Search */}
          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center max-w-2xl">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search jobs by title, company, or skill…"
                className="h-11 w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          </div>

          {/* Category filter */}
          <div className="mt-4 flex flex-wrap gap-2">
            {categoryOptions.map(c => (
              <button
                key={c.id}
                onClick={() => setActiveCat(c.id)}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                  activeCat === c.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          {/* Job listings */}
          <div>
            <p className="mb-5 font-mono text-xs text-muted-foreground">
              {filtered.length} position{filtered.length !== 1 ? 's' : ''} found
            </p>
            {filtered.length > 0 ? (
              <div className="flex flex-col gap-4">
                {filtered.map(job => <JobCard key={job.id} job={job} />)}
              </div>
            ) : (
              <div className="rounded-xl border border-border py-20 text-center">
                <p className="font-display text-xl font-semibold">No jobs match your search</p>
                <p className="mt-2 text-muted-foreground">Try adjusting the filters or search terms.</p>
                <button
                  onClick={() => { setQuery(''); setActiveCat('all'); }}
                  className="mt-4 rounded-xl bg-primary px-6 py-2 font-medium text-primary-foreground"
                >
                  Clear filters
                </button>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-5">
            {/* Job boards */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Top Engineering Job Boards</h3>
              <p className="mt-1.5 text-xs text-muted-foreground">Search thousands more listings on these platforms:</p>
              <div className="mt-4 flex flex-col gap-3">
                {jobBoards.map(board => (
                  <a
                    key={board.name}
                    href={board.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-start gap-3 rounded-lg border border-border p-3 transition-all hover:border-primary/30 hover:bg-primary/5"
                  >
                    <ExternalLink className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary opacity-60 group-hover:opacity-100" />
                    <div>
                      <p className="text-sm font-medium group-hover:text-primary">{board.name}</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">{board.description}</p>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {/* Salary guide */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Engineering Salary Ranges</h3>
              <div className="mt-4 space-y-3">
                {[
                  { role: 'Entry-level ME', range: '$65k–$85k' },
                  { role: 'Mid-level (3–7 yrs)', range: '$90k–$125k' },
                  { role: 'Senior Engineer', range: '$120k–$165k' },
                  { role: 'Principal Engineer', range: '$155k–$210k' },
                  { role: 'Engineering Manager', range: '$140k–$200k' },
                ].map(s => (
                  <div key={s.role} className="flex items-center justify-between border-b border-border pb-2.5 last:border-0 last:pb-0">
                    <span className="text-sm text-muted-foreground">{s.role}</span>
                    <span className="font-mono text-xs font-semibold text-green-400">{s.range}</span>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[10px] text-muted-foreground">US national median ranges. Varies significantly by location, industry, and company size.</p>
            </div>

            {/* Skills in demand */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Most In-Demand Skills</h3>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {['ANSYS', 'SOLIDWORKS', 'Python', 'FEA', 'CFD', 'Fusion 360', 'GD&T', 'CATIA', 'OpenFOAM', 'ROS', 'Six Sigma', 'Agile', 'MATLAB', 'Machine Learning'].map(skill => (
                  <span key={skill} className="rounded-full border border-border bg-muted/40 px-3 py-1 font-mono text-[10px] text-muted-foreground">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
