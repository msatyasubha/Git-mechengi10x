import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, ArrowRight, Zap, Star, ExternalLink, ChevronRight, Briefcase, Shield, Award, Users, BookOpen, TrendingUp, ChevronDown } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import ToolCard from '@/components/ToolCard';
import SpinWheel from '@/components/SpinWheel';
import { categories, navCategories, featuredTools, freeTools, tools } from '@/data/tools';
import { featuredGuides } from '@/data/guides';
import pb from '@/lib/pocketbaseClient';
import { trackNewsletterSignup } from '@/lib/analytics';

const ticker = [
  'ChatGPT · ANSYS · Fusion 360 · SimScale · Jira · Coursera · FreeCAD · Zapier · Onshape · GitHub Copilot · Claude · Notion · Brilliant · MIT OCW',
  'ChatGPT · ANSYS · Fusion 360 · SimScale · Jira · Coursera · FreeCAD · Zapier · Onshape · GitHub Copilot · Claude · Notion · Brilliant · MIT OCW',
];

const stats = [
  { value: '50+', label: 'Tools Reviewed', icon: Shield },
  { value: '6', label: 'Tool Categories', icon: BookOpen },
  { value: '100%', label: 'Independent', icon: Award },
  { value: '10K+', label: 'Engineers Helped', icon: Users },
];

const trustSignals = [
  {
    icon: Shield,
    title: 'Vendor-Independent Reviews',
    desc: 'We accept no vendor sponsorship. Every review is based on hands-on testing and real engineer feedback — no pay-to-rank.',
  },
  {
    icon: Award,
    title: 'Expert-Verified Ratings',
    desc: 'Our MechEngi Score combines expert evaluation across 8 criteria: capability, usability, value, integration, support, documentation, community, and scalability.',
  },
  {
    icon: TrendingUp,
    title: 'Continuously Updated',
    desc: 'Tool ratings, pricing, and reviews are refreshed every quarter to reflect software updates, pricing changes, and new community feedback.',
  },
  {
    icon: Users,
    title: 'Built by Engineers',
    desc: 'Every guide and comparison is authored by working mechanical and software engineers — not content writers who\'ve never run an FEA simulation.',
  },
];

export default function HomePage() {
  const [query, setQuery] = useState('');
  const [email, setEmail] = useState('');
  const [newsletterState, setNewsletterState] = useState('idle');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) navigate(`/tools?q=${encodeURIComponent(query.trim())}`);
    else navigate('/tools');
  };

  const handleNewsletter = async (e) => {
    e.preventDefault();
    if (!email) return;
    setNewsletterState('loading');
    try {
      await pb.collection('newsletter_subscribers').create({ email, source: 'homepage' });
      trackNewsletterSignup('homepage');
      setNewsletterState('success');
    } catch (err) {
      if (err?.response?.data?.email) {
        setNewsletterState('already');
      } else {
        setNewsletterState('error');
      }
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>MechEngi 10X — AI & Engineering Tool Discovery Platform for Engineers</title>
        <meta
          name="description"
          content="Discover, compare, and choose the best software tools for mechanical engineering. Expert reviews, ratings, and comparisons for 50+ AI, CAD, simulation, and automation tools."
        />
      </Helmet>

      <SiteHeader />

      {/* ── Hero ─────────────────────────────────────── */}
      <section className="relative min-h-[100dvh] overflow-hidden">
        <div className="dot-grid absolute inset-0 opacity-50" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/0 via-background/60 to-background" />
        <div className="pointer-events-none absolute left-1/4 top-1/3 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/10 blur-3xl" />
        <div className="pointer-events-none absolute right-1/4 top-1/2 h-64 w-64 rounded-full bg-accent/8 blur-3xl" />

        <div className="relative mx-auto flex min-h-[100dvh] max-w-[72rem] flex-col items-center justify-center px-5 py-24 text-center">
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-5 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs text-primary"
          >
            <Zap className="h-3.5 w-3.5" />
            The #1 AI &amp; Engineering Tool Discovery Platform
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.08 }}
            className="font-display text-5xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl"
          >
            Discover. Compare. Learn.
            <br />
            <span className="text-primary">10X Your Engineering.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.16 }}
            className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground"
          >
            Independent expert reviews of 50+ AI, CAD, simulation, and automation tools.
            Find the right tool for your engineering workflow in minutes — not months.
          </motion.p>

          {/* Primary CTA */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.20 }}
            className="mt-8 flex flex-wrap justify-center gap-3"
          >
            <Link
              to="/tools"
              className="glow-primary inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-4 font-display text-base font-bold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
            >
              Find the Right Tool <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/compare"
              className="inline-flex items-center gap-2 rounded-xl border border-border px-8 py-4 font-display text-base font-semibold transition-colors hover:border-primary/40 hover:text-primary"
            >
              Compare Tools
            </Link>
          </motion.div>

          {/* Search */}
          <motion.form
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.26 }}
            onSubmit={handleSearch}
            className="mt-6 flex w-full max-w-xl gap-2"
          >
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder='Search tools, e.g. "best AI for CAD"'
                className="h-12 w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <button
              type="submit"
              className="h-12 rounded-xl border border-primary/40 px-5 font-mono text-sm text-primary transition-colors hover:bg-primary/10"
            >
              Search
            </button>
          </motion.form>

          {/* Category pills */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.33 }}
            className="mt-5 flex flex-wrap justify-center gap-2"
          >
            {navCategories.map((c) => (
              <Link
                key={c.id}
                to={`/tools?cat=${c.id}`}
                className="flex items-center gap-1.5 rounded-full border border-border bg-card/60 px-4 py-1.5 font-mono text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
              >
                <span>{c.icon}</span>
                {c.label}
              </Link>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Wizard CTA Banner ────────────────────────── */}
      <div className="border-b border-primary/20 bg-primary/5 py-4">
        <div className="mx-auto flex max-w-[72rem] flex-wrap items-center justify-between gap-4 px-5">
          <div className="flex items-center gap-3">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
              <Zap className="h-4 w-4 text-primary" />
            </span>
            <div>
              <p className="font-display text-sm font-bold">Not sure which tool is right for you?</p>
              <p className="text-xs text-muted-foreground">Answer 3 questions → get 5 personalized recommendations</p>
            </div>
          </div>
          <Link
            to="/wizard"
            className="inline-flex items-center gap-2 rounded-xl border border-primary/30 bg-primary/10 px-5 py-2 font-mono text-xs font-semibold text-primary transition-colors hover:bg-primary/20"
          >
            Take the Wizard <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>

      {/* ── Ticker ───────────────────────────────────── */}
      <div className="overflow-hidden border-y border-border bg-card/50 py-3">
        <div className="marquee-track flex w-max gap-8">
          {ticker.map((t, i) => (
            <span key={i} className="whitespace-nowrap font-mono text-xs uppercase tracking-widest text-muted-foreground/60">
              {t}
            </span>
          ))}
        </div>
      </div>

      {/* ── Stats ─────────────────────────────────────── */}
      <div className="border-b border-border bg-card/30">
        <div className="mx-auto grid max-w-[72rem] grid-cols-2 divide-x divide-border px-5 md:grid-cols-4">
          {stats.map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.label} className="py-6 text-center">
                <div className="flex justify-center">
                  <Icon className="mb-2 h-4 w-4 text-primary/60" />
                </div>
                <p className="font-display text-3xl font-extrabold text-primary">{s.value}</p>
                <p className="mt-1 text-sm text-muted-foreground">{s.label}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Category Showcase ──────────────────────────── */}
      <section className="mx-auto max-w-[90rem] px-5 py-16">
        <div className="text-center">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">Browse by Category</p>
          <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">
            Every Tool Category Covered
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-muted-foreground">
            From AI assistants to professional simulation platforms — independent reviews across every category engineers care about.
          </p>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {navCategories.map((cat) => (
            <Link
              key={cat.id}
              to={`/tools?cat=${cat.id}`}
              className="group flex items-start gap-4 rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:bg-primary/5 hover:shadow-lg hover:shadow-primary/5"
            >
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-border bg-muted text-2xl transition-colors group-hover:border-primary/30 group-hover:bg-primary/10">
                {cat.icon}
              </div>
              <div className="min-w-0">
                <p className="font-display text-base font-semibold group-hover:text-primary">{cat.label}</p>
                <p className="mt-1 text-sm leading-snug text-muted-foreground">{cat.description}</p>
              </div>
              <ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground opacity-0 transition-all group-hover:translate-x-1 group-hover:text-primary group-hover:opacity-100" />
            </Link>
          ))}
        </div>
      </section>

      {/* ── Engineering Use Cases ─────────────────────── */}
      <section className="border-t border-border py-14">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="mb-8 text-center">
            <p className="font-mono text-xs uppercase tracking-widest text-primary">Discover by Workflow</p>
            <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">What Are You Trying to Do?</h2>
            <p className="mx-auto mt-3 max-w-lg text-muted-foreground">
              Browse tools by engineering use case. Find the right software for your specific workflow — not just your job title.
            </p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: '🤖', label: 'AI for Engineering', desc: 'ChatGPT, Claude, Copilot', to: '/tools?cat=ai', badge: 'ai' },
              { icon: '🔄', label: 'Automate Reports', desc: 'Zapier, Make, n8n', to: '/tools?cat=automation', badge: 'automation' },
              { icon: '📐', label: 'CAD Productivity', desc: 'SOLIDWORKS, Fusion 360, Onshape', to: '/tools?cat=cad', badge: 'cad' },
              { icon: '🔬', label: 'FEA & Simulation', desc: 'ANSYS, COMSOL, SimScale', to: '/tools?cat=simulation', badge: 'simulation' },
              { icon: '📋', label: 'Project Management', desc: 'Notion, Jira, Asana', to: '/tools?cat=management', badge: 'management' },
              { icon: '🎓', label: 'Learning & Upskilling', desc: 'Coursera, Udemy, Brilliant', to: '/tools?cat=learning', badge: 'learning' },
              { icon: '📊', label: 'Data Analysis', desc: 'Python, AI tools, automation', to: '/tools?cat=ai', badge: 'ai' },
              { icon: '⚡', label: 'Workflow Automation', desc: 'No-code & low-code tools', to: '/tools?cat=automation', badge: 'automation' },
            ].map((uc) => (
              <Link
                key={uc.label}
                to={uc.to}
                className="group flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:bg-primary/5 hover:shadow-md hover:shadow-primary/5"
              >
                <span className="text-2xl">{uc.icon}</span>
                <div className="min-w-0 flex-1">
                  <p className="font-display text-sm font-semibold group-hover:text-primary leading-snug">{uc.label}</p>
                  <p className="mt-0.5 truncate text-xs text-muted-foreground">{uc.desc}</p>
                </div>
                <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground opacity-0 transition-all group-hover:translate-x-1 group-hover:text-primary group-hover:opacity-100" />
              </Link>
            ))}
          </div>
          <div className="mt-6 text-center">
            <Link
              to="/wizard"
              className="glow-primary inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-display font-bold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
            >
              Not sure? Take the 3-step wizard <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ── AI Tool Profiles CTA ─────────────────────── */}
      <section className="border-t border-border bg-primary/5 py-12">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-center">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="rounded-full border border-primary/30 bg-primary/10 px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-primary">Phase 1 — New</span>
              </div>
              <h2 className="font-display text-2xl font-bold sm:text-3xl">10 Deep-Dive AI Tool Profiles Published</h2>
              <p className="mt-2 max-w-lg text-muted-foreground">
                ChatGPT, Claude, Gemini, Copilot, Perplexity, Midjourney, DALL-E, Jasper, Copy.ai, and Synthesia — each with 2,000+ word engineering-focused reviews, real-world examples, FAQ, and structured data.
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {['ChatGPT', 'Claude', 'Gemini', 'Copilot', 'Perplexity', 'Midjourney', 'DALL-E', 'Jasper', 'Synthesia'].map(t => (
                  <span key={t} className="rounded-full border border-border bg-card px-3 py-1 font-mono text-[10px] text-muted-foreground">{t}</span>
                ))}
              </div>
            </div>
            <Link
              to="/ai-tools"
              className="glow-primary shrink-0 inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-display font-bold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
            >
              View All AI Tool Profiles <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ── Trending Tools ────────────────────────────── */}
      <section className="border-t border-border bg-card/10 py-14">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="flex items-end justify-between mb-8">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-accent">Most Reviewed</p>
              <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Trending Engineering Tools</h2>
            </div>
            <Link to="/tools" className="hidden font-mono text-xs text-muted-foreground hover:text-primary md:block">
              All tools →
            </Link>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[...tools].sort((a, b) => b.reviewCount - a.reviewCount).slice(0, 4).map((tool, i) => (
              <div key={tool.slug} className="relative flex flex-col rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
                <div className="absolute right-3 top-3 flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 font-display text-xs font-bold text-primary">
                  #{i + 1}
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{tool.logoEmoji}</span>
                  <div>
                    <p className="font-display font-semibold">{tool.name}</p>
                    <p className="text-xs text-muted-foreground">{tool.vendor}</p>
                  </div>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${tool.mechengiScore}%` }} />
                  </div>
                  <span className="font-mono text-xs font-semibold text-primary">{tool.mechengiScore}</span>
                </div>
                <p className="mt-2 text-xs text-muted-foreground">{tool.reviewCount.toLocaleString()} engineer reviews</p>
                <div className="mt-3 flex gap-2">
                  <Link
                    to={`/tools/${tool.slug}`}
                    className="flex-1 rounded-lg border border-border py-1.5 text-center font-mono text-xs text-muted-foreground hover:border-primary/40 hover:text-primary"
                  >
                    Review
                  </Link>
                  <a
                    href={tool.affiliateUrl}
                    target="_blank"
                    rel="noopener noreferrer sponsored"
                    className="flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 font-mono text-xs text-primary-foreground hover:opacity-90"
                  >
                    Try <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Featured Tools ───────────────────────────── */}
      <section className="border-t border-border bg-card/20 py-16">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="flex items-end justify-between">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-primary">Expert-Reviewed</p>
              <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Top-Rated Engineering Tools</h2>
            </div>
            <Link to="/tools" className="hidden items-center gap-1 font-mono text-xs text-muted-foreground hover:text-primary md:flex">
              View all tools <ChevronRight className="h-3.5 w-3.5" />
            </Link>
          </div>

          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {featuredTools.map((tool) => (
              <ToolCard key={tool.slug} tool={tool} />
            ))}
          </div>

          <div className="mt-6 text-center md:hidden">
            <Link to="/tools" className="font-mono text-sm text-primary hover:underline">
              Browse all tools →
            </Link>
          </div>
        </div>
      </section>

      {/* ── Trust / Credibility ─────────────────────── */}
      <section className="border-y border-border py-16">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="mb-10 text-center">
            <p className="font-mono text-xs uppercase tracking-widest text-primary">Why Engineers Trust Us</p>
            <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Engineering Credibility, First</h2>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {trustSignals.map((ts) => {
              const Icon = ts.icon;
              return (
                <div key={ts.title} className="flex flex-col gap-3 rounded-xl border border-border bg-card p-5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-display text-base font-bold">{ts.title}</h3>
                  <p className="text-sm leading-relaxed text-muted-foreground">{ts.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── Free Tools ──────────────────────────────── */}
      <section className="py-16">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="flex items-end justify-between">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-green-400">No credit card required</p>
              <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Best Free Engineering Tools</h2>
            </div>
            <Link to="/tools?free=1" className="hidden font-mono text-xs text-muted-foreground hover:text-primary md:block">
              See all free tools →
            </Link>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {freeTools.slice(0, 4).map((tool) => (
              <div key={tool.slug} className="flex flex-col rounded-xl border border-border bg-card p-4 transition-all hover:border-green-500/30">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{tool.logoEmoji}</span>
                  <div>
                    <p className="font-display font-semibold">{tool.name}</p>
                    <p className="font-mono text-xs text-green-400">Free forever</p>
                  </div>
                </div>
                <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-muted-foreground">{tool.tagline}</p>
                <div className="mt-3 flex gap-2">
                  <Link
                    to={`/tools/${tool.slug}`}
                    className="flex-1 rounded-lg border border-border py-1.5 text-center font-mono text-xs text-muted-foreground hover:border-primary/40 hover:text-primary"
                  >
                    Review
                  </Link>
                  <a
                    href={tool.affiliateUrl}
                    target="_blank"
                    rel="noopener noreferrer sponsored"
                    className="flex items-center gap-1 rounded-lg bg-green-500/15 px-3 py-1.5 font-mono text-xs text-green-400 hover:bg-green-500/25"
                  >
                    Try free <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── AI Engineering Advisor CTA ──────────────── */}
      <section className="border-y border-border bg-card/20 py-20">
        <div className="relative mx-auto max-w-[90rem] px-5">
          <div className="overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-background to-accent/5 p-8 md:p-12">
            <div className="pointer-events-none absolute inset-0">
              <div className="dot-grid h-full w-full opacity-20" />
            </div>
            <div className="relative grid gap-8 lg:grid-cols-[1fr_auto] lg:items-center">
              <div>
                <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs text-primary">
                  <Zap className="h-3.5 w-3.5" />
                  AI Engineering Advisor — Powered by GPT-4
                </div>
                <h2 className="font-display text-3xl font-bold sm:text-4xl">
                  Not sure which tool to choose?
                  <br />
                  <span className="text-primary">Ask our AI Engineering Advisor.</span>
                </h2>
                <p className="mt-4 max-w-lg text-muted-foreground">
                  Describe your engineering workflow, team size, and budget. Our AI Advisor gives personalized, bias-free tool recommendations with honest pros, cons, pricing, and side-by-side comparisons — in seconds.
                </p>
                <ul className="mt-5 space-y-2">
                  {[
                    'Personalized recommendations based on your discipline & workflow',
                    'Side-by-side pricing and feature comparisons on demand',
                    'Vendor-neutral — no sponsored recommendations',
                  ].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
                <div className="mt-8 flex flex-wrap gap-3">
                  <Link
                    to="/advisor"
                    className="glow-primary inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
                  >
                    Chat with AI Advisor <ArrowRight className="h-4 w-4" />
                  </Link>
                  <Link
                    to="/compare"
                    className="inline-flex items-center gap-2 rounded-xl border border-border px-8 py-3 font-semibold transition-colors hover:border-primary/40 hover:text-primary"
                  >
                    Browse Comparisons
                  </Link>
                </div>
              </div>
              <div className="hidden lg:block">
                <div className="w-72 rounded-2xl border border-border bg-card/80 p-5">
                  <div className="flex items-center gap-2 border-b border-border pb-3">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full border border-primary/30 bg-primary/10">
                      <Zap className="h-3.5 w-3.5 text-primary" />
                    </div>
                    <span className="font-display text-sm font-semibold">AI Engineering Advisor</span>
                  </div>
                  <div className="mt-4 space-y-3">
                    <div className="rounded-xl bg-muted/50 px-3 py-2.5 text-sm text-muted-foreground">
                      "I need FEA simulation for aerospace components under $5k/yr"
                    </div>
                    <div className="rounded-xl border border-primary/20 bg-primary/5 px-3 py-2.5 text-sm">
                      Based on your requirements, I recommend <span className="font-semibold text-primary">SimScale Professional</span> or <span className="font-semibold text-primary">ANSYS Student</span>. Here's a comparison...
                    </div>
                    <div className="flex items-center gap-2 rounded-lg bg-muted/30 px-3 py-2">
                      <span className="h-2 w-2 animate-pulse rounded-full bg-green-400" />
                      <span className="font-mono text-xs text-muted-foreground">Online · Free to use</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Spin Wheel ──────────────────────────────── */}
      <section className="py-16">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="grid gap-10 lg:grid-cols-[1fr_380px] lg:items-center">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-primary">Category Discovery</p>
              <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">
                Not sure where to start?
                <br />
                <span className="text-primary">Spin the Wheel.</span>
              </h2>
              <p className="mt-4 max-w-md text-muted-foreground">
                Let fate decide your next engineering tool discovery. Spin to land on a category and instantly explore the best tools, guides, and resources for that area.
              </p>
              <div className="mt-6 flex flex-wrap gap-2">
                {navCategories.map(cat => (
                  <span key={cat.id} className="rounded-full border border-border bg-card px-3 py-1 font-mono text-xs text-muted-foreground">
                    {cat.icon} {cat.label}
                  </span>
                ))}
                <span className="rounded-full border border-border bg-card px-3 py-1 font-mono text-xs text-muted-foreground">
                  💼 Jobs
                </span>
              </div>
            </div>
            <div className="flex justify-center">
              <SpinWheel />
            </div>
          </div>
        </div>
      </section>

      {/* ── Jobs Teaser ─────────────────────────────── */}
      <section className="border-t border-border bg-card/20 py-16">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="flex items-end justify-between">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-accent">Career Opportunities</p>
              <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Engineering Jobs</h2>
            </div>
            <Link to="/jobs" className="hidden font-mono text-xs text-muted-foreground hover:text-primary md:block">
              All job listings →
            </Link>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { title: 'Senior Mechanical Design Engineer', company: 'SpaceX', location: 'Hawthorne, CA', category: 'cad', salary: '$120k–$160k', tags: ['SOLIDWORKS', 'Aerospace'] },
              { title: 'FEA / Simulation Engineer', company: 'Tesla', location: 'Fremont, CA', category: 'simulation', salary: '$110k–$150k', tags: ['ANSYS', 'Python'] },
              { title: 'Robotics Automation Engineer', company: 'Boston Dynamics', location: 'Waltham, MA', category: 'automation', salary: '$115k–$155k', tags: ['ROS', 'Control Systems'] },
            ].map(job => (
              <Link key={job.title} to="/jobs" className="group flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${job.category}`}>
                      {job.category === 'cad' ? 'CAD' : job.category.charAt(0).toUpperCase() + job.category.slice(1)}
                    </span>
                    <h3 className="mt-2 font-display text-base font-semibold leading-snug group-hover:text-primary">{job.title}</h3>
                  </div>
                  <Briefcase className="mt-1 h-4 w-4 shrink-0 text-muted-foreground" />
                </div>
                <p className="mt-1 font-mono text-xs text-muted-foreground">{job.company} · {job.location}</p>
                <p className="mt-2 font-mono text-xs text-green-400">{job.salary}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {job.tags.map(t => (
                    <span key={t} className="rounded-full border border-border bg-muted/40 px-2.5 py-0.5 font-mono text-[10px] text-muted-foreground">{t}</span>
                  ))}
                </div>
              </Link>
            ))}
          </div>
          <div className="mt-5 text-center md:hidden">
            <Link to="/jobs" className="font-mono text-sm text-primary hover:underline">Browse all jobs →</Link>
          </div>
        </div>
      </section>

      {/* ── Guides ──────────────────────────────────── */}
      <section className="border-t border-border py-16">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="flex items-end justify-between">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-primary">Expert Deep Dives</p>
              <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Engineering Tool Guides</h2>
            </div>
            <Link to="/guides" className="hidden font-mono text-xs text-muted-foreground hover:text-primary md:block">
              All guides →
            </Link>
          </div>
          <div className="mt-8 grid gap-5 md:grid-cols-3">
            {featuredGuides.slice(0, 3).map((g) => (
              <Link key={g.slug} to={`/guides?open=${g.slug}`} className="group flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30">
                <span className={`self-start rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${g.category}`}>
                  {g.category}
                </span>
                <h3 className="mt-3 font-display text-base font-semibold leading-snug group-hover:text-primary">
                  {g.title}
                </h3>
                <p className="mt-2 line-clamp-2 flex-1 text-sm text-muted-foreground">{g.excerpt}</p>
                <div className="mt-4 flex items-center gap-3 font-mono text-xs text-muted-foreground">
                  <span>{g.readTime} min read</span>
                  <span>·</span>
                  <span>{g.date}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── Free Tools Teaser ──────────────────────── */}
      <section className="border-t border-border py-14">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-green-400">No sign-up required</p>
              <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Free Engineering Calculators</h2>
              <p className="mt-3 max-w-lg text-muted-foreground">
                Online engineering utilities built for practising engineers. Unit converters, beam calculators, material selectors, and more — no ads, no registration, no paywall.
              </p>
              <div className="mt-5 flex flex-wrap gap-2">
                {['Unit Converter (Live)', 'Beam Calculator (Soon)', 'Reynolds Number (Soon)', 'Bolt Torque (Soon)', 'Material Selector (Soon)'].map(t => (
                  <span key={t} className={`rounded-full border px-3 py-1 font-mono text-[10px] ${t.includes('Live') ? 'border-green-500/30 bg-green-500/10 text-green-400' : 'border-border text-muted-foreground'}`}>
                    {t}
                  </span>
                ))}
              </div>
              <Link
                to="/free-tools"
                className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90"
              >
                Open Free Tools <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="hidden rounded-2xl border border-border bg-card p-6 lg:block lg:w-80">
              <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-3">Unit Converter Preview</p>
              <div className="space-y-2">
                {[['100 mm', '3.937 in'], ['1 MPa', '145.0 psi'], ['50 kPa', '7.252 psi'], ['200 Nm', '147.5 lb·ft']].map(([from, to]) => (
                  <div key={from} className="flex items-center justify-between rounded-lg bg-muted/50 px-3 py-2">
                    <span className="font-mono text-sm text-muted-foreground">{from}</span>
                    <span className="font-mono text-xs text-muted-foreground">→</span>
                    <span className="font-mono text-sm text-primary font-semibold">{to}</span>
                  </div>
                ))}
              </div>
              <Link to="/free-tools" className="mt-4 flex items-center justify-center gap-2 rounded-lg border border-border py-2 text-sm font-medium text-muted-foreground hover:border-primary/40 hover:text-primary">
                Open Calculator <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── Newsletter ──────────────────────────────── */}
      <section className="border-t border-border bg-card/20 py-16">
        <div className="mx-auto max-w-[40rem] px-5 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs text-primary">
            <Zap className="h-3.5 w-3.5" />
            Weekly Engineering Intelligence
          </div>
          <h2 className="font-display text-2xl font-bold sm:text-3xl">
            Get one practical AI or digital engineering idea every week.
          </h2>
          <p className="mt-3 text-muted-foreground">
            One tool review, comparison insight, or workflow tip — delivered every Thursday. Independent, vendor-neutral, and worth your time. Trusted by 10,000+ engineers.
          </p>
          {newsletterState === 'success' ? (
            <div className="mt-6 rounded-xl border border-green-500/30 bg-green-500/10 p-4 text-green-400">
              You're in! Check your inbox for a confirmation.
            </div>
          ) : (
            <form onSubmit={handleNewsletter} className="mt-6 flex gap-2">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="h-12 flex-1 rounded-xl border border-border bg-card px-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
              <button
                type="submit"
                disabled={newsletterState === 'loading'}
                className="h-12 rounded-xl bg-primary px-6 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-50"
              >
                {newsletterState === 'loading' ? 'Joining…' : 'Subscribe'}
              </button>
            </form>
          )}
          {newsletterState === 'already' && (
            <p className="mt-2 text-sm text-muted-foreground">You're already subscribed!</p>
          )}
          {newsletterState === 'error' && (
            <p className="mt-2 text-sm text-destructive">Something went wrong. Please try again.</p>
          )}
          <p className="mt-3 text-xs text-muted-foreground">No spam. Unsubscribe anytime.</p>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
