import { useState } from 'react';
import Helmet from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import SiteHeader from '@/components/SiteHeader';
import useAuth from '@/hooks/use-auth';

const AuthPage = ({ mode }) => {
    const isSignup = mode === 'signup';
    const { login, signup } = useAuth();
    const navigate = useNavigate();
    const [form, setForm] = useState({ name: '', email: '', password: '' });
    const [error, setError] = useState('');
    const [busy, setBusy] = useState(false);
    const [done, setDone] = useState(false);

    const onSubmit = async (e) => {
        e.preventDefault();
        setBusy(true);
        setError('');
        try {
            if (isSignup) {
                await signup(form.email, form.password, form.name);
                setDone(true);
            } else {
                await login(form.email, form.password);
                navigate('/tutor');
            }
        } catch (err) {
            setError(err?.message || 'Something went wrong.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <div className="min-h-screen bg-background">
            <Helmet>
                <title>{isSignup ? 'Create your TorqueLab account' : 'Sign in to TorqueLab'}</title>
                <meta name="description" content={isSignup ? 'Create a free TorqueLab account to use the AI mechanical engineering tutor and keep your worked problems.' : 'Sign in to TorqueLab to continue learning mechanical engineering with the AI tutor.'} />
            </Helmet>
            <SiteHeader />
            <div className="blueprint-grid min-h-[calc(100dvh-4rem)] px-5 py-20">
                <div className="mx-auto max-w-md border border-border bg-card p-8">
                    <h1 className="font-display text-2xl font-bold tracking-tight">
                        {isSignup ? 'Create your account' : 'Welcome back'}
                    </h1>
                    {done ? (
                        <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
                            Account created. Check your inbox and click the verification link, then open the
                            tutor — no need to sign in again.
                        </p>
                    ) : (
                        <form onSubmit={onSubmit} className="mt-7 space-y-5">
                            {isSignup && (
                                <div className="flex flex-col gap-2">
                                    <label htmlFor="name" className="font-tech text-xs uppercase tracking-widest text-muted-foreground">Name</label>
                                    <input
                                        id="name"
                                        value={form.name}
                                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                                        className="min-h-[44px] rounded-sm border border-input bg-background px-3 text-sm outline-none focus:border-accent"
                                    />
                                </div>
                            )}
                            <div className="flex flex-col gap-2">
                                <label htmlFor="email" className="font-tech text-xs uppercase tracking-widest text-muted-foreground">Email</label>
                                <input
                                    id="email"
                                    type="email"
                                    required
                                    value={form.email}
                                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                                    className="min-h-[44px] rounded-sm border border-input bg-background px-3 text-sm outline-none focus:border-accent"
                                />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label htmlFor="password" className="font-tech text-xs uppercase tracking-widest text-muted-foreground">Password</label>
                                <input
                                    id="password"
                                    type="password"
                                    required
                                    minLength={8}
                                    value={form.password}
                                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                                    className="min-h-[44px] rounded-sm border border-input bg-background px-3 text-sm outline-none focus:border-accent"
                                />
                            </div>
                            {error && <p className="text-sm text-destructive">{error}</p>}
                            <button
                                type="submit"
                                disabled={busy}
                                className="min-h-[48px] w-full rounded-sm bg-primary font-tech text-xs uppercase tracking-widest text-primary-foreground disabled:opacity-60 active:scale-[0.98]"
                            >
                                {busy ? 'Working…' : isSignup ? 'Create account' : 'Sign in'}
                            </button>
                        </form>
                    )}
                    <p className="mt-6 text-sm text-muted-foreground">
                        {isSignup ? 'Already have an account? ' : 'New here? '}
                        <Link to={isSignup ? '/login' : '/signup'} className="text-accent hover:underline">
                            {isSignup ? 'Sign in' : 'Create one'}
                        </Link>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default AuthPage;
