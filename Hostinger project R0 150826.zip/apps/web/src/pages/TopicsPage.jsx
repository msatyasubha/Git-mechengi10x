import Helmet from 'react-helmet';
import { Link } from 'react-router-dom';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { topics } from '@/data/curriculum';

const TopicsPage = () => (
    <div className="min-h-screen bg-background">
        <Helmet>
            <title>Mechanical Engineering Topics & Syllabus — TorqueLab</title>
            <meta name="description" content="Six mechanical engineering subject tracks: statics, strength of materials, thermodynamics, fluid mechanics, heat transfer and machine design, each with an AI tutor entry point." />
        </Helmet>
        <SiteHeader />
        <section className="border-b border-border">
            <div className="blueprint-grid">
                <div className="mx-auto max-w-[72rem] px-5 py-20">
                    <p className="font-tech text-xs uppercase tracking-[0.35em] text-accent">Syllabus</p>
                    <h1 className="mt-5 max-w-2xl font-display text-4xl font-bold tracking-tight sm:text-5xl">
                        Six tracks, sixty lessons, one continuous thread of physics.
                    </h1>
                </div>
            </div>
        </section>
        <section className="mx-auto max-w-[72rem] px-5 py-16">
            <div className="grid gap-6 md:grid-cols-2">
                {topics.map((t) => (
                    <article key={t.id} className="flex flex-col border border-border bg-card/60 p-6">
                        <div className="flex items-center justify-between">
                            <span className="font-tech text-xs uppercase tracking-widest text-primary">{t.level}</span>
                            <span className="font-tech text-xs text-muted-foreground">{t.lessons} lessons</span>
                        </div>
                        <h2 className="mt-4 font-display text-xl font-semibold">{t.title}</h2>
                        <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">{t.blurb}</p>
                        <p className="mt-4 font-tech text-xs text-accent">{t.key}</p>
                        <Link
                            to={`/tutor?q=${encodeURIComponent(t.ask)}`}
                            className="mt-5 inline-flex min-h-[44px] items-center font-tech text-xs uppercase tracking-widest text-foreground hover:text-primary"
                        >
                            Start with the tutor →
                        </Link>
                    </article>
                ))}
            </div>
        </section>
        <SiteFooter />
    </div>
);

export default TopicsPage;
