import { Helmet } from 'react-helmet';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ExternalLink, CheckCircle, XCircle, ArrowLeft, Star, MessageSquare, Send, Loader2 } from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import ToolCard from '@/components/ToolCard';
import { StarRating } from '@/components/ToolCard';
import { getToolBySlug, getRelatedTools } from '@/data/tools';
import pb from '@/lib/pocketbaseClient';
import { trackToolView, trackAffiliateClick } from '@/lib/analytics';

const categoryLabel = {
  ai: 'AI Tools',
  cad: 'CAD & Design',
  simulation: 'Simulation',
  automation: 'Automation',
  management: 'Engineering Management',
  learning: 'Learning',
};

function ReviewStarPicker({ value, onChange }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <button
          key={s}
          type="button"
          onMouseEnter={() => setHover(s)}
          onMouseLeave={() => setHover(0)}
          onClick={() => onChange(s)}
          className="text-2xl transition-transform hover:scale-110 active:scale-95"
          aria-label={`Rate ${s} stars`}
        >
          <Star
            className={`h-7 w-7 ${s <= (hover || value) ? 'fill-current text-amber-400' : 'text-border'}`}
            strokeWidth={s <= (hover || value) ? 0 : 1.5}
          />
        </button>
      ))}
    </div>
  );
}

function ReviewCard({ review }) {
  const date = new Date(review.created).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary">
            {(review.expand?.owner?.name || review.expand?.owner?.email || 'U').charAt(0).toUpperCase()}
          </div>
          <div>
            <p className="text-sm font-medium">{review.expand?.owner?.name || 'Anonymous Engineer'}</p>
            <p className="text-xs text-muted-foreground">{date}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5].map((s) => (
            <Star
              key={s}
              className={`h-3.5 w-3.5 ${s <= review.rating ? 'fill-current text-amber-400' : 'text-border'}`}
              strokeWidth={0}
            />
          ))}
        </div>
      </div>
      {review.title && <p className="mt-3 font-semibold">{review.title}</p>}
      {review.body && <p className="mt-2 text-sm leading-relaxed text-foreground/80">{review.body}</p>}
    </div>
  );
}

function ReviewsSection({ toolSlug }) {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [avgRating, setAvgRating] = useState(0);
  const [userReview, setUserReview] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ rating: 0, title: '', body: '' });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const user = pb.authStore.record;

  const loadReviews = useCallback(async () => {
    try {
      const list = await pb.collection('tool_reviews').getFullList({
        filter: pb.filter('tool_slug = {:s}', { s: toolSlug }),
        sort: '-created',
        expand: 'owner',
        requestKey: `reviews-${toolSlug}`,
      });
      setReviews(list);
      if (list.length > 0) {
        setAvgRating(list.reduce((sum, r) => sum + r.rating, 0) / list.length);
      }
      if (user) {
        const mine = list.find((r) => r.owner === user.id);
        setUserReview(mine || null);
      }
    } catch (e) {
      // ignore fetch errors
    } finally {
      setLoading(false);
    }
  }, [toolSlug, user]);

  useEffect(() => { loadReviews(); }, [loadReviews]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.rating === 0) { setError('Please select a star rating.'); return; }
    setSubmitting(true);
    setError('');
    try {
      await pb.collection('tool_reviews').create({
        tool_slug: toolSlug,
        rating: form.rating,
        title: form.title,
        body: form.body,
        owner: user.id,
      });
      setForm({ rating: 0, title: '', body: '' });
      setShowForm(false);
      await loadReviews();
    } catch (err) {
      if (err?.status === 400) {
        setError('You have already submitted a review for this tool.');
      } else {
        setError('Failed to submit review. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mt-14" id="reviews">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-5">
        <div className="flex items-center gap-4">
          <MessageSquare className="h-5 w-5 text-primary" />
          <h2 className="font-display text-2xl font-bold">Engineer Reviews</h2>
          {reviews.length > 0 && (
            <span className="rounded-full border border-border bg-muted px-3 py-0.5 font-mono text-xs text-muted-foreground">
              {reviews.length} review{reviews.length !== 1 ? 's' : ''}
            </span>
          )}
        </div>
        {reviews.length > 0 && (
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className={`h-4 w-4 ${s <= Math.round(avgRating) ? 'fill-current text-amber-400' : 'text-border'}`} strokeWidth={0} />
              ))}
            </div>
            <span className="font-display text-lg font-bold">{avgRating.toFixed(1)}</span>
            <span className="text-sm text-muted-foreground">avg from engineers</span>
          </div>
        )}
      </div>

      {/* Write a review CTA */}
      {!loading && (
        <div className="mt-5">
          {!user ? (
            <div className="rounded-xl border border-border bg-muted/30 px-5 py-4 text-sm text-muted-foreground">
              <Link to="/login" className="font-semibold text-primary hover:underline">Sign in</Link> to leave a review and help other engineers.
            </div>
          ) : userReview ? (
            <div className="rounded-xl border border-green-500/20 bg-green-500/5 px-5 py-3 font-mono text-xs text-green-400">
              You rated this tool {userReview.rating}/5. Thank you for your review!
            </div>
          ) : !showForm ? (
            <button
              onClick={() => setShowForm(true)}
              className="rounded-xl border border-primary/30 bg-primary/5 px-5 py-3 text-sm font-semibold text-primary transition-colors hover:bg-primary/10"
            >
              Write a Review
            </button>
          ) : null}

          {showForm && !userReview && (
            <form onSubmit={handleSubmit} className="mt-4 rounded-xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Your Review</h3>
              <div className="mt-4">
                <label className="mb-2 block text-xs font-medium text-muted-foreground uppercase tracking-wider">Rating *</label>
                <ReviewStarPicker value={form.rating} onChange={(r) => setForm((f) => ({ ...f, rating: r }))} />
              </div>
              <div className="mt-4">
                <label className="mb-2 block text-xs font-medium text-muted-foreground uppercase tracking-wider">Headline (optional)</label>
                <input
                  value={form.title}
                  onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                  maxLength={200}
                  placeholder="e.g. 'Great for CAD automation, weak documentation'"
                  className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
              <div className="mt-4">
                <label className="mb-2 block text-xs font-medium text-muted-foreground uppercase tracking-wider">Review (optional)</label>
                <textarea
                  value={form.body}
                  onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))}
                  maxLength={2000}
                  rows={4}
                  placeholder="Share your experience with this tool for engineering work..."
                  className="w-full resize-none rounded-lg border border-border bg-muted px-3 py-2.5 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
              {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
              <div className="mt-4 flex gap-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-50"
                >
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  {submitting ? 'Submitting...' : 'Submit Review'}
                </button>
                <button
                  type="button"
                  onClick={() => { setShowForm(false); setError(''); }}
                  className="rounded-lg border border-border px-5 py-2.5 text-sm font-medium transition-colors hover:border-foreground"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* Reviews list */}
      {loading ? (
        <div className="mt-6 space-y-3">
          {[1, 2].map((i) => (
            <div key={i} className="h-24 animate-pulse rounded-xl border border-border bg-card" />
          ))}
        </div>
      ) : reviews.length === 0 ? (
        <div className="mt-8 rounded-xl border border-border bg-muted/20 py-10 text-center">
          <p className="text-muted-foreground">No reviews yet. Be the first engineer to review this tool.</p>
        </div>
      ) : (
        <div className="mt-5 space-y-4">
          {reviews.map((r) => <ReviewCard key={r.id} review={r} />)}
        </div>
      )}
    </div>
  );
}

export default function ToolDetailPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const tool = getToolBySlug(slug);

  useEffect(() => {
    if (tool) trackToolView(tool.slug, tool.name, tool.category);
  }, [tool]);

  if (!tool) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
          <p className="font-display text-2xl font-bold">Tool not found</p>
          <button onClick={() => navigate('/tools')} className="text-primary hover:underline">
            Back to all tools
          </button>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const related = getRelatedTools(tool);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{tool.name} Review 2024 — Pros, Cons &amp; Pricing | MechEngi 10X</title>
        <meta
          name="description"
          content={`Honest review of ${tool.name} for engineers. Pros, cons, pricing, MechEngi Score ${tool.mechengiScore}/100, and alternatives. ${tool.tagline}`}
        />
      </Helmet>

      <SiteHeader />

      {/* Breadcrumb */}
      <div className="border-b border-border bg-card/30 py-4">
        <div className="mx-auto flex max-w-[72rem] flex-wrap items-center gap-1.5 px-5 font-mono text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Home</Link>
          <span>/</span>
          <Link to="/tools" className="hover:text-foreground">Tools</Link>
          <span>/</span>
          <Link to={`/tools?cat=${tool.category}`} className="hover:text-foreground">{categoryLabel[tool.category]}</Link>
          <span>/</span>
          <span className="text-foreground">{tool.name}</span>
        </div>
      </div>

      <div className="mx-auto max-w-[72rem] px-5 py-8 md:py-10">
        {/* Hero */}
        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          <div>
            <div className="flex flex-wrap items-start gap-4">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-border bg-card text-3xl shrink-0">
                {tool.logoEmoji}
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${tool.category}`}>
                    {categoryLabel[tool.category]}
                  </span>
                  {tool.badge && (
                    <span className="rounded-full bg-accent/15 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-accent">
                      {tool.badge}
                    </span>
                  )}
                  {tool.verified && (
                    <span className="rounded-full bg-primary/10 px-2.5 py-0.5 font-mono text-[10px] text-primary">
                      Verified Review
                    </span>
                  )}
                </div>
                <h1 className="mt-1 font-display text-2xl font-extrabold sm:text-3xl md:text-4xl">{tool.name}</h1>
                <p className="text-sm text-muted-foreground">by {tool.vendor}</p>
              </div>
            </div>

            {/* Ratings row */}
            <div className="mt-5 flex flex-wrap items-center gap-4 md:gap-6">
              <div>
                <p className="font-mono text-xs text-muted-foreground">User Rating</p>
                <div className="mt-1 flex items-center gap-2">
                  <StarRating rating={tool.rating} />
                  <span className="font-display text-lg font-bold">{tool.rating}</span>
                  <span className="font-mono text-xs text-muted-foreground">({tool.reviewCount.toLocaleString()})</span>
                </div>
              </div>
              <div className="h-8 w-px bg-border" />
              <div>
                <p className="font-mono text-xs text-muted-foreground">MechEngi Score</p>
                <div className="mt-1 flex items-center gap-2">
                  <div className="h-2 w-20 overflow-hidden rounded-full bg-muted md:w-24">
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${tool.mechengiScore}%` }}
                    />
                  </div>
                  <span className="font-display text-lg font-bold text-primary">{tool.mechengiScore}/100</span>
                </div>
              </div>
            </div>

            <p className="mt-5 text-base leading-relaxed text-muted-foreground md:text-lg">{tool.tagline}</p>
            <p className="mt-3 leading-relaxed text-foreground/80 text-sm md:text-base">{tool.description}</p>
          </div>

          {/* Sticky sidebar CTA */}
          <div className="lg:sticky lg:top-24 lg:h-fit">
            <div className="rounded-2xl border border-border bg-card p-5 md:p-6">
              <div className="flex items-center justify-between">
                <span className="font-display text-base font-bold md:text-lg">{tool.name}</span>
                <span className="font-display text-lg font-extrabold text-primary md:text-xl">{tool.mechengiScore}/100</span>
              </div>

              {/* Pricing */}
              <div className="mt-4 space-y-2">
                {tool.pricing.free && (
                  <div className="flex items-center justify-between rounded-lg bg-green-500/10 px-3 py-2">
                    <span className="font-mono text-xs text-green-400">Free tier</span>
                    <span className="text-xs text-muted-foreground">{tool.pricing.freeLabel}</span>
                  </div>
                )}
                {tool.pricing.paidFrom > 0 && (
                  <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2">
                    <span className="font-mono text-xs text-foreground">Paid from</span>
                    <span className="font-mono text-xs font-semibold">
                      ${tool.pricing.paidFrom}/{tool.pricing.paidFrom >= 100 ? 'yr' : 'mo'}
                    </span>
                  </div>
                )}
                <div className="pt-1 text-xs text-muted-foreground">{tool.pricing.paidLabel}</div>
              </div>

              <a
                href={tool.affiliateUrl}
                target="_blank"
                rel="noopener noreferrer sponsored"
                onClick={() => trackAffiliateClick(tool.slug, tool.name, 'sidebar')}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
              >
                Try {tool.name} <ExternalLink className="h-4 w-4" />
              </a>
              <p className="mt-2 text-center font-mono text-[10px] text-muted-foreground">
                Affiliate link — we earn a commission at no extra cost to you
              </p>

              <Link
                to="/advisor"
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-border py-2.5 text-sm font-medium transition-colors hover:border-primary/40 hover:text-primary"
              >
                Ask AI Advisor for alternatives
              </Link>
            </div>
          </div>
        </div>

        {/* Pros & Cons */}
        <div className="mt-10 grid gap-5 md:grid-cols-2 md:mt-12">
          <div className="rounded-2xl border border-green-500/20 bg-green-500/5 p-5 md:p-6">
            <h2 className="flex items-center gap-2 font-display text-lg font-bold text-green-400">
              <CheckCircle className="h-5 w-5" /> Pros
            </h2>
            <ul className="mt-4 space-y-3">
              {tool.pros.map((p, i) => (
                <li key={i} className="flex items-start gap-3 text-sm">
                  <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-green-500" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-5 md:p-6">
            <h2 className="flex items-center gap-2 font-display text-lg font-bold text-red-400">
              <XCircle className="h-5 w-5" /> Cons
            </h2>
            <ul className="mt-4 space-y-3">
              {tool.cons.map((c, i) => (
                <li key={i} className="flex items-start gap-3 text-sm">
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />
                  <span>{c}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Features & Use Cases */}
        <div className="mt-5 grid gap-5 md:grid-cols-2">
          <div className="rounded-2xl border border-border bg-card p-5 md:p-6">
            <h2 className="font-display text-lg font-bold">Key Features</h2>
            <ul className="mt-4 space-y-2">
              {tool.features.map((f, i) => (
                <li key={i} className="flex items-center gap-2 text-sm">
                  <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-2xl border border-border bg-card p-5 md:p-6">
            <h2 className="font-display text-lg font-bold">Best For</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {tool.useCases.map((u, i) => (
                <span key={i} className={`rounded-lg border px-3 py-1 text-sm badge-${tool.category}`}>
                  {u}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Affiliate CTA banner */}
        <div className="mt-8 flex flex-col items-start justify-between gap-4 rounded-2xl border border-primary/20 bg-primary/5 px-5 py-5 sm:flex-row sm:items-center md:px-6">
          <div>
            <p className="font-display text-lg font-bold">Ready to try {tool.name}?</p>
            <p className="text-sm text-muted-foreground">
              {tool.pricing.free ? 'Start free — no credit card required.' : `Starts at $${tool.pricing.paidFrom}${tool.pricing.paidFrom >= 100 ? '/yr' : '/mo'}.`}
            </p>
          </div>
          <a
            href={tool.affiliateUrl}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="flex shrink-0 items-center gap-2 rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90"
          >
            Get {tool.name} <ExternalLink className="h-4 w-4" />
          </a>
        </div>

        {/* Reviews section */}
        <ReviewsSection toolSlug={tool.slug} />

        {/* Related tools */}
        {related.length > 0 && (
          <div className="mt-14">
            <h2 className="font-display text-2xl font-bold">Related {categoryLabel[tool.category]} Tools</h2>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {related.map((t) => (
                <ToolCard key={t.slug} tool={t} />
              ))}
            </div>
          </div>
        )}

        <div className="mt-10">
          <Link to="/tools" className="flex items-center gap-2 font-mono text-sm text-muted-foreground hover:text-primary">
            <ArrowLeft className="h-4 w-4" /> Back to all tools
          </Link>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
