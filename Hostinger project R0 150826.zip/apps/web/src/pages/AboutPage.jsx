import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Shield, Award, Users, CheckCircle, BarChart2, Zap } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

const scoreCategories = [
  { name: 'Engineering Usefulness', weight: 25, desc: 'Does the tool genuinely improve engineering work? We evaluate fit for real engineering tasks, not marketing claims.', color: 'bg-blue-500' },
  { name: 'Features & Capability', weight: 20, desc: 'Depth and breadth of features vs. the category benchmark. Advanced features only count if they work reliably.', color: 'bg-purple-500' },
  { name: 'Value for Money', weight: 15, desc: 'Price-to-capability ratio at the tier most engineers would use. Free tiers and student discounts factored in.', color: 'bg-green-500' },
  { name: 'Ease of Use', weight: 15, desc: 'Learning curve, UI quality, and time-to-first-result for a practising engineer, not a software demo specialist.', color: 'bg-amber-500' },
  { name: 'Integration', weight: 10, desc: 'How well the tool connects with the rest of a typical engineering stack — CAD exports, PLM, CI/CD, databases.', color: 'bg-cyan-500' },
  { name: 'Reliability & Support', weight: 10, desc: 'Uptime, performance on large models/datasets, vendor responsiveness, and quality of documentation.', color: 'bg-orange-500' },
  { name: 'Community & Ecosystem', weight: 5, desc: 'Third-party tutorials, add-ins, active forums, and library of templates. Good communities multiply a tool\'s value.', color: 'bg-pink-500' },
];

const principles = [
  { icon: Shield, title: 'Vendor Independence', desc: 'We do not accept sponsorship, paid placements, or "partner" arrangements that influence our scoring. Every tool is evaluated on its own merits.' },
  { icon: Award, title: 'Hands-On Testing', desc: 'Tools are evaluated by practising engineers, not content writers. We run real simulations, model real parts, and automate real workflows before scoring.' },
  { icon: CheckCircle, title: 'Transparent Criteria', desc: 'Our scoring criteria, weights, and methodology are published here and updated when we change them. No hidden factors.' },
  { icon: Users, title: 'Community Verification', desc: 'Expert scores are cross-checked against community reviews and weighted user ratings. Large divergences are investigated and explained.' },
  { icon: BarChart2, title: 'Quarterly Updates', desc: 'Tool scores, pricing, and features are reviewed every quarter. Software changes fast — our reviews keep pace.' },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>About MechEngi 10X — Editorial Policy & Review Methodology</title>
        <meta name="description" content="Learn about MechEngi 10X's editorial policy, review methodology, MechEngi Score system, and our commitment to independent, vendor-neutral engineering tool reviews." />
      </Helmet>

      <SiteHeader />

      {/* Hero */}
      <div className="border-b border-border bg-card/30 py-12">
        <div className="mx-auto max-w-[72rem] px-5">
          <div className="flex items-center gap-2 mb-3">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Zap className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Who We Are</p>
          </div>
          <h1 className="font-display text-3xl font-bold sm:text-4xl">About MechEngi 10X</h1>
          <p className="mt-3 max-w-2xl text-lg text-muted-foreground leading-relaxed">
            MechEngi 10X is an independent engineering tool discovery and review platform built by engineers, for engineers. Our goal is to cut through vendor marketing noise and give you honest, criteria-driven evaluations of the software tools that shape modern engineering practice.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-[72rem] px-5 py-12 space-y-16">

        {/* Mission */}
        <section>
          <h2 className="font-display text-2xl font-bold mb-4">Our Mission</h2>
          <div className="prose-like max-w-3xl space-y-4 text-foreground/80 leading-relaxed">
            <p>
              Every year, engineering teams waste thousands of dollars on software tools that do not fit their workflow — because the information available at purchase time is dominated by vendor marketing, affiliate sites with no hands-on experience, and review platforms that prioritize breadth over depth.
            </p>
            <p>
              MechEngi 10X exists to fix that. We evaluate engineering tools the way engineers evaluate anything: with a defined methodology, measurable criteria, honest assessment of trade-offs, and transparent disclosure of how we reached our conclusions.
            </p>
            <p>
              We cover six categories — AI Tools, CAD & Design, Simulation, Automation, Engineering Management, and Learning — with plans to expand as the engineering software landscape evolves.
            </p>
          </div>
        </section>

        {/* Editorial Policy */}
        <section>
          <h2 className="font-display text-2xl font-bold mb-2">Editorial Policy</h2>
          <p className="mb-8 text-muted-foreground max-w-2xl">Our editorial process is designed to protect the independence of our reviews from commercial pressures.</p>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {principles.map((p) => {
              const Icon = p.icon;
              return (
                <div key={p.title} className="rounded-xl border border-border bg-card p-5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 mb-3">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-display font-bold mb-2">{p.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
                </div>
              );
            })}
          </div>
          <div className="mt-6 rounded-xl border border-amber-500/20 bg-amber-500/5 p-5">
            <p className="text-sm text-amber-400 font-semibold mb-1">Affiliate Disclosure</p>
            <p className="text-sm text-muted-foreground">
              MechEngi 10X uses affiliate links on "Try Tool" and "Get [Tool]" buttons. If you purchase a product through one of these links, we may earn a commission at no additional cost to you. Affiliate relationships never influence our scores, rankings, or editorial content. A tool can have an affiliate link and still receive a low score if it does not deserve a high one.
            </p>
          </div>
        </section>

        {/* Score Methodology */}
        <section>
          <h2 className="font-display text-2xl font-bold mb-2">MechEngi 10X Score Methodology</h2>
          <p className="mb-8 text-muted-foreground max-w-2xl">
            Every tool reviewed on MechEngi 10X receives a composite score from 0–100, calculated across seven criteria. Here are the criteria, their weights, and what we measure in each.
          </p>
          <div className="space-y-4">
            {scoreCategories.map((cat) => (
              <div key={cat.name} className="rounded-xl border border-border bg-card p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-display font-bold">{cat.name}</h3>
                      <span className="rounded-full bg-primary/10 px-2.5 py-0.5 font-mono text-xs font-semibold text-primary">
                        {cat.weight}%
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{cat.desc}</p>
                  </div>
                  <div className="w-full mt-3">
                    <div className="h-1.5 w-full rounded-full bg-muted">
                      <div
                        className={`h-full rounded-full ${cat.color} transition-all`}
                        style={{ width: `${cat.weight * 4}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 rounded-xl border border-border bg-muted/30 p-5">
            <h3 className="font-display font-semibold mb-2">How the Score is Calculated</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Each criterion is scored 1–10 by our reviewer team based on defined rubrics. Scores are then multiplied by the criterion's weight percentage and summed to produce the final 0–100 MechEngi Score. Tools scoring 90+ are exceptional by engineering standards. 75–89 is recommended. Below 65 indicates significant limitations. We publish the criterion-level breakdown for any reader who requests it.
            </p>
          </div>
        </section>

        {/* Contact */}
        <section id="contact">
          <h2 className="font-display text-2xl font-bold mb-4">Contact</h2>
          <div className="rounded-xl border border-border bg-card p-6 max-w-lg">
            <p className="text-muted-foreground mb-4">
              For editorial inquiries, tool submission requests, corrections, or partnership questions, reach us at:
            </p>
            <div className="space-y-3">
              <div>
                <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-1">General Inquiries</p>
                <p className="font-semibold text-primary">hello@mechengi10x.com</p>
              </div>
              <div>
                <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-1">Tool Submissions</p>
                <p className="font-semibold">tools@mechengi10x.com</p>
              </div>
              <div>
                <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-1">Editorial Corrections</p>
                <p className="font-semibold">corrections@mechengi10x.com</p>
              </div>
            </div>
            <p className="mt-4 text-xs text-muted-foreground">
              We aim to respond within 2 business days. Tool submissions are reviewed on a rolling basis — we evaluate approximately 5–10 new tools per month.
            </p>
          </div>
        </section>

      </div>

      <SiteFooter />
    </div>
  );
}
