import { useState } from 'react';
import { Helmet } from 'react-helmet';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

const sections = ['Affiliate Disclosure', 'Privacy Policy', 'Terms of Use'];

export default function LegalPage() {
  const [active, setActive] = useState(0);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Legal — Affiliate Disclosure, Privacy & Terms | MechEngi 10X</title>
        <meta name="description" content="MechEngi 10X affiliate disclosure, privacy policy, and terms of use." />
      </Helmet>

      <SiteHeader />

      <div className="border-b border-border bg-card/30 py-10">
        <div className="mx-auto max-w-[72rem] px-5">
          <h1 className="font-display text-3xl font-bold">Legal & Policies</h1>
          <div className="mt-5 flex flex-wrap gap-2">
            {sections.map((s, i) => (
              <button
                key={s}
                onClick={() => setActive(i)}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${active === i ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'}`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[56rem] px-5 py-12">
        {active === 0 && (
          <div className="space-y-6 text-foreground/80 leading-relaxed">
            <h2 className="font-display text-2xl font-bold text-foreground">Affiliate Disclosure</h2>
            <p className="text-sm text-muted-foreground">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}</p>

            <p>MechEngi 10X participates in affiliate marketing programs. This means that when you click certain links on our site — typically "Try Tool," "Get [Tool Name]," or similar call-to-action buttons — and subsequently make a purchase or sign up, we may receive a commission from the tool vendor.</p>

            <h3 className="font-display text-lg font-bold text-foreground">What This Means for You</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />There is <strong>no additional cost</strong> to you when you use our affiliate links. The price you pay is identical to going directly to the vendor's website.</li>
              <li className="flex items-start gap-2"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />Affiliate commissions help fund our independent research, tool testing, and platform development.</li>
              <li className="flex items-start gap-2"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />Affiliate relationships <strong>do not influence</strong> our review scores, rankings, or editorial content in any way.</li>
              <li className="flex items-start gap-2"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />A tool can receive an affiliate link and still receive a low MechEngi Score. We have declined to maintain affiliate relationships with tools we could not honestly recommend.</li>
            </ul>

            <h3 className="font-display text-lg font-bold text-foreground">Identifying Affiliate Links</h3>
            <p>Affiliate links on MechEngi 10X are marked with the HTML attribute <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">rel="sponsored"</code> and are typically styled as primary CTA buttons (e.g., "Try Tool" or "Get SOLIDWORKS"). Our editorial links to tool pages — links within review text or comparison tables — are non-affiliate links to the tool's canonical documentation or homepage where possible.</p>

            <h3 className="font-display text-lg font-bold text-foreground">Contact Regarding Affiliates</h3>
            <p>If you have questions about our affiliate relationships or believe a review has been influenced by a commercial relationship, contact us at <strong>editorial@mechengi10x.com</strong>.</p>
          </div>
        )}

        {active === 1 && (
          <div className="space-y-6 text-foreground/80 leading-relaxed">
            <h2 className="font-display text-2xl font-bold text-foreground">Privacy Policy</h2>
            <p className="text-sm text-muted-foreground">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}</p>

            <p>This Privacy Policy describes how MechEngi 10X ("we," "us," or "our") collects, uses, and shares information when you use our website and services.</p>

            <h3 className="font-display text-lg font-bold text-foreground">Information We Collect</h3>
            <p><strong>Information you provide voluntarily:</strong> When you create an account or subscribe to our newsletter, we collect your email address and, optionally, your name.</p>
            <p><strong>Information collected automatically:</strong> We collect standard web analytics data including pages visited, time on site, referring URL, browser type, and device type. This data is collected in aggregate and not tied to individual identities unless you have an account.</p>
            <p><strong>User reviews:</strong> When you submit a tool review, your review text, star rating, and account name are stored in our database and may be displayed publicly on the relevant tool page.</p>

            <h3 className="font-display text-lg font-bold text-foreground">How We Use Your Information</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />To provide and improve our platform services</li>
              <li className="flex items-start gap-2"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />To send our weekly engineering newsletter (if subscribed)</li>
              <li className="flex items-start gap-2"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />To analyze usage patterns and improve content quality</li>
              <li className="flex items-start gap-2"><span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />To respond to your inquiries and support requests</li>
            </ul>

            <h3 className="font-display text-lg font-bold text-foreground">Data Sharing</h3>
            <p>We do not sell your personal information to third parties. We may share aggregate, anonymized analytics data for industry benchmarking purposes. Service providers who process data on our behalf (hosting, email delivery, analytics) are bound by data processing agreements.</p>

            <h3 className="font-display text-lg font-bold text-foreground">Your Rights</h3>
            <p>You may request access to, correction of, or deletion of your personal data at any time by emailing <strong>privacy@mechengi10x.com</strong>. Newsletter subscribers may unsubscribe at any time via the link in any newsletter email.</p>

            <h3 className="font-display text-lg font-bold text-foreground">Cookies</h3>
            <p>We use essential cookies required for site functionality (authentication sessions) and analytics cookies to understand usage patterns. You can disable analytics cookies in your browser settings without affecting core site functionality.</p>
          </div>
        )}

        {active === 2 && (
          <div className="space-y-6 text-foreground/80 leading-relaxed">
            <h2 className="font-display text-2xl font-bold text-foreground">Terms of Use</h2>
            <p className="text-sm text-muted-foreground">Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}</p>

            <p>By accessing and using MechEngi 10X, you agree to the following terms. If you do not agree, please do not use our platform.</p>

            <h3 className="font-display text-lg font-bold text-foreground">Acceptable Use</h3>
            <p>You may use MechEngi 10X for personal, professional, and educational purposes. You may not: scrape our content at scale without permission, submit false or misleading reviews, attempt to manipulate our scoring system, or use our platform in any way that violates applicable law.</p>

            <h3 className="font-display text-lg font-bold text-foreground">User-Submitted Reviews</h3>
            <p>By submitting a review, you grant MechEngi 10X a non-exclusive license to display your review on our platform. You represent that your review reflects your genuine experience with the tool and is not submitted on behalf of a vendor (including the reviewed tool's vendor) in exchange for compensation.</p>
            <p>We reserve the right to remove reviews that are fraudulent, defamatory, off-topic, or otherwise violate these terms.</p>

            <h3 className="font-display text-lg font-bold text-foreground">Information Accuracy</h3>
            <p>Tool pricing, features, and scores are updated quarterly. We strive for accuracy but cannot guarantee that all information is current at the moment you read it. Always verify pricing and features directly with the vendor before making a purchase decision.</p>

            <h3 className="font-display text-lg font-bold text-foreground">Limitation of Liability</h3>
            <p>MechEngi 10X provides information for educational and informational purposes only. We make no warranties regarding the accuracy of tool reviews or suitability of any tool for your specific use case. Your use of any tool recommended on this platform is at your own risk and subject to the vendor's own terms and conditions.</p>

            <h3 className="font-display text-lg font-bold text-foreground">Changes to These Terms</h3>
            <p>We may update these terms from time to time. Continued use of MechEngi 10X after changes constitutes acceptance of the updated terms. Material changes will be noted with an updated "Last updated" date.</p>

            <h3 className="font-display text-lg font-bold text-foreground">Contact</h3>
            <p>Questions about these terms: <strong>legal@mechengi10x.com</strong></p>
          </div>
        )}
      </div>

      <SiteFooter />
    </div>
  );
}
