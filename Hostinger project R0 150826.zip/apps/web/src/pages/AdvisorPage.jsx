import { useState, useRef, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Send, Zap, Bot, User, Loader2, RefreshCw, LogIn } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { useAuth } from '@/hooks/use-auth';
import { useIntegratedAi } from '@/hooks/use-integrated-ai';

const starters = [
  'What\'s the best free CAD tool for a mechanical engineer just starting out?',
  'I need to run FEA for my product design. ANSYS vs SimScale — which makes more sense?',
  'I\'m a team of 5 engineers. What project management tool should we use?',
  'Compare ChatGPT and Claude for writing engineering documentation.',
  'What AI tools save the most time for mechanical engineers in 2024?',
];

function Message({ msg }) {
  const isUser = msg.role === 'user';
  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${isUser ? 'bg-primary' : 'bg-card border border-border'}`}>
        {isUser ? <User className="h-4 w-4 text-primary-foreground" /> : <Bot className="h-4 w-4 text-primary" />}
      </div>
      <div className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${isUser ? 'bg-primary text-primary-foreground' : 'bg-card border border-border text-foreground'}`}>
        {msg.content ? (
          <div className="whitespace-pre-wrap">{msg.content}</div>
        ) : (
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        )}
      </div>
    </div>
  );
}

function ChatUI() {
  const { messages, isStreaming, sendMessage, clearMessages } = useIntegratedAi();
  const [input, setInput] = useState('');
  const bottomRef = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = () => {
    const text = input.trim();
    if (!text || isStreaming) return;
    setInput('');
    sendMessage(text);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-1 flex-col overflow-hidden rounded-2xl border border-border bg-card">
      {/* Chat header */}
      <div className="flex items-center justify-between border-b border-border px-5 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full border border-primary/30 bg-primary/10">
            <Zap className="h-4 w-4 text-primary" />
          </div>
          <div>
            <p className="font-display text-sm font-semibold">MechEngi AI Advisor</p>
            <p className="font-mono text-[10px] text-muted-foreground">Engineering tools expert</p>
          </div>
        </div>
        {messages.length > 0 && (
          <button
            onClick={clearMessages}
            className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 font-mono text-xs text-muted-foreground hover:border-foreground/40 hover:text-foreground"
          >
            <RefreshCw className="h-3 w-3" /> New chat
          </button>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-5">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10">
              <Bot className="h-8 w-8 text-primary" />
            </div>
            <h3 className="mt-4 font-display text-xl font-bold">Ask the MechEngi Advisor</h3>
            <p className="mt-2 max-w-sm text-sm text-muted-foreground">
              Get personalized engineering tool recommendations based on your workflow, team size, and budget.
            </p>
            <div className="mt-6 flex flex-col gap-2 w-full max-w-md">
              {starters.map((s) => (
                <button
                  key={s}
                  onClick={() => { setInput(''); sendMessage(s); }}
                  className="rounded-xl border border-border bg-muted/30 px-4 py-2.5 text-left text-sm text-muted-foreground transition-colors hover:border-primary/30 hover:text-foreground"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-5">
            {messages.map((m, i) => (
              <Message key={i} msg={m} />
            ))}
            {isStreaming && messages[messages.length - 1]?.role !== 'assistant' && (
              <div className="flex gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-border bg-card">
                  <Bot className="h-4 w-4 text-primary" />
                </div>
                <div className="flex items-center gap-2 rounded-2xl border border-border bg-card px-4 py-3">
                  <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  <span className="font-mono text-xs text-muted-foreground">Thinking…</span>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-border p-4">
        <div className="flex gap-3">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask about tools, pricing, comparisons…"
            rows={1}
            className="flex-1 resize-none rounded-xl border border-border bg-muted/30 px-4 py-3 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            style={{ minHeight: '48px', maxHeight: '120px' }}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isStreaming}
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-all hover:opacity-90 active:scale-[0.95] disabled:opacity-40"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
        <p className="mt-2 text-center font-mono text-[10px] text-muted-foreground">
          AI Advisor gives general guidance — verify tool pricing before purchasing.
        </p>
      </div>
    </div>
  );
}

function LoginPrompt() {
  return (
    <div className="flex flex-1 flex-col items-center justify-center rounded-2xl border border-border bg-card p-12 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10">
        <LogIn className="h-8 w-8 text-primary" />
      </div>
      <h3 className="mt-5 font-display text-2xl font-bold">Sign in to chat with the AI Advisor</h3>
      <p className="mt-3 max-w-sm text-muted-foreground">
        Create a free account to get personalized engineering tool recommendations, save your conversation history, and access exclusive guides.
      </p>
      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <Link
          to="/signup"
          className="rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
        >
          Create Free Account
        </Link>
        <Link
          to="/login"
          className="rounded-xl border border-border px-8 py-3 font-semibold transition-colors hover:border-primary/40 hover:text-primary"
        >
          Sign In
        </Link>
      </div>
      <p className="mt-4 font-mono text-xs text-muted-foreground">
        Free forever · No credit card required
      </p>
    </div>
  );
}

export default function AdvisorPage() {
  const { user } = useAuth();

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Helmet>
        <title>AI Advisor — MechEngi 10X Engineering Tool Recommendations</title>
        <meta name="description" content="Chat with our AI Advisor to get personalized engineering software tool recommendations based on your discipline, team size, and budget." />
      </Helmet>

      <SiteHeader />

      <div className="mx-auto flex w-full max-w-[72rem] flex-1 flex-col px-5 py-8">
        {/* Page header */}
        <div className="mb-6">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Zap className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">AI-Powered</p>
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Engineering Tool Advisor</h1>
          <p className="mt-2 text-muted-foreground">
            Describe your engineering workflow and get honest, specific tool recommendations in seconds.
          </p>
        </div>

        <div className="flex flex-1 flex-col gap-6 md:flex-row">
          {/* Main chat */}
          <div className="flex min-h-[540px] flex-1 flex-col">
            {user ? <ChatUI /> : <LoginPrompt />}
          </div>

          {/* Sidebar */}
          <div className="w-full shrink-0 space-y-4 md:w-72">
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">What I can help with</h3>
              <ul className="mt-3 space-y-2">
                {[
                  'CAD software selection',
                  'FEA / CFD tool comparison',
                  'AI tools for engineers',
                  'Project management setup',
                  'Learning platform picks',
                  'Budget vs premium tradeoffs',
                  'Free tool alternatives',
                  'Team size considerations',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Browse instead</h3>
              <div className="mt-3 flex flex-col gap-2">
                <Link to="/tools" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">
                  → Tools Directory
                </Link>
                <Link to="/compare" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">
                  → Tool Comparisons
                </Link>
                <Link to="/guides" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">
                  → Engineering Guides
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
