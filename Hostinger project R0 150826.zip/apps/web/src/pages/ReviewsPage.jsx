import { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Search, Star, ArrowRight } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { reviews, reviewCategories } from '@/data/reviews';

function ScoreRing({ score }) {
  const pct = (score / 10) * 100;
  return (
    <div className="relative flex h-14 w-14 shrink-0 items-center justify-center">
      <svg className="absolute inset-0 h-14 w-14 -rotate-90" viewBox="0 0 36 36">
        <circle cx="18" cy="18" r="15.9" fill="none" stroke="hsl(var(--border))" strokeWidth="3" />
        <circle
          cx="18" cy="18" r="15.9" fill="none"
          stroke="hsl(var(--primary))" strokeWidth="3" strokeLinecap="round"
          strokeDasharray={`${pct} 100`}
        />
      </svg>
      <span className="font-display text-sm font-extrabold">{score.toFixed(1)}</span>
    </div>
  );
}

export default function ReviewsPage() {
  const [cat, setCat] = useState('all');
  const [q, setQ] = useState('');

  const filtered = useMemo(() => {
    return reviews.filter((r) => {
      if (cat !== 'all' && r.category !== cat) return false;
      if (!q) return true;
      const t = q.toLowerCase();
      return r.name.toLowerCase().includes(t) || r.vendor.toLowerCase().includes(t) || r.summary.toLowerCase().includes(t);
    });
  }, [cat, q]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Expert Product Reviews — MechEngi 10X Engineering Tool Reviews</title>
        <meta name="description" content="In-depth expert reviews of engineering software and measurement tools. Scored on ease of use, features, performance, and value with real engineering use cases." />
      </Helmet>
      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-14">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">Phase 2 · Expert Reviews</p>
          <h1 className="mt-2 max-w-2xl font-display text-4xl font-extrabold leading-tight sm:text-5xl">
            Expert Product Reviews
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-muted-foreground">
            {reviews.length} in-depth, vendor-neutral reviews scored across ease of use, features,
            performance, value, and support — written for practicing engineers.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search reviews by tool or vendor…"
                className="min-h-[48px] w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm outline-none focus:border-primary"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {reviewCategories.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setCat(c.id)}
                  className={`min-h-[44px] rounded-xl border px-4 text-sm font-medium transition-colors ${
                    cat === c.id
                      ? 'border-primary bg-primary/10 text-primary'
                      : 'border-border text-muted-foreground hover:border-primary/40 hover:text-foreground'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[72rem] px-5 py-12">
        <p className="mb-6 font-mono text-xs text-muted-foreground">
          {filtered.length} review{filtered.length === 1 ? '' : 's'}
        </p>

        {filtered.length === 0 ? (
          <div className="rounded-xl border border-border py-20 text-center">
            <p className="font-display text-lg font-semibold">No reviews match your search</p>
            <button onClick={() => { setQ(''); setCat('all'); }} className="mt-4 rounded-lg border border-border px-5 py-2 text-sm hover:border-primary/50">
              Clear filters
            </button>
          </div>
        ) : (
          <div className="grid gap-5 md:grid-cols-2">
            {filtered.map((r) => (
              <Link
                key={r.slug}
                to={`/reviews/${r.slug}`}
                className="group flex flex-col rounded-2xl border border-border bg-card p-6 transition-all hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5"
              >
                <div className="flex items-start gap-4">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-border bg-muted text-2xl">
                    {r.logoEmoji}
                  </span>
                  <div className="min-w-0 flex-1">
                    <h2 className="font-display text-lg font-bold leading-snug group-hover:text-primary">{r.name}</h2>
                    <p className="font-mono text-[11px] text-muted-foreground">{r.vendor}</p>
                  </div>
                  <ScoreRing score={r.overallScore} />
                </div>
                <p className="mt-4 line-clamp-3 text-sm leading-relaxed text-muted-foreground">{r.summary}</p>
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  {r.badge && (
                    <span className="rounded-full border border-accent/30 bg-accent/10 px-2.5 py-0.5 font-mono text-[10px] text-accent">
                      {r.badge}
                    </span>
                  )}
                  <span className="flex items-center gap-1 font-mono text-[10px] text-muted-foreground">
                    <Star className="h-3 w-3 star-filled" fill="currentColor" /> {r.overallScore}/10
                  </span>
                  <span className="font-mono text-[10px] text-muted-foreground">{r.readTime} min read</span>
                  <span className="ml-auto flex items-center gap-1 text-xs font-medium text-primary">
                    Read review <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

      <SiteFooter />
    </div>
  );
}
