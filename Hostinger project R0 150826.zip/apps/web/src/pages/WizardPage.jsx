import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowRight, ArrowLeft, CheckCircle, ExternalLink, Zap, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { StarRating } from '@/components/ToolCard';
import { tools } from '@/data/tools';
import { trackWizardComplete } from '@/lib/analytics';

const ROLES = [
  { id: 'me', label: 'Mechanical Engineer', icon: '⚙️' },
  { id: 'ee', label: 'Electrical / Electronics Engineer', icon: '⚡' },
  { id: 'sw', label: 'Software / Automation Engineer', icon: '💻' },
  { id: 'mgr', label: 'Engineering Manager / Team Lead', icon: '📊' },
  { id: 'student', label: 'Student / Academic', icon: '🎓' },
  { id: 'startup', label: 'Entrepreneur / Startup Founder', icon: '🚀' },
];

const GOALS = [
  { id: 'cad', label: 'CAD & 3D Modeling', icon: '📐', cats: ['cad'] },
  { id: 'sim', label: 'FEA / CFD Simulation', icon: '🔬', cats: ['simulation'] },
  { id: 'automate', label: 'Automate Repetitive Tasks', icon: '🔄', cats: ['automation'] },
  { id: 'pm', label: 'Manage Engineering Projects', icon: '📋', cats: ['management'] },
  { id: 'learn', label: 'Learn New Engineering Skills', icon: '📚', cats: ['learning'] },
  { id: 'ai', label: 'AI-Assisted Technical Work', icon: '🤖', cats: ['ai'] },
  { id: 'docs', label: 'Engineering Documentation', icon: '📝', cats: ['management', 'ai'] },
  { id: 'data', label: 'Data Analysis & Processing', icon: '📈', cats: ['ai', 'automation'] },
];

const BUDGETS = [
  { id: 'free', label: 'Free only', sub: 'No paid subscriptions', max: 0 },
  { id: 'low', label: 'Up to $20/month', sub: 'Entry-level tools', max: 20 },
  { id: 'mid', label: '$20–$100/month', sub: 'Professional tier', max: 100 },
  { id: 'high', label: 'Over $100/month', sub: 'Enterprise grade', max: 99999 },
  { id: 'any', label: 'No budget limit', sub: 'Show me everything', max: 99999 },
];

const ROLE_WEIGHTS = {
  me:      { cad: 1.5, simulation: 1.5, ai: 1.0, learning: 1.2 },
  ee:      { ai: 1.2, automation: 1.3, simulation: 1.1 },
  sw:      { automation: 1.5, ai: 1.3, management: 1.1 },
  mgr:     { management: 1.5, automation: 1.2, ai: 1.0 },
  student: { learning: 1.6, cad: 1.3, simulation: 1.3, ai: 1.0 },
  startup: { automation: 1.3, ai: 1.4, management: 1.2 },
};

const GOAL_REASONS = {
  cad:      'Best for your CAD & 3D Modeling needs',
  sim:      'Ideal for FEA / CFD simulation workflows',
  automate: 'Top pick for workflow automation',
  pm:       'Recommended for project management',
  learn:    'Perfect for professional upskilling',
  ai:       'Top AI tool for engineering tasks',
  docs:     'Great for engineering documentation',
  data:     'Excellent for data analysis workflows',
};

function recommendTools(role, goal, budget) {
  const goalDef = GOALS.find((g) => g.id === goal);
  const weights = ROLE_WEIGHTS[role] || {};
  const max = BUDGETS.find((b) => b.id === budget)?.max ?? 99999;

  return tools
    .filter((t) => {
      if (budget === 'free') return t.pricing.paidFrom === 0 || t.pricing.free;
      const monthly = t.pricing.paidFrom >= 100 ? t.pricing.paidFrom / 12 : t.pricing.paidFrom;
      return t.pricing.paidFrom === 0 || monthly <= max;
    })
    .map((t) => {
      let score = t.mechengiScore;
      score *= weights[t.category] || 1.0;
      if (goalDef?.cats.includes(t.category)) score *= 1.5;
      if (budget === 'free' && t.pricing.paidFrom === 0) score *= 1.2;
      if (t.featured) score *= 1.05;
      return { tool: t, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map((r) => r.tool);
}

const steps = ['Your Role', 'Your Goal', 'Budget', 'Results'];

function ProgressBar({ step }) {
  return (
    <div className="mx-auto mb-8 max-w-lg">
      <div className="flex items-center justify-between text-center">
        {steps.map((s, i) => (
          <div key={s} className="flex flex-1 flex-col items-center gap-1.5">
            <div className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold transition-all ${
              i < step ? 'bg-green-500 text-white' : i === step ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
            }`}>
              {i < step ? <CheckCircle className="h-4 w-4" /> : i + 1}
            </div>
            <span className={`hidden font-mono text-[10px] uppercase tracking-wider sm:block ${i === step ? 'text-primary' : 'text-muted-foreground'}`}>
              {s}
            </span>
          </div>
        ))}
      </div>
      <div className="relative mt-2 h-1 rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-primary transition-all duration-500"
          style={{ width: `${(step / (steps.length - 1)) * 100}%` }}
        />
      </div>
    </div>
  );
}

function OptionGrid({ options, selected, onSelect, cols = 2 }) {
  return (
    <div className={`grid gap-3 ${cols === 3 ? 'sm:grid-cols-3' : 'sm:grid-cols-2'}`}>
      {options.map((opt) => (
        <button
          key={opt.id}
          onClick={() => onSelect(opt.id)}
          className={`flex items-center gap-3 rounded-xl border p-4 text-left transition-all active:scale-[0.98] ${
            selected === opt.id
              ? 'border-primary bg-primary/10 ring-1 ring-primary'
              : 'border-border bg-card hover:border-primary/40 hover:bg-primary/5'
          }`}
        >
          <span className="text-2xl">{opt.icon}</span>
          <div>
            <p className="font-display text-sm font-semibold">{opt.label}</p>
            {opt.sub && <p className="mt-0.5 text-xs text-muted-foreground">{opt.sub}</p>}
          </div>
          {selected === opt.id && (
            <CheckCircle className="ml-auto h-4 w-4 shrink-0 text-primary" />
          )}
        </button>
      ))}
    </div>
  );
}

function ResultCard({ tool, index, goalId }) {
  const reason = GOAL_REASONS[goalId] || 'Recommended for your profile';
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08 }}
      className="flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 sm:flex-row sm:items-start sm:gap-5"
    >
      <div className="flex shrink-0 items-center gap-3 sm:flex-col sm:items-center sm:gap-2">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-border bg-muted text-2xl">
          {tool.logoEmoji}
        </div>
        <div className="text-center sm:block hidden">
          <span className="font-display text-xl font-extrabold text-primary">{tool.mechengiScore}</span>
          <p className="font-mono text-[9px] text-muted-foreground">Score</p>
        </div>
        <div className="sm:hidden flex items-center gap-1">
          <span className="font-mono text-xs font-semibold text-primary">{tool.mechengiScore}/100</span>
        </div>
      </div>
      <div className="flex-1 min-w-0 mt-3 sm:mt-0">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <h3 className="font-display text-lg font-bold">{tool.name}</h3>
            <p className="text-xs text-muted-foreground">{tool.vendor}</p>
          </div>
          <div>
            <StarRating rating={tool.rating} />
            <p className="mt-0.5 text-right font-mono text-[10px] text-muted-foreground">{tool.rating} ({tool.reviewCount.toLocaleString()})</p>
          </div>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{tool.tagline}</p>
        <div className="mt-2 flex items-center gap-1.5">
          <CheckCircle className="h-3.5 w-3.5 shrink-0 text-green-500" />
          <span className="text-xs font-medium text-green-400">{reason}</span>
        </div>
        <div className="mt-2 flex items-center gap-2">
          {tool.pricing.free && (
            <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] text-green-400">Free tier</span>
          )}
          {tool.pricing.paidFrom > 0 ? (
            <span className="font-mono text-xs text-muted-foreground">
              From <span className="text-foreground">${tool.pricing.paidFrom}</span>{tool.pricing.paidFrom >= 100 ? '/yr' : '/mo'}
            </span>
          ) : (
            <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] text-green-400">Free forever</span>
          )}
        </div>
        <div className="mt-4 flex gap-2">
          <Link
            to={`/tools/${tool.slug}`}
            className="flex-1 rounded-lg border border-border py-2 text-center text-sm font-medium transition-colors hover:border-primary/60 hover:text-primary"
          >
            Full Review
          </Link>
          <a
            href={tool.affiliateUrl}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-all hover:opacity-90"
          >
            Try {tool.name} <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>
    </motion.div>
  );
}

export default function WizardPage() {
  const [step, setStep] = useState(0);
  const [role, setRole] = useState('');
  const [goal, setGoal] = useState('');
  const [budget, setBudget] = useState('');
  const [results, setResults] = useState([]);

  const canNext = [role, goal, budget][step] !== '';

  const handleNext = () => {
    if (step === 2) {
      const recs = recommendTools(role, goal, budget);
      setResults(recs);
      trackWizardComplete(role, goal, budget, recs.length);
      setStep(3);
    } else {
      setStep(step + 1);
    }
  };

  const reset = () => {
    setStep(0);
    setRole('');
    setGoal('');
    setBudget('');
    setResults([]);
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Find the Right Engineering Tool — MechEngi 10X Recommendation Wizard</title>
        <meta name="description" content="Answer 3 quick questions and get personalized engineering tool recommendations matched to your role, goals, and budget. No sign-up required." />
      </Helmet>

      <SiteHeader />

      <div className="mx-auto max-w-[56rem] px-5 py-12">
        {/* Header */}
        <div className="mb-10 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs text-primary">
            <Zap className="h-3.5 w-3.5" />
            Tool Recommendation Wizard
          </div>
          <h1 className="font-display text-3xl font-extrabold sm:text-4xl">
            Find Your Perfect Engineering Tool
          </h1>
          <p className="mx-auto mt-3 max-w-md text-muted-foreground">
            Answer 3 quick questions. Get 5 personalized tool recommendations with honest scores and pricing. No sign-up required.
          </p>
        </div>

        <ProgressBar step={step} />

        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div key="step0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h2 className="mb-6 text-center font-display text-xl font-bold">What is your role?</h2>
              <OptionGrid options={ROLES} selected={role} onSelect={setRole} cols={2} />
            </motion.div>
          )}

          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h2 className="mb-6 text-center font-display text-xl font-bold">What is your primary goal?</h2>
              <OptionGrid options={GOALS} selected={goal} onSelect={setGoal} cols={2} />
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h2 className="mb-6 text-center font-display text-xl font-bold">What is your budget?</h2>
              <OptionGrid options={BUDGETS} selected={budget} onSelect={setBudget} cols={2} />
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <div className="mb-6 flex items-center justify-between">
                <div>
                  <h2 className="font-display text-xl font-bold">Your Top Tool Matches</h2>
                  <p className="text-sm text-muted-foreground">
                    Based on: {ROLES.find(r => r.id === role)?.label} · {GOALS.find(g => g.id === goal)?.label} · {BUDGETS.find(b => b.id === budget)?.label}
                  </p>
                </div>
                <button
                  onClick={reset}
                  className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 font-mono text-xs text-muted-foreground hover:border-foreground/40 hover:text-foreground"
                >
                  <RotateCcw className="h-3.5 w-3.5" /> Restart
                </button>
              </div>

              {results.length > 0 ? (
                <div className="flex flex-col gap-4">
                  {results.map((tool, i) => (
                    <ResultCard key={tool.slug} tool={tool} index={i} goalId={goal} />
                  ))}
                </div>
              ) : (
                <div className="rounded-xl border border-border py-16 text-center">
                  <p className="font-display text-lg font-semibold">No tools match your exact criteria</p>
                  <p className="mt-2 text-muted-foreground">Try relaxing your budget to see more options.</p>
                  <button onClick={reset} className="mt-4 rounded-xl bg-primary px-6 py-2.5 font-medium text-primary-foreground">
                    Try Again
                  </button>
                </div>
              )}

              <div className="mt-8 rounded-xl border border-border bg-card/50 p-5 text-center">
                <p className="text-sm text-muted-foreground">
                  Not seeing what you need? Browse the full directory or use our AI Advisor.
                </p>
                <div className="mt-3 flex flex-wrap justify-center gap-3">
                  <Link to="/tools" className="rounded-lg border border-border px-5 py-2 text-sm font-medium hover:border-primary/40 hover:text-primary">
                    Browse All Tools
                  </Link>
                  <Link to="/compare" className="rounded-lg border border-border px-5 py-2 text-sm font-medium hover:border-primary/40 hover:text-primary">
                    Compare Tools
                  </Link>
                  <Link to="/advisor" className="rounded-lg bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
                    Ask AI Advisor
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation buttons */}
        {step < 3 && (
          <div className="mt-8 flex items-center justify-between">
            <button
              onClick={() => setStep(Math.max(0, step - 1))}
              disabled={step === 0}
              className="flex items-center gap-2 rounded-xl border border-border px-5 py-2.5 font-medium text-muted-foreground transition-colors hover:border-foreground/40 hover:text-foreground disabled:opacity-0"
            >
              <ArrowLeft className="h-4 w-4" /> Back
            </button>
            <span className="font-mono text-xs text-muted-foreground">{step + 1} of 3</span>
            <button
              onClick={handleNext}
              disabled={!canNext}
              className="flex items-center gap-2 rounded-xl bg-primary px-6 py-2.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
            >
              {step === 2 ? 'Get Recommendations' : 'Next'} <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        )}

        <p className="mt-8 text-center font-mono text-[10px] text-muted-foreground">
          Affiliate disclosure: "Try" buttons may earn MechEngi 10X a commission at no extra cost to you.
        </p>
      </div>

      <SiteFooter />
    </div>
  );
}
