import { useEffect, useMemo, useRef, useState } from 'react';
import Helmet from 'react-helmet';
import { Link, useSearchParams } from 'react-router-dom';
import { Paperclip, Send, Sparkles, X } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { useIntegratedAi } from '@/hooks/use-integrated-ai';
import useAuth from '@/hooks/use-auth';
import { useAnimatedText } from '@/hooks/use-animated-text';
import { toast } from '@/hooks/use-toast';
import pb from '@/lib/pocketbaseClient';
import { topics } from '@/data/curriculum';

const suggestions = topics.slice(0, 4).map((t) => ({ label: t.title, ask: t.ask }));

const TutorPage = () => {
    const { isAuthed, user } = useAuth();
    const [params] = useSearchParams();
    const [input, setInput] = useState(params.get('q') || '');
    const [files, setFiles] = useState([]);
    const fileRef = useRef(null);
    const endRef = useRef(null);
    const { messages, isStreaming, isLoadingHistory, sendMessage } = useIntegratedAi();

    const previews = useMemo(
        () => files.map((f) => ({ key: `${f.name}${f.size}`, url: URL.createObjectURL(f), name: f.name })),
        [files],
    );
    useEffect(() => () => previews.forEach((p) => URL.revokeObjectURL(p.url)), [previews]);

    const last = messages[messages.length - 1];
    const streamingText = useAnimatedText(isStreaming && last?.role === 'assistant' ? last.content : '');

    useEffect(() => {
        endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }, [messages]);

    const submit = (e) => {
        e.preventDefault();
        const text = input.trim();
        if ((!text && files.length === 0) || isStreaming) return;
        setInput('');
        setFiles([]);
        sendMessage(text, files);
    };

    if (!isAuthed) {
        return (
            <div className="min-h-screen bg-background">
                <Helmet>
                    <title>AI Mechanical Engineering Tutor — TorqueLab</title>
                    <meta name="description" content="Sign in to TorqueLab to ask the AI mechanical engineering tutor for derivations, worked solutions and diagrams." />
                </Helmet>
                <SiteHeader />
                <div className="blueprint-grid mx-auto max-w-[56rem] px-5 py-28 text-center">
                    <Sparkles className="mx-auto h-6 w-6 text-primary" />
                    <h1 className="mt-6 font-display text-4xl font-bold tracking-tight">The AI tutor is members-only</h1>
                    <p className="mx-auto mt-5 max-w-lg leading-relaxed text-muted-foreground">
                        Create a free account so your worked problems and conversation history stay with you
                        between sessions.
                    </p>
                    <div className="mt-9 flex flex-wrap justify-center gap-4">
                        <Link to="/signup" className="flex min-h-[48px] items-center rounded-sm bg-primary px-6 font-tech text-xs uppercase tracking-widest text-primary-foreground active:scale-[0.98]">
                            Create account
                        </Link>
                        <Link to="/login" className="flex min-h-[48px] items-center rounded-sm border border-border px-6 font-tech text-xs uppercase tracking-widest active:scale-[0.98]">
                            Sign in
                        </Link>
                    </div>
                </div>
                <SiteFooter />
            </div>
        );
    }

    return (
        <div className="flex min-h-screen flex-col bg-background">
            <Helmet>
                <title>AI Mechanical Engineering Tutor — TorqueLab</title>
                <meta name="description" content="Ask the TorqueLab AI tutor about statics, thermodynamics, fluids, heat transfer and machine design. Step-by-step solutions with units and assumptions." />
            </Helmet>
            <SiteHeader />

            <main className="mx-auto flex w-full max-w-[56rem] flex-1 flex-col px-5 py-8">
                <div className="border-b border-border pb-5">
                    <h1 className="font-display text-2xl font-bold tracking-tight">AI tutor</h1>
                    <p className="mt-1 text-sm text-muted-foreground">
                        Mechanical engineering only. Ask for derivations, numeric solutions or a labelled diagram.
                    </p>
                </div>

                {user && user.verified === false && (
                    <div className="mt-5 border border-primary/40 bg-primary/10 p-4 text-sm">
                        <p className="text-foreground">
                            Confirm your email to start chatting — check your inbox for the verification link.
                        </p>
                        <button
                            onClick={() =>
                                pb
                                    .collection('users')
                                    .requestVerification(user.email)
                                    .then(() => toast({ title: 'Verification email sent' }))
                                    .catch((err) => toast({ variant: 'destructive', title: 'Error', description: err.message }))
                            }
                            className="mt-3 font-tech text-xs uppercase tracking-widest text-primary hover:underline"
                        >
                            Resend email
                        </button>
                    </div>
                )}

                <div className="flex-1 space-y-5 py-6">
                    {isLoadingHistory && (
                        <p className="font-tech text-xs uppercase tracking-widest text-muted-foreground">Loading history…</p>
                    )}
                    {!isLoadingHistory && messages.length === 0 && (
                        <div className="border border-border bg-card/50 p-6">
                            <p className="font-tech text-xs uppercase tracking-widest text-accent">Try one of these</p>
                            <div className="mt-4 flex flex-wrap gap-3">
                                {suggestions.map((s) => (
                                    <button
                                        key={s.label}
                                        onClick={() => setInput(s.ask)}
                                        className="rounded-sm border border-border px-3 py-2 text-left text-sm text-muted-foreground transition hover:border-accent hover:text-foreground"
                                    >
                                        {s.label}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                    {messages.map((m, i) => {
                        const isStreamingLast = isStreaming && i === messages.length - 1 && m.role === 'assistant';
                        const body = isStreamingLast ? streamingText : m.content;
                        return (
                            <div key={i} className={m.role === 'user' ? 'flex justify-end' : 'flex justify-start'}>
                                <div
                                    className={`max-w-[85%] rounded-sm border px-4 py-3 text-sm leading-relaxed ${
                                        m.role === 'user'
                                            ? 'border-primary/50 bg-primary/15'
                                            : 'border-border bg-card'
                                    }`}
                                >
                                    {body && <p className="whitespace-pre-wrap">{body}</p>}
                                    {m.images?.map((url, j) => (
                                        <img key={j} src={url} alt="Generated engineering diagram" className="mt-3 max-w-full rounded-sm border border-border" loading="lazy" />
                                    ))}
                                    {isStreamingLast && !m.content && (
                                        <span className="inline-block h-4 w-2 animate-pulse bg-primary" />
                                    )}
                                </div>
                            </div>
                        );
                    })}
                    <div ref={endRef} />
                </div>

                <div className="sticky bottom-0 border-t border-border bg-background pt-4 pb-6">
                    {previews.length > 0 && (
                        <div className="mb-3 flex flex-wrap gap-2">
                            {previews.map((p, i) => (
                                <div key={p.key} className="relative">
                                    <img src={p.url} alt={p.name} className="h-20 w-20 rounded-sm border border-border object-cover" />
                                    <button
                                        type="button"
                                        onClick={() => setFiles((prev) => prev.filter((_, idx) => idx !== i))}
                                        className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-destructive-foreground"
                                    >
                                        <X className="h-3 w-3" />
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                    <form onSubmit={submit} className="flex items-end gap-2">
                        <input
                            ref={fileRef}
                            type="file"
                            accept="image/jpeg,image/png,image/webp"
                            multiple
                            className="hidden"
                            onChange={(e) => {
                                setFiles((prev) => [...prev, ...Array.from(e.target.files || [])].slice(0, 5));
                                if (fileRef.current) fileRef.current.value = '';
                            }}
                        />
                        <button
                            type="button"
                            onClick={() => fileRef.current?.click()}
                            className="flex h-11 w-11 items-center justify-center rounded-sm border border-border text-muted-foreground hover:text-foreground"
                            title="Attach a problem sheet"
                        >
                            <Paperclip className="h-4 w-4" />
                        </button>
                        <textarea
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) submit(e);
                            }}
                            rows={2}
                            placeholder="e.g. Derive the bending stress formula, then size a beam for 4 kN at 2 m"
                            className="min-h-[44px] flex-1 resize-none rounded-sm border border-input bg-card px-3 py-3 text-sm outline-none focus:border-accent"
                            disabled={isStreaming}
                        />
                        <button
                            type="submit"
                            disabled={isStreaming || (!input.trim() && files.length === 0)}
                            className="flex h-11 items-center gap-2 rounded-sm bg-primary px-4 font-tech text-xs uppercase tracking-widest text-primary-foreground disabled:opacity-50 active:scale-[0.98]"
                        >
                            <Send className="h-4 w-4" /> Ask
                        </button>
                    </form>
                </div>
            </main>
            <SiteFooter />
        </div>
    );
};

export default TutorPage;
