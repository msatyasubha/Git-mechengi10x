import { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { useSearchParams, Link } from 'react-router-dom';
import { Search, SlidersHorizontal, Zap } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import ToolCard from '@/components/ToolCard';
import { categories, tools } from '@/data/tools';
import { trackSearch } from '@/lib/analytics';

const sortOptions = [
  { id: 'score', label: 'MechEngi Score' },
  { id: 'rating', label: 'User Rating' },
  { id: 'name', label: 'Name A–Z' },
  { id: 'price-asc', label: 'Price: Low to High' },
];

export default function ToolsPage() {
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState(params.get('q') || '');
  const [sort, setSort] = useState('score');

  const activeCat = params.get('cat') || 'all';
  const freeOnly = params.get('free') === '1';

  const setCategory = (id) => {
    const next = new URLSearchParams(params);
    if (id === 'all') next.delete('cat');
    else next.set('cat', id);
    next.delete('q');
    setQuery('');
    setParams(next);
  };

  const filtered = useMemo(() => {
    let list = tools;
    if (activeCat !== 'all') list = list.filter((t) => t.category === activeCat);
    if (freeOnly) list = list.filter((t) => t.pricing.paidFrom === 0);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.tagline.toLowerCase().includes(q) ||
          t.vendor.toLowerCase().includes(q) ||
          t.category.includes(q)
      );
    }
    if (query.trim()) trackSearch(query.trim(), list.length);
    return [...list].sort((a, b) => {
      if (sort === 'score') return b.mechengiScore - a.mechengiScore;
      if (sort === 'rating') return b.rating - a.rating;
      if (sort === 'name') return a.name.localeCompare(b.name);
      if (sort === 'price-asc') return a.pricing.paidFrom - b.pricing.paidFrom;
      return 0;
    });
  }, [activeCat, freeOnly, query, sort]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Tools Directory — MechEngi 10X</title>
        <meta name="description" content="Browse 50+ engineering software tools across AI, CAD, simulation, automation, management, and learning. Filter by category, price, and rating." />
      </Helmet>

      <SiteHeader />

      {/* Page header */}
      <div className="border-b border-border bg-card/30 py-10">
        <div className="mx-auto max-w-[90rem] px-5">
          <h1 className="font-display text-3xl font-bold sm:text-4xl">Engineering Tools Directory</h1>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <p className="text-muted-foreground">{tools.length} tools reviewed across {categories.length - 1} categories.</p>
            <div className="flex flex-wrap gap-2">
              <Link to="/wizard" className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 font-mono text-[10px] text-primary hover:bg-primary/10">
                <Zap className="h-3 w-3" /> Find the Right Tool
              </Link>
              <Link to="/about#methodology" className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1 font-mono text-[10px] text-muted-foreground hover:border-primary/30 hover:text-primary">
                Score Methodology
              </Link>
            </div>
          </div>

          {/* Search + Sort row */}
          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search tools by name, category, or use case…"
                className="h-11 w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4 shrink-0 text-muted-foreground" />
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="h-11 rounded-xl border border-border bg-card px-3 text-sm focus:border-primary focus:outline-none"
              >
                {sortOptions.map((o) => (
                  <option key={o.id} value={o.id}>{o.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Category filter */}
          <div className="mt-4 flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setCategory(c.id)}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                  activeCat === c.id
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/30 hover:text-foreground'
                }`}
              >
                {c.label}
              </button>
            ))}
            <button
              onClick={() => {
                const next = new URLSearchParams(params);
                if (freeOnly) next.delete('free');
                else next.set('free', '1');
                setParams(next);
              }}
              className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                freeOnly
                  ? 'border-green-500/40 bg-green-500/10 text-green-400'
                  : 'border-border text-muted-foreground hover:border-green-500/30'
              }`}
            >
              Free only
            </button>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="mx-auto max-w-[90rem] px-5 py-10">
        {filtered.length > 0 ? (
          <>
            <p className="mb-6 font-mono text-xs text-muted-foreground">
              {filtered.length} tool{filtered.length !== 1 ? 's' : ''} found
            </p>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filtered.map((tool) => (
                <ToolCard key={tool.slug} tool={tool} />
              ))}
            </div>
          </>
        ) : (
          <div className="py-24 text-center">
            <p className="font-display text-xl font-semibold">No tools found</p>
            <p className="mt-2 text-muted-foreground">Try adjusting your search or filters.</p>
            <button
              onClick={() => { setQuery(''); setParams({}); }}
              className="mt-4 rounded-xl bg-primary px-6 py-2 font-medium text-primary-foreground"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>

      <SiteFooter />
    </div>
  );
}
