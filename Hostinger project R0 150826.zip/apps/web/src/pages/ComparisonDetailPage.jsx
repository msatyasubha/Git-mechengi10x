import { Helmet } from 'react-helmet';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, ChevronRight, Clock, Zap } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { getComparisonBySlug, comparisons } from '@/data/comparisons';
import { getToolBySlug } from '@/data/tools';

const categoryBadge = {
  ai: 'AI Tools',
  cad: 'CAD & Design',
  simulation: 'Simulation',
  automation: 'Automation',
};

function renderContent(content) {
  const lines = content.trim().split('\n');
  const elements = [];
  let key = 0;
  let ulItems = [];

  const flushUl = () => {
    if (ulItems.length > 0) {
      elements.push(
        <ul key={key++} className="mt-3 space-y-1.5">
          {ulItems}
        </ul>
      );
      ulItems = [];
    }
  };

  for (const line of lines) {
    if (line.startsWith('## ')) {
      flushUl();
      elements.push(
        <h2 key={key++} className="mt-8 font-display text-xl font-bold sm:text-2xl">
          {line.replace('## ', '')}
        </h2>
      );
    } else if (line.startsWith('### ')) {
      flushUl();
      elements.push(
        <h3 key={key++} className="mt-5 font-display text-lg font-bold">
          {line.replace('### ', '')}
        </h3>
      );
    } else if (line.startsWith('**') && line.endsWith('**') && !line.includes(':** ')) {
      flushUl();
      elements.push(
        <p key={key++} className="mt-4 font-semibold">{line.replace(/\*\*/g, '')}</p>
      );
    } else if (line.startsWith('- ')) {
      ulItems.push(
        <li key={key++} className="flex items-start gap-2 text-sm text-foreground/80">
          <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
          <span dangerouslySetInnerHTML={{ __html: line.replace('- ', '').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
        </li>
      );
    } else if (line.startsWith('| ')) {
      flushUl();
      // Render table rows
      const cells = line.split('|').filter(Boolean).map(c => c.trim());
      const isHeader = !cells[0].startsWith('---');
      const isSeparator = cells[0].startsWith('---');
      if (!isSeparator) {
        elements.push(
          <div key={key++} className={`grid border-b border-border ${isHeader ? 'bg-muted/50 font-semibold' : 'hover:bg-muted/20'}`}
            style={{ gridTemplateColumns: `repeat(${cells.length}, 1fr)` }}>
            {cells.map((cell, i) => (
              <div key={i} className={`px-3 py-2 text-sm ${i > 0 ? 'border-l border-border' : ''}`}
                dangerouslySetInnerHTML={{ __html: cell.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
            ))}
          </div>
        );
      }
    } else if (line.trim() === '') {
      flushUl();
    } else {
      flushUl();
      elements.push(
        <p key={key++} className="mt-3 text-sm leading-relaxed text-foreground/80"
          dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/`([^`]+)`/g, '<code class="rounded bg-muted px-1 py-0.5 font-mono text-xs">$1</code>') }} />
      );
    }
  }
  flushUl();
  return elements;
}

export default function ComparisonDetailPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const comparison = getComparisonBySlug(slug);
  const related = comparisons.filter(c => c.slug !== slug).slice(0, 3);

  if (!comparison) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4">
          <p className="font-display text-2xl font-bold">Comparison not found</p>
          <button onClick={() => navigate('/compare')} className="text-primary hover:underline">
            Back to Comparisons
          </button>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const toolData = comparison.tools.map(slug => getToolBySlug(slug)).filter(Boolean);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{comparison.seoTitle} | MechEngi 10X</title>
        <meta name="description" content={comparison.metaDescription} />
        <link rel="canonical" href={`https://mechengi10x.com/comparisons/${comparison.slug}`} />
        <meta property="og:title" content={`${comparison.seoTitle} | MechEngi 10X`} />
        <meta property="og:description" content={comparison.metaDescription} />
      </Helmet>

      <script type="application/ld+json" dangerouslySetInnerHTML={{
        __html: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          "headline": comparison.title,
          "description": comparison.metaDescription,
          "author": { "@type": "Organization", "name": "MechEngi 10X" },
          "publisher": { "@type": "Organization", "name": "MechEngi 10X", "url": "https://mechengi10x.com" },
          "url": `https://mechengi10x.com/comparisons/${comparison.slug}`,
          "breadcrumb": {
            "@type": "BreadcrumbList",
            "itemListElement": [
              { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://mechengi10x.com" },
              { "@type": "ListItem", "position": 2, "name": "Comparisons", "item": "https://mechengi10x.com/compare" },
              { "@type": "ListItem", "position": 3, "name": comparison.title, "item": `https://mechengi10x.com/comparisons/${comparison.slug}` },
            ]
          }
        })
      }} />

      <SiteHeader />

      {/* Breadcrumb */}
      <div className="border-b border-border bg-card/30 py-3">
        <div className="mx-auto flex max-w-[72rem] flex-wrap items-center gap-1.5 px-5 font-mono text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Home</Link>
          <ChevronRight className="h-3 w-3" />
          <Link to="/compare" className="hover:text-foreground">Comparisons</Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground truncate max-w-[200px]">{comparison.title}</span>
        </div>
      </div>

      <div className="mx-auto max-w-[72rem] px-5 py-8 lg:py-12">
        <div className="grid gap-10 lg:grid-cols-[1fr_300px]">
          {/* Main */}
          <main>
            <header>
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${comparison.category}`}>
                  {categoryBadge[comparison.category] || comparison.category}
                </span>
                <span className="rounded-full bg-primary/10 px-2 py-0.5 font-mono text-[10px] text-primary">In-Depth Comparison</span>
              </div>
              <h1 className="font-display text-2xl font-extrabold sm:text-3xl lg:text-4xl leading-tight">
                {comparison.title}
              </h1>
              <div className="mt-3 flex flex-wrap items-center gap-4 text-xs text-muted-foreground font-mono">
                <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {comparison.readTime} min read</span>
                <span>{comparison.date}</span>
                <span>MechEngi 10X Team</span>
              </div>
              <p className="mt-4 text-base leading-relaxed text-muted-foreground">{comparison.excerpt}</p>
            </header>

            {/* Tools being compared */}
            {toolData.length > 0 && (
              <div className="mt-6 flex flex-wrap gap-3">
                {toolData.map((tool, i) => (
                  <Link key={tool.slug} to={`/tools/${tool.slug}`}
                    className="flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-medium transition-colors hover:border-primary/30 hover:text-primary">
                    <span className="text-lg">{tool.logoEmoji}</span>
                    <span>{tool.name}</span>
                    <span className="font-mono text-xs text-primary">{tool.mechengiScore}/100</span>
                  </Link>
                ))}
              </div>
            )}

            {/* Article content */}
            <article className="mt-8 border-t border-border pt-8">
              {renderContent(comparison.content)}
            </article>

            {/* Internal links to AI tool profiles */}
            {comparison.toolProfiles?.length > 0 && (
              <div className="mt-10">
                <h3 className="font-display font-bold mb-3">Full AI Tool Profiles</h3>
                <div className="flex flex-wrap gap-2">
                  {comparison.toolProfiles.map(slug => (
                    <Link key={slug} to={`/ai-tools/${slug}`}
                      className="rounded-lg border border-border bg-card px-3 py-1.5 font-mono text-xs text-muted-foreground transition-colors hover:border-primary/30 hover:text-primary">
                      {slug.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())} →
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* CTA */}
            <div className="mt-10 rounded-2xl border border-primary/20 bg-primary/5 p-6">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="h-4 w-4 text-primary" />
                <span className="font-mono text-xs uppercase tracking-widest text-primary">Still unsure?</span>
              </div>
              <p className="font-display text-lg font-bold">Let our AI Advisor recommend the right tool for your workflow.</p>
              <p className="mt-1 text-sm text-muted-foreground">Describe your engineering discipline, team size, and budget.</p>
              <Link to="/advisor" className="mt-4 inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground hover:opacity-90">
                Ask AI Advisor <ArrowRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="mt-8">
              <Link to="/compare" className="flex items-center gap-2 font-mono text-sm text-muted-foreground hover:text-primary">
                <ArrowLeft className="h-4 w-4" /> Back to all comparisons
              </Link>
            </div>
          </main>

          {/* Sidebar */}
          <aside className="lg:sticky lg:top-24 lg:h-fit space-y-5">
            {/* Other comparisons */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <p className="font-display font-bold mb-4">More Comparisons</p>
              <div className="space-y-3">
                {related.map(c => (
                  <Link key={c.slug} to={`/comparisons/${c.slug}`}
                    className="group flex flex-col rounded-xl border border-border bg-muted/30 p-3 transition-all hover:border-primary/30">
                    <span className={`self-start rounded-md border px-1.5 py-0.5 font-mono text-[10px] badge-${c.category}`}>
                      {categoryBadge[c.category] || c.category}
                    </span>
                    <p className="mt-1.5 text-sm font-medium leading-snug group-hover:text-primary">{c.title}</p>
                    <p className="mt-1 font-mono text-xs text-muted-foreground">{c.readTime} min read</p>
                  </Link>
                ))}
              </div>
            </div>

            {/* Navigation links */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <p className="font-display font-bold mb-3">Explore More</p>
              <div className="space-y-2">
                {[
                  { to: '/tools', label: 'Engineering Tool Directory' },
                  { to: '/ai-tools', label: 'AI Tool Profiles' },
                  { to: '/guides', label: 'Engineering Guides' },
                  { to: '/wizard', label: 'Find the Right Tool' },
                  { to: '/advisor', label: 'AI Engineering Advisor' },
                ].map(l => (
                  <Link key={l.to} to={l.to} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary">
                    <ChevronRight className="h-3.5 w-3.5 shrink-0" />{l.label}
                  </Link>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
