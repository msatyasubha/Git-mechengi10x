import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { CheckCircle, XCircle, ExternalLink, ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { StarRating } from '@/components/ToolCard';
import { getToolBySlug, categories, tools } from '@/data/tools';
import { comparisons as detailedComparisons } from '@/data/comparisons';

const comparisons = [
  { title: 'ChatGPT vs Claude for Engineers', slugs: ['chatgpt', 'claude'], category: 'ai' },
  { title: 'SOLIDWORKS vs Fusion 360', slugs: ['solidworks', 'fusion360'], category: 'cad' },
  { title: 'Fusion 360 vs Onshape', slugs: ['fusion360', 'onshape'], category: 'cad' },
  { title: 'ANSYS vs COMSOL Multiphysics', slugs: ['ansys', 'comsol'], category: 'simulation' },
  { title: 'SimScale vs ANSYS Mechanical', slugs: ['simscale', 'ansys'], category: 'simulation' },
  { title: 'Zapier vs Make vs n8n', slugs: ['zapier', 'make'], category: 'automation' },
  { title: 'Notion vs Jira for Engineering', slugs: ['notion', 'jira'], category: 'management' },
  { title: 'Asana vs Monday.com', slugs: ['asana', 'monday'], category: 'management' },
  { title: 'Coursera vs Udemy for Engineers', slugs: ['coursera', 'udemy'], category: 'learning' },
];

const categoryLabel = {
  ai: 'AI Tools',
  cad: 'CAD & Design',
  simulation: 'Simulation',
  automation: 'Automation',
  management: 'Engineering Management',
  learning: 'Learning',
};

// Feature rows for detailed comparison
function buildFeatureRows(a, b) {
  return [
    {
      section: 'Scores',
      rows: [
        {
          label: 'MechEngi Score',
          valA: `${a.mechengiScore}/100`,
          valB: `${b.mechengiScore}/100`,
          winA: a.mechengiScore > b.mechengiScore,
          winB: b.mechengiScore > a.mechengiScore,
          tie: a.mechengiScore === b.mechengiScore,
        },
        {
          label: 'User Rating',
          valA: `${a.rating} / 5`,
          valB: `${b.rating} / 5`,
          winA: a.rating > b.rating,
          winB: b.rating > a.rating,
          tie: a.rating === b.rating,
        },
        {
          label: 'Review Count',
          valA: a.reviewCount.toLocaleString() + ' reviews',
          valB: b.reviewCount.toLocaleString() + ' reviews',
          winA: a.reviewCount > b.reviewCount,
          winB: b.reviewCount > a.reviewCount,
          tie: false,
          neutral: true,
        },
      ],
    },
    {
      section: 'Pricing',
      rows: [
        {
          label: 'Free Tier',
          valA: a.pricing.free ? (a.pricing.freeLabel || 'Yes') : 'No free tier',
          valB: b.pricing.free ? (b.pricing.freeLabel || 'Yes') : 'No free tier',
          winA: a.pricing.free && !b.pricing.free,
          winB: b.pricing.free && !a.pricing.free,
          tie: a.pricing.free === b.pricing.free,
        },
        {
          label: 'Starting Price',
          valA: a.pricing.paidFrom === 0 ? 'Free' : `$${a.pricing.paidFrom}${a.pricing.paidFrom >= 100 ? '/yr' : '/mo'}`,
          valB: b.pricing.paidFrom === 0 ? 'Free' : `$${b.pricing.paidFrom}${b.pricing.paidFrom >= 100 ? '/yr' : '/mo'}`,
          winA: a.pricing.paidFrom <= b.pricing.paidFrom,
          winB: b.pricing.paidFrom < a.pricing.paidFrom,
          tie: a.pricing.paidFrom === b.pricing.paidFrom,
        },
        {
          label: 'Pricing Model',
          valA: a.pricing.paidLabel || '—',
          valB: b.pricing.paidLabel || '—',
          neutral: true,
        },
      ],
    },
    {
      section: 'Category',
      rows: a.category === b.category ? [
        {
          label: 'Category',
          valA: categoryLabel[a.category],
          valB: categoryLabel[b.category],
          neutral: true,
        },
        {
          label: 'Best For',
          valA: a.useCases.slice(0, 2).join(', '),
          valB: b.useCases.slice(0, 2).join(', '),
          neutral: true,
        },
      ] : [],
    },
  ].filter((s) => s.rows.length > 0);
}

function FeatureRow({ row }) {
  const cellBase = 'px-3 py-3.5 text-sm align-top sm:px-4 sm:py-4';
  return (
    <tr className="border-b border-border last:border-0">
      <td className={`${cellBase} w-1/3 font-mono text-xs text-muted-foreground`}>{row.label}</td>
      <td className={`${cellBase} border-l border-border`}>
        <span className={`flex items-start gap-1.5 ${row.winA && !row.neutral ? 'text-green-400' : ''}`}>
          {row.winA && !row.neutral && <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />}
          {row.valA}
        </span>
      </td>
      <td className={`${cellBase} border-l border-border`}>
        <span className={`flex items-start gap-1.5 ${row.winB && !row.neutral ? 'text-green-400' : ''}`}>
          {row.winB && !row.neutral && <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />}
          {row.valB}
        </span>
      </td>
    </tr>
  );
}

function ComparisonTable({ slugA, slugB }) {
  const a = getToolBySlug(slugA);
  const b = getToolBySlug(slugB);
  if (!a || !b) return null;

  const sections = buildFeatureRows(a, b);

  return (
    <div className="overflow-hidden rounded-2xl border border-border">
      {/* Sticky header */}
      <div className="grid grid-cols-[1fr_1fr_1fr] border-b border-border bg-card/80">
        <div className="p-3 sm:p-4 flex items-end">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Feature</span>
        </div>
        {[a, b].map((tool) => (
          <div key={tool.slug} className="border-l border-border p-3 sm:p-4">
            <div className="flex items-center gap-2">
              <span className="text-xl sm:text-2xl">{tool.logoEmoji}</span>
              <div className="min-w-0">
                <p className="font-display text-sm font-bold leading-tight sm:text-base">{tool.name}</p>
                <p className="hidden font-mono text-xs text-muted-foreground sm:block">{tool.vendor}</p>
              </div>
            </div>
            {/* Score pills */}
            <div className="mt-2 flex flex-wrap gap-1.5">
              <span className="rounded-full bg-primary/10 px-2 py-0.5 font-mono text-[10px] font-semibold text-primary">
                {tool.mechengiScore}/100
              </span>
              <span className="rounded-full bg-amber-500/10 px-2 py-0.5 font-mono text-[10px] text-amber-400">
                {tool.rating}★
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Sections */}
      {sections.map((section) => (
        <div key={section.section}>
          <div className="bg-muted/40 px-3 py-2 sm:px-4">
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{section.section}</span>
          </div>
          <table className="w-full">
            <tbody>
              {section.rows.map((row) => (
                <FeatureRow key={row.label} row={row} />
              ))}
            </tbody>
          </table>
        </div>
      ))}

      {/* Feature bullets comparison */}
      <div className="bg-muted/40 px-3 py-2 sm:px-4">
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Key Features</span>
      </div>
      <div className="grid grid-cols-[1fr_1fr_1fr] border-b border-border">
        <div className="p-3 sm:p-4 font-mono text-xs text-muted-foreground">Features</div>
        {[a, b].map((tool) => (
          <div key={tool.slug} className="border-l border-border p-3 sm:p-4">
            <ul className="space-y-1.5">
              {tool.features.slice(0, 5).map((f, i) => (
                <li key={i} className="flex items-start gap-1.5 text-xs">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* CTA row */}
      <div className="grid grid-cols-[1fr_1fr_1fr] bg-muted/30">
        <div className="p-3 sm:p-4 font-mono text-xs text-muted-foreground flex items-center">Try it</div>
        {[a, b].map((tool, idx) => (
          <div key={tool.slug} className="border-l border-border p-3 sm:p-4">
            <a
              href={tool.affiliateUrl}
              target="_blank"
              rel="noopener noreferrer sponsored"
              className={`flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold transition-all hover:opacity-90 ${
                idx === 0
                  ? 'bg-primary text-primary-foreground'
                  : 'border border-border hover:border-primary/40 hover:text-primary'
              }`}
            >
              Try {tool.name} <ExternalLink className="h-3 w-3 shrink-0" />
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProsConsCards({ slugA, slugB }) {
  const a = getToolBySlug(slugA);
  const b = getToolBySlug(slugB);
  if (!a || !b) return null;

  return (
    <div className="mt-8 grid gap-5 md:grid-cols-2">
      {[a, b].map((tool) => (
        <div key={tool.slug} className="rounded-2xl border border-border bg-card p-5 md:p-6">
          <div className="flex items-center gap-3 border-b border-border pb-4">
            <span className="text-2xl">{tool.logoEmoji}</span>
            <div>
              <p className="font-display text-base font-bold md:text-lg">{tool.name}</p>
              <StarRating rating={tool.rating} />
            </div>
            <span className="ml-auto font-display text-xl font-extrabold text-primary md:text-2xl">{tool.mechengiScore}</span>
          </div>

          <div className="mt-4 space-y-2">
            <p className="font-mono text-[10px] uppercase tracking-wider text-green-400">Pros</p>
            {tool.pros.slice(0, 3).map((p, i) => (
              <div key={i} className="flex items-start gap-2 text-sm">
                <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-green-500" />
                {p}
              </div>
            ))}
            <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-red-400">Cons</p>
            {tool.cons.slice(0, 2).map((c, i) => (
              <div key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />
                {c}
              </div>
            ))}
          </div>

          <div className="mt-5 flex gap-2">
            <Link
              to={`/tools/${tool.slug}`}
              className="flex-1 rounded-lg border border-border py-2 text-center text-sm font-medium transition-colors hover:border-primary/60 hover:text-primary"
            >
              Full Review
            </Link>
            <a
              href={tool.affiliateUrl}
              target="_blank"
              rel="noopener noreferrer sponsored"
              className="flex items-center gap-1 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-all hover:opacity-90"
            >
              Try <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function ComparePage() {
  const [activeComp, setActiveComp] = useState(comparisons[0]);
  const [activeCat, setActiveCat] = useState('all');

  const visibleComps = activeCat === 'all' ? comparisons : comparisons.filter((c) => c.category === activeCat);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Tool Comparisons — MechEngi 10X</title>
        <meta name="description" content="Side-by-side comparisons of the best engineering software tools. SOLIDWORKS vs Fusion 360, ANSYS vs COMSOL, ChatGPT vs Claude, Zapier vs Make, and more." />
      </Helmet>

      <SiteHeader />

      {/* Header */}
      <div className="border-b border-border bg-card/30 py-8 md:py-10">
        <div className="mx-auto max-w-[72rem] px-5">
          <h1 className="font-display text-2xl font-bold sm:text-3xl md:text-4xl">Tool Comparisons</h1>
          <p className="mt-2 text-muted-foreground">
            Side-by-side breakdowns to help you choose the right tool for your engineering workflow.
          </p>

          {/* Category filter */}
          <div className="mt-5 flex flex-wrap gap-2">
            <button
              onClick={() => setActiveCat('all')}
              className={`rounded-full border px-3 py-1.5 font-mono text-xs transition-colors sm:px-4 ${activeCat === 'all' ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'}`}
            >
              All
            </button>
            {categories.slice(1).map((c) => (
              <button
                key={c.id}
                onClick={() => setActiveCat(c.id)}
                className={`rounded-full border px-3 py-1.5 font-mono text-xs transition-colors sm:px-4 ${activeCat === c.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'}`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[72rem] px-5 py-8 md:py-10">
        {/* Comparison selector — scrollable cards */}
        <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {visibleComps.map((c) => {
            const toolA = getToolBySlug(c.slugs[0]);
            const toolB = getToolBySlug(c.slugs[1]);
            const isActive = activeComp.title === c.title;
            return (
              <button
                key={c.title}
                onClick={() => setActiveComp(c)}
                className={`flex items-center gap-3 rounded-xl border p-3.5 text-left transition-all sm:p-4 ${
                  isActive ? 'border-primary bg-primary/5' : 'border-border bg-card hover:border-primary/30'
                }`}
              >
                <span className="text-xl">{toolA?.logoEmoji}</span>
                <span className="text-xs text-muted-foreground font-mono">vs</span>
                <span className="text-xl">{toolB?.logoEmoji}</span>
                <div className="min-w-0 flex-1">
                  <p className="font-display text-sm font-semibold leading-tight">{c.title}</p>
                  <span className={`mt-1 inline-block rounded-md border px-1.5 py-0.5 font-mono text-[10px] uppercase badge-${c.category}`}>
                    {categoryLabel[c.category]}
                  </span>
                </div>
                {isActive && <ArrowRight className="h-4 w-4 shrink-0 text-primary" />}
              </button>
            );
          })}
        </div>

        {/* Active comparison */}
        <div className="mt-10">
          <h2 className="mb-5 font-display text-xl font-bold md:text-2xl">{activeComp.title}</h2>

          {/* Scrollable table wrapper for mobile */}
          <div className="overflow-x-auto rounded-2xl">
            <div className="min-w-[420px]">
              <ComparisonTable slugA={activeComp.slugs[0]} slugB={activeComp.slugs[1]} />
            </div>
          </div>

          {/* Pros & cons cards */}
          <ProsConsCards slugA={activeComp.slugs[0]} slugB={activeComp.slugs[1]} />
        </div>

        {/* Detailed Comparison Articles */}
        <div className="mt-14">
          <h2 className="font-display text-xl font-bold md:text-2xl">In-Depth Comparison Guides</h2>
          <p className="mt-1 text-muted-foreground text-sm">Long-form comparison articles with feature tables, pricing, and engineering-specific recommendations.</p>
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {detailedComparisons.map((c) => (
              <Link key={c.slug} to={`/comparisons/${c.slug}`}
                className="group flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
                <span className={`self-start rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${c.category}`}>
                  {c.category === 'ai' ? 'AI Tools' : c.category === 'cad' ? 'CAD & Design' : c.category}
                </span>
                <h3 className="mt-2 font-display text-base font-semibold leading-snug group-hover:text-primary">{c.title}</h3>
                <p className="mt-2 flex-1 text-xs text-muted-foreground line-clamp-2">{c.excerpt}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="font-mono text-xs text-muted-foreground">{c.readTime} min read</span>
                  <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 transition-all group-hover:translate-x-1 group-hover:text-primary group-hover:opacity-100" />
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* AI Advisor CTA */}
        <div className="mt-12 rounded-2xl border border-primary/20 bg-primary/5 p-6 text-center md:p-8">
          <p className="font-display text-lg font-bold md:text-xl">Still unsure? Let AI decide for you.</p>
          <p className="mt-2 text-sm text-muted-foreground md:text-base">Tell our AI Advisor your workflow and it'll recommend the right tool instantly.</p>
          <Link to="/advisor" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground hover:opacity-90 md:px-8">
            Ask AI Advisor
          </Link>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
