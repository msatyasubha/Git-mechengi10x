import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/HomePage';
import ToolsPage from './pages/ToolsPage';
import ToolDetailPage from './pages/ToolDetailPage';
import ComparePage from './pages/ComparePage';
import GuidesPage from './pages/GuidesPage';
import AdvisorPage from './pages/AdvisorPage';
import AuthPage from './pages/AuthPage';
import JobsPage from './pages/JobsPage';
import WizardPage from './pages/WizardPage';
import AboutPage from './pages/AboutPage';
import LegalPage from './pages/LegalPage';
import FreeToolsPage from './pages/FreeToolsPage';
import AIToolsPage from './pages/AIToolsPage';
import AIToolProfilePage from './pages/AIToolProfilePage';
import ComparisonDetailPage from './pages/ComparisonDetailPage';
import ReviewsPage from './pages/ReviewsPage';
import { Toaster } from '@/components/ui/toaster';

function App() {
    return (
        <Router>
            <ScrollToTop />
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/tools" element={<ToolsPage />} />
                <Route path="/tools/:slug" element={<ToolDetailPage />} />
                <Route path="/ai-tools" element={<AIToolsPage />} />
                <Route path="/ai-tools/:slug" element={<AIToolProfilePage />} />
                <Route path="/reviews" element={<ReviewsPage />} />
                <Route path="/compare" element={<ComparePage />} />
                <Route path="/comparisons/:slug" element={<ComparisonDetailPage />} />
                <Route path="/guides" element={<GuidesPage />} />
                <Route path="/advisor" element={<AdvisorPage />} />
                <Route path="/jobs" element={<JobsPage />} />
                <Route path="/wizard" element={<WizardPage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/legal" element={<LegalPage />} />
                <Route path="/free-tools" element={<FreeToolsPage />} />
                <Route path="/login" element={<AuthPage mode="login" />} />
                <Route path="/signup" element={<AuthPage mode="signup" />} />
            </Routes>
            <Toaster />
        </Router>
    );
}

export default App;
