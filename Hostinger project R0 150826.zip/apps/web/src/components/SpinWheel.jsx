import { useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, useAnimation } from 'framer-motion';
import { Zap } from 'lucide-react';

const SEGMENTS = [
  { id: 'ai', label: 'AI Tools', color: '#3b82f6', bg: '#1e3a5f', route: '/tools?cat=ai', description: 'Discover the best AI tools for engineers' },
  { id: 'cad', label: 'CAD & Design', color: '#a855f7', bg: '#3b1f5e', route: '/tools?cat=cad', description: 'Find the perfect CAD software for your workflow' },
  { id: 'simulation', label: 'Simulation', color: '#06b6d4', bg: '#0c3544', route: '/tools?cat=simulation', description: 'Explore FEA, CFD, and multiphysics tools' },
  { id: 'automation', label: 'Automation', color: '#22c55e', bg: '#0f3320', route: '/tools?cat=automation', description: 'Automate your engineering workflows' },
  { id: 'management', label: 'Management', color: '#f59e0b', bg: '#3d2a06', route: '/tools?cat=management', description: 'Manage projects and teams effectively' },
  { id: 'learning', label: 'Learning', color: '#ec4899', bg: '#3d1228', route: '/tools?cat=learning', description: 'Upskill with the best engineering courses' },
  { id: 'jobs', label: 'Jobs', color: '#f97316', bg: '#3d1a06', route: '/jobs', description: 'Find engineering job opportunities' },
];

const TOTAL = SEGMENTS.length;
const SEGMENT_ANGLE = 360 / TOTAL;

function polarToCartesian(cx, cy, r, angleDeg) {
  const rad = ((angleDeg - 90) * Math.PI) / 180;
  return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
}

function buildArcPath(cx, cy, r, startAngle, endAngle) {
  const s = polarToCartesian(cx, cy, r, startAngle);
  const e = polarToCartesian(cx, cy, r, endAngle);
  const largeArc = endAngle - startAngle > 180 ? 1 : 0;
  return `M ${cx} ${cy} L ${s.x} ${s.y} A ${r} ${r} 0 ${largeArc} 1 ${e.x} ${e.y} Z`;
}

export default function SpinWheel() {
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState(null);
  const [totalDeg, setTotalDeg] = useState(0);
  const controls = useAnimation();
  const navigate = useNavigate();
  const spinCountRef = useRef(0);

  const CX = 160, CY = 160, R = 148, INNER_R = 34;

  const spin = useCallback(async () => {
    if (spinning) return;
    setSpinning(true);
    setResult(null);

    const winIndex = Math.floor(Math.random() * TOTAL);
    const extraSpins = 5 + Math.floor(Math.random() * 4); // 5–8 full rotations
    // The "pointer" is at top (0°). Segment i starts at i * SEGMENT_ANGLE.
    // To land segment winIndex at the top: rotate so that segment center aligns with top.
    const segCenter = winIndex * SEGMENT_ANGLE + SEGMENT_ANGLE / 2;
    const neededRotation = 360 - segCenter;
    spinCountRef.current += extraSpins * 360 + neededRotation;
    // Snap to a value that avoids drift accumulation
    const target = Math.ceil(spinCountRef.current / 360) * 360 - (360 - neededRotation);
    spinCountRef.current = target;

    await controls.start({
      rotate: target,
      transition: { duration: 4 + Math.random() * 1.5, ease: [0.08, 0.82, 0.17, 1] },
    });

    setResult(SEGMENTS[winIndex]);
    setSpinning(false);
  }, [spinning, controls]);

  return (
    <div className="flex flex-col items-center gap-6">
      {/* Wheel */}
      <div className="relative">
        {/* Pointer triangle at top */}
        <div
          className="pointer-events-none absolute left-1/2 top-0 z-10 -translate-x-1/2 -translate-y-1"
          style={{ filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.6))' }}
        >
          <svg width="20" height="24" viewBox="0 0 20 24">
            <polygon points="10,22 0,0 20,0" fill="white" />
          </svg>
        </div>

        <motion.div animate={controls} style={{ originX: '50%', originY: '50%' }}>
          <svg width="320" height="320" viewBox="0 0 320 320">
            {/* Segments */}
            {SEGMENTS.map((seg, i) => {
              const start = i * SEGMENT_ANGLE;
              const end = start + SEGMENT_ANGLE;
              const midAngle = start + SEGMENT_ANGLE / 2;
              const labelPos = polarToCartesian(CX, CY, R * 0.68, midAngle);
              const rad = ((midAngle - 90) * Math.PI) / 180;
              return (
                <g key={seg.id}>
                  <path
                    d={buildArcPath(CX, CY, R, start, end)}
                    fill={seg.bg}
                    stroke="hsl(220 22% 12%)"
                    strokeWidth="2"
                  />
                  {/* Colored outer arc accent */}
                  <path
                    d={buildArcPath(CX, CY, R, start + 1, end - 1)}
                    fill="none"
                    stroke={seg.color}
                    strokeWidth="3"
                    opacity="0.7"
                    style={{ pointerEvents: 'none' }}
                  />
                  <text
                    x={labelPos.x}
                    y={labelPos.y}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    transform={`rotate(${midAngle}, ${labelPos.x}, ${labelPos.y})`}
                    fill={seg.color}
                    fontSize="11"
                    fontFamily="'JetBrains Mono', monospace"
                    fontWeight="600"
                    style={{ pointerEvents: 'none', userSelect: 'none' }}
                  >
                    {seg.label}
                  </text>
                </g>
              );
            })}
            {/* Center circle */}
            <circle cx={CX} cy={CY} r={INNER_R} fill="hsl(222 45% 6%)" stroke="hsl(220 22% 22%)" strokeWidth="2" />
            <circle cx={CX} cy={CY} r={INNER_R - 6} fill="hsl(217 91% 60% / 0.12)" stroke="hsl(217 91% 60% / 0.4)" strokeWidth="1.5" />
          </svg>
        </motion.div>

        {/* Center Zap icon overlay */}
        <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <Zap className="h-6 w-6 text-primary" />
        </div>

        {/* Outer glow ring */}
        <div className="pointer-events-none absolute inset-0 rounded-full"
          style={{ boxShadow: '0 0 32px hsl(217 91% 60% / 0.2)', borderRadius: '50%' }} />
      </div>

      {/* Spin button */}
      <button
        onClick={spin}
        disabled={spinning}
        className="glow-primary relative overflow-hidden rounded-2xl bg-primary px-10 py-4 font-display text-lg font-bold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.97] disabled:opacity-60 disabled:cursor-not-allowed"
      >
        {spinning ? (
          <span className="flex items-center gap-2">
            <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
            Spinning…
          </span>
        ) : (
          result ? 'Spin Again' : 'Spin the Wheel'
        )}
      </button>

      {/* Result card */}
      {result && !spinning && (
        <motion.div
          initial={{ opacity: 0, y: 12, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          className="w-full max-w-sm rounded-2xl border p-5 text-center"
          style={{ borderColor: result.color + '55', background: result.bg + '88' }}
        >
          <p className="font-mono text-xs uppercase tracking-widest" style={{ color: result.color }}>
            You landed on
          </p>
          <p className="mt-1 font-display text-2xl font-extrabold" style={{ color: result.color }}>
            {result.label}
          </p>
          <p className="mt-2 text-sm text-muted-foreground">{result.description}</p>
          <button
            onClick={() => navigate(result.route)}
            className="mt-4 inline-flex items-center gap-2 rounded-xl px-6 py-2.5 font-semibold text-sm transition-all hover:opacity-90 active:scale-[0.98]"
            style={{ background: result.color, color: '#0a0e1a' }}
          >
            Explore {result.label} →
          </button>
        </motion.div>
      )}
    </div>
  );
}
