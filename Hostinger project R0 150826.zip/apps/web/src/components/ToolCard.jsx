import { Link } from 'react-router-dom';
import { Star, ExternalLink } from 'lucide-react';

const categoryLabel = {
  ai: 'AI Tools',
  cad: 'CAD & Design',
  simulation: 'Simulation',
  automation: 'Automation',
  management: 'Management',
  learning: 'Learning',
};

function StarRating({ rating }) {
  return (
    <span className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          className={`h-3.5 w-3.5 ${s <= Math.round(rating) ? 'star-filled fill-current' : 'star-empty'}`}
          strokeWidth={0}
          fill="currentColor"
        />
      ))}
    </span>
  );
}

export default function ToolCard({ tool, compact = false }) {
  return (
    <div className="group relative flex flex-col rounded-xl border border-border bg-card p-4 transition-all duration-200 hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5 sm:p-5">
      {/* Badge */}
      {tool.badge && (
        <span className="absolute right-4 top-4 rounded-full bg-accent/15 px-2.5 py-0.5 font-mono text-[10px] font-medium uppercase tracking-wider text-accent">
          {tool.badge}
        </span>
      )}

      {/* Header */}
      <div className="flex items-start gap-3">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-border bg-muted text-2xl">
          {tool.logoEmoji}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${tool.category}`}>
              {categoryLabel[tool.category]}
            </span>
          </div>
          <h3 className="mt-1 font-display text-base font-semibold leading-tight">
            {tool.name}
          </h3>
          <p className="text-xs text-muted-foreground">{tool.vendor}</p>
        </div>
      </div>

      {/* Rating */}
      <div className="mt-3 flex items-center gap-2">
        <StarRating rating={tool.rating} />
        <span className="font-mono text-xs font-medium text-foreground">{tool.rating}</span>
        <span className="text-xs text-muted-foreground">({tool.reviewCount.toLocaleString()} reviews)</span>
      </div>

      {/* MechEngi Score */}
      <div className="mt-1 flex items-center gap-2">
        <span className="font-mono text-xs text-muted-foreground">MechEngi Score</span>
        <span className="font-mono text-xs font-semibold text-primary">{tool.mechengiScore}/100</span>
      </div>

      {/* Tagline */}
      {!compact && (
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground line-clamp-2">{tool.tagline}</p>
      )}

      {/* Pricing */}
      <div className="mt-3 flex items-center gap-2">
        {tool.pricing.free && (
          <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] font-medium text-green-400">
            Free tier
          </span>
        )}
        {tool.pricing.paidFrom > 0 ? (
          <span className="font-mono text-xs text-muted-foreground">
            From <span className="text-foreground">${tool.pricing.paidFrom}</span>
            {tool.pricing.paidFrom >= 100 ? '/yr' : '/mo'}
          </span>
        ) : (
          <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] font-medium text-green-400">
            Free forever
          </span>
        )}
      </div>

      {/* Actions */}
      <div className="mt-4 flex gap-2">
        <Link
          to={`/tools/${tool.slug}`}
          className="flex-1 rounded-lg border border-border py-2 text-center text-sm font-medium transition-colors hover:border-primary/60 hover:bg-primary/5 hover:text-primary"
        >
          View Review
        </Link>
        <a
          href={tool.affiliateUrl}
          target="_blank"
          rel="noopener noreferrer sponsored"
          className="flex items-center gap-1 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
        >
          Try <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>
    </div>
  );
}

export { StarRating };
