import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Zap, Menu, X, ChevronDown, ArrowRight } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { navCategories } from '@/data/tools';

const navLinks = [
  { to: '/tools', label: 'Tools' },
  { to: '/ai-tools', label: 'AI Profiles' },
  { to: '/wizard', label: 'Find a Tool' },
  { to: '/compare', label: 'Compare' },
  { to: '/guides', label: 'Guides' },
  { to: '/jobs', label: 'Jobs' },
  { to: '/advisor', label: 'AI Advisor' },
];

export default function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-[90rem] items-center justify-between px-5">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold shrink-0">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary">
            <Zap className="h-4 w-4 text-primary-foreground" strokeWidth={2.5} />
          </span>
          <span>MechEngi<span className="text-primary"> 10X</span></span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-0.5 md:flex">
          {/* Tools megamenu trigger */}
          <div
            className="relative"
            onMouseEnter={() => setToolsOpen(true)}
            onMouseLeave={() => setToolsOpen(false)}
          >
            <button className="flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">
              Tools <ChevronDown className="h-3.5 w-3.5" />
            </button>
            {toolsOpen && (
              <div className="absolute left-0 top-full mt-1 w-72 rounded-xl border border-border bg-card p-2 shadow-xl shadow-black/20">
                <Link
                  to="/tools"
                  className="mb-1 flex items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold text-primary hover:bg-primary/10"
                  onClick={() => setToolsOpen(false)}
                >
                  All Tools Directory <ArrowRight className="h-3.5 w-3.5" />
                </Link>
                <Link
                  to="/ai-tools"
                  className="mb-1 flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium text-accent hover:bg-accent/10"
                  onClick={() => setToolsOpen(false)}
                >
                  AI Tool Profiles (Phase 1) <ArrowRight className="h-3.5 w-3.5" />
                </Link>
                <div className="my-1.5 h-px bg-border" />
                {navCategories.map((cat) => (
                  <Link
                    key={cat.id}
                    to={`/tools?cat=${cat.id}`}
                    onClick={() => setToolsOpen(false)}
                    className="flex items-center gap-2.5 rounded-lg px-3 py-2 transition-colors hover:bg-muted"
                  >
                    <span className="text-base">{cat.icon}</span>
                    <span className="text-sm font-medium">{cat.label}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {navLinks.slice(1).map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  isActive ? 'bg-muted text-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        {/* Desktop auth + CTA */}
        <div className="hidden items-center gap-3 md:flex">
          {user ? (
            <div className="flex items-center gap-3">
              <span className="max-w-[160px] truncate text-sm text-muted-foreground">{user.email}</span>
              <button
                onClick={handleLogout}
                className="rounded-md border border-border px-4 py-1.5 text-sm font-medium transition-colors hover:border-foreground"
              >
                Sign out
              </button>
            </div>
          ) : (
            <>
              <Link
                to="/login"
                className="rounded-md px-4 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                Sign in
              </Link>
              <Link
                to="/tools"
                className="glow-primary rounded-md bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
              >
                Find a Tool
              </Link>
            </>
          )}
        </div>

        {/* Mobile hamburger */}
        <button
          className="rounded-md p-2 text-muted-foreground md:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="border-t border-border bg-background/95 px-5 py-4 md:hidden">
          {/* Category shortcuts */}
          <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Browse by Category</p>
          <div className="mb-3 grid grid-cols-2 gap-1.5">
            {navCategories.map((cat) => (
              <Link
                key={cat.id}
                to={`/tools?cat=${cat.id}`}
                className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground"
                onClick={() => setOpen(false)}
              >
                <span>{cat.icon}</span>
                <span className="truncate text-xs font-medium">{cat.label}</span>
              </Link>
            ))}
          </div>
          <div className="h-px bg-border" />
          <nav className="mt-3 flex flex-col gap-1">
            {navLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="rounded-md px-3 py-2.5 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
                onClick={() => setOpen(false)}
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="mt-4 flex flex-col gap-2 border-t border-border pt-4">
            {user ? (
              <button
                onClick={() => { handleLogout(); setOpen(false); }}
                className="rounded-md border border-border px-4 py-2 text-sm font-medium"
              >
                Sign out
              </button>
            ) : (
              <>
                <Link to="/login" className="rounded-md px-4 py-2 text-center text-sm font-medium text-muted-foreground" onClick={() => setOpen(false)}>
                  Sign in
                </Link>
                <Link to="/tools" className="rounded-md bg-primary px-4 py-2 text-center text-sm font-semibold text-primary-foreground" onClick={() => setOpen(false)}>
                  Find a Tool
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
