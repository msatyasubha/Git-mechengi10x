import { Link } from 'react-router-dom';
import { Zap } from 'lucide-react';

const cols = [
  {
    heading: 'Tools',
    links: [
      { to: '/tools?cat=ai', label: 'AI Tools' },
      { to: '/tools?cat=cad', label: 'CAD & Design' },
      { to: '/tools?cat=simulation', label: 'Simulation' },
      { to: '/tools?cat=automation', label: 'Automation' },
      { to: '/tools?cat=management', label: 'Engineering Management' },
      { to: '/tools?cat=learning', label: 'Learning' },
      { to: '/free-tools', label: 'Free Tools & Calculators' },
    ],
  },
  {
    heading: 'AI Tool Profiles',
    links: [
      { to: '/ai-tools', label: 'All AI Tool Profiles' },
      { to: '/ai-tools/chatgpt-for-engineering', label: 'ChatGPT for Engineers' },
      { to: '/ai-tools/claude-for-engineering', label: 'Claude for Engineers' },
      { to: '/ai-tools/gemini-for-engineering', label: 'Google Gemini for Engineers' },
      { to: '/ai-tools/copilot-for-engineering', label: 'GitHub Copilot' },
      { to: '/ai-tools/perplexity-for-engineering', label: 'Perplexity AI for Engineers' },
    ],
  },
  {
    heading: 'Resources',
    links: [
      { to: '/wizard', label: 'Find the Right Tool' },
      { to: '/compare', label: 'Tool Comparisons' },
      { to: '/guides', label: 'Engineering Guides' },
      { to: '/jobs', label: 'Engineering Jobs' },
      { to: '/advisor', label: 'AI Engineering Advisor' },
    ],
  },
  {
    heading: 'Company',
    links: [
      { to: '/about', label: 'About MechEngi 10X' },
      { to: '/about#methodology', label: 'Review Methodology' },
      { to: '/legal', label: 'Affiliate Disclosure' },
      { to: '/legal?tab=1', label: 'Privacy Policy' },
      { to: '/legal?tab=2', label: 'Terms of Use' },
      { to: '/signup', label: 'Create Account' },
      { to: '/login', label: 'Sign In' },
    ],
  },
];

export default function SiteFooter() {
  return (
    <footer className="border-t border-border bg-card/40">
      <div className="mx-auto max-w-[90rem] px-5 py-14">
        <div className="grid gap-10 md:grid-cols-[2fr_1fr_1fr_1fr_1fr]">
          {/* Brand */}
          <div>
            <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold">
              <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary">
                <Zap className="h-4 w-4 text-primary-foreground" strokeWidth={2.5} />
              </span>
              <span>MechEngi<span className="text-primary"> 10X</span></span>
            </Link>
            <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-primary">AI &amp; Engineering Tool Discovery Platform</p>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-muted-foreground">
              The independent resource for engineers discovering, comparing, and choosing the right software tools.
              Expert reviews. Honest ratings. Vendor-neutral.
            </p>
            <div className="mt-4 space-y-1">
              <p className="text-xs text-muted-foreground/60">
                <Link to="/legal" className="hover:text-muted-foreground underline underline-offset-2">Affiliate disclosure</Link>:
                {' '}Some links earn us a commission at no cost to you.
              </p>
              <p className="text-xs text-muted-foreground/60">
                Tool scores are independent of affiliate relationships.
              </p>
            </div>
          </div>

          {/* Nav columns */}
          {cols.map((col) => (
            <div key={col.heading}>
              <h3 className="mb-4 font-display text-sm font-semibold uppercase tracking-wider text-foreground/60">
                {col.heading}
              </h3>
              <ul className="flex flex-col gap-2.5">
                {col.links.map((l) => (
                  <li key={l.to}>
                    <Link
                      to={l.to}
                      className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-4 border-t border-border pt-8 text-xs text-muted-foreground sm:flex-row sm:items-center">
          <p>&copy; {new Date().getFullYear()} MechEngi 10X. All rights reserved.</p>
          <div className="flex flex-wrap gap-4">
            <Link to="/about" className="hover:text-foreground">About</Link>
            <Link to="/legal" className="hover:text-foreground">Disclosure</Link>
            <Link to="/legal?tab=1" className="hover:text-foreground">Privacy</Link>
            <Link to="/legal?tab=2" className="hover:text-foreground">Terms</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
