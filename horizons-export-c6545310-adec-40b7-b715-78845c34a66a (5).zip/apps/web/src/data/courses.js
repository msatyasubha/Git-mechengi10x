export const courses = [
  {
    slug: 'ai-for-mechanical-engineers',
    title: 'AI for Mechanical Engineers',
    subtitle: 'A practical, hands-on introduction to using LLMs, copilots, and AI tools in daily engineering work.',
    level: 'Beginner',
    duration: '6 hours',
    lessons: 24,
    price: 149,
    rating: 4.8,
    students: 1240,
    category: 'AI Tools',
    accent: 'badge-ai',
    icon: '🤖',
    cover: 'linear-gradient(135deg, hsl(217 91% 60%), hsl(217 91% 40%))',
    description:
      'Stop watching AI from the sidelines. This course takes you from "what is ChatGPT?" to confidently using AI tools for calculations, documentation, design ideation, and code — all in the context of real mechanical engineering tasks.',
    outcomes: [
      'Write engineering prompts that produce reliable, citable output',
      'Use ChatGPT and Claude for unit analysis, derivations, and documentation',
      'Generate and debug MATLAB / Python code with AI copilots',
      'Build a personal AI workflow that saves 5+ hours per week',
    ],
    modules: [
      {
        title: 'Foundations of AI for Engineers',
        lessons: [
          'How LLMs actually work (no math required)',
          'What AI can and cannot do for mechanical engineering',
          'Setting up your AI toolkit: ChatGPT, Claude, Copilot',
          'Prompt anatomy: context, instruction, format, constraint',
        ],
      },
      {
        title: 'AI for Calculations & Analysis',
        lessons: [
          'Unit analysis and dimensional checking with AI',
          'Deriving formulas step-by-step with verification',
          'Sanity-checking FEA and hand-calc results',
          'When to trust AI math — and when not to',
        ],
      },
      {
        title: 'AI for Documentation & Reports',
        lessons: [
          'Drafting engineering reports from bullet points',
          'Summarizing long specs and standards',
          'Generating test plans and procedures',
          'Creating technical diagrams with AI',
        ],
      },
      {
        title: 'AI for Code & Automation',
        lessons: [
          'Generating MATLAB scripts from a problem statement',
          'Python for engineering data with Copilot',
          'Debugging and refactoring engineering code',
          'Building a reusable AI prompt library',
        ],
      },
      {
        title: 'Putting It All Together',
        lessons: [
          'A full worked example: from problem to report',
          'Building your personal AI workflow',
          'Avoiding common AI pitfalls',
          'Staying current as AI tools evolve',
        ],
      },
    ],
    instructor: { name: 'Dr. Sarah Chen', role: 'Former Tesla engineer, MechEngi 10X editor' },
  },
  {
    slug: 'cad-productivity-with-onshape',
    title: 'CAD Productivity with Onshape',
    subtitle: 'Master cloud-native CAD and ship designs faster with parametric modeling best practices.',
    level: 'Intermediate',
    duration: '8 hours',
    lessons: 32,
    price: 199,
    rating: 4.9,
    students: 860,
    category: 'CAD',
    accent: 'badge-cad',
    icon: '📐',
    cover: 'linear-gradient(135deg, hsl(280 80% 60%), hsl(280 80% 40%))',
    description:
      'Onshape changes how teams collaborate on CAD. This course covers parametric modeling, assemblies, version control, and the workflows that make cloud CAD dramatically faster than desktop CAD.',
    outcomes: [
      'Build robust parametric models that do not break on edits',
      'Manage assemblies and mates efficiently',
      'Use Onshape versioning for real team collaboration',
      'Apply DFM best practices directly in your CAD workflow',
    ],
    modules: [
      {
        title: 'Onshape Fundamentals',
        lessons: [
          'The cloud CAD mindset',
          'Sketching with intent',
          'Parametric feature strategy',
          'Avoiding the "dead model" trap',
        ],
      },
      {
        title: 'Advanced Modeling',
        lessons: [
          'Multi-part part studios',
          'Configurations and variables',
          'In-context editing',
          'Derived and mirrored parts',
        ],
      },
      {
        title: 'Assemblies & Mates',
        lessons: [
          'Mate strategy for mechanisms',
          'Subassemblies and flexible parts',
          'Interference detection',
          'Assembly performance tuning',
        ],
      },
      {
        title: 'Collaboration & Version Control',
        lessons: [
          'Branching and merging designs',
          'Release management',
          'Simultaneous editing workflows',
          'Commenting and review cycles',
        ],
      },
      {
        title: 'Production-Ready CAD',
        lessons: [
          'DFM checks in Onshape',
          'Drawings and BOMs',
          'Exporting for manufacturing',
          'Integrating with PLM and ERP',
        ],
      },
    ],
    instructor: { name: 'Marcus Lindqvist', role: '15 years CAD experience, ex-Dassault' },
  },
  {
    slug: 'fea-essentials-with-ansys',
    title: 'FEA Essentials with ANSYS',
    subtitle: 'Set up, run, and interpret linear static analyses you can actually trust.',
    level: 'Intermediate',
    duration: '10 hours',
    lessons: 38,
    price: 249,
    rating: 4.7,
    students: 540,
    category: 'Simulation',
    accent: 'badge-simulation',
    icon: '🔬',
    cover: 'linear-gradient(135deg, hsl(190 80% 50%), hsl(190 80% 35%))',
    description:
      'Finite element analysis is powerful — and easy to get wrong. This course teaches you to set up clean meshes, apply realistic loads, and critically interpret results so your simulations inform real decisions.',
    outcomes: [
      'Choose the right element type for your problem',
      'Build convergence-quality meshes',
      'Apply realistic boundary conditions and loads',
      'Validate FEA results against hand calculations',
    ],
    modules: [
      {
        title: 'FEA First Principles',
        lessons: [
          'What FEA actually solves',
          'Stiffness, DOF, and the matrix underneath',
          'Linear static assumptions and limits',
          'Reading ANSYS results critically',
        ],
      },
      {
        title: 'Meshing Mastery',
        lessons: [
          'Element types and when to use each',
          'Mesh refinement and convergence',
          'Defeaturing for analysis',
          'Mesh quality metrics',
        ],
      },
      {
        title: 'Loads & Boundary Conditions',
        lessons: [
          'Realistic constraints vs. over-constraint',
          'Contact and connection modeling',
          'Load paths and reaction forces',
          'Symmetry exploitation',
        ],
      },
      {
        title: 'Interpreting Results',
        lessons: [
          'Stress concentrations vs. singularities',
          'Safety factors and failure criteria',
          'Hand-calc validation',
          'Reporting results to non-FEA engineers',
        ],
      },
      {
        title: 'Worked Case Studies',
        lessons: [
          'Bracket analysis start to finish',
          'Thermal-stress coupling basics',
          'Assembly-level analysis',
          'Common mistakes and how to spot them',
        ],
      },
    ],
    instructor: { name: 'Dr. Raj Patel', role: 'PhD in computational mechanics, ANSYS certified' },
  },
  {
    slug: 'engineering-automation-with-python',
    title: 'Engineering Automation with Python',
    subtitle: 'Automate the boring 20% of your job — file handling, data parsing, report generation, and more.',
    level: 'Beginner',
    duration: '7 hours',
    lessons: 28,
    price: 179,
    rating: 4.8,
    students: 1530,
    category: 'Automation',
    accent: 'badge-automation',
    icon: '⚙️',
    cover: 'linear-gradient(135deg, hsl(150 70% 45%), hsl(150 70% 30%))',
    description:
      'Engineers waste hours on repetitive file and data tasks. This course teaches practical Python automation — no computer science degree required — so you can reclaim that time for real engineering.',
    outcomes: [
      'Write Python scripts to parse and clean engineering data',
      'Automate batch file renaming, conversion, and organization',
      'Generate reports and plots automatically',
      'Schedule and share your automation tools',
    ],
    modules: [
      {
        title: 'Python for Engineers',
        lessons: [
          'Setting up Python without the pain',
          'Core syntax you actually need',
          'Working with files and paths',
          'Virtual environments explained simply',
        ],
      },
      {
        title: 'Data Handling',
        lessons: [
          'Reading CSV, Excel, and text data',
          'pandas for engineering datasets',
          'Cleaning messy exported data',
          'Joining and filtering tables',
        ],
      },
      {
        title: 'Automation Patterns',
        lessons: [
          'Batch processing files in a folder',
          'Renaming and organizing outputs',
          'Calling command-line tools from Python',
          'Logging and error handling',
        ],
      },
      {
        title: 'Reports & Plots',
        lessons: [
          'Auto-generating plots with matplotlib',
          'Filling report templates',
          'Exporting to PDF and Excel',
          'Building a one-click report script',
        ],
      },
      {
        title: 'Sharing Your Tools',
        lessons: [
          'Packaging scripts for colleagues',
          'Scheduling with cron / Task Scheduler',
          'Building a simple CLI',
          'Where to go next',
        ],
      },
    ],
    instructor: { name: 'Elena Rossi', role: 'Automation engineer, ex-ABB' },
  },
  {
    slug: 'engineering-project-management',
    title: 'Engineering Project Management',
    subtitle: 'Lead technical projects that ship on time — without becoming a full-time manager.',
    level: 'Intermediate',
    duration: '5 hours',
    lessons: 20,
    price: 129,
    rating: 4.6,
    students: 720,
    category: 'Management',
    accent: 'badge-management',
    icon: '📊',
    cover: 'linear-gradient(135deg, hsl(38 96% 52%), hsl(38 96% 38%))',
    description:
      'Most engineering projects slip because of poor scope and communication, not poor engineering. This course gives you the lightweight PM skills to keep technical projects on track while staying hands-on.',
    outcomes: [
      'Define and control project scope',
      'Build realistic engineering schedules',
      'Run effective technical standups and reviews',
      'Track risk and communicate status up',
    ],
    modules: [
      {
        title: 'Scope & Requirements',
        lessons: [
          'Writing a usable project brief',
          'Turning requirements into tasks',
          'Scope creep and how to contain it',
          'Stakeholder alignment',
        ],
      },
      {
        title: 'Scheduling',
        lessons: [
          'Estimating engineering work honestly',
          'Critical path for technical projects',
          'Buffering for unknowns',
          'Gantt vs. kanban for engineering',
        ],
      },
      {
        title: 'Execution',
        lessons: [
          'Running technical standups',
          'Design reviews that work',
          'Decision logs and why they matter',
          'Handling blocked tasks',
        ],
      },
      {
        title: 'Risk & Reporting',
        lessons: [
          'Identifying engineering risks early',
          'Status reports engineers respect',
          'Escalating without drama',
          'Post-mortems that improve things',
        ],
      },
    ],
    instructor: { name: 'James Okafor', role: 'Engineering manager, ex-SpaceX' },
  },
];

export function getCourseBySlug(slug) {
  return courses.find((c) => c.slug === slug);
}
