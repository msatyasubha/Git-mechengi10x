/**
 * Unified 100-point MechEngi Score framework.
 *
 * This is the SINGLE source of truth for the evaluation methodology, the
 * /methodology page, and the MechEngiScoreBreakdown component. The eight
 * weighted categories sum to exactly 100 points.
 *
 * IMPORTANT — honesty contract:
 * No per-category or total numerical scores are displayed for any tool unless
 * they are backed by documented, reproducible benchmark data. Until that data
 * exists, the breakdown renders an explicit "Not Yet Rated — Awaiting
 * Benchmark Data" state. The framework itself is published and transparent;
 * the scores are not invented.
 */

export const SCORE_CATEGORIES = [
  {
    id: 'engineering-effectiveness',
    name: 'Engineering Effectiveness',
    max: 20,
    weight: '20%',
    summary: 'Does the tool reliably solve the core engineering task it targets?',
    description:
      'Measures whether the tool produces correct, usable engineering output for its target task — accurate geometry, valid mesh/solve results, correct code, or reliable automation. Evaluated against representative engineering workloads, not marketing feature lists. A tool that fails on real models cannot recover here, regardless of feature breadth.',
    howVerified:
      'Scored only when representative engineering test cases have been run and documented. Without hands-on test output, this category is marked "Not yet rated".',
  },
  {
    id: 'reliability-maturity',
    name: 'Reliability & Maturity',
    max: 15,
    weight: '15%',
    summary: 'Stability, crash resistance, and track record on real projects.',
    description:
      'Assesses stability under load, frequency of regressions, large-assembly/large-mesh behaviour, and the maturity of the release cycle. Draws on documented version history and publicly reported stability — never on assumed reliability.',
    howVerified:
      'Based on documented release notes, public issue trackers, and stated long-term support commitments. Where these are not publicly available, the category is marked "Not yet rated".',
  },
  {
    id: 'api-extensibility',
    name: 'API Extensibility & CAD Automation',
    max: 15,
    weight: '15%',
    summary: 'Scripting surface for automation, macros, and CAD-to-ERP pipelines.',
    description:
      'Evaluates the documented programmatic surface — VBA/C#/Python APIs, REST endpoints, webhooks, and macro recorders — and whether automation is turnkey or API-only. A tool with no scripting API cannot participate in an automated QA or CAD-to-ERP pipeline.',
    howVerified:
      'Derived from each vendor\u2019s official API documentation. Automation capability is reported as a descriptive level, never as an invented numeric star rating.',
  },
  {
    id: 'tco-value',
    name: 'Total Cost of Ownership & Value',
    max: 15,
    weight: '15%',
    summary: 'Real cost including seats, add-ins, training, and hidden fees.',
    description:
      'Looks beyond sticker price to per-seat minimums, paid add-ins for CAM/FEA, network licence servers, mandatory PLM bundles, training, and support. Pricing is published in USD; INR is an approximate conversion. Where a vendor only quotes "contact sales", we say so plainly rather than inventing a number.',
    howVerified:
      'Pricing is taken from official vendor pricing pages at time of review and labelled with the verification date. Unverifiable or "contact sales" pricing is stated as such.',
  },
  {
    id: 'security-data',
    name: 'Security & Data Control',
    max: 10,
    weight: '10%',
    summary: 'Deployment model, data residency, and compliance posture.',
    description:
      'Considers cloud vs. local deployment options, data residency, encryption, SSO/SAML, and stated compliance certifications (ISO/IEC 27001, SOC 2). Security specifics vary by licence tier and release and are not independently audited by MechEngi 10X.',
    howVerified:
      'Reported only from vendor-published security and compliance documentation. Where a vendor has not published this, the category shows "Not documented" rather than a guess.',
  },
  {
    id: 'industry-adoption',
    name: 'Industry Adoption & Standards Compliance',
    max: 10,
    weight: '10%',
    summary: 'Real-world adoption and standards/format support.',
    description:
      'Reflects genuine industry adoption (supply-chain file-format requirements, OEM mandates) and support for relevant standards — STEP (ISO 10303), IGES, DXF/DWG, GD&T, and domain standards. Adoption is evidenced by market presence, not claimed.',
    howVerified:
      'Based on publicly verifiable format support and documented industry usage. Adoption claims without public evidence are not scored.',
  },
  {
    id: 'ux-learning',
    name: 'User Experience & Learning Curve',
    max: 10,
    weight: '10%',
    summary: 'Interface quality and time-to-productivity.',
    description:
      'Assesses interface clarity, documentation discoverability, and the learning curve a practising engineer faces. Subjective impressions are labelled as such; we do not present opinion as measurement.',
    howVerified:
      'Based on documented onboarding materials and stated training requirements. Hands-on UX scoring requires direct testing and is marked "Not yet rated" until performed.',
  },
  {
    id: 'documentation-support',
    name: 'Documentation & Support',
    max: 5,
    weight: '5%',
    summary: 'Quality of docs, community, and vendor support channels.',
    description:
      'Evaluates the breadth and accuracy of official documentation, community/forum health, and available support tiers. Community size is reported descriptively, not as an invented metric.',
    howVerified:
      'Based on publicly accessible documentation and support pages. Where documentation is gated or unavailable, this is stated.',
  },
];

export const SCORE_TOTAL = SCORE_CATEGORIES.reduce((sum, c) => sum + c.max, 0); // 100

/**
 * Whether a tool currently has a verified, benchmark-backed total score.
 * In this build NO tool has completed benchmark testing, so every tool
 * renders the honest "Not Yet Rated" state. This flag exists so that when
 * real benchmark data is introduced later, only genuinely-scored tools flip
 * to a numeric display.
 */
export const hasVerifiedScore = () => false;
