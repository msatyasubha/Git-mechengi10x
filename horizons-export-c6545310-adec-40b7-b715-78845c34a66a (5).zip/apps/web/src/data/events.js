export const eventCategories = [
  { id: 'all', label: 'All Events' },
  { id: 'ai', label: 'AI Tools' },
  { id: 'cad', label: 'CAD & Design' },
  { id: 'simulation', label: 'Simulation' },
  { id: 'automation', label: 'Automation' },
  { id: 'careers', label: 'Careers' },
];

// Static webinar metadata. Registrations are persisted to the
// `event_registrations` PocketBase collection via the registration form.
export const events = [
  {
    slug: 'ai-trends-2025-engineering',
    title: 'AI Trends 2025: What Engineers Should Actually Adopt',
    category: 'ai',
    date: '2025-11-12',
    time: '14:00',
    duration: '45 min',
    timezone: 'UTC',
    speaker: 'Dr. Sarah Chen',
    speakerRole: 'Former Tesla engineer, MechEngi 10X editor',
    cover: 'linear-gradient(135deg, hsl(217 91% 55%), hsl(217 91% 35%))',
    description:
      'A live, demo-driven walkthrough of the AI capabilities engineers should adopt in 2025 — and the hype to ignore. We cover LLM-assisted calculations, copilots in the IDE, AI meshing, and surrogate models, with honest assessments of where each is production-ready.',
    learningPoints: [
      'Which AI capabilities are production-ready for engineering today',
      'A reusable prompt library for calculations and documentation',
      'How surrogate models compress simulation loops by 100x+',
      'Where AI still fails and the verification habits that catch it',
    ],
    sponsor: null,
    capacity: 500,
  },
  {
    slug: 'cad-best-practices-onshape',
    title: 'CAD Best Practices: Cloud-Native Collaboration with Onshape',
    category: 'cad',
    date: '2025-11-19',
    time: '15:00',
    duration: '45 min',
    timezone: 'UTC',
    speaker: 'Marcus Lindqvist',
    speakerRole: '15 years CAD experience, ex-Dassault',
    cover: 'linear-gradient(135deg, hsl(280 80% 55%), hsl(280 80% 35%))',
    description:
      'A live modeling session showing the cloud-CAD workflows that cut design cycle time 38% for a distributed robotics team. We cover branching, real-time editing, FeatureScript automation, and release management — with the model open for live Q&A.',
    learningPoints: [
      'Git-style branching for CAD feature work',
      'Real-time multi-user editing and mate strategy',
      'FeatureScript for parametric family automation',
      'Release management and PDM without IT overhead',
    ],
    sponsor: { name: 'Onshape', logo: 'OS' },
    capacity: 400,
  },
  {
    slug: 'fea-trust-and-validation',
    title: 'FEA You Can Trust: Setup, Convergence, and Validation',
    category: 'simulation',
    date: '2025-12-03',
    time: '16:00',
    duration: '60 min',
    timezone: 'UTC',
    speaker: 'Dr. Raj Patel',
    speakerRole: 'PhD computational mechanics, ANSYS certified',
    cover: 'linear-gradient(135deg, hsl(190 80% 50%), hsl(190 80% 30%))',
    description:
      'A live FEA workshop on building simulations you can defend. We mesh a bracket, run a convergence study, distinguish singularities from real concentrations, and validate against hand calculations — with the common mistakes that produce dangerous results called out throughout.',
    learningPoints: [
      'Element-type selection and mesh convergence',
      'Realistic boundary conditions vs. over-constraint',
      'Singularity vs. stress concentration diagnosis',
      'Hand-calc validation for every FEA result',
    ],
    sponsor: null,
    capacity: 350,
  },
  {
    slug: 'automation-python-n8n',
    title: 'Automating Engineering Work with Python and n8n',
    category: 'automation',
    date: '2025-12-10',
    time: '14:00',
    duration: '50 min',
    timezone: 'UTC',
    speaker: 'Elena Rossi',
    speakerRole: 'Automation engineer, ex-ABB',
    cover: 'linear-gradient(135deg, hsl(150 70% 40%), hsl(150 70% 25%))',
    description:
      'A live build-along: we deploy n8n on a VPS and construct a real engineering data pipeline — CMM CSV → Python code node → SPC chart → scheduled PDF email report. You leave with the workflow file and the deployment playbook.',
    learningPoints: [
      'Self-hosting n8n for unlimited executions',
      'Python code nodes for data transformation',
      'Scheduled report generation and alerting',
      'When to use n8n vs Make vs Zapier',
    ],
    sponsor: { name: 'n8n', logo: 'n8' },
    capacity: 450,
  },
  {
    slug: 'engineering-career-ai-fluency',
    title: 'Engineering Your Career: Building AI Fluency That Matters',
    category: 'careers',
    date: '2025-12-17',
    time: '17:00',
    duration: '45 min',
    timezone: 'UTC',
    speaker: 'James Okafor',
    speakerRole: 'Engineering manager, ex-SpaceX',
    cover: 'linear-gradient(135deg, hsl(38 96% 52%), hsl(340 80% 50%))',
    description:
      'A candid session on the AI skills that actually move engineering careers forward — the minimum viable skill set, the projects that build credibility, and the common self-teaching dead-ends. Includes a live Q&A on career pivots.',
    learningPoints: [
      'The minimum viable AI skill set for engineers',
      'Portfolio projects that build real credibility',
      'Common self-teaching dead-ends and how to avoid them',
      'How hiring managers evaluate AI fluency',
    ],
    sponsor: null,
    capacity: 600,
  },
];

export const getEventBySlug = (slug) => events.find((e) => e.slug === slug);
export const getEventsByCategory = (cat) =>
  cat === 'all' ? events : events.filter((e) => e.category === cat);
