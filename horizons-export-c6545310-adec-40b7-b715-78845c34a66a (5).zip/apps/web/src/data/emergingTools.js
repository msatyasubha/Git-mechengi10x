/**
 * MechEngi 10X — Emerging & Actively Developing AI Tools
 *
 * Every entry below was researched and verified against the vendor's official
 * site / announcement before being added. We deliberately do NOT assign
 * MechEngi Scores, star ratings, or review counts to these tools — they are
 * new or still developing, so invented ratings would be dishonest.
 *
 * Status values:
 *   - "ga"            → Generally Available (anyone can sign up / download)
 *   - "public-beta"   → Public beta (open, no waitlist, but still in beta)
 *   - "early-access"  → Limited / waitlist / rolling access
 *
 * `lastVerified` is the month we last confirmed the status, pricing, and link.
 * Re-verify before relying on pricing for a purchase decision.
 */

export const emergingToolStatuses = [
  { id: 'all', label: 'All Statuses' },
  { id: 'ga', label: 'Generally Available' },
  { id: 'public-beta', label: 'Public Beta' },
  { id: 'early-access', label: 'Early Access' },
];

export const emergingToolCategories = [
  { id: 'all', label: 'All Types' },
  { id: 'coding-agent', label: 'Terminal Coding Agents' },
  { id: 'agentic-ide', label: 'Agentic IDEs' },
  { id: 'autonomous-agent', label: 'Autonomous Agents' },
];

export const emergingTools = [
  {
    slug: 'claude-code',
    name: 'Claude Code',
    vendor: 'Anthropic',
    category: 'coding-agent',
    status: 'ga',
    lastVerified: 'September 2026',
    logoEmoji: '🧩',
    tagline: 'Agentic coding agent that runs in your terminal and IDE',
    description:
      'Claude Code is Anthropic’s agentic coding agent. It runs directly in the terminal (and via extensions for VS Code and JetBrains), reads your codebase, edits files, runs commands, and can work in the background through the Claude Code SDK and GitHub Actions. It reached general availability in May 2025 alongside the Claude 4 models and has been in steady development since.',
    keyFeatures: [
      'Terminal-native agentic coding — reads and edits files directly',
      'VS Code and JetBrains extensions show edits inline',
      'Background tasks via GitHub Actions and the Claude Code SDK',
      'Powered by Claude Sonnet and Opus models',
      'Shares one usage pool across Claude chat and the terminal',
    ],
    useCases: [
      'Multi-file refactors in engineering codebases',
      'Writing and debugging FEA / data-analysis scripts',
      'Automating repetitive repo maintenance tasks',
    ],
    pricing: {
      model: 'bundled',
      free: false,
      freeLabel: 'No standalone free tier (Claude.ai free chat is separate)',
      paidFrom: 17,
      paidLabel: 'Included in Claude Pro ($17/mo annual, $20/mo monthly); Max from $100/mo',
    },
    officialUrl: 'https://claude.com/product/claude-code',
    affiliateUrl: 'https://claude.com/product/claude-code',
    isFree: false,
    emerging: true,
  },
  {
    slug: 'openai-codex-cli',
    name: 'OpenAI Codex CLI',
    vendor: 'OpenAI',
    category: 'coding-agent',
    status: 'ga',
    lastVerified: 'September 2026',
    logoEmoji: '🟢',
    tagline: 'Open-source terminal coding agent from OpenAI',
    description:
      'Codex CLI is OpenAI’s open-source, terminal-native coding agent. It runs locally, reads your repository, proposes and applies code changes, and can execute commands. The Codex cloud product is now generally available, and the CLI itself is under active open-source development on GitHub with frequent releases.',
    keyFeatures: [
      'Open-source CLI, installed via npm / Homebrew',
      'Terminal-native: proposes and applies edits locally',
      'Backed by OpenAI’s Codex / GPT-5-class coding models',
      'Cloud Codex product is generally available',
      'Active public development on GitHub',
    ],
    useCases: [
      'Local code generation and refactoring from the terminal',
      'Iterating on engineering scripts and automation',
      'Open-source contributors who want an inspectable agent',
    ],
    pricing: {
      model: 'freemium',
      free: true,
      freeLabel: 'Free to install; usage draws on your OpenAI account / ChatGPT plan or API credits',
      paidFrom: 0,
      paidLabel: 'Free to install — model usage billed via OpenAI API or ChatGPT Plus ($20/mo) and higher plans',
    },
    officialUrl: 'https://github.com/openai/codex',
    affiliateUrl: 'https://github.com/openai/codex',
    isFree: true,
    emerging: true,
  },
  {
    slug: 'gemini-cli',
    name: 'Gemini CLI',
    vendor: 'Google',
    category: 'coding-agent',
    status: 'ga',
    lastVerified: 'September 2026',
    logoEmoji: '✨',
    tagline: 'Free, open-source terminal agent powered by Gemini',
    description:
      'Gemini CLI is Google’s free, open-source (Apache 2.0) AI agent that brings Gemini models directly into the terminal. With a personal Google account you get a generous free tier — 60 requests per minute and 1,000 requests per day using Gemini 2.5 Pro — making it one of the most accessible agentic coding tools for individual engineers and students.',
    keyFeatures: [
      'Free and open source (Apache 2.0)',
      '60 requests/min, 1,000 requests/day free with a personal Google account',
      'Powered by Gemini 2.5 Pro (and newer models as they ship)',
      'Query and edit large codebases from the terminal',
      'Generate apps from images or PDFs',
    ],
    useCases: [
      'Zero-cost agentic coding for students and solo engineers',
      'Scripting and automation from the terminal',
      'Exploring agentic workflows without a paid plan',
    ],
    pricing: {
      model: 'freemium',
      free: true,
      freeLabel: 'Free tier: 60 req/min, 1,000 req/day with a personal Google account',
      paidFrom: 0,
      paidLabel: 'Free with personal Google account; higher usage via Google AI Studio or Vertex AI keys',
    },
    officialUrl: 'https://github.com/google-gemini/gemini-cli',
    affiliateUrl: 'https://github.com/google-gemini/gemini-cli',
    isFree: true,
    emerging: true,
  },
  {
    slug: 'google-jules',
    name: 'Google Jules',
    vendor: 'Google',
    category: 'autonomous-agent',
    status: 'public-beta',
    lastVerified: 'September 2026',
    logoEmoji: '🦑',
    tagline: 'Asynchronous autonomous coding agent (public beta)',
    description:
      'Jules is Google’s asynchronous, autonomous coding agent. It clones your repository to a cloud VM, builds a plan, writes tests, fixes bugs, and opens a pull request with a diff for you to review. Jules entered public beta in May 2025 with no waitlist, and is available worldwide wherever the Gemini model is available. It now uses the Gemini 3 Pro model. Because it is still in beta, expect rough edges and always review its diffs.',
    keyFeatures: [
      'Async: clones your repo to a cloud VM and works in the background',
      'Writes tests, fixes bugs, and opens pull requests',
      'Assign tasks via the "jules" label on GitHub issues',
      'Powered by Gemini 3 Pro',
      'No waitlist — available wherever Gemini is available',
    ],
    useCases: [
      'Clearing small bug-fix and test-writing backlogs async',
      'Triage of open GitHub issues',
      'Evaluating autonomous agents on real repositories',
    ],
    pricing: {
      model: 'free-beta',
      free: true,
      freeLabel: 'Free during public beta (higher model access on paid Jules plan)',
      paidFrom: 0,
      paidLabel: 'Free during public beta; paid plan adds higher access to the latest models',
    },
    officialUrl: 'https://jules.google/',
    affiliateUrl: 'https://jules.google/',
    isFree: true,
    emerging: true,
  },
  {
    slug: 'devin',
    name: 'Devin',
    vendor: 'Cognition',
    category: 'autonomous-agent',
    status: 'ga',
    lastVerified: 'September 2026',
    logoEmoji: '🤝',
    tagline: 'Autonomous AI software engineer by Cognition',
    description:
      'Devin is Cognition’s autonomous AI software engineer. Given a task or a link to a GitHub issue, Devin sets up its own environment, gathers context, writes code, runs tests, and prepares a PR. It integrates with GitHub, Linear, Slack, and Teams. Devin is now generally available, with an individual plan and a team plan priced per seat plus agent-compute usage. It is one of the more expensive options in this category — evaluate on a real task before committing.',
    keyFeatures: [
      'Autonomously plans and completes engineering tasks end-to-end',
      'Assigns work via GitHub issues, Linear tickets, or Slack/Teams',
      'Learns your codebase and retains tribal knowledge',
      'Generally available (no waitlist)',
      'Also available as Devin Desktop (the IDE formerly known as Windsurf)',
    ],
    useCases: [
      'Autonomously resolving well-scoped GitHub issues',
      'Parallelizing routine backend work',
      'Teams trialing autonomous agents in their workflow',
    ],
    pricing: {
      model: 'paid',
      free: false,
      freeLabel: 'No free tier (Devin Desktop has a free tier — see Windsurf / Devin Desktop)',
      paidFrom: 20,
      paidLabel: 'Individual $20/mo; Team $500/seat/mo plus Agent Compute Unit (ACU) usage — confirm current rates on devin.ai',
    },
    officialUrl: 'https://devin.ai/',
    affiliateUrl: 'https://devin.ai/',
    isFree: false,
    emerging: true,
  },
  {
    slug: 'windsurf',
    name: 'Windsurf',
    vendor: 'Codeium / Cognition',
    category: 'agentic-ide',
    status: 'ga',
    lastVerified: 'September 2026',
    logoEmoji: '🏄',
    tagline: 'Agentic AI IDE with the Cascade agent',
    description:
      'Windsurf is an agentic AI code editor (a VS Code-based IDE) originally built by Codeium and acquired by Cognition AI in December 2025. Its Cascade agent indexes your entire codebase, plans multi-file edits, runs terminal commands, and learns your coding style via Memories. Cognition is transitioning the IDE to "Devin Desktop" while keeping the IDE experience intact. Pricing moved from credits to a quota-based system in 2026.',
    keyFeatures: [
      'Cascade agent plans and applies multi-file edits with full codebase context',
      'Memories adapt to your coding style over time',
      'Free tier with a monthly quota of prompts',
      'SOC 2 compliance and zero data retention options',
      'Now part of Cognition (transitioning to Devin Desktop)',
    ],
    useCases: [
      'Engineers who want deep, automatic codebase context in an IDE',
      'Teams wanting an agentic IDE at a lower price point than some rivals',
      'Existing Codeium / Windsurf users migrating to Devin Desktop',
    ],
    pricing: {
      model: 'freemium',
      free: true,
      freeLabel: 'Free tier with a monthly prompt quota',
      paidFrom: 15,
      paidLabel: 'Pro from $15–20/mo; Teams ~$30–35/user/mo; Enterprise custom — confirm on windsurf.com',
    },
    officialUrl: 'https://windsurf.com/',
    affiliateUrl: 'https://windsurf.com/',
    isFree: true,
    emerging: true,
  },
];

export const getEmergingToolBySlug = (slug) => emergingTools.find((t) => t.slug === slug);
