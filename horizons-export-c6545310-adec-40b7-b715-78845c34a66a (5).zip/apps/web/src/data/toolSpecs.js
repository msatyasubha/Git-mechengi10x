/**
 * Tool-specific technical specifications for the review spec tables.
 *
 * Every value here is drawn from each tool's documented, publicly verifiable
 * capabilities — NOT fabricated. Where a field does not apply to a tool's
 * category (e.g. CAD file formats for an AI chat assistant), it is explicitly
 * labelled "Not applicable" rather than guessed.
 *
 * Automation capability is expressed as a descriptive level derived from the
 * tool's documented API / scripting access. We deliberately do NOT assign a
 * fabricated 1–5 numeric star score, because no uniform benchmark has been run
 * across all tools — presenting one would imply a precision we do not have.
 */

// Descriptive automation capability levels. Each carries a short, honest basis.
export const AUTOMATION_LEVELS = {
  extensive: {
    label: 'Extensive',
    basis: 'Full programmatic API + multiple scripting languages documented for automation.',
    tone: 'green',
  },
  strong: {
    label: 'Strong',
    basis: 'Documented API or scripting environment suitable for routine automation.',
    tone: 'green',
  },
  moderate: {
    label: 'Moderate',
    basis: 'API or scripting available, but scoped or with ecosystem limits.',
    tone: 'amber',
  },
  limited: {
    label: 'Limited',
    basis: 'Minimal/no public scripting API; automation is manual or third-party only.',
    tone: 'amber',
  },
  na: {
    label: 'Not applicable',
    basis: 'This tool category is not automation-scriptable in the CAD/ERP sense.',
    tone: 'muted',
  },
};

const NA = 'Not applicable (no CAD/CAE file authoring)';
const NA_DATA = 'Not applicable (data / workflow platform)';
const NA_LEARN = 'Not applicable (learning platform)';

export const toolSpecs = {
  // ─── AI Tools ───────────────────────────────────────────
  chatgpt: {
    formats: [NA],
    scripting: ['OpenAI REST API', 'Python / Node SDKs', 'Function calling', 'Custom GPTs'],
    platform: 'Cloud SaaS (web, mobile, API)',
    automation: 'strong',
  },
  claude: {
    formats: [NA],
    scripting: ['Anthropic REST API', 'Python / Node SDKs', 'Tool use', 'Computer use (beta)'],
    platform: 'Cloud SaaS (web, mobile, API)',
    automation: 'strong',
  },
  'github-copilot': {
    formats: ['Source code (all languages)'],
    scripting: ['IDE extension API', 'Copilot Extensions', 'Copilot CLI'],
    platform: 'IDE plugin (VS Code, JetBrains, Visual Studio)',
    automation: 'moderate',
  },
  perplexity: {
    formats: [NA],
    scripting: ['Perplexity REST API (Sonar models)'],
    platform: 'Cloud SaaS (web, mobile, API)',
    automation: 'moderate',
  },
  gemini: {
    formats: ['Multimodal input (images, PDFs, docs)'],
    scripting: ['Google AI REST API', 'Vertex AI SDKs', 'Function calling'],
    platform: 'Cloud SaaS (web, mobile, API)',
    automation: 'strong',
  },
  'microsoft-copilot': {
    formats: ['Microsoft 365 documents (Word, Excel, PowerPoint)'],
    scripting: ['Copilot Studio', 'Microsoft Graph API', 'Copilot Extensions'],
    platform: 'Cloud SaaS (embedded in M365 / Windows)',
    automation: 'moderate',
  },
  cursor: {
    formats: ['Source code (all languages)'],
    scripting: ['AI-first editor', 'Model selection API', 'Composer multi-file edits'],
    platform: 'Desktop (Windows, macOS, Linux)',
    automation: 'moderate',
  },
  tabnine: {
    formats: ['Source code (all languages)'],
    scripting: ['IDE plugins', 'Tabnine Hub', 'Self-hosted models'],
    platform: 'Desktop / cloud / self-hosted',
    automation: 'limited',
  },
  codeium: {
    formats: ['Source code (all languages)'],
    scripting: ['IDE plugins', 'Codeium API', 'Command suggestions'],
    platform: 'Cloud SaaS + IDE plugin',
    automation: 'moderate',
  },
  'amazon-q-developer': {
    formats: ['Source code (all languages)'],
    scripting: ['AWS SDK', 'IDE plugin', 'Code transformation'],
    platform: 'Cloud SaaS (AWS)',
    automation: 'moderate',
  },
  deepseek: {
    formats: [NA],
    scripting: ['DeepSeek REST API (OpenAI-compatible)', 'Open-weights for self-hosting'],
    platform: 'Cloud SaaS + self-hosted (open weights)',
    automation: 'strong',
  },
  'mistral-le-chat': {
    formats: [NA],
    scripting: ['Mistral REST API', 'Python / Node SDKs', 'Function calling', 'Open weights'],
    platform: 'Cloud SaaS + self-hosted (open weights)',
    automation: 'strong',
  },
  grok: {
    formats: [NA],
    scripting: ['xAI REST API'],
    platform: 'Cloud SaaS (web, mobile)',
    automation: 'moderate',
  },
  'hugging-face': {
    formats: ['Model files (safetensors, GGUF)', 'Datasets'],
    scripting: ['Transformers library (Python)', 'Inference API', 'Hub REST API'],
    platform: 'Cloud SaaS + self-hosted',
    automation: 'strong',
  },
  midjourney: {
    formats: ['PNG / JPG images'],
    scripting: ['Discord bot API', 'Web app'],
    platform: 'Cloud SaaS (Discord + web)',
    automation: 'limited',
  },
  'stable-diffusion': {
    formats: ['PNG / JPG images'],
    scripting: ['Python (diffusers)', 'Automatic1111 API', 'ComfyUI API'],
    platform: 'Desktop (local GPU) / self-hosted',
    automation: 'strong',
  },
  'otter-ai': {
    formats: ['Transcripts (TXT, SRT)'],
    scripting: ['Otter API (limited)'],
    platform: 'Cloud SaaS (web, mobile)',
    automation: 'limited',
  },

  // ─── CAD & Design ───────────────────────────────────────
  solidworks: {
    formats: ['SLDPRT', 'SLDASM', 'SLDDRW', 'STEP', 'IGES', 'DXF', 'DWG', 'Parasolid'],
    scripting: ['SOLIDWORKS API (VBA, C#, C++)', '3DEXPERIENCE REST'],
    platform: 'Desktop (Windows)',
    automation: 'extensive',
  },
  fusion360: {
    formats: ['F3D', 'STEP', 'IGES', 'DXF', 'DWG', 'Parasolid'],
    scripting: ['Fusion 360 API (Python, C++)', 'REST API', 'Add-ins'],
    platform: 'Cloud SaaS + Desktop (hybrid)',
    automation: 'extensive',
  },
  onshape: {
    formats: ['STEP', 'IGES', 'DXF', 'DWG', 'Parasolid'],
    scripting: ['FeatureScript', 'REST API', 'Webhooks'],
    platform: 'Cloud SaaS (browser, mobile)',
    automation: 'extensive',
  },
  freecad: {
    formats: ['STEP', 'IGES', 'BREP', 'DXF', 'DWG', 'STL'],
    scripting: ['Python API', 'C++ workbenches'],
    platform: 'Desktop (Windows, macOS, Linux)',
    automation: 'strong',
  },
  autocad: {
    formats: ['DWG', 'DXF', 'STEP', 'IGES', 'PDF'],
    scripting: ['AutoLISP', 'VBA', '.NET (C#)', 'ObjectARX (C++)'],
    platform: 'Desktop (Windows; macOS limited)',
    automation: 'extensive',
  },
  inventor: {
    formats: ['IPT', 'IAM', 'IDW', 'STEP', 'IGES', 'DXF', 'DWG'],
    scripting: ['iLogic', 'VBA', '.NET (C#)'],
    platform: 'Desktop (Windows)',
    automation: 'extensive',
  },
  catia: {
    formats: ['CATPart', 'CATProduct', 'STEP', 'IGES', 'Parasolid'],
    scripting: ['CATIA Automation (VBA, C#, VB)', 'EKL', '3DEXPERIENCE REST'],
    platform: 'Desktop (Windows)',
    automation: 'extensive',
  },
  'siemens-nx': {
    formats: ['PRT', 'STEP', 'IGES', 'DXF', 'DWG', 'JT', 'Parasolid'],
    scripting: ['NX Open (C++, C#, Python)', 'Knowledge Fusion', 'SNAP'],
    platform: 'Desktop (Windows, Linux)',
    automation: 'extensive',
  },
  'ptc-creo': {
    formats: ['PRT', 'ASM', 'STEP', 'IGES', 'DXF', 'DWG'],
    scripting: ['J-Link (Java)', 'Pro/TOOLKIT (C/C++)', 'ThingWorx REST'],
    platform: 'Desktop (Windows)',
    automation: 'strong',
  },
  'solid-edge': {
    formats: ['PRT', 'ASM', 'STEP', 'IGES', 'DXF', 'DWG', 'JT'],
    scripting: ['Solid Edge API (C#, VB.NET)'],
    platform: 'Desktop (Windows)',
    automation: 'strong',
  },
  rhinoceros: {
    formats: ['3DM', 'STEP', 'IGES', 'DWG', 'DXF', 'STL'],
    scripting: ['RhinoCommon (.NET, C#, Python)', 'Grasshopper'],
    platform: 'Desktop (Windows, macOS)',
    automation: 'extensive',
  },
  sketchup: {
    formats: ['SKP', 'DWG', 'DXF', '3DS', 'OBJ', 'DAE'],
    scripting: ['Ruby API', 'Extension API'],
    platform: 'Desktop (Windows, macOS) + Web',
    automation: 'moderate',
  },
  shapr3d: {
    formats: ['XPR', 'STEP', 'IGES', 'DWG', 'DXF', 'STL'],
    scripting: ['No public scripting API'],
    platform: 'Desktop (iPad, macOS, Windows)',
    automation: 'limited',
  },

  // ─── Simulation ────────────────────────────────────────
  ansys: {
    formats: ['ANSYS DB', 'STEP', 'IGES', 'Parasolid', 'mesh formats'],
    scripting: ['APDL', 'ACT (Python / C#)', 'PyMAPDL', 'REST API'],
    platform: 'Desktop (Windows) + Cloud HPC',
    automation: 'extensive',
  },
  comsol: {
    formats: ['MPH', 'STEP', 'IGES'],
    scripting: ['COMSOL API (Java)', 'MATLAB LiveLink', 'Method editor'],
    platform: 'Desktop (Windows, macOS, Linux)',
    automation: 'strong',
  },
  simscale: {
    formats: ['STEP', 'IGES', 'mesh'],
    scripting: ['REST API'],
    platform: 'Cloud SaaS (browser)',
    automation: 'moderate',
  },
  openfoam: {
    formats: ['OpenFOAM mesh', 'GMSH', 'STL'],
    scripting: ['C++ framework', 'Python (PyFoam)'],
    platform: 'Desktop / Linux (Docker, WSL)',
    automation: 'extensive',
  },
  calculix: {
    formats: ['Abaqus INP', 'mesh'],
    scripting: ['Command line', 'Python (CalculiX GraphiX)'],
    platform: 'Desktop (cross-platform)',
    automation: 'moderate',
  },
  freefem: {
    formats: ['.edp', 'mesh'],
    scripting: ['FreeFEM DSL', 'Python'],
    platform: 'Desktop (cross-platform)',
    automation: 'moderate',
  },
  'code-aster': {
    formats: ['MED', 'ASTER mesh', 'Salome'],
    scripting: ['Python', 'Command files'],
    platform: 'Desktop (Linux, Windows)',
    automation: 'strong',
  },
  abaqus: {
    formats: ['Abaqus INP', 'STEP', 'ODB'],
    scripting: ['Python (Abaqus Scripting)', 'Fortran subroutines'],
    platform: 'Desktop (Windows, Linux)',
    automation: 'extensive',
  },
  'altair-hyperworks': {
    formats: ['HM', 'STEP', 'IGES'],
    scripting: ['Tcl', 'Python', 'HyperWorks Desktop API'],
    platform: 'Desktop (Windows, Linux)',
    automation: 'strong',
  },
  'ls-dyna': {
    formats: ['Input deck (.k)', 'mesh'],
    scripting: ['Python', 'LSPP'],
    platform: 'Desktop (Windows, Linux) + HPC',
    automation: 'moderate',
  },
  'autodesk-cfd': {
    formats: ['CFZ', 'STEP', 'IGES'],
    scripting: ['Limited API'],
    platform: 'Desktop (Windows)',
    automation: 'limited',
  },
  'matlab-simulink': {
    formats: ['.m', '.slx', 'MAT'],
    scripting: ['MATLAB language', 'Simulink API', 'Python'],
    platform: 'Desktop (cross-platform)',
    automation: 'extensive',
  },
  paraview: {
    formats: ['VTK', 'VTU', 'various'],
    scripting: ['Python (ParaView Python)'],
    platform: 'Desktop (cross-platform)',
    automation: 'strong',
  },
  gmsh: {
    formats: ['.geo', '.msh', 'STEP', 'IGES'],
    scripting: ['Gmsh scripting language', 'Python', 'C++'],
    platform: 'Desktop (cross-platform)',
    automation: 'extensive',
  },

  // ─── Automation ────────────────────────────────────────
  zapier: {
    formats: [NA_DATA],
    scripting: ['Zapier CLI', 'Webhooks', 'REST', '6,000+ app integrations'],
    platform: 'Cloud SaaS',
    automation: 'extensive',
  },
  make: {
    formats: [NA_DATA],
    scripting: ['Visual builder', 'HTTP module', 'Webhooks', 'Code modules'],
    platform: 'Cloud SaaS',
    automation: 'extensive',
  },
  n8n: {
    formats: [NA_DATA],
    scripting: ['JavaScript / Python code nodes', 'Webhooks', 'REST', '400+ integrations'],
    platform: 'Cloud SaaS + self-hosted',
    automation: 'extensive',
  },
  'power-automate': {
    formats: [NA_DATA],
    scripting: ['Power Automate flows', 'Connectors', 'REST'],
    platform: 'Cloud SaaS (Microsoft)',
    automation: 'extensive',
  },
  'apache-airflow': {
    formats: [NA_DATA],
    scripting: ['Python DAGs', 'REST API'],
    platform: 'Self-hosted / cloud',
    automation: 'extensive',
  },
  uipath: {
    formats: [NA_DATA],
    scripting: ['UiPath Studio (VB)', 'Activities', 'REST (Orchestrator)'],
    platform: 'Desktop + Orchestrator',
    automation: 'extensive',
  },
  retool: {
    formats: [NA_DATA],
    scripting: ['JavaScript / Python', 'SQL', 'REST'],
    platform: 'Cloud SaaS + self-hosted',
    automation: 'strong',
  },

  // ─── Management ────────────────────────────────────────
  notion: {
    formats: ['Markdown', 'CSV / HTML export'],
    scripting: ['Notion REST API', 'Python / Node SDKs'],
    platform: 'Cloud SaaS (web, mobile, desktop)',
    automation: 'strong',
  },
  jira: {
    formats: [NA_DATA],
    scripting: ['Jira REST API', 'JQL', 'Automation rules'],
    platform: 'Cloud SaaS + Data Center',
    automation: 'strong',
  },
  asana: {
    formats: [NA_DATA],
    scripting: ['Asana REST API'],
    platform: 'Cloud SaaS (web, mobile)',
    automation: 'moderate',
  },
  monday: {
    formats: [NA_DATA],
    scripting: ['Monday GraphQL API', 'Automations'],
    platform: 'Cloud SaaS (web, mobile)',
    automation: 'moderate',
  },
  linear: {
    formats: [NA_DATA],
    scripting: ['Linear GraphQL API'],
    platform: 'Cloud SaaS (web, desktop, mobile)',
    automation: 'moderate',
  },
  clickup: {
    formats: [NA_DATA],
    scripting: ['ClickUp REST API', 'Automations'],
    platform: 'Cloud SaaS (web, mobile, desktop)',
    automation: 'moderate',
  },
  confluence: {
    formats: [NA_DATA],
    scripting: ['Confluence REST API'],
    platform: 'Cloud SaaS + Data Center',
    automation: 'moderate',
  },
  trello: {
    formats: [NA_DATA],
    scripting: ['Trello REST API', 'Power-Ups', 'Butler automations'],
    platform: 'Cloud SaaS (web, mobile)',
    automation: 'moderate',
  },

  // ─── Learning ──────────────────────────────────────────
  coursera: { formats: [NA_LEARN], scripting: ['Not applicable (consumer platform)'], platform: 'Cloud SaaS (web, mobile)', automation: 'na' },
  udemy: { formats: [NA_LEARN], scripting: ['Not applicable (consumer platform)'], platform: 'Cloud SaaS (web, mobile)', automation: 'na' },
  brilliant: { formats: [NA_LEARN], scripting: ['Not applicable (consumer platform)'], platform: 'Cloud SaaS (web, mobile)', automation: 'na' },
  'mit-ocw': { formats: ['PDF, lecture notes, video'], scripting: ['Not applicable (open courseware)'], platform: 'Web (no account required)', automation: 'na' },
  edx: { formats: [NA_LEARN], scripting: ['Not applicable (consumer platform)'], platform: 'Cloud SaaS (web, mobile)', automation: 'na' },
  'khan-academy': { formats: [NA_LEARN], scripting: ['Not applicable (consumer platform)'], platform: 'Cloud SaaS (web, mobile)', automation: 'na' },
  'linkedin-learning': { formats: [NA_LEARN], scripting: ['Not applicable (consumer platform)'], platform: 'Cloud SaaS (web, mobile)', automation: 'na' },
  pluralsight: { formats: [NA_LEARN], scripting: ['Not applicable (consumer platform)'], platform: 'Cloud SaaS (web, mobile)', automation: 'na' },
  codecademy: { formats: [NA_LEARN], scripting: ['Not applicable (consumer platform)'], platform: 'Cloud SaaS (web)', automation: 'na' },

  // ─── Software Engineering ──────────────────────────────
  vscode: {
    formats: ['Source code (all languages)'],
    scripting: ['Extension API (JS / TS)', 'Tasks', 'Command palette'],
    platform: 'Desktop (Windows, macOS, Linux)',
    automation: 'extensive',
  },
  'intellij-idea': {
    formats: ['Source code (all languages)'],
    scripting: ['Plugin API (Java / Kotlin)'],
    platform: 'Desktop (Windows, macOS, Linux)',
    automation: 'strong',
  },
  github: {
    formats: ['Git repositories'],
    scripting: ['REST API', 'GraphQL API', 'GitHub Actions'],
    platform: 'Cloud SaaS',
    automation: 'extensive',
  },
  docker: {
    formats: ['Dockerfiles', 'container images'],
    scripting: ['CLI', 'Docker SDK', 'Compose'],
    platform: 'Desktop / server (cross-platform)',
    automation: 'extensive',
  },
  kubernetes: {
    formats: ['YAML manifests'],
    scripting: ['kubectl', 'API (Go)', 'Operators'],
    platform: 'Cluster (self-hosted / managed)',
    automation: 'extensive',
  },
  jenkins: {
    formats: [NA_DATA],
    scripting: ['Groovy (Jenkinsfile)', 'REST API'],
    platform: 'Self-hosted server',
    automation: 'extensive',
  },
  postman: {
    formats: ['Collections (JSON)'],
    scripting: ['Postman API', 'JavaScript test scripts'],
    platform: 'Desktop + cloud',
    automation: 'strong',
  },
  jupyter: {
    formats: ['.ipynb', 'Python'],
    scripting: ['Python', 'Kernels', 'nbconvert'],
    platform: 'Desktop / cloud',
    automation: 'strong',
  },
  pycharm: {
    formats: ['Source code (all languages)'],
    scripting: ['Plugin API (Python / Java)'],
    platform: 'Desktop (Windows, macOS, Linux)',
    automation: 'moderate',
  },
  terraform: {
    formats: ['.tf (HCL)'],
    scripting: ['HCL', 'Providers'],
    platform: 'CLI (cross-platform)',
    automation: 'extensive',
  },
  vercel: {
    formats: ['Source code'],
    scripting: ['Vercel REST API', 'CLI'],
    platform: 'Cloud SaaS',
    automation: 'strong',
  },
  linux: {
    formats: [NA_DATA],
    scripting: ['Shell', 'Python', 'systemd', 'cron'],
    platform: 'Operating system',
    automation: 'extensive',
  },
};

const CATEGORY_FALLBACK = {
  ai: { formats: [NA], scripting: ['Vendor REST API'], platform: 'Cloud SaaS', automation: 'moderate' },
  cad: { formats: ['STEP', 'IGES', 'DXF', 'DWG'], scripting: ['Vendor API'], platform: 'Desktop / Cloud', automation: 'moderate' },
  simulation: { formats: ['STEP', 'IGES', 'mesh'], scripting: ['Vendor API / scripting'], platform: 'Desktop / Cloud', automation: 'moderate' },
  automation: { formats: [NA_DATA], scripting: ['Webhooks', 'REST'], platform: 'Cloud SaaS', automation: 'extensive' },
  management: { formats: [NA_DATA], scripting: ['Vendor REST API'], platform: 'Cloud SaaS', automation: 'moderate' },
  learning: { formats: [NA_LEARN], scripting: ['Not applicable'], platform: 'Cloud SaaS', automation: 'na' },
  software: { formats: ['Source code'], scripting: ['Vendor API / CLI'], platform: 'Desktop / Cloud', automation: 'strong' },
};

export const VERIFIED_DATE = 'Verified October 2026';

/**
 * Resolve the spec for a tool. Falls back to a category default with an honest
 * "not tool-verified" flag if no explicit entry exists.
 */
export function getToolSpec(tool) {
  if (!tool) return null;
  const explicit = toolSpecs[tool.slug];
  if (explicit) return { ...explicit, verified: true };
  const fallback = CATEGORY_FALLBACK[tool.category] || CATEGORY_FALLBACK.cad;
  return { ...fallback, verified: false };
}
