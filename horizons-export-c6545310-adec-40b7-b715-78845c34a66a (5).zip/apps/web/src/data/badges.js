// Gamification badge definitions. Points are awarded when a badge is earned.
// Badge awarding logic lives in the profile page (client-side, persisted to
// the `user_badges` PocketBase collection).

export const badges = [
  { id: 'first-save', name: 'First Tool Saved', description: 'Saved your first tool.', points: 1, icon: '🔖' },
  { id: 'collector', name: 'Collector', description: 'Saved 5 tools or reviews.', points: 5, icon: '📦' },
  { id: 'archivist', name: 'Archivist', description: 'Saved 20 items total.', points: 10, icon: '🗂️' },
  { id: 'reviewer', name: 'Review Expert', description: 'Wrote your first tool review.', points: 10, icon: '⭐' },
  { id: 'critic', name: 'Critic', description: 'Wrote 5 tool reviews.', points: 25, icon: '✍️' },
  { id: 'forum-starter', name: 'Forum Contributor', description: 'Started your first forum thread.', points: 10, icon: '💬' },
  { id: 'forum-regular', name: 'Forum Regular', description: 'Posted 10 forum replies.', points: 20, icon: '🗣️' },
  { id: 'event-attendee', name: 'Event Attendee', description: 'Registered for a webinar.', points: 5, icon: '🎥' },
  { id: 'course-completer', name: 'Course Completer', description: 'Enrolled in a premium course.', points: 50, icon: '🎓' },
  { id: 'member', name: 'Premium Member', description: 'Joined MechEngi 10X Premium.', points: 30, icon: '👑' },
  { id: 'referrer', name: 'Referrer', description: 'Referred your first signup.', points: 15, icon: '🤝' },
  { id: 'advisor-user', name: 'Advisor User', description: 'Chatted with the AI Advisor.', points: 5, icon: '🤖' },
];

export const levels = [
  { name: 'Novice', min: 0 },
  { name: 'Apprentice', min: 25 },
  { name: 'Practitioner', min: 75 },
  { name: 'Expert', min: 150 },
  { name: 'Master', min: 300 },
];

export function getLevel(points) {
  let current = levels[0];
  let next = null;
  for (let i = 0; i < levels.length; i++) {
    if (points >= levels[i].min) {
      current = levels[i];
      next = levels[i + 1] || null;
    }
  }
  return { current, next };
}

export const getBadgeById = (id) => badges.find((b) => b.id === id);
