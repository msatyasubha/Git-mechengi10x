// DFM & Standards evaluation data — MechEngi 10X.
//
// HONEST SCOPE: every entry below records capabilities that are publicly
// documented by the vendor (product documentation / feature pages). We have
// NOT run hands-on DFM stress tests on these tools, so no DFM score is
// awarded anywhere on the site — only a per-criterion status of
// "documented" / "partial" / "not-documented", plus the vendor-doc evidence
// note. Tools without an entry here are shown as "not yet evaluated".
// Confirm coverage for your license tier and release on the vendor's site.

export const DFM_CRITERIA = [
  { id: 'gdnt', label: 'GD&T callouts (ASME Y14.5 / ISO 1101)' },
  { id: 'toleranceStack', label: 'Automated tolerance stack-up analysis' },
  { id: 'castingDraft', label: 'Casting draft-angle / DFM checks' },
  { id: 'sheetMetal', label: 'Sheet-metal bend relief & manufacturability' },
  { id: 'weldments', label: 'Weldment cut lists' },
  { id: 'piping', label: 'Piping / flow-line standards' },
  { id: 'drawingCompliance', label: 'ISO / ASME drawing compliance' },
];

export const DFM_STATUS = {
  documented: { label: 'Documented', color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/30' },
  partial: { label: 'Partial', color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30' },
  'not-documented': { label: 'Not documented', color: 'text-muted-foreground', bg: 'bg-muted/40', border: 'border-border' },
};

const VENDOR_DOC_EVIDENCE =
  'Assessment based on publicly documented vendor product features — confirm coverage for your license tier and release on the vendor site. We have not yet run hands-on DFM stress tests on this tool, so no DFM score is awarded.';

export const dfmStandards = {
  solidworks: {
    evidence: VENDOR_DOC_EVIDENCE,
    criteria: {
      gdnt: { status: 'documented', note: 'DimXpert applies ASME Y14.5 feature-control frames to 3D models and drawings.' },
      toleranceStack: { status: 'documented', note: 'TolAnalyst add-in computes worst-case and RSS stack-ups along a dimension chain (Professional tier and above).' },
      castingDraft: { status: 'documented', note: 'Draft analysis tool checks draft angles on molded and cast parts.' },
      sheetMetal: { status: 'documented', note: 'Sheet-metal module with bend parameters, gauge tables, and bend relief.' },
      weldments: { status: 'documented', note: 'Weldments module generates cut lists from structural members.' },
      piping: { status: 'documented', note: 'Routing add-in (Premium tier) covers piping and tubing to common standards.' },
      drawingCompliance: { status: 'documented', note: 'Drawing templates are configurable to ISO and ASME drafting standards.' },
    },
  },
  fusion360: {
    evidence: VENDOR_DOC_EVIDENCE,
    criteria: {
      gdnt: { status: 'partial', note: 'Drawings support geometric tolerance symbols; no model-based DimXpert-style automation.' },
      toleranceStack: { status: 'not-documented', note: 'No automated tolerance stack-up analysis documented.' },
      castingDraft: { status: 'partial', note: 'Draft analysis exists in the molding toolset; no general casting DFM checker.' },
      sheetMetal: { status: 'documented', note: 'Sheet Metal design environment with bend relief and flat-pattern export.' },
      weldments: { status: 'not-documented', note: 'No dedicated weldment cut-list tool documented — BOM only.' },
      piping: { status: 'not-documented', note: 'No routed-piping standards toolset documented in core Fusion.' },
      drawingCompliance: { status: 'partial', note: 'Drawings follow configurable drafting standards (ANSI/ISO); verify per template.' },
    },
  },
  onshape: {
    evidence: VENDOR_DOC_EVIDENCE,
    criteria: {
      gdnt: { status: 'partial', note: 'Drawings support geometric tolerances; verify current GD&T coverage per standard.' },
      toleranceStack: { status: 'not-documented', note: 'No automated tolerance stack-up analysis documented.' },
      castingDraft: { status: 'not-documented', note: 'No casting draft-angle checker documented.' },
      sheetMetal: { status: 'documented', note: 'Sheet Metal modeling with bend relief and flat patterns.' },
      weldments: { status: 'not-documented', note: 'No dedicated weldment cut-list tool documented.' },
      piping: { status: 'not-documented', note: 'No routed-piping standards toolset documented.' },
      drawingCompliance: { status: 'partial', note: 'Drawings configurable to ANSI/ISO standards.' },
    },
  },
  freecad: {
    evidence: VENDOR_DOC_EVIDENCE,
    criteria: {
      gdnt: { status: 'partial', note: 'TechDraw provides dimensions and annotations; GD&T symbol support is limited — verify against your standard.' },
      toleranceStack: { status: 'not-documented', note: 'No automated tolerance stack-up analysis documented.' },
      castingDraft: { status: 'not-documented', note: 'No casting draft-angle checker documented.' },
      sheetMetal: { status: 'partial', note: 'Community Sheet Metal workbench handles bends and flats; no DFM checker.' },
      weldments: { status: 'not-documented', note: 'No weldment cut-list tool documented.' },
      piping: { status: 'partial', note: 'Community piping workbenches exist; not part of the core.' },
      drawingCompliance: { status: 'partial', note: 'TechDraw templates can follow ISO conventions with manual setup.' },
    },
  },
  inventor: {
    evidence: VENDOR_DOC_EVIDENCE,
    criteria: {
      gdnt: { status: 'documented', note: 'Model dimensions and tolerance annotations support GD&T; verify current release coverage.' },
      toleranceStack: { status: 'partial', note: 'Recent releases include tolerance analysis tooling — confirm availability in your version and license.' },
      castingDraft: { status: 'not-documented', note: 'No dedicated casting draft-angle checker documented.' },
      sheetMetal: { status: 'documented', note: 'Sheet Metal environment with bend relief, unfold, and flat-pattern output.' },
      weldments: { status: 'partial', note: 'Frame Generator produces member lists/BOM; dedicated weldment cut lists depend on version and template.' },
      piping: { status: 'partial', note: 'Tube & Pipe add-in covers routed systems; standards coverage varies by configuration.' },
      drawingCompliance: { status: 'documented', note: 'Drawing standards configurable (ISO/ANSI and others).' },
    },
  },
  catia: {
    evidence: VENDOR_DOC_EVIDENCE,
    criteria: {
      gdnt: { status: 'documented', note: 'FTA workbench applies ISO GPS-compliant tolerancing annotations (3D Master).' },
      toleranceStack: { status: 'partial', note: 'Stack-up analysis typically via separately licensed add-ons; not core.' },
      castingDraft: { status: 'partial', note: 'Part Design provides draft features; dedicated casting DFM via add-ons.' },
      sheetMetal: { status: 'documented', note: 'Generative Sheetmetal Design workbench.' },
      weldments: { status: 'not-documented', note: 'No dedicated weldment cut-list tool documented.' },
      piping: { status: 'documented', note: 'Piping and tubing design workbenches in plant/ship configurations.' },
      drawingCompliance: { status: 'documented', note: 'Drafting workbench configurable to ISO/ASME standards.' },
    },
  },
  'siemens-nx': {
    evidence: VENDOR_DOC_EVIDENCE,
    criteria: {
      gdnt: { status: 'documented', note: 'PMI applies ASME Y14.5-compliant annotations with GD&T validation checks.' },
      toleranceStack: { status: 'partial', note: 'Tolerance analysis capability exists in some configurations — confirm licensing.' },
      castingDraft: { status: 'partial', note: 'Mold/casting toolsets exist in some configurations; confirm licensing.' },
      sheetMetal: { status: 'documented', note: 'NX Sheet Metal (Solid Edge heritage tooling).' },
      weldments: { status: 'not-documented', note: 'No dedicated weldment cut-list tool documented.' },
      piping: { status: 'documented', note: 'Routing application covers piping and pipeline systems.' },
      drawingCompliance: { status: 'documented', note: 'Drafting configurable to ISO/ASME standards.' },
    },
  },
  'ptc-creo': {
    evidence: VENDOR_DOC_EVIDENCE,
    criteria: {
      gdnt: { status: 'partial', note: 'GD&T Advisor extension guides standards-compliant annotations; separately licensed.' },
      toleranceStack: { status: 'partial', note: 'Tolerance Analysis extension — confirm licensing.' },
      castingDraft: { status: 'partial', note: 'Casting/mold toolsets exist in some configurations; confirm licensing.' },
      sheetMetal: { status: 'documented', note: 'Sheet Metal module with bend relief and flat patterns.' },
      weldments: { status: 'not-documented', note: 'No dedicated weldment cut-list tool documented.' },
      piping: { status: 'not-documented', note: 'No routed-piping standards toolset documented in core Creo.' },
      drawingCompliance: { status: 'documented', note: 'Drawings configurable to ISO/ASME standards.' },
    },
  },
  autocad: {
    evidence: VENDOR_DOC_EVIDENCE,
    criteria: {
      gdnt: { status: 'partial', note: '2D geometric tolerance symbols via drafting tools; no model-based validation.' },
      toleranceStack: { status: 'not-documented', note: 'No automated tolerance stack-up analysis documented.' },
      castingDraft: { status: 'not-documented', note: 'No casting draft-angle checker documented.' },
      sheetMetal: { status: 'not-documented', note: 'No sheet-metal toolset in core AutoCAD.' },
      weldments: { status: 'not-documented', note: 'No weldment cut-list tool documented.' },
      piping: { status: 'partial', note: 'AutoCAD Plant 3D (separate product) covers piping to ISO/ASME; base AutoCAD does not.' },
      drawingCompliance: { status: 'partial', note: 'Templates configurable to ISO/ASME drafting conventions.' },
    },
  },
  'solid-edge': {
    evidence: VENDOR_DOC_EVIDENCE,
    criteria: {
      gdnt: { status: 'documented', note: 'PMI annotations support ASME Y14.5.' },
      toleranceStack: { status: 'not-documented', note: 'No core tolerance stack-up analysis documented.' },
      castingDraft: { status: 'not-documented', note: 'No dedicated casting draft-angle checker documented.' },
      sheetMetal: { status: 'documented', note: 'Solid Edge Sheet Metal is a flagship capability with bend relief and flats.' },
      weldments: { status: 'not-documented', note: 'No dedicated weldment cut-list tool documented.' },
      piping: { status: 'partial', note: 'Piping add-on in some configurations; confirm licensing.' },
      drawingCompliance: { status: 'documented', note: 'Drafting configurable to ISO/ASME standards.' },
    },
  },
};

export const getDfmStandards = (slug) => dfmStandards[slug];
