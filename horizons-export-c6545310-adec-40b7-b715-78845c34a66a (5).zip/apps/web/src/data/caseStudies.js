export const caseStudies = [
  {
    slug: 'onshape-distributed-cad-collaboration',
    title: 'How a 40-Engineer Distributed Team Cut CAD Cycle Time 38% with Onshape',
    client: 'Aurora Robotics',
    industry: 'Robotics / Industrial Automation',
    tool: 'Onshape',
    toolSlug: 'onshape',
    category: 'cad',
    date: '2025-01-15',
    readTime: 12,
    cover: 'linear-gradient(135deg, hsl(280 80% 50%), hsl(280 80% 30%))',
    challenge:
      'Aurora Robotics designs autonomous warehouse robots across three offices (Boston, Munich, Bangalore). Their legacy desktop CAD workflow forced nightly file merges, constant version conflicts, and a 5-day average design review cycle. Engineers spent 12+ hours/week on file management instead of engineering.',
    solution:
      'The team migrated to Onshape Professional, adopting Git-style branching for every feature, real-time multi-user editing for mechanism design, and FeatureScript to automate their repeated gripper-finger parametric family. Design reviews moved into the browser with live commenting, eliminating file-pack handoffs.',
    results: [
      { metric: 'Design cycle time', value: '-38%' },
      { metric: 'File-management hours / engineer / week', value: '12 → 2' },
      { metric: 'Design review cycle', value: '5 days → 1.5 days' },
      { metric: 'Time to first prototype', value: '-27%' },
    ],
    roi:
      'Onshape cost $60,000/yr for 40 seats. Saved ~16,000 engineer-hours/yr (12 hrs × 40 × 52 weeks × 0.83 net) valued at $1.6M+ in loaded labor. Net ROI: 25x in the first year, before counting faster time-to-market revenue.',
    testimonial: {
      quote: 'We stopped managing files and started managing designs. The real-time collaboration alone paid for the platform in a quarter.',
      author: 'VP of Engineering, Aurora Robotics',
    },
    internalLinks: [
      { to: '/reviews/onshape-professional-review', text: 'Onshape Professional Review' },
      { to: '/comparisons/cloud-cad-onshape-vs-fusion360', text: 'Cloud CAD Comparison' },
      { to: '/courses/cad-productivity-with-onshape', text: 'CAD Productivity with Onshape Course' },
    ],
  },
  {
    slug: 'simscale-cloud-fea-startup',
    title: 'Startup Validates Bracket Design in 48 Hours with SimScale — No HPC Required',
    client: 'Helix Medical Devices',
    industry: 'Medical Devices',
    tool: 'SimScale',
    toolSlug: 'simscale',
    category: 'simulation',
    date: '2025-02-02',
    readTime: 10,
    cover: 'linear-gradient(135deg, hsl(190 80% 50%), hsl(190 80% 30%))',
    challenge:
      'Helix needed to certify a titanium surgical bracket for fatigue life before a regulatory submission, but had no on-premise FEA hardware and a 6-week lead time to procure an ANSYS license and workstation. The submission deadline was 3 weeks out.',
    solution:
      'Helix ran linear static and fatigue analyses on SimScale\'s cloud platform using the Community + Professional tier. They imported STEP geometry, used the automated mesher, and ran 14 design iterations over two days — each taking ~25 minutes of cloud compute instead of overnight local solves.',
    results: [
      { metric: 'Time to certified analysis', value: '6 weeks → 48 hours' },
      { metric: 'Hardware investment', value: '$0 (cloud)' },
      { metric: 'Design iterations before submission', value: '14' },
      { metric: 'Bracket mass', value: '-18% (within stress limit)' },
    ],
    roi:
      'SimScale Professional ($349/mo) replaced a ~$12,000 ANSYS seat + $4,000 workstation. The 48-hour turnaround kept the regulatory submission on schedule, avoiding an estimated $250,000 in delayed-launch costs.',
    testimonial: {
      quote: 'We went from "we need a workstation" to "we have a certified bracket" in two days. Cloud FEA removed the procurement bottleneck entirely.',
      author: 'Lead Mechanical Engineer, Helix Medical Devices',
    },
    internalLinks: [
      { to: '/tools/simscale', text: 'SimScale Tool Profile' },
      { to: '/comparisons/ansys-vs-comsol-vs-simscale', text: 'ANSYS vs COMSOL vs SimScale' },
      { to: '/courses/fea-essentials-with-ansys', text: 'FEA Essentials Course' },
    ],
  },
  {
    slug: 'n8n-automation-manufacturing-data',
    title: 'Manufacturing Engineer Reclaims 14 Hours/Week with n8n Self-Hosted Automation',
    client: 'Pinnacle Precision Machining',
    industry: 'Precision Manufacturing',
    tool: 'n8n',
    toolSlug: 'n8n',
    category: 'automation',
    date: '2025-02-20',
    readTime: 11,
    cover: 'linear-gradient(135deg, hsl(150 70% 40%), hsl(150 70% 25%))',
    challenge:
      'Pinnacle\'s process engineer spent 14 hours/week manually exporting CMM measurement data, reformatting CSVs, generating SPC charts, and emailing weekly quality reports to three managers. The manual pipeline was error-prone and delayed quality signals by up to a week.',
    solution:
      'A self-hosted n8n instance on a $20/mo VPS now polls the CMM output folder, parses CSVs with a Python code node, computes Cpk and control limits, renders matplotlib charts, and emails a branded PDF report every Friday at 8am — with a Slack alert if any Cpk drops below 1.33.',
    results: [
      { metric: 'Weekly report labor', value: '14 hrs → 0 hrs (automated)' },
      { metric: 'Quality signal latency', value: '7 days → real-time alerts' },
      { metric: 'Reporting errors', value: '-94%' },
      { metric: 'Monthly tool cost', value: '$20 (VPS)' },
    ],
    roi:
      '14 hrs/week × $85/hr loaded = $1,190/week saved = ~$61,800/yr. Against $240/yr VPS cost, ROI is 257x. The real-time Cpk alerting also caught a spindle drift issue 4 days earlier than the old weekly report would have.',
    testimonial: {
      quote: 'n8n let me, an engineer — not a developer — build a production data pipeline in an afternoon. It paid for itself the first week.',
      author: 'Process Engineer, Pinnacle Precision',
    },
    internalLinks: [
      { to: '/tools/n8n', text: 'n8n Tool Profile' },
      { to: '/courses/engineering-automation-with-python', text: 'Engineering Automation with Python' },
      { to: '/guides', text: 'Engineering Guides' },
    ],
  },
  {
    slug: 'chatgpt-documentation-workflow',
    title: 'Engineering Team Cuts Report Writing Time 60% with a ChatGPT Prompt Library',
    client: 'Vector Energy',
    industry: 'Renewable Energy / Power Systems',
    tool: 'ChatGPT',
    toolSlug: 'chatgpt',
    category: 'ai',
    date: '2025-03-05',
    readTime: 9,
    cover: 'linear-gradient(135deg, hsl(217 91% 55%), hsl(217 91% 35%))',
    challenge:
      'Vector\'s 12-person engineering team produced 30+ technical reports/month for utility clients. Each report took 6-8 hours to draft from analysis notes, with inconsistent formatting across authors. Senior engineers reviewed more for style than substance.',
    solution:
      'The team built a shared ChatGPT prompt library: a "report skeleton" prompt that converts bullet-point analysis into a structured first draft, a "standards citation" prompt that surfaces relevant IEEE sections, and a "plain-language summary" prompt for executive sections. Engineers edit and verify rather than write from scratch.',
    results: [
      { metric: 'Avg. report drafting time', value: '7 hrs → 2.8 hrs (-60%)' },
      { metric: 'Reports / month', value: '30 → 48 (capacity up 60%)' },
      { metric: 'Formatting inconsistencies', value: '-81%' },
      { metric: 'Senior review time', value: '-45%' },
    ],
    roi:
      '4.2 hrs saved per report × 48 reports × $90/hr = $18,144/mo = ~$217,000/yr in reclaimed capacity. ChatGPT Team cost: $2,400/yr. ROI: 90x, plus 60% more throughput without hiring.',
    testimonial: {
      quote: 'The prompt library turned ChatGPT from a toy into a report-writing teammate. Our engineers now spend time on engineering, not formatting.',
      author: 'Engineering Manager, Vector Energy',
    },
    internalLinks: [
      { to: '/ai-tools/chatgpt-for-engineering', text: 'ChatGPT for Engineers' },
      { to: '/reviews/chatgpt-pro-review', text: 'ChatGPT Pro Review' },
      { to: '/courses/ai-for-mechanical-engineers', text: 'AI for Mechanical Engineers Course' },
    ],
  },
  {
    slug: 'keyence-vision-defect-detection',
    title: 'Electronics Manufacturer Cuts Defect Escape Rate 92% with Keyence AI Vision',
    client: 'Cirtronics EMS',
    industry: 'Electronics Manufacturing (EMS)',
    tool: 'Keyence Vision Systems',
    toolSlug: 'keyence-vision-system-review',
    category: 'simulation',
    date: '2025-03-18',
    readTime: 13,
    cover: 'linear-gradient(135deg, hsl(38 96% 52%), hsl(38 96% 35%))',
    challenge:
      'Cirtronics inspected solder joints on high-mix PCB assemblies with manual microscopy. Defect escape rate to customers ran at 0.8% — unacceptable for medical-device OEM clients. Hiring vision specialists for a custom Cognex deployment was a 9-month project.',
    solution:
      'A Keyence CV-X system with the AI deep-learning module was commissioned in 3 weeks by Cirtronics\' own process engineers (no vision specialists). They trained the defect classifier on 180 labeled images of solder defects and deployed inline inspection on two high-volume lines.',
    results: [
      { metric: 'Defect escape rate', value: '0.8% → 0.06% (-92%)' },
      { metric: 'Inspection throughput', value: '+210%' },
      { metric: 'Deployment time', value: '9 months → 3 weeks' },
      { metric: 'Manual inspection labor', value: '-70%' },
    ],
    roi:
      'System cost ~$45,000. Avoided one medical-device OEM contract loss worth $1.2M/yr and cut 2.5 FTE inspection roles (~$170,000/yr). Payback: under 4 months. The AI module\'s small-dataset training removed the vision-specialist dependency entirely.',
    testimonial: {
      quote: 'Keyence let our own engineers build a vision system in three weeks. The AI defect detection caught defects we were missing by eye every day.',
      author: 'Quality Director, Cirtronics EMS',
    },
    internalLinks: [
      { to: '/reviews/keyence-vision-system-review', text: 'Keyence Vision System Review' },
      { to: '/comparisons/keyence-vs-cognex-vs-flir-measurement', text: 'Keyence vs Cognex vs FLIR' },
      { to: '/guides', text: 'Engineering Guides' },
    ],
  },
  {
    slug: 'fusion360-generative-design-lightweighting',
    title: 'Aerospace Supplier Lightweights Bracket 34% with Fusion 360 Generative Design',
    client: 'Stratos Aerostructures',
    industry: 'Aerospace Supply Chain',
    tool: 'Autodesk Fusion 360',
    toolSlug: 'fusion360',
    category: 'cad',
    date: '2025-04-01',
    readTime: 11,
    cover: 'linear-gradient(135deg, hsl(190 80% 50%), hsl(217 91% 40%))',
    challenge:
      'Stratos needed to lightweight an engine mounting bracket to win a new airframe contract with a strict mass budget. Traditional topology optimization required a separate Altair Inspire license ($20k/yr) and a specialist — neither available in the 4-week bid window.',
    solution:
      'Using Fusion 360\'s included generative design, Stratos set preserve and obstacle geometries, applied load cases (thrust, vibration, landing), and generated 6 manufacturable variants in a single afternoon. They selected a CNC-millable titanium variant and validated it with Fusion\'s built-in FEA.',
    results: [
      { metric: 'Bracket mass', value: '-34%' },
      { metric: 'Generative design time', value: '2 weeks → 1 day' },
      { metric: 'Additional software cost', value: '$0 (included)' },
      { metric: 'Stress margin', value: '+12% safety factor' },
    ],
    roi:
      'Fusion 360 ($545/yr) replaced a $20,000 Altair Inspire seat. The 34% mass reduction won the $4.8M airframe contract — a bid they would have lost on mass alone. ROI measured in contract value, not just cost savings.',
    testimonial: {
      quote: 'Generative design in Fusion 360 let us win a contract we had no business winning with our old toolset. One afternoon of compute beat two weeks of specialist work.',
      author: 'Chief Engineer, Stratos Aerostructures',
    },
    internalLinks: [
      { to: '/reviews/fusion360-advanced-review', text: 'Fusion 360 Review' },
      { to: '/comparisons/solidworks-vs-fusion360-vs-onshape', text: 'CAD Comparison' },
      { to: '/courses/cad-productivity-with-onshape', text: 'CAD Productivity Course' },
    ],
  },
  {
    slug: 'ansys-simai-certification-acceleration',
    title: 'Automotive Tier-1 Cuts Crash Simulation Time 99% with ANSYS SimAI Surrogates',
    client: 'Meridian Automotive',
    industry: 'Automotive Tier-1 Supplier',
    tool: 'ANSYS Workbench',
    toolSlug: 'ansys-workbench-review',
    category: 'simulation',
    date: '2025-04-22',
    readTime: 14,
    cover: 'linear-gradient(135deg, hsl(190 80% 45%), hsl(217 91% 45%))',
    challenge:
      'Meridian runs 300+ crashworthiness simulations per vehicle program. Each full LS-DYNA run took 18 hours on a 256-core cluster, bottlenecking the design exploration loop to 2-3 variants/week. The certification deadline for a new EV battery enclosure left no room for iteration.',
    solution:
      'Meridian trained an ANSYS SimAI surrogate model on 200 prior crash runs. The surrogate predicts stress and deformation fields in under 30 seconds — 2,000x faster — letting engineers screen 50+ design variants per day and reserve full-fidelity runs for the top 3 finalists.',
    results: [
      { metric: 'Per-variant simulation time', value: '18 hrs → 25 sec (-99.9%)' },
      { metric: 'Variants screened / week', value: '3 → 250+' },
      { metric: 'Cluster core-hours / program', value: '-68%' },
      { metric: 'Certification submission', value: 'On time (was 3 weeks late)' },
    ],
    roi:
      'SimAI license added ~$35,000/yr. Saved 46,000 cluster core-hours/program (~$138,000 in HPC costs) and avoided a 3-week launch delay worth an estimated $900,000 in delayed revenue. Net first-year ROI: ~28x.',
    testimonial: {
      quote: 'SimAI didn\'t replace our full-fidelity runs — it made them count. We now only run the expensive simulations on designs we already know are good.',
      author: 'CAE Manager, Meridian Automotive',
    },
    internalLinks: [
      { to: '/reviews/ansys-workbench-review', text: 'ANSYS Workbench Review' },
      { to: '/comparisons/ansys-vs-comsol-vs-simscale', text: 'Simulation Comparison' },
      { to: '/courses/fea-essentials-with-ansys', text: 'FEA Essentials Course' },
    ],
  },
  {
    slug: 'claude-standards-review-workflow',
    title: 'Consultancy Halves Standards-Review Time with Claude\'s 200K Context Window',
    client: 'Beacon Engineering Consultants',
    industry: 'Engineering Consulting',
    tool: 'Claude',
    toolSlug: 'claude',
    category: 'ai',
    date: '2025-05-08',
    readTime: 10,
    cover: 'linear-gradient(135deg, hsl(280 80% 55%), hsl(340 80% 50%))',
    challenge:
      'Beacon reviews client designs against full ASME B31.3 and API 610 standards — documents that run 300+ pages each. Engineers manually cross-referenced clauses, producing review reports that took 3 days per project and occasionally missed applicable clauses.',
    solution:
      'Beacon loads the full standard PDFs plus the client design package into Claude\'s 200K context window, then prompts Claude to extract every applicable clause, flag non-conformances, and draft a structured compliance report. Engineers verify each citation against the source (Claude flags uncertainty rather than fabricating).',
    results: [
      { metric: 'Standards-review time / project', value: '3 days → 1.2 days (-60%)' },
      { metric: 'Missed-clause incidents', value: '-78%' },
      { metric: 'Projects / engineer / month', value: '+55%' },
      { metric: 'Citation accuracy (verified)', value: '96%' },
    ],
    roi:
      '1.8 days saved per project × 22 projects/mo × $110/hr = $42,000/mo = ~$500,000/yr in reclaimed capacity. Claude Pro: $240/yr. ROI: 2,000x+, with materially fewer compliance misses.',
    testimonial: {
      quote: 'Claude reads the whole standard in one pass and tells us what applies. We verify every citation — but the finding is done in minutes, not days.',
      author: 'Principal Consultant, Beacon Engineering',
    },
    internalLinks: [
      { to: '/ai-tools/claude-for-engineering', text: 'Claude for Engineers' },
      { to: '/reviews', text: 'Expert Reviews' },
      { to: '/courses/ai-for-mechanical-engineers', text: 'AI for Mechanical Engineers' },
    ],
  },
  {
    slug: 'flir-thermal-predictive-maintenance',
    title: 'Food Processor Prevents $1.4M Line Stoppage with FLIR Thermal Monitoring',
    client: 'Greenfield Foods',
    industry: 'Food & Beverage Manufacturing',
    tool: 'FLIR Thermal Imaging',
    toolSlug: 'flir-thermal-imaging-review',
    category: 'simulation',
    date: '2025-05-20',
    readTime: 12,
    cover: 'linear-gradient(135deg, hsl(0 72% 52%), hsl(38 96% 45%))',
    challenge:
      'Greenfield\'s continuous bottling line had two unplanned motor failures in a year, each causing 14-hour stoppages costing ~$100,000/hour in lost production. Preventive maintenance was calendar-based and caught neither failure.',
    solution:
      'Greenfield installed FLIR A50 fixed thermal cameras on 18 critical motors and bearings, connected to FLIR Thermal Studio\'s AI anomaly detection. The system baselines each asset\'s thermal signature and alerts maintenance when temperatures trend outside the learned normal envelope — before failure.',
    results: [
      { metric: 'Unplanned motor failures', value: '2/yr → 0 (12 months running)' },
      { metric: 'Mean time to detect bearing fault', value: 'Failure → 9 days early' },
      { metric: 'Unplanned downtime', value: '-100%' },
      { metric: 'Maintenance scheduling', value: 'Calendar-based → condition-based' },
    ],
    roi:
      'System cost ~$72,000 (cameras + software). Avoided 2 stoppages/yr × 14 hrs × $100,000 = $2.8M in lost production. ROI: 38x in year one. The early bearing-fault detection alone prevented an estimated $1.4M stoppage.',
    testimonial: {
      quote: 'The FLIR system told us a bearing was failing nine days before it would have taken down the line. That single catch paid for the entire system.',
      author: 'Maintenance Manager, Greenfield Foods',
    },
    internalLinks: [
      { to: '/reviews/flir-thermal-imaging-review', text: 'FLIR Thermal Imaging Review' },
      { to: '/guides?open=predictive-maintenance-ai-guide', text: 'AI Predictive Maintenance Guide' },
      { to: '/comparisons/keyence-vs-cognex-vs-flir-measurement', text: 'Vision & Measurement Comparison' },
    ],
  },
  {
    slug: 'mit-ocw-team-upskilling',
    title: 'Engineering Firm Upskills 30 Engineers for $0 with MIT OpenCourseWare',
    client: 'Lattice Engineering',
    industry: 'Multi-discipline Engineering Services',
    tool: 'MIT OpenCourseWare',
    toolSlug: 'mit-ocw',
    category: 'learning',
    date: '2025-06-03',
    readTime: 9,
    cover: 'linear-gradient(135deg, hsl(340 80% 50%), hsl(280 80% 45%))',
    challenge:
      'Lattice needed 30 engineers across three offices to strengthen fundamentals in thermodynamics, fluid mechanics, and control systems for a new energy-systems practice. A commercial training provider quoted $180,000 for a 6-month program — over budget and off-schedule.',
    solution:
      'Lattice built a structured learning path from MIT OCW courses (2.006, 2.003, 2.140), paired each engineer with a peer-study partner, and ran biweekly internal discussion sessions led by senior staff. Engineers completed problem sets on their own schedule, with OCW\'s free solutions for self-checking.',
    results: [
      { metric: 'Training cost', value: '$180,000 → $0' },
      { metric: 'Engineers upskilled', value: '30' },
      { metric: 'Completion rate', value: '87% (26/30)' },
      { metric: 'New practice revenue (yr 1)', value: '$1.1M' },
    ],
    roi:
      'MIT OCW cost: $0. Avoided $180,000 in vendor training. The upskilled team launched the energy-systems practice, which booked $1.1M in first-year revenue that would otherwise have required hiring 3 senior engineers (~$510,000/yr). Effective ROI: infinite on direct cost; ~7x on opportunity cost.',
    testimonial: {
      quote: 'We gave our engineers MIT-caliber fundamentals for free. The internal discussion sessions made it stick — and we launched a new practice without hiring.',
      author: 'Director of Engineering, Lattice Engineering',
    },
    internalLinks: [
      { to: '/tools/mit-ocw', text: 'MIT OpenCourseWare Profile' },
      { to: '/courses', text: 'Premium Courses' },
      { to: '/guides', text: 'Engineering Guides' },
    ],
  },
];

export const caseStudyCategories = [
  { id: 'all', label: 'All Case Studies' },
  { id: 'ai', label: 'AI Tools' },
  { id: 'cad', label: 'CAD & Design' },
  { id: 'simulation', label: 'Simulation' },
  { id: 'automation', label: 'Automation' },
  { id: 'learning', label: 'Learning' },
];

export const getCaseStudyBySlug = (slug) => caseStudies.find((c) => c.slug === slug);
export const getCaseStudiesByCategory = (cat) =>
  cat === 'all' ? caseStudies : caseStudies.filter((c) => c.category === cat);
