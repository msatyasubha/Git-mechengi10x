export const sponsorshipPackages = [
  {
    id: 'featured-tool',
    name: 'Featured Tool',
    tagline: 'Top-of-directory visibility for your engineering product',
    price: 2500,
    period: '/ quarter',
    accent: 'badge-ai',
    popular: false,
    summary:
      'Get your tool pinned to the top of its category and the homepage featured row, with a branded card, verified badge, and direct affiliate link.',
    deliverables: [
      'Pinned placement in your category for 90 days',
      'Homepage "Featured Tools" rotation',
      'Branded card with logo, screenshot & custom copy',
      '"Verified Partner" badge on your tool profile',
      'Direct affiliate / trial link with click tracking',
      'Monthly performance report (impressions, clicks, conversions)',
    ],
    benefits: [
      '3–5x more profile views than standard listings',
      'Priority indexing on comparison pages',
      'Included in the weekly newsletter once per quarter',
    ],
    roi: [
      { metric: 'Avg. profile views / mo', value: '4,200' },
      { metric: 'Avg. CTR to your site', value: '8.4%' },
      { metric: 'Estimated trial signups / qtr', value: '180–260' },
    ],
    bestFor: 'Established tools that want sustained category leadership.',
  },
  {
    id: 'exclusive-review',
    name: 'Exclusive Review',
    tagline: 'A full expert review written by our engineering team',
    price: 5000,
    period: ' one-time',
    accent: 'badge-management',
    popular: true,
    summary:
      'Our engineering team publishes a 2,500+ word expert review with an editorial assessment across our 8 MechEngi Score categories, use cases, and FAQ — permanently hosted and SEO-optimized.',
    deliverables: [
      '2,500–3,500 word expert review by a mechanical engineer',
      'Editorial assessment across the 8 MechEngi Score categories',
      'Workflow walkthroughs and documented use cases',
      'Dedicated /reviews/:slug page, permanently hosted',
      'SEO optimization (Article, FAQ & BreadcrumbList schema)',
      'Internal links from relevant guides & comparisons',
      'Syndication teaser in the newsletter + LinkedIn',
    ],
    benefits: [
      'Permanent high-intent search traffic',
      'Third-party credibility from an independent review',
      'Reusable asset for your own sales enablement',
    ],
    roi: [
      { metric: 'Avg. review page views / mo', value: '2,800' },
      { metric: 'Time on page', value: '4m 12s' },
      { metric: 'Inbound "try tool" clicks / mo', value: '230' },
    ],
    bestFor: 'Tools that benefit from deep, trusted third-party evaluation.',
  },
  {
    id: 'webinar-sponsorship',
    name: 'Webinar Sponsorship',
    tagline: 'Co-host a live engineering webinar with MechEngi 10X',
    price: 7500,
    period: '/ event',
    accent: 'badge-learning',
    popular: false,
    summary:
      'Co-produce a 45-minute live webinar on an engineering topic your tool solves. We handle audience, hosting, and promotion; you bring the expertise and demo.',
    deliverables: [
      '45-minute live webinar (Zoom), co-hosted',
      'Promotion to our engineering-subscriber audience',
      'Branded webinar landing page with registration',
      'Live tool demo segment (10 min)',
      'Recorded replay hosted for 12 months',
      'Attendee list export (opt-in contacts only)',
      'Post-webinar recap blog post with sponsor mention',
    ],
    benefits: [
      'Direct lead generation from a qualified audience',
      'Thought leadership alongside your product',
      'Replay content keeps generating leads for a year',
    ],
    roi: [
      { metric: 'Avg. registrations', value: '650' },
      { metric: 'Avg. live attendees', value: '240' },
      { metric: 'Opt-in leads delivered', value: '180–220' },
    ],
    bestFor: 'Tools with a clear educational angle and a demo-ready workflow.',
  },
];

export const sponsorTestimonials = [
  {
    company: 'Onshape',
    logo: 'OS',
    quote:
      'The Exclusive Review drove more qualified trial signups in one quarter than our last two trade shows combined. The MechEngi team genuinely understands engineering software.',
    author: 'Director of Growth',
    results: [
      { metric: 'Trial signups', value: '+212%' },
      { metric: 'Review page views', value: '9,400' },
    ],
  },
  {
    company: 'SimScale',
    logo: 'SS',
    quote:
      'Webinar sponsorship gave us a room full of mechanical engineers who actually needed cloud simulation. The replay is still sending us leads six months later.',
    author: 'Head of Marketing',
    results: [
      { metric: 'Registrations', value: '780' },
      { metric: 'Qualified leads', value: '210' },
    ],
  },
  {
    company: 'n8n',
    logo: 'n8',
    quote:
      'Featured Tool placement kept us at the top of the automation category for the whole quarter. The monthly reports made it easy to justify renewal.',
    author: 'Community Lead',
    results: [
      { metric: 'Profile views', value: '12,600' },
      { metric: 'CTR to site', value: '9.1%' },
    ],
  },
];

export const budgetRanges = [
  'Under $2,500',
  '$2,500 – $5,000',
  '$5,000 – $10,000',
  '$10,000 – $25,000',
  '$25,000+',
];

export function getPackageById(id) {
  return sponsorshipPackages.find((p) => p.id === id);
}
