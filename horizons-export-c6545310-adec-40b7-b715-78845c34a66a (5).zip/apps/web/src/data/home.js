import { Shield, Award, Users, BookOpen, TrendingUp } from 'lucide-react';

export const ticker = [
  'ChatGPT · ANSYS · Fusion 360 · SimScale · Jira · Coursera · FreeCAD · Zapier · Onshape · GitHub Copilot · Claude · Notion · Brilliant · MIT OCW · VS Code · Docker · Kubernetes · MATLAB · CATIA · Cursor · Linear',
  'ChatGPT · ANSYS · Fusion 360 · SimScale · Jira · Coursera · FreeCAD · Zapier · Onshape · GitHub Copilot · Claude · Notion · Brilliant · MIT OCW · VS Code · Docker · Kubernetes · MATLAB · CATIA · Cursor · Linear',
];

export const stats = [
  { value: '80+', label: 'Tools Reviewed', icon: Shield },
  { value: '7', label: 'Expert Guides', icon: BookOpen },
  { value: '10', label: 'Comparisons', icon: TrendingUp },
  { value: '100%', label: 'Independent', icon: Award },
];

export const trustSignals = [
  {
    icon: Shield,
    title: 'Vendor-Independent Reviews',
    desc: 'Commercial Transparency: MechEngi10X may receive sponsorship, affiliate revenue, or other commercial support from technology providers. Commercial relationships do not determine our editorial scores, rankings, or recommendations. Sponsored placements are clearly identified.',
  },
  {
    icon: Award,
    title: 'Independent Editorial Assessment',
    desc: 'Our MechEngi Score framework assesses tools across 8 weighted categories: engineering effectiveness, reliability, API extensibility, TCO, security, industry adoption, UX, and documentation. Per-category numeric scores are published only when backed by documented benchmark data — until then, tools show an explicit “Not Yet Rated” state.',
  },
  {
    icon: TrendingUp,
    title: 'Continuously Updated',
    desc: 'Tool pricing, features, and editorial assessments are reviewed regularly to reflect software updates and pricing changes. We publish what is verified and clearly label what is not.',
  },
  {
    icon: Users,
    title: 'Built by Engineers',
    desc: 'Every guide and comparison is authored by working mechanical and software engineers — not content writers who\'ve never run an FEA simulation.',
  },
];

export const useCases = [
  { icon: '🤖', label: 'AI for Engineering', desc: 'ChatGPT, Claude, Copilot', to: '/tools?cat=ai', badge: 'ai' },
  { icon: '🔄', label: 'Automate Reports', desc: 'Zapier, Make, n8n', to: '/tools?cat=automation', badge: 'automation' },
  { icon: '📐', label: 'CAD Productivity', desc: 'SOLIDWORKS, Fusion 360, Onshape', to: '/tools?cat=cad', badge: 'cad' },
  { icon: '🔬', label: 'FEA & Simulation', desc: 'ANSYS, COMSOL, SimScale', to: '/tools?cat=simulation', badge: 'simulation' },
  { icon: '📋', label: 'Project Management', desc: 'Notion, Jira, Asana', to: '/tools?cat=management', badge: 'management' },
  { icon: '🎓', label: 'Learning & Upskilling', desc: 'Coursera, Udemy, Brilliant', to: '/tools?cat=learning', badge: 'learning' },
  { icon: '📊', label: 'Data Analysis', desc: 'Python, AI tools, automation', to: '/tools?cat=ai', badge: 'ai' },
  { icon: '📷', label: 'Measurement & QC', desc: 'Keyence, Cognex, FLIR', to: '/tools?cat=simulation', badge: 'simulation' },
  { icon: '💻', label: 'Software & DevOps', desc: 'VS Code, Docker, Kubernetes, Git', to: '/tools?cat=software', badge: 'software' },
];

export const jobsTeaser = [
  // Global — curated international (US/EU) featured positions
  { title: 'Senior Mechanical Design Engineer', company: 'SpaceX', location: 'Hawthorne, CA', region: 'global', category: 'cad', salary: '$120k–$160k', posted: '2 days ago', tags: ['SOLIDWORKS', 'Aerospace'] },
  { title: 'FEA / Simulation Engineer', company: 'Tesla', location: 'Fremont, CA', region: 'global', category: 'simulation', salary: '$110k–$150k', posted: '3 days ago', tags: ['ANSYS', 'Python'] },
  { title: 'Robotics Automation Engineer', company: 'Boston Dynamics', location: 'Waltham, MA', region: 'global', category: 'automation', salary: '$115k–$155k', posted: '5 days ago', tags: ['ROS', 'Control Systems'] },
  // India — curated India-based positions with indicative CTC bands (₹)
  { title: 'Senior CAD Engineer', company: 'Tata Technologies', location: 'Pune, India', region: 'india', category: 'cad', salary: '₹8–15 LPA', posted: '2 days ago', tags: ['CATIA', 'SOLIDWORKS'] },
  { title: 'CAE Analyst', company: 'Bosch India', location: 'Bengaluru, India', region: 'india', category: 'simulation', salary: '₹6–12 LPA', posted: '4 days ago', tags: ['ANSYS', 'Hypermesh'] },
  { title: 'Design Engineer', company: 'Larsen & Toubro', location: 'Hyderabad, India', region: 'india', category: 'cad', salary: '₹5–10 LPA', posted: '6 days ago', tags: ['Creo', 'AutoCAD'] },
];
