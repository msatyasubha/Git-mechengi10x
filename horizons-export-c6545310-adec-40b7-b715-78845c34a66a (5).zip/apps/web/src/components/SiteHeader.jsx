import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Zap, Menu, X, ChevronDown, ArrowRight } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { navCategories } from '@/data/tools';
import CurrencyToggle from '@/components/CurrencyToggle';

const navLinks = [
  { to: '/wizard', label: 'Find a Tool' },
  { to: '/ai-tools', label: 'AI Profiles' },
  { to: '/emerging-tools', label: 'Emerging AI' },
  { to: '/advisor', label: 'AI Advisor' },
  { to: '/compare', label: 'Compare' },
  { to: '/guides', label: 'Guides' },
  { to: '/reviews', label: 'Reviews' },
  { to: '/calculators', label: 'Calculators' },
  { to: '/free-tools', label: 'Free Tools' },
  { to: '/resources', label: 'Resources' },
  { to: '/macro-generator', label: 'Macro Generator' },
  { to: '/macro-library', label: 'Macro & Script Library' },
  { to: '/workflows', label: 'Workflow Library' },
  { to: '/enterprise-quote', label: 'Enterprise CAD/FEA Quotes' },
  { to: '/erp-integration', label: 'CAD-to-ERP Integration' },
  { to: '/stack-consulting', label: 'Stack Consulting' },
  { to: '/jobs', label: 'Jobs' },
  { to: '/membership', label: 'Premium Membership' },
];

const mobileExtraLinks = [
  { to: '/case-studies', label: 'Case Studies' },
  { to: '/videos', label: 'Video Library' },
  { to: '/podcast', label: 'Podcast' },
  { to: '/events', label: 'Webinars' },
  { to: '/membership', label: 'Membership' },
  { to: '/affiliate', label: 'Affiliate Program' },
  { to: '/referral', label: 'Referral Program' },
];

export default function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-[90rem] items-center justify-between gap-3 px-4 sm:h-16 sm:px-5">
        {/* Logo — distinct flex item, never squeezed by nav */}
        <Link to="/" className="flex shrink-0 items-center gap-2 font-display text-base font-bold sm:text-lg">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-primary">
            <Zap className="h-4 w-4 text-primary-foreground" strokeWidth={2.5} />
          </span>
          <span className="truncate">MechEngi<span className="text-primary"> 10X</span></span>
        </Link>

        {/* Desktop nav — collapses to the hamburger below 1300px so the
            "Find a Tool" CTA is never pushed off screen. */}
        <nav className="hidden items-center gap-0.5 min-[1300px]:flex">
          {/* Tools megamenu trigger */}
          <div
            className="relative"
            onMouseEnter={() => setToolsOpen(true)}
            onMouseLeave={() => setToolsOpen(false)}
          >
            <button className="flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">
              Tools <ChevronDown className="h-3.5 w-3.5" />
            </button>
            {toolsOpen && (
              <div className="absolute left-0 top-full mt-1 w-72 rounded-xl border border-border bg-card p-2 shadow-xl shadow-black/20">
                <Link
                  to="/tools"
                  className="mb-1 flex items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold text-primary hover:bg-primary/10"
                  onClick={() => setToolsOpen(false)}
                >
                  All Tools Directory <ArrowRight className="h-3.5 w-3.5" />
                </Link>
                <Link
                  to="/ai-tools"
                  className="mb-1 flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium text-accent hover:bg-accent/10"
                  onClick={() => setToolsOpen(false)}
                >
                  AI Tool Profiles <ArrowRight className="h-3.5 w-3.5" />
                </Link>
                <div className="my-1.5 h-px bg-border" />
                {navCategories.map((cat) => (
                  <Link
                    key={cat.id}
                    to={`/tools?cat=${cat.id}`}
                    onClick={() => setToolsOpen(false)}
                    className="flex items-center gap-2.5 rounded-lg px-3 py-2 transition-colors hover:bg-muted"
                  >
                    <span className="text-base">{cat.icon}</span>
                    <span className="text-sm font-medium">{cat.label}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {[
            { to: '/ai-tools', label: 'AI Profiles' },
            { to: '/tools', label: 'Directory' },
            { to: '/advisor', label: 'AI Advisor' },
            { to: '/compare', label: 'Compare' },
            { to: '/guides', label: 'Guides' },
            { to: '/reviews', label: 'Reviews' },
          ].map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-muted text-foreground underline decoration-primary decoration-2 underline-offset-4'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}

          {/* More megamenu */}
          <div
            className="relative"
            onMouseEnter={() => setMoreOpen(true)}
            onMouseLeave={() => setMoreOpen(false)}
          >
            <button className="flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">
              More <ChevronDown className="h-3.5 w-3.5" />
            </button>
            {moreOpen && (
              <div className="absolute right-0 top-full mt-1 w-56 rounded-xl border border-border bg-card p-2 shadow-xl shadow-black/20">
                {[
                  { to: '/membership', label: 'Premium Membership' },
                  { to: '/jobs', label: 'Engineering Jobs' },
                  { to: '/erp-integration', label: 'CAD-to-ERP Integration' },
                  { to: '/stack-consulting', label: 'Stack Consulting' },
                  { to: '/macro-generator', label: 'CAD Macro Generator' },
                  { to: '/macro-library', label: 'Macro & Script Library' },
                  { to: '/workflows', label: 'Workflow Library' },
                  { to: '/enterprise-quote', label: 'Enterprise CAD/FEA Quotes' },
                ].map((l) => (
                  <Link
                    key={l.to}
                    to={l.to}
                    onClick={() => setMoreOpen(false)}
                    className="flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                  >
                    {l.label} <ArrowRight className="h-3.5 w-3.5 opacity-50" />
                  </Link>
                ))}
              </div>
            )}
          </div>
        </nav>

        {/* Desktop auth + CTA */}
        <div className="hidden items-center gap-3 min-[1300px]:flex">
          <CurrencyToggle compact />
          {user ? (
            <div className="flex items-center gap-3">
              <Link to="/profile" className="max-w-[140px] truncate text-sm text-muted-foreground hover:text-foreground">{user.email}</Link>
              <button
                onClick={handleLogout}
                className="rounded-md border border-border px-4 py-1.5 text-sm font-medium transition-colors hover:border-foreground"
              >
                Sign out
              </button>
            </div>
          ) : (
            <>
              <Link
                to="/sponsor"
                className="inline-flex items-center gap-1.5 rounded-md border border-accent/40 bg-accent/5 px-3 py-1.5 text-sm font-medium text-accent transition-colors hover:bg-accent/10"
              >
                Sponsor
                <span className="rounded bg-accent/15 px-1 py-0.5 font-mono text-[8px] uppercase tracking-wider">B2B</span>
              </Link>
              <Link
                to="/login"
                className="rounded-md px-4 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                Sign in
              </Link>
              <Link
                to="/tools"
                className="glow-primary rounded-md bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
              >
                Find a Tool
              </Link>
            </>
          )}
        </div>

        {/* Mobile hamburger */}
        <button
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-md text-muted-foreground min-[1300px]:hidden"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="max-h-[calc(100dvh-3.5rem)] overflow-y-auto border-t border-border bg-background/95 px-4 py-4 sm:px-5 min-[1300px]:hidden">
          <div className="mb-3 flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Display currency</span>
            <CurrencyToggle />
          </div>
          {/* Category shortcuts */}
          <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Browse by Category</p>
          <div className="mb-3 grid grid-cols-2 gap-1.5">
            {navCategories.map((cat) => (
              <Link
                key={cat.id}
                to={`/tools?cat=${cat.id}`}
                className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-muted-foreground hover:border-primary/30 hover:text-foreground"
                onClick={() => setOpen(false)}
              >
                <span>{cat.icon}</span>
                <span className="text-xs font-medium">{cat.label === 'Engineering Management' ? 'Management' : cat.label}</span>
              </Link>
            ))}
          </div>
          <div className="h-px bg-border" />
          <nav className="mt-3 flex flex-col gap-1">
            {navLinks.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="rounded-md px-3 py-2.5 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
                onClick={() => setOpen(false)}
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="mt-4 flex flex-col gap-2 border-t border-border pt-4">
            {user ? (
              <>
                <Link to="/profile" className="rounded-md border border-border px-4 py-2 text-center text-sm font-medium hover:border-primary/40 hover:text-primary" onClick={() => setOpen(false)}>
                  My Profile
                </Link>
                <button
                  onClick={() => { handleLogout(); setOpen(false); }}
                  className="rounded-md border border-border px-4 py-2 text-sm font-medium"
                >
                  Sign out
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="rounded-md px-4 py-2 text-center text-sm font-medium text-muted-foreground" onClick={() => setOpen(false)}>
                  Sign in
                </Link>
                <Link to="/tools" className="rounded-md bg-primary px-4 py-2 text-center text-sm font-semibold text-primary-foreground" onClick={() => setOpen(false)}>
                  Find a Tool
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
