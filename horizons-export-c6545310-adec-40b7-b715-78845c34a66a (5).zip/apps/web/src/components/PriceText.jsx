import { useCurrency } from '@/contexts/CurrencyContext';
import { formatInr, pricePeriod } from '@/lib/currency';

/**
 * Renders a tool's "From $X/yr" starting price. When the visitor has selected
 * INR display, the approximate INR conversion is shown alongside the original
 * USD vendor price (never replacing it).
 */
export default function PriceText({ usd, className = '' }) {
  const { currency } = useCurrency();
  if (!usd || usd <= 0) return null;
  const period = pricePeriod(usd);
  if (currency === 'INR') {
    return (
      <span className={className}>
        From <span className="text-foreground">${usd}</span>
        {period}
        <span className="text-muted-foreground"> (≈{formatInr(usd)}{period})</span>
      </span>
    );
  }
  return (
    <span className={className}>
      From <span className="text-foreground">${usd}</span>
      {period}
    </span>
  );
}
