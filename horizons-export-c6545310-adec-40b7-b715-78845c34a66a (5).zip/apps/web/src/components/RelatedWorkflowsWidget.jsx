import { Link } from 'react-router-dom';
import { Workflow } from 'lucide-react';

/**
 * RelatedWorkflowsWidget — contextual sidebar widget that surfaces relevant
 * engineering workflow guides on individual tool detail pages.
 *
 * Link selection is driven by the tool's CATEGORY (not its display name), so it
 * stays correct as the tool directory grows. Only guides whose routes actually
 * exist in App.jsx are listed; categories whose designated destination is
 * missing (e.g. simulation → /workflows/fea-mesh-audit, ai →
 * /workflows/ai-document-compliance) are intentionally omitted rather than
 * producing broken links. When a category has no valid links the widget
 * renders nothing, so unsupported pages show no misleading recommendations.
 *
 * Visual tokens (per spec): slate-700 border (#334155), slate-900 background
 * (#0F172A), slate-200 text, 12px radius, 20px padding. Links are wrapped in a
 * semantic <nav aria-label="Related Engineering Workflows"> and meet the 44px
 * minimum touch-target height on mobile.
 */
const WORKFLOW_LINKS = {
  // CAD / modeling tools → both drawing-QA and BOM guides exist.
  cad: [
    { to: '/workflows/ai-drawing-qa-gdt', label: 'Automated SOLIDWORKS Drawing QA & GD&T Pipeline →' },
    { to: '/workflows/solidworks-bom-n8n', label: 'SOLIDWORKS BOM Extraction → JSON → n8n Guide →' },
  ],
  // simulation: /workflows/fea-mesh-audit does not exist → omitted (no broken link).
  // ai: /workflows/ai-document-compliance does not exist → omitted (no broken link).
};

export default function RelatedWorkflowsWidget({ category, className = '' }) {
  const links = category ? WORKFLOW_LINKS[category] : null;
  if (!links || links.length === 0) return null;

  return (
    <nav
      aria-label="Related Engineering Workflows"
      className={`rounded-xl border border-[#334155] bg-[#0F172A] p-5 text-[#F8FAFC] ${className}`}
    >
      <div className="mb-3 flex items-center gap-2">
        <Workflow className="h-4 w-4 text-[#60A5FA]" />
        <span className="font-mono text-[11px] uppercase tracking-wider text-[#CBD5E1]">
          Related Engineering Workflows
        </span>
      </div>
      <ul className="space-y-2">
        {links.map((l) => (
          <li key={l.to}>
            <Link
              to={l.to}
              className="flex min-h-[44px] items-center justify-between gap-2 rounded-lg border border-[#334155] bg-slate-800/40 px-3 py-2.5 text-sm font-medium text-[#93C5FD] transition-colors hover:border-[#60A5FA] hover:text-[#F8FAFC] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#60A5FA] focus-visible:outline-offset-2"
            >
              <span>{l.label}</span>
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}
