import { useCurrency } from '@/contexts/CurrencyContext';

/**
 * Compact USD / INR display toggle. INR is an approximate conversion view —
 * the original USD vendor price is always shown alongside (see PriceText).
 */
export default function CurrencyToggle({ compact = false }) {
  const { currency, setCurrency } = useCurrency();
  const base =
    'rounded-md px-2 py-1 font-mono text-[11px] font-medium transition-colors';
  return (
    <div
      className="flex items-center gap-0.5 rounded-lg border border-border bg-muted/40 p-0.5"
      role="group"
      aria-label="Display currency"
      title="INR shows an approximate conversion of vendor USD list prices. Original USD price is always shown alongside."
    >
      <button
        type="button"
        onClick={() => setCurrency('USD')}
        className={`${base} ${currency === 'USD' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
        aria-pressed={currency === 'USD'}
      >
        US$
      </button>
      <button
        type="button"
        onClick={() => setCurrency('INR')}
        className={`${base} ${currency === 'INR' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}
        aria-pressed={currency === 'INR'}
      >
        ₹
      </button>
      {compact && currency === 'INR' && (
        <span className="ml-1 hidden font-mono text-[10px] text-muted-foreground lg:inline">approx</span>
      )}
    </div>
  );
}
