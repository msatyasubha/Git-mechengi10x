import { useState } from 'react';
import { Link } from 'react-router-dom';
import { X, GitCompare, CheckCircle2, ExternalLink, Check, Minus } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import ToolLogo from '@/components/ToolLogo';
import { categoryLabel } from '@/data/tools';
import { useCurrency } from '@/contexts/CurrencyContext';
import { formatInr, pricePeriod, FX_CAVEAT } from '@/lib/currency';

const MAX_SELECT = 3;
const MIN_SELECT = 2;

function priceLabel(tool, currency) {
  if (tool.pricing.contactForPricing) return 'Contact for pricing';
  if (tool.pricing.paidFrom === 0) return 'Free forever';
  const period = pricePeriod(tool.pricing.paidFrom);
  const usd = `$${tool.pricing.paidFrom}${period}`;
  return currency === 'INR' ? `${usd} (≈${formatInr(tool.pricing.paidFrom)}${period})` : usd;
}

function freeTierLabel(tool) {
  if (tool.pricing.free || tool.pricing.paidFrom === 0) {
    return tool.pricing.freeLabel || (tool.pricing.paidFrom === 0 ? 'Fully free' : 'Yes');
  }
  return 'No free tier';
}

function MatrixCell({ children, win = false }) {
  return (
    <td className="border-l border-border px-3 py-3 align-top text-sm sm:px-4">
      <span className={`flex items-start gap-1.5 ${win ? 'text-green-400' : 'text-foreground/90'}`}>
        {win && <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />}
        {children}
      </span>
    </td>
  );
}

function CompareMatrix({ tools, open, onOpenChange }) {
  const { currency } = useCurrency();
  if (!tools || tools.length < MIN_SELECT) return null;

  const rows = [
    {
      label: 'MechEngi Score',
      render: () => 'Not Yet Rated',
      winner: () => false,
    },
    {
      label: 'Free Tier',
      render: (t) => freeTierLabel(t),
      winner: (t) => (t.pricing.free || t.pricing.paidFrom === 0) && !tools.every((x) => x.pricing.free || x.pricing.paidFrom === 0),
    },
    {
      label: 'Starting Price',
      render: (t) => priceLabel(t, currency),
      winner: (t) => Number.isFinite(t.pricing.paidFrom) && t.pricing.paidFrom === Math.min(...tools.map((x) => x.pricing.paidFrom ?? Infinity)),
    },
    {
      label: 'Pricing Model',
      render: (t) => t.pricing.paidLabel || '—',
      winner: () => false,
    },
    {
      label: 'Category',
      render: (t) => categoryLabel[t.category] || t.category,
      winner: () => false,
    },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto border-border bg-card p-0 sm:max-w-5xl">
        <DialogHeader className="border-b border-border px-5 py-4">
          <DialogTitle className="font-display text-lg font-bold sm:text-xl">
            Side-by-Side Comparison
          </DialogTitle>
          <DialogDescription className="text-xs text-muted-foreground">
            Evidence-backed feature and pricing data from our independent directory. Scores are
            independent of affiliate relationships.
          </DialogDescription>
        </DialogHeader>

        <div className="overflow-x-auto px-2 pb-2 sm:px-4">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-border">
                <th className="w-32 sticky left-0 z-10 bg-card px-3 py-3 text-left align-bottom sm:w-40 sm:px-4">
                  <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                    Feature
                  </span>
                </th>
                {tools.map((t) => (
                  <th key={t.slug} className="border-l border-border px-3 py-3 text-left align-top sm:px-4">
                    <div className="flex items-center gap-2">
                      <ToolLogo name={t.name} category={t.category} size="sm" />
                      <div className="min-w-0">
                        <Link
                          to={`/tools/${t.slug}`}
                          className="block font-display text-sm font-bold leading-tight hover:text-primary sm:text-base"
                        >
                          {t.name}
                        </Link>
                        <p className="hidden font-mono text-[10px] text-muted-foreground sm:block">{t.vendor}</p>
                      </div>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      <span className="rounded-full border border-border bg-muted/40 px-2 py-0.5 font-mono text-[10px] text-muted-foreground">
                        Not Yet Rated
                      </span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.label} className="border-b border-border last:border-0">
                  <td className="sticky left-0 z-10 bg-card px-3 py-3 font-mono text-xs text-muted-foreground sm:px-4">
                    {row.label}
                  </td>
                  {tools.map((t) => (
                    <MatrixCell key={t.slug} win={row.winner(t)}>
                      {row.render(t)}
                    </MatrixCell>
                  ))}
                </tr>
              ))}

              {/* Best For */}
              <tr className="border-b border-border">
                <td className="sticky left-0 z-10 bg-card px-3 py-3 font-mono text-xs text-muted-foreground sm:px-4">
                  Best For
                </td>
                {tools.map((t) => (
                  <td key={t.slug} className="border-l border-border px-3 py-3 align-top text-xs sm:px-4">
                    <ul className="space-y-1">
                      {t.useCases.slice(0, 3).map((u, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                          {u}
                        </li>
                      ))}
                    </ul>
                  </td>
                ))}
              </tr>

              {/* Key Features */}
              <tr className="border-b border-border">
                <td className="sticky left-0 z-10 bg-card px-3 py-3 font-mono text-xs text-muted-foreground sm:px-4">
                  Key Features
                </td>
                {tools.map((t) => (
                  <td key={t.slug} className="border-l border-border px-3 py-3 align-top text-xs sm:px-4">
                    <ul className="space-y-1">
                      {t.features.slice(0, 5).map((f, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <Check className="mt-0.5 h-3 w-3 shrink-0 text-green-500" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </td>
                ))}
              </tr>

              {/* Pros */}
              <tr className="border-b border-border">
                <td className="sticky left-0 z-10 bg-card px-3 py-3 font-mono text-xs text-green-400 sm:px-4">
                  Pros
                </td>
                {tools.map((t) => (
                  <td key={t.slug} className="border-l border-border px-3 py-3 align-top text-xs sm:px-4">
                    <ul className="space-y-1">
                      {t.pros.slice(0, 3).map((p, i) => (
                        <li key={i} className="flex items-start gap-1.5 text-foreground/85">
                          <Check className="mt-0.5 h-3 w-3 shrink-0 text-green-500" />
                          {p}
                        </li>
                      ))}
                    </ul>
                  </td>
                ))}
              </tr>

              {/* Cons */}
              <tr className="border-b border-border">
                <td className="sticky left-0 z-10 bg-card px-3 py-3 font-mono text-xs text-red-400 sm:px-4">
                  Cons
                </td>
                {tools.map((t) => (
                  <td key={t.slug} className="border-l border-border px-3 py-3 align-top text-xs sm:px-4">
                    <ul className="space-y-1">
                      {t.cons.slice(0, 2).map((c, i) => (
                        <li key={i} className="flex items-start gap-1.5 text-muted-foreground">
                          <Minus className="mt-0.5 h-3 w-3 shrink-0 text-red-500" />
                          {c}
                        </li>
                      ))}
                    </ul>
                  </td>
                ))}
              </tr>

              {/* CTA */}
              <tr>
                <td className="sticky left-0 z-10 bg-card px-3 py-3 font-mono text-xs text-muted-foreground sm:px-4">
                  Try it
                </td>
                {tools.map((t) => (
                  <td key={t.slug} className="border-l border-border px-3 py-3 sm:px-4">
                    <a
                      href={t.affiliateUrl}
                      target="_blank"
                      rel="noopener noreferrer sponsored"
                      className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground transition-all hover:opacity-90"
                    >
                      Try {t.name} <ExternalLink className="h-3 w-3" />
                    </a>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>

        <div className="border-t border-border px-5 py-3">
          <p className="affiliate-disclosure font-mono text-[10px] text-muted-foreground">
            Affiliate links — we earn a commission at no extra cost to you. Tool scores are
            independent of affiliate relationships.
          </p>
          {currency === 'INR' && (
            <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">{FX_CAVEAT}</p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function CompareTray({ selected, onRemove, onClear, tools }) {
  const [open, setOpen] = useState(false);
  const count = selected.length;

  if (count === 0) return null;

  const canCompare = count >= MIN_SELECT && count <= MAX_SELECT;

  return (
    <>
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-[90rem] flex-wrap items-center gap-3 px-4 py-3 sm:px-5">
          <div className="flex min-w-0 items-center gap-2">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/15">
              <GitCompare className="h-4 w-4 text-primary" />
            </span>
            <div className="min-w-0">
              <p className="font-display text-sm font-bold">
                Compare {count}/{MAX_SELECT}
              </p>
              <p className="font-mono text-[10px] text-muted-foreground">
                {canCompare
                  ? 'Ready to compare'
                  : `Select ${MIN_SELECT}–${MAX_SELECT} tools to compare`}
              </p>
            </div>
          </div>

          {/* Selected tool chips */}
          <div className="flex min-w-0 flex-1 flex-wrap items-center gap-2">
            {selected.map((slug) => {
              const t = tools.find((x) => x.slug === slug);
              if (!t) return null;
              return (
                <span
                  key={slug}
                  className="inline-flex max-w-full items-center gap-1.5 rounded-full border border-border bg-muted/40 py-1 pl-2 pr-1 text-xs"
                >
                  <span className="truncate">{t.name}</span>
                  <button
                    onClick={() => onRemove(slug)}
                    className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-muted-foreground hover:bg-destructive/20 hover:text-destructive"
                    aria-label={`Remove ${t.name} from comparison`}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              );
            })}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClear}
              className="rounded-lg border border-border px-3 py-2 text-xs font-medium text-muted-foreground transition-colors hover:border-foreground hover:text-foreground"
            >
              Clear
            </button>
            <button
              onClick={() => canCompare && setOpen(true)}
              disabled={!canCompare}
              className="glow-primary inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 disabled:shadow-none"
            >
              <GitCompare className="h-3.5 w-3.5" />
              Compare now
            </button>
          </div>
        </div>
      </div>

      <CompareMatrix
        tools={selected.map((slug) => tools.find((x) => x.slug === slug)).filter(Boolean)}
        open={open}
        onOpenChange={setOpen}
      />
    </>
  );
}

export { MAX_SELECT, MIN_SELECT };
