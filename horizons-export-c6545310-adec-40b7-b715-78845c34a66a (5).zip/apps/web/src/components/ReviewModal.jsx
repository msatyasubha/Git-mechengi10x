import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Star, Send, Loader2, ShieldCheck, Clock, LogIn } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import ToolLogo from '@/components/ToolLogo';
import { categoryLabel } from '@/data/tools';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbaseClient';

function ReviewStarPicker({ value, onChange }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <button
          key={s}
          type="button"
          onMouseEnter={() => setHover(s)}
          onMouseLeave={() => setHover(0)}
          onClick={() => onChange(s)}
          className="text-2xl transition-transform hover:scale-110 active:scale-95"
          aria-label={`Rate ${s} stars`}
        >
          <Star
            className={`h-7 w-7 ${s <= (hover || value) ? 'fill-current text-amber-400' : 'text-border'}`}
            strokeWidth={s <= (hover || value) ? 0 : 1.5}
          />
        </button>
      ))}
    </div>
  );
}

export default function ReviewModal({ tool, open, onOpenChange }) {
  const { user } = useAuth();
  const [form, setForm] = useState({ rating: 0, title: '', body: '' });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const reset = () => {
    setForm({ rating: 0, title: '', body: '' });
    setError('');
    setDone(false);
  };

  const handleClose = (v) => {
    onOpenChange(v);
    if (!v) {
      // reset after close animation
      setTimeout(reset, 150);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.rating === 0) {
      setError('Please select a star rating.');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      await pb.collection('tool_reviews').create({
        tool_slug: tool.slug,
        rating: form.rating,
        title: form.title,
        body: form.body,
        owner: user.id,
        // status is not set by the client — server default is 'pending'
        // and the create rule rejects any attempt to set it to 'approved'.
      });
      setDone(true);
    } catch (err) {
      if (err?.status === 400) {
        setError('You have already submitted a review for this tool.');
      } else {
        setError('Failed to submit review. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto border-border bg-card p-0 sm:max-w-lg">
        <DialogHeader className="border-b border-border px-5 py-4">
          <DialogTitle className="font-display text-lg font-bold">Write a Review</DialogTitle>
          <DialogDescription className="text-xs text-muted-foreground">
            Community reviews are moderated before they appear publicly.
          </DialogDescription>
        </DialogHeader>

        <div className="px-5 py-4">
          {/* Tool context */}
          {tool && (
            <div className="flex items-center gap-3 rounded-xl border border-border bg-muted/30 p-3">
              <ToolLogo name={tool.name} category={tool.category} size="sm" />
              <div className="min-w-0">
                <p className="font-display text-sm font-bold leading-tight">{tool.name}</p>
                <p className="font-mono text-[10px] text-muted-foreground">
                  {categoryLabel[tool.category]} · {tool.vendor}
                </p>
              </div>
            </div>
          )}

          {/* Not signed in */}
          {!user ? (
            <div className="mt-5 rounded-xl border border-border bg-muted/20 px-5 py-8 text-center">
              <LogIn className="mx-auto h-6 w-6 text-primary" />
              <p className="mt-3 font-display text-sm font-semibold">Sign in to write a review</p>
              <p className="mt-1 text-xs text-muted-foreground">
                Community reviews are written by signed-in engineers and moderated before publishing.
              </p>
              <Link
                to="/login"
                className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90"
              >
                <LogIn className="h-4 w-4" /> Sign in
              </Link>
            </div>
          ) : done ? (
            <div className="mt-5 flex items-start gap-2.5 rounded-xl border border-amber-500/25 bg-amber-500/5 px-4 py-4">
              <Clock className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
              <div>
                <p className="font-semibold text-foreground">Review submitted — pending moderation.</p>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  Our team reviews every submission before it is published. You will not see it on the
                  tool page until it is approved. One review per engineer per tool.
                </p>
                <button
                  onClick={() => handleClose(false)}
                  className="mt-3 rounded-lg border border-border px-4 py-2 text-xs font-medium transition-colors hover:border-foreground"
                >
                  Close
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="mt-5">
              {/* Moderation notice */}
              <div className="flex items-start gap-2.5 rounded-lg border border-border bg-muted/20 px-3 py-2.5 text-[11px] leading-relaxed text-muted-foreground">
                <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                <p>
                  Reviews are written by signed-in engineers and <span className="text-foreground">moderated before they appear</span>.
                  We do not award verified-reviewer badges or publish ratings that have not gone through this flow.
                </p>
              </div>

              <div className="mt-4">
                <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Rating *
                </label>
                <ReviewStarPicker
                  value={form.rating}
                  onChange={(r) => setForm((f) => ({ ...f, rating: r }))}
                />
              </div>
              <div className="mt-4">
                <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Headline (optional)
                </label>
                <input
                  value={form.title}
                  onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                  maxLength={200}
                  placeholder="e.g. 'Great for CAD automation, weak documentation'"
                  className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
              <div className="mt-4">
                <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Review (optional)
                </label>
                <textarea
                  value={form.body}
                  onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))}
                  maxLength={2000}
                  rows={4}
                  placeholder="Share your experience with this tool for engineering work..."
                  className="w-full resize-none rounded-lg border border-border bg-muted px-3 py-2.5 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
              {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
              <div className="mt-4 flex gap-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-50"
                >
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  {submitting ? 'Submitting...' : 'Submit Review'}
                </button>
                <button
                  type="button"
                  onClick={() => handleClose(false)}
                  className="rounded-lg border border-border px-5 py-2.5 text-sm font-medium transition-colors hover:border-foreground"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
