import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import ToolCard from '@/components/ToolCard';
import { featuredTools } from '@/data/tools';

export default function HomeFeaturedTools() {
  return (
    <section className="border-t border-border bg-card/20 py-16">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="flex items-end justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-primary">Tool Directory</p>
            <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Featured Engineering Tools</h2>
          </div>
          <Link to="/tools" className="hidden items-center gap-1 font-mono text-xs text-muted-foreground hover:text-primary md:flex">
            View all tools <ChevronRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {featuredTools.slice(0, 9).map((tool) => (
            <ToolCard key={tool.slug} tool={tool} />
          ))}
        </div>

        <div className="mt-6 text-center md:hidden">
          <Link to="/tools" className="font-mono text-sm text-primary hover:underline">
            Browse all tools →
          </Link>
        </div>
      </div>
    </section>
  );
}
