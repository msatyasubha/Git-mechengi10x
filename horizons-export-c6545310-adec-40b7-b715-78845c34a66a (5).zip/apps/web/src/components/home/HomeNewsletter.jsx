import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Zap } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { trackNewsletterSignup } from '@/lib/analytics';

export default function HomeNewsletter() {
  const [email, setEmail] = useState('');
  const [newsletterState, setNewsletterState] = useState('idle');

  const handleNewsletter = async (e) => {
    e.preventDefault();
    if (!email) return;
    setNewsletterState('loading');
    try {
      await pb.collection('newsletter_subscribers').create({ email, source: 'homepage' });
      trackNewsletterSignup('homepage');
      setNewsletterState('success');
    } catch (err) {
      if (err?.response?.data?.email) {
        setNewsletterState('already');
      } else {
        setNewsletterState('error');
      }
    }
  };

  return (
    <section className="border-t border-border bg-card/20 py-16">
      <div className="mx-auto max-w-[40rem] px-5 text-center">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs text-primary">
          <Zap className="h-3.5 w-3.5" />
          Weekly Engineering Intelligence
        </div>
        <h2 className="font-display text-2xl font-bold sm:text-3xl">
          Get one practical AI or digital engineering idea every week.
        </h2>
        <p className="mt-3 text-muted-foreground">
          One tool review, comparison insight, or workflow tip — delivered every Thursday. Independent, vendor-neutral, and worth your time.
        </p>
        {newsletterState === 'success' ? (
          <div className="mt-6 rounded-xl border border-green-500/30 bg-green-500/10 p-4 text-green-400">
            You're in! Check your inbox for a confirmation.
          </div>
        ) : (
          <>
          <form onSubmit={handleNewsletter} className="mt-6 flex flex-col gap-2 sm:flex-row">
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              className="h-12 w-full flex-1 rounded-xl border border-border bg-card px-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            />
            <button
              type="submit"
              disabled={newsletterState === 'loading'}
              className="h-12 w-full rounded-xl bg-primary px-6 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-50 sm:w-auto"
            >
              {newsletterState === 'loading' ? 'Joining…' : 'Subscribe'}
            </button>
          </form>
          </>
        )}
        {newsletterState === 'already' && (
          <p className="mt-2 text-sm text-muted-foreground">You're already subscribed!</p>
        )}
        {newsletterState === 'error' && (
          <p className="mt-2 text-sm text-destructive">Something went wrong. Please try again.</p>
        )}
        <div className="subscription-footer-text mt-3 flex items-center justify-center gap-2 text-[0.85rem] text-muted-foreground">
          <span>No spam. Unsubscribe anytime.</span>
          <span aria-hidden="true">·</span>
          <Link to="/guides" className="text-primary no-underline hover:underline">Explore engineering guides →</Link>
        </div>
      </div>
    </section>
  );
}
