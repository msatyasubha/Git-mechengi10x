import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import SpinWheel from '@/components/SpinWheel';
import { navCategories } from '@/data/tools';

export default function HomeSpinWheelSection() {
  return (
    <section className="py-16">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="grid gap-10 lg:grid-cols-[1fr_300px] lg:items-center">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-primary">Category Discovery</p>
            <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">
              Not sure where to start?
              <br />
              <span className="text-primary">Spin the Wheel.</span>
            </h2>
            <p className="mt-4 max-w-md text-muted-foreground">
              Discover something new — spin to explore a random category, then dig into its best tools, guides, and resources.
            </p>
            <p className="mt-5 font-mono text-xs text-muted-foreground">Or jump straight to:</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {navCategories.map(cat => (
                <Link key={cat.id} to={`/tools?cat=${cat.id}`} className="rounded-full border border-border bg-card px-3 py-1 font-mono text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary">
                  {cat.icon} {cat.label}
                </Link>
              ))}
              <Link to="/jobs" className="rounded-full border border-border bg-card px-3 py-1 font-mono text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary">
                💼 Jobs
              </Link>
            </div>
          </div>
          <div className="flex justify-center">
            <SpinWheel />
          </div>
        </div>
      </div>
    </section>
  );
}
