import { Link } from 'react-router-dom';
import { GraduationCap, MessageSquare, Sparkles, ArrowRight } from 'lucide-react';

const features = [
  {
    to: '/courses',
    icon: GraduationCap,
    title: 'Premium Courses',
    body: 'Hands-on, project-based courses on AI tools, CAD, FEA, Python automation, and project management — built by engineers, for engineers.',
    cta: 'Browse courses',
    accent: 'text-primary',
  },
  {
    to: '/forum',
    icon: MessageSquare,
    title: 'Community Forum',
    body: 'Ask questions, share workflows, and compare notes with thousands of mechanical engineers solving the same problems you are.',
    cta: 'Join the discussion',
    accent: 'text-accent',
  },
  {
    to: '/sponsor',
    icon: Sparkles,
    title: 'Sponsor MechEngi 10X',
    body: 'Put your engineering tool in front of thousands of mechanical engineers through featured placement, expert reviews, or co-hosted webinars.',
    cta: 'View packages',
    accent: 'text-primary',
  },
];

export default function HomeExploreMore() {
  return (
    <section className="mx-auto max-w-[90rem] px-5 pb-14 pt-8">
      <div className="mb-12 text-center">
        <p className="font-mono text-xs uppercase tracking-wider text-primary">Go deeper</p>
        <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">More from MechEngi 10X</h2>
        <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
          Beyond tool discovery — learn, connect, and grow with the engineering community.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {features.map((f) => (
          <Link
            key={f.to}
            to={f.to}
            className="group flex flex-col rounded-2xl border border-border bg-card p-7 transition-all hover:-translate-y-1 hover:border-primary/40"
          >
            <f.icon className={`h-8 w-8 ${f.accent}`} />
            <h3 className="mt-5 font-display text-xl font-bold">{f.title}</h3>
            <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
            <span className="mt-5 inline-flex items-center gap-1.5 font-mono text-xs uppercase tracking-wider text-primary group-hover:gap-2.5">
              {f.cta} <ArrowRight className="h-3.5 w-3.5 transition-all" />
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}
