import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, ArrowRight, Zap } from 'lucide-react';
import { navCategories } from '@/data/tools';
import { ticker, stats } from '@/data/home';

export default function HomeHero() {
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) navigate(`/tools?q=${encodeURIComponent(query.trim())}`);
    else navigate('/tools');
  };

  return (
    <>
      {/* ── Hero ─────────────────────────────────────── */}
      <section className="relative min-h-[100dvh] overflow-x-clip overflow-y-visible">
        <div className="dot-grid absolute inset-0 opacity-50" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/0 via-background/60 to-background" />
        <div className="pointer-events-none absolute left-1/4 top-1/3 h-64 w-64 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/10 blur-3xl sm:h-96 sm:w-96" />
        <div className="pointer-events-none absolute right-1/4 top-1/2 h-48 w-48 rounded-full bg-accent/8 blur-3xl sm:h-64 sm:w-64" />

        <div className="relative mx-auto flex min-h-[100dvh] w-full max-w-[72rem] flex-col items-center justify-center px-4 py-20 text-center sm:px-5 sm:py-24">
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-5 inline-flex max-w-[min(100%,22rem)] items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1.5 font-mono text-[10px] leading-snug text-primary sm:max-w-full sm:px-4 sm:text-xs"
          >
            <Zap className="h-3.5 w-3.5 shrink-0" />
            <span className="min-w-0 text-balance text-center">AI &amp; Engineering Tool Discovery Platform</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.08 }}
            style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}
            className="w-full max-w-full font-display font-extrabold leading-[1.1] tracking-tight text-balance"
          >
            <span className="block">Make Smarter</span>
            <span className="mt-1 block text-primary sm:mt-0">Engineering Technology Decisions</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.16 }}
            className="mt-5 max-w-xl px-1 text-[0.9375rem] leading-relaxed text-muted-foreground text-pretty sm:mt-6 sm:text-lg"
          >
            Independent expert reviews of 80+ AI, CAD, simulation, and automation tools.
            Find the right tool for your engineering workflow in minutes — not months.
          </motion.p>

          {/* Primary CTA */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.20 }}
            className="mt-7 flex w-full max-w-md flex-col items-stretch gap-3 sm:mt-8 sm:max-w-none sm:flex-row sm:flex-wrap sm:justify-center"
          >
            <Link
              to="/wizard"
              className="glow-primary inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-display text-base font-bold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] sm:px-8 sm:py-4"
            >
              Find My Engineering Tool <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/compare"
              className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-border px-6 py-3.5 font-display text-base font-semibold transition-colors hover:border-primary/40 hover:text-primary sm:px-8 sm:py-4"
            >
              Compare Tools
            </Link>
            <Link
              to="/tools"
              className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-xl border border-border px-6 py-3.5 font-display text-base font-semibold transition-colors hover:border-primary/40 hover:text-primary sm:px-8 sm:py-4"
            >
              Engineering Workflows
            </Link>
          </motion.div>

          {/* Search */}
          <motion.form
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.26 }}
            onSubmit={handleSearch}
            className="mt-6 flex w-full max-w-xl flex-col gap-2 sm:flex-row"
          >
            <div className="relative min-w-0 flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder='Search tools, e.g. "best AI for CAD"'
                className="search-bar h-12 w-full rounded-xl border border-border bg-card pl-10 pr-16 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
              <kbd className="pointer-events-none absolute right-3 top-1/2 hidden -translate-y-1/2 items-center gap-0.5 rounded-md border border-border bg-muted/60 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground sm:flex">
                <span className="text-[9px]">⌘</span>K
              </kbd>
            </div>
            <button
              type="submit"
              className="h-12 shrink-0 rounded-xl border border-primary/40 px-5 font-mono text-sm text-primary transition-colors hover:bg-primary/10"
            >
              Search
            </button>
          </motion.form>

          {/* Category pills */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.33 }}
            className="mt-5 flex w-full max-w-full flex-wrap justify-center gap-2"
          >
            {navCategories.map((c) => (
              <Link
                key={c.id}
                to={`/tools?cat=${c.id}`}
                className="flex max-w-full items-center gap-1.5 rounded-full border border-border bg-card/60 px-3 py-1.5 font-mono text-[11px] text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary sm:px-4 sm:text-xs"
              >
                <span className="shrink-0">{c.icon}</span>
                <span className="truncate">{c.label}</span>
              </Link>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Wizard CTA Banner ────────────────────────── */}
      <div className="border-b border-primary/20 bg-primary/5 py-4">
        <div className="mx-auto flex max-w-[72rem] flex-wrap items-center justify-between gap-4 px-5">
          <div className="flex items-center gap-3">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
              <Zap className="h-4 w-4 text-primary" />
            </span>
            <div>
              <p className="font-display text-sm font-bold">Not sure which tool is right for you?</p>
              <p className="text-xs text-muted-foreground">Answer 3 questions → get 5 personalized recommendations</p>
            </div>
          </div>
          <Link
            to="/wizard"
            className="inline-flex items-center gap-2 rounded-xl border border-primary/30 bg-primary/10 px-5 py-2 font-mono text-xs font-semibold text-primary transition-colors hover:bg-primary/20"
          >
            Take the Wizard <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>

      {/* ── Ticker ───────────────────────────────────── */}
      <div className="ticker-container overflow-hidden border-y border-border bg-card/50 py-3">
        <div className="marquee-track flex w-max gap-8">
          {ticker.map((t, i) => (
            <span key={i} className="whitespace-nowrap font-mono text-xs uppercase tracking-widest text-muted-foreground/60">
              {t}
            </span>
          ))}
        </div>
      </div>

      {/* ── Stats ─────────────────────────────────────── */}
      <div className="border-b border-border bg-card/30">
        <div className="mx-auto grid max-w-[72rem] grid-cols-2 divide-x divide-border px-5 md:grid-cols-4">
          {stats.map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.label} className="py-6 text-center">
                <div className="flex justify-center">
                  <Icon className="mb-2 h-4 w-4 text-primary/60" />
                </div>
                <p className="font-display text-3xl font-extrabold text-primary">{s.value}</p>
                <p className="mt-1 text-sm text-muted-foreground">{s.label}</p>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}
