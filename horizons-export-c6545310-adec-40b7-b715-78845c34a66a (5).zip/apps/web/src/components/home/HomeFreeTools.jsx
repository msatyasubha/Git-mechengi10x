import { Link } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';
import { freeTools } from '@/data/tools';
import ToolLogo from '@/components/ToolLogo';

export default function HomeFreeTools() {
  return (
    <section className="py-12">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="flex items-end justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-green-400">No credit card required</p>
            <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Best Free Engineering Tools</h2>
          </div>
          <Link to="/tools?free=1" className="hidden font-mono text-xs text-muted-foreground hover:text-primary md:block">
            See all free tools →
          </Link>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {freeTools.slice(0, 4).map((tool) => (
            <div key={tool.slug} className="flex flex-col rounded-xl border border-border bg-card p-4 transition-all hover:border-green-500/30">
              <div className="flex items-center gap-3">
                <ToolLogo name={tool.name} category={tool.category} size="sm" />
                <div>
                  <p className="font-display font-semibold">{tool.name}</p>
                  <p className="font-mono text-xs text-green-400">Free forever</p>
                </div>
              </div>
              <div className="mt-3 flex items-center gap-2">
                <span className="font-mono text-xs text-muted-foreground">MechEngi Score</span>
                <span className="font-mono text-xs font-semibold text-muted-foreground">Not Yet Rated</span>
              </div>
              <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-muted-foreground">{tool.tagline}</p>
              <div className="mt-3 flex gap-2">
                <Link
                  to={`/tools/${tool.slug}`}
                  className="flex-1 rounded-lg border border-border py-1.5 text-center font-mono text-xs text-muted-foreground hover:border-primary/40 hover:text-primary"
                >
                  Review
                </Link>
                <a
                  href={tool.affiliateUrl}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="flex items-center gap-1 rounded-lg bg-green-500/15 px-3 py-1.5 font-mono text-xs text-green-400 hover:bg-green-500/25"
                >
                  Try free <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
