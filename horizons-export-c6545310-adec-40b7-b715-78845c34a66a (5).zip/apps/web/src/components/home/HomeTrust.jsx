import { Link } from 'react-router-dom';
import { trustSignals } from '@/data/home';

export default function HomeTrust() {
  return (
    <section className="border-y border-border py-16">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="mb-10 text-center">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">Why Engineers Trust Us</p>
          <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Engineering Credibility, First</h2>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {trustSignals.map((ts) => {
            const Icon = ts.icon;
            return (
              <div key={ts.title} className="trust-card flex flex-col gap-3 rounded-xl border border-border bg-card p-5">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-display text-base font-bold">{ts.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{ts.desc}</p>
              </div>
            );
          })}
        </div>
        <div className="mt-8 text-center">
          <Link to="/methodology" className="inline-flex items-center gap-1.5 font-mono text-xs text-primary hover:underline">
            Read the full scoring methodology →
          </Link>
        </div>
      </div>
    </section>
  );
}
