import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { useCases } from '@/data/home';

export default function HomeUseCases() {
  return (
    <section className="border-t border-border py-14">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="mb-8 text-center">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">Discover by Workflow</p>
          <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">What Are You Trying to Do?</h2>
          <p className="mx-auto mt-3 max-w-lg text-muted-foreground">
            Browse tools by engineering use case. Find the right software for your specific workflow — not just your job title.
          </p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {useCases.map((uc) => (
            <Link
              key={uc.label}
              to={uc.to}
              className="group flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:bg-primary/5 hover:shadow-md hover:shadow-primary/5"
            >
              <span className="text-2xl">{uc.icon}</span>
              <div className="min-w-0 flex-1">
                <p className="font-display text-sm font-semibold group-hover:text-primary leading-snug">{uc.label}</p>
                <p className="mt-0.5 truncate text-xs text-muted-foreground">{uc.desc}</p>
              </div>
              <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground opacity-0 transition-all group-hover:translate-x-1 group-hover:text-primary group-hover:opacity-100" />
            </Link>
          ))}
        </div>
        <div className="mt-6 text-center">
          <Link
            to="/wizard"
            className="glow-primary inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-display font-bold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
          >
            Not sure? Take the 3-step wizard <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
