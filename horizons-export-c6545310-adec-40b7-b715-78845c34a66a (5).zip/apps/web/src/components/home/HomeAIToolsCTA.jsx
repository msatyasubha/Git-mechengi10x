import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export default function HomeAIToolsCTA() {
  return (
    <section className="border-t border-border bg-primary/5 py-12">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-center">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="rounded-full border border-primary/30 bg-primary/10 px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-primary">AI Tool Profiles</span>
            </div>
            <h2 className="font-display text-2xl font-bold sm:text-3xl">In-Depth AI Tool Profiles Published</h2>
            <p className="mt-2 max-w-lg text-muted-foreground">
              ChatGPT, Claude, Gemini, Copilot, Perplexity, Midjourney, DALL-E, Jasper, Copy.ai, and Synthesia — each with engineering-focused reviews, real-world examples, FAQ, and structured data.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {['ChatGPT', 'Claude', 'Gemini', 'Copilot', 'Perplexity', 'Midjourney', 'DALL-E', 'Jasper', 'Synthesia'].map(t => (
                <span key={t} className="rounded-full border border-border bg-card px-3 py-1 font-mono text-[10px] text-muted-foreground">{t}</span>
              ))}
            </div>
          </div>
          <Link
            to="/ai-tools"
            className="glow-primary shrink-0 inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-display font-bold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
          >
            View All AI Tool Profiles <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
