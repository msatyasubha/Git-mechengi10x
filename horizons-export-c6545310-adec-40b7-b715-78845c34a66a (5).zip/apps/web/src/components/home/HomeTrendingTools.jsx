import { Link } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';
import { tools } from '@/data/tools';
import ToolLogo from '@/components/ToolLogo';

export default function HomeTrendingTools() {
  return (
    <section className="border-t border-border bg-card/10 py-14">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-accent">Explore Tools</p>
            <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Engineering Tools to Explore</h2>
          </div>
          <Link to="/tools" className="hidden font-mono text-xs text-muted-foreground hover:text-primary md:block">
            All tools →
          </Link>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {tools.filter((tool) => tool.featured).slice(0, 4).map((tool) => (
            <div key={tool.slug} className="relative flex flex-col rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
              <div className="flex items-center gap-3">
                <ToolLogo name={tool.name} category={tool.category} size="sm" />
                <div>
                  <p className="font-display font-semibold">{tool.name}</p>
                  <p className="text-xs text-muted-foreground">{tool.vendor}</p>
                </div>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <span className="font-mono text-xs text-muted-foreground">Benchmark score pending</span>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">Explore specifications, pricing and use cases while benchmark evidence is pending.</p>
              <div className="mt-3 flex gap-2">
                <Link
                  to={`/tools/${tool.slug}`}
                  className="flex-1 rounded-lg border border-border py-1.5 text-center font-mono text-xs text-muted-foreground hover:border-primary/40 hover:text-primary"
                >
                  Review
                </Link>
                <a
                  href={tool.affiliateUrl}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 font-mono text-xs text-primary-foreground hover:opacity-90"
                >
                  Try <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
