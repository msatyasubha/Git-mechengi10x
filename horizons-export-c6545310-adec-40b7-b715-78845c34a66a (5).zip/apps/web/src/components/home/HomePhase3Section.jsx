import { Link } from 'react-router-dom';
import { TrendingUp, PlayCircle, Mic, Video, Crown, Gift, ArrowRight } from 'lucide-react';

const items = [
  { to: '/case-studies', icon: TrendingUp, label: 'Case Studies', desc: 'Explore workflow examples and reported ROI; results are not independently verified.' },
  { to: '/videos', icon: PlayCircle, label: 'Video Topics', desc: 'Explore engineering topics and search for related videos.' },
  { to: '/podcast', icon: Mic, label: 'Podcast Topics', desc: 'Topic outlines on engineering tools and careers; audio is not available here.' },
  { to: '/events', icon: Video, label: 'Webinars', desc: 'Explore webinar topics and check the date and availability.' },
  { to: '/membership', icon: Crown, label: 'Membership', desc: 'Advanced guides, early access, priority Advisor. From $9.99/mo.' },
  { to: '/referral', icon: Gift, label: 'Referral Program', desc: 'Earn $10 per signup and $50 per course sale.' },
];

export default function HomePhase3Section() {
  return (
    <section className="border-y border-border bg-card/30">
      <div className="mx-auto max-w-[90rem] px-5 py-20">
        <div className="mb-12 text-center">
          <p className="font-mono text-xs uppercase tracking-wider text-primary">Go deeper</p>
          <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">More ways to 10X your engineering</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Case studies, videos, podcasts, live webinars, membership, and a referral program — all built for engineers.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((it) => (
            <Link
              key={it.to}
              to={it.to}
              className="group flex items-start gap-4 rounded-2xl border border-border bg-card p-6 transition-all hover:-translate-y-1 hover:border-primary/40"
            >
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <it.icon className="h-5 w-5" />
              </span>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-display font-semibold group-hover:text-primary">{it.label}</h3>
                  <ArrowRight className="h-3.5 w-3.5 text-primary opacity-0 transition-opacity group-hover:opacity-100" />
                </div>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{it.desc}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
