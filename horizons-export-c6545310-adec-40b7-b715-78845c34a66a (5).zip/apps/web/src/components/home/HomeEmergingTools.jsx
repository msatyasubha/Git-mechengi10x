import { Link } from 'react-router-dom';
import { ArrowRight, ExternalLink, Sparkles, FlaskConical } from 'lucide-react';
import { emergingTools } from '@/data/emergingTools';

const statusStyles = {
  ga: { label: 'Generally Available', cls: 'border-green-500/30 bg-green-500/10 text-green-400' },
  'public-beta': { label: 'Public Beta', cls: 'border-amber-500/30 bg-amber-500/10 text-amber-400' },
  'early-access': { label: 'Early Access', cls: 'border-primary/30 bg-primary/10 text-primary' },
};

export default function HomeEmergingTools() {
  // Show the 4 most notable on the home section; full list on /emerging-tools
  const featured = emergingTools.slice(0, 4);

  return (
    <section className="border-t border-border bg-card/20 py-12">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="flex items-center gap-1.5 font-mono text-xs uppercase tracking-widest text-primary">
              <FlaskConical className="h-3.5 w-3.5" /> Emerging & Developing
            </p>
            <h2 className="mt-1 font-display text-2xl font-bold sm:text-3xl">
              Latest AI Tools in Active Development
            </h2>
            <p className="mt-2 max-w-2xl text-sm text-muted-foreground sm:text-base">
              New and actively evolving AI coding agents and agentic IDEs. Each is clearly labeled with its real
              availability — Generally Available, Public Beta, or Early Access — and a last-verified date. No invented
              ratings: these are too new to score honestly.
            </p>
          </div>
          <Link
            to="/emerging-tools"
            className="inline-flex shrink-0 items-center gap-1.5 self-start rounded-xl border border-border px-4 py-2 font-mono text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary sm:self-auto"
          >
            View all <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((tool) => {
            const st = statusStyles[tool.status];
            return (
              <article
                key={tool.slug}
                className="group flex flex-col rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5"
              >
                <div className="flex items-start gap-2.5">
                  <span className="text-2xl">{tool.logoEmoji}</span>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-display text-sm font-bold leading-tight group-hover:text-primary">
                      {tool.name}
                    </h3>
                    <p className="text-[11px] text-muted-foreground">{tool.vendor}</p>
                  </div>
                </div>

                <span className={`mt-3 inline-flex w-fit items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[10px] ${st.cls}`}>
                  <Sparkles className="h-2.5 w-2.5" /> {st.label}
                </span>

                <p className="mt-2.5 line-clamp-3 flex-1 text-xs leading-relaxed text-muted-foreground">
                  {tool.tagline}
                </p>

                <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
                  <span className="font-mono text-[10px] text-muted-foreground">
                    {tool.pricing.free ? 'Free tier' : `From $${tool.pricing.paidFrom}/mo`}
                  </span>
                  <span className="font-mono text-[10px] text-muted-foreground/70">
                    Verified {tool.lastVerified}
                  </span>
                </div>

                <a
                  href={tool.officialUrl}
                  target="_blank"
                  rel="noopener noreferrer sponsored"
                  className="mt-3 flex items-center justify-center gap-1.5 rounded-lg bg-primary/90 py-2 font-mono text-[11px] text-primary-foreground transition-opacity hover:opacity-90"
                >
                  Visit official site <ExternalLink className="h-3 w-3" />
                </a>
              </article>
            );
          })}
        </div>

        <p className="mt-5 text-center text-[11px] text-muted-foreground/80">
          Availability and pricing change fast for developing tools. Always confirm on the vendor’s site before purchasing.
        </p>
      </div>
    </section>
  );
}
