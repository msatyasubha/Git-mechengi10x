import { Link } from 'react-router-dom';
import { ArrowRight, Zap } from 'lucide-react';

export default function HomeAdvisorCTA() {
  return (
    <section className="border-y border-border bg-card/20 py-12">
      <div className="relative mx-auto max-w-[90rem] px-5">
        <div className="overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-background to-accent/5 p-8 md:p-12">
          <div className="pointer-events-none absolute inset-0">
            <div className="dot-grid h-full w-full opacity-20" />
          </div>
          <div className="relative grid gap-8 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs text-primary">
                <Zap className="h-3.5 w-3.5" />
                AI Engineering Advisor — Powered by GPT-4
              </div>
              <h2 className="font-display text-3xl font-bold sm:text-4xl">
                Not sure which tool to choose?
                <br />
                <span className="text-primary">Ask our AI Engineering Advisor.</span>
              </h2>
              <p className="mt-4 max-w-lg text-muted-foreground">
                Describe your engineering workflow, team size, and budget. Our AI Advisor gives personalized, bias-free tool recommendations with honest pros, cons, pricing, and side-by-side comparisons — in seconds.
              </p>
              <ul className="mt-5 space-y-2">
                {[
                  'Personalized recommendations based on your discipline & workflow',
                  'Side-by-side pricing and feature comparisons on demand',
                  'Vendor-neutral — no sponsored recommendations',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                    {item}
                  </li>
                ))}
              </ul>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link
                  to="/advisor"
                  className="glow-primary inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
                >
                  Chat with AI Advisor <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  to="/compare"
                  className="inline-flex items-center gap-2 rounded-xl border border-border px-8 py-3 font-semibold transition-colors hover:border-primary/40 hover:text-primary"
                >
                  Browse Comparisons
                </Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="w-72 rounded-2xl border border-border bg-card/80 p-5">
                <div className="flex items-center gap-2 border-b border-border pb-3">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full border border-primary/30 bg-primary/10">
                    <Zap className="h-3.5 w-3.5 text-primary" />
                  </div>
                  <span className="font-display text-sm font-semibold">AI Engineering Advisor</span>
                </div>
                <div className="mt-4 space-y-3">
                  <div className="rounded-xl bg-muted/50 px-3 py-2.5 text-sm text-muted-foreground">
                    "I need FEA simulation for aerospace components under $5k/yr"
                  </div>
                  <div className="rounded-xl border border-primary/20 bg-primary/5 px-3 py-2.5 text-sm">
                    Based on your requirements, I recommend <span className="font-semibold text-primary">SimScale Professional</span> or <span className="font-semibold text-primary">ANSYS Student</span>. Here's a comparison...
                  </div>
                  <div className="flex items-center gap-2 rounded-lg bg-muted/30 px-3 py-2">
                    <span className="h-2 w-2 animate-pulse rounded-full bg-green-400" />
                    <span className="font-mono text-xs text-muted-foreground">Online · Free to use</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
