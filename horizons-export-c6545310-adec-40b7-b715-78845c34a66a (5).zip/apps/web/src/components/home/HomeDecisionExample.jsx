import { Link } from 'react-router-dom';
import { Lightbulb, ArrowRight } from 'lucide-react';

/**
 * Illustrative worked example — NOT a real review or measured result.
 * Shows how a practicing engineer would apply the MechEngi framework to a
 * real decision, so readers see the methodology in motion. Every figure here
 * is a clearly-labelled example, not a verified benchmark.
 */

const STEPS = [
  {
    n: 1,
    title: 'Define the engineering need',
    body: 'A 3-person product team needs parametric 3D CAD for consumer hardware prototypes, with cloud collaboration and a Python API for automating repeat drawings. Budget is under $600/seat/year.',
  },
  {
    n: 2,
    title: 'Shortlist from the directory',
    body: 'Filtering the /tools directory by CAD category and "has free tier" surfaces SOLIDWORKS, Fusion 360, Onshape, and FreeCAD. Each carries its vendor, pricing model, and a "Not Yet Rated" score state.',
  },
  {
    n: 3,
    title: 'Apply the 8-category lens (qualitatively)',
    body: 'Until benchmark scores exist, the team reads each tool profile against the eight categories: Engineering Effectiveness, Reliability, API Extensibility, TCO, Security, Industry Adoption, UX, and Documentation — noting where evidence is documented vs. absent.',
  },
  {
    n: 4,
    title: 'Pressure-test with the AI Advisor',
    body: 'The team pastes their constraints (OS, deployment, team size, budget, priority) into the AI Advisor and asks for a ranked shortlist with trade-offs — then verifies every vendor claim against the primary source before buying.',
  },
];

export default function HomeDecisionExample() {
  return (
    <section className="border-y border-border bg-card/20">
      <div className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.4fr] lg:items-start">
          {/* Left — intro */}
          <div className="lg:sticky lg:top-24">
            <p className="font-mono text-xs uppercase tracking-widest text-primary">Illustrative example</p>
            <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">See the framework applied to a real decision</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground sm:text-base">
              A walk-through of how a small product team would use MechEngi 10X to choose a CAD tool &mdash; from need
              to shortlist to verified decision.
            </p>
            <div className="mt-5 flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/5 px-4 py-3">
              <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
              <p className="text-[11px] leading-relaxed text-amber-400">
                This is an <span className="font-semibold">illustrative example</span> to show the process &mdash; not a
                real review, measured benchmark, or endorsement of any tool. Vendor capabilities and pricing must be
                confirmed on each vendor&rsquo;s site before purchase.
              </p>
            </div>
            <Link
              to="/wizard"
              className="mt-6 inline-flex items-center gap-2 rounded-xl border border-primary/30 bg-primary/10 px-5 py-2.5 font-mono text-xs font-semibold text-primary transition-colors hover:bg-primary/20"
            >
              Try the live tool wizard <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>

          {/* Right — steps */}
          <ol className="relative space-y-5 border-l border-border pl-6">
            {STEPS.map((s) => (
              <li key={s.n} className="relative">
                <span className="absolute -left-[1.65rem] flex h-7 w-7 items-center justify-center rounded-full border border-primary/40 bg-card font-mono text-xs font-bold text-primary">
                  {s.n}
                </span>
                <div className="rounded-2xl border border-border bg-card p-5">
                  <h3 className="font-display text-base font-bold sm:text-lg">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
