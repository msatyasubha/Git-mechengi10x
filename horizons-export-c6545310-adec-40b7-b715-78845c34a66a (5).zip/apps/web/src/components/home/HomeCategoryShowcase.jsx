import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { navCategories, tools } from '@/data/tools';

const countFor = (catId) =>
  catId === 'all' ? tools.length : tools.filter((t) => t.category === catId).length;

export default function HomeCategoryShowcase() {
  return (
    <section className="mx-auto max-w-[90rem] px-5 py-16">
      <div className="text-center">
        <p className="font-mono text-xs uppercase tracking-widest text-primary">Browse by Category</p>
        <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">
          Every Tool Category Covered
        </h2>
        <p className="mx-auto mt-3 max-w-lg text-muted-foreground">
          From AI assistants to professional simulation platforms — independent reviews across every category engineers care about.
        </p>
      </div>
      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {navCategories.map((cat) => (
          <Link
            key={cat.id}
            to={`/tools?cat=${cat.id}`}
            className="group flex items-start gap-4 rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:bg-primary/5 hover:shadow-lg hover:shadow-primary/5"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-border bg-muted text-2xl transition-colors group-hover:border-primary/30 group-hover:bg-primary/10">
              {cat.icon}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="font-display text-base font-semibold group-hover:text-primary">{cat.label}</p>
                <span className="shrink-0 rounded-full border border-border bg-muted/40 px-2 py-0.5 font-mono text-[10px] text-muted-foreground">
                  {countFor(cat.id)} tools
                </span>
              </div>
              <p className="mt-1 text-sm leading-snug text-muted-foreground">{cat.description}</p>
            </div>
            <ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground opacity-0 transition-all group-hover:translate-x-1 group-hover:text-primary group-hover:opacity-100" />
          </Link>
        ))}
      </div>
    </section>
  );
}
