import { Link } from 'react-router-dom';
import { CheckCircle2, Clock, AlertTriangle, ArrowRight } from 'lucide-react';

/**
 * Honest "verification scoreboard" — the single strongest trust signal we can
 * show. Instead of claiming authority, it states plainly what is and is not
 * yet backed by evidence. Every row is a verifiable statement about the site's
 * own process, not a claim about a third party.
 */
const ROWS = [
  {
    status: 'verified',
    label: 'Evaluation framework published',
    detail: 'The 100-point, 8-category MechEngi Score framework is public on the methodology page.',
  },
  {
    status: 'verified',
    label: 'Commercial relationships disclosed',
    detail: 'Affiliate links carry rel="sponsored" and a disclosure line; sponsorships are labelled.',
  },
  {
    status: 'verified',
    label: 'Tool directory is real & browsable',
    detail: '80+ tools with vendor, category, pricing model, and a documented free-tier flag.',
  },
  {
    status: 'pending',
    label: 'Hands-on benchmark scores',
    detail: 'No tool has a numeric MechEngi Score yet — every tool shows "Not Yet Rated" until data exists.',
  },
  {
    status: 'pending',
    label: 'Peer-verified reviews',
    detail: 'Community reviews are collected and moderated, but no verified peer review is published yet.',
  },
  {
    status: 'pending',
    label: 'Independent security audit',
    detail: 'Vendor security claims are reported from published docs only — not independently audited.',
  },
];

const TONE = {
  verified: {
    icon: CheckCircle2,
    color: 'text-green-400',
    bg: 'bg-green-500/10',
    border: 'border-green-500/30',
    label: 'Verified',
  },
  pending: {
    icon: Clock,
    color: 'text-amber-400',
    bg: 'bg-amber-500/5',
    border: 'border-amber-500/30',
    label: 'In progress',
  },
  unverified: {
    icon: AlertTriangle,
    color: 'text-muted-foreground',
    bg: 'bg-muted/30',
    border: 'border-border',
    label: 'Not started',
  },
};

export default function HomeVerificationStatus() {
  return (
    <section className="border-y border-border bg-card/20">
      <div className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
        <div className="mx-auto mb-10 max-w-2xl text-center">
          <p className="font-mono text-xs uppercase tracking-widest text-primary">Radical Transparency</p>
          <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">What we&rsquo;ve verified — and what we haven&rsquo;t</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground sm:text-base">
            Most review sites hide their gaps. We publish ours. Here is the honest current state of the evidence
            behind MechEngi 10X — updated as work is completed.
          </p>
        </div>

        <div className="mx-auto max-w-3xl overflow-hidden rounded-2xl border border-border">
          {ROWS.map((r, i) => {
            const tone = TONE[r.status] || TONE.unverified;
            const Icon = tone.icon;
            return (
              <div
                key={r.label}
                className={`flex items-start gap-4 px-5 py-4 sm:px-6 ${
                  i !== ROWS.length - 1 ? 'border-b border-border' : ''
                }`}
              >
                <span className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${tone.bg} ${tone.border} border`}>
                  <Icon className={`h-4 w-4 ${tone.color}`} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-display text-sm font-bold text-foreground">{r.label}</p>
                    <span className={`rounded-full border px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider ${tone.color} ${tone.bg} ${tone.border}`}>
                      {tone.label}
                    </span>
                  </div>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{r.detail}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mx-auto mt-8 flex max-w-3xl flex-col items-center gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/5 px-6 py-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm leading-relaxed text-muted-foreground">
            <span className="font-semibold text-foreground">We don&rsquo;t invent scores.</span> Until a tool has
            documented benchmark data, it stays &ldquo;Not Yet Rated&rdquo; — even if it&rsquo;s a sponsor.
          </p>
          <Link
            to="/methodology"
            className="inline-flex shrink-0 items-center gap-1.5 rounded-xl border border-primary/30 bg-primary/10 px-5 py-2.5 font-mono text-xs font-semibold text-primary transition-colors hover:bg-primary/20"
          >
            Read the framework <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
