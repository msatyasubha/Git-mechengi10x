import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export default function HomeFreeToolsTeaser() {
  return (
    <section className="border-t border-border py-10">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-center">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-green-400">No sign-up required</p>
            <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Free Engineering Calculators</h2>
            <p className="mt-3 max-w-lg text-muted-foreground">
              Online engineering utilities built for practicing engineers. Unit conversion, beam deflection, bolt torque estimates, and more — no registration or paywall.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {['Unit Converter (Live)', 'Reynolds Number (Live)', 'Beam Calculator (Live)', 'Bolt Torque (Live)', 'Material Selector (Soon)'].map(t => (
                <span key={t} className={`rounded-full border px-3 py-1 font-mono text-[10px] ${t.includes('Live') ? 'border-green-500/30 bg-green-500/10 text-green-400' : 'border-border text-muted-foreground'}`}>
                  {t}
                </span>
              ))}
            </div>
            <Link
              to="/free-tools"
              className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90"
            >
              Open Free Tools <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="hidden rounded-2xl border border-border bg-card p-6 lg:block lg:w-80">
            <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-3">Unit Converter Preview</p>
            <div className="space-y-2">
              {[['100 mm', '3.937 in'], ['1 MPa', '145.0 psi'], ['50 kPa', '7.252 psi'], ['200 Nm', '147.5 lb·ft']].map(([from, to]) => (
                <div key={from} className="flex items-center justify-between rounded-lg bg-muted/50 px-3 py-2">
                  <span className="font-mono text-sm text-muted-foreground">{from}</span>
                  <span className="font-mono text-xs text-muted-foreground">→</span>
                  <span className="font-mono text-sm text-primary font-semibold">{to}</span>
                </div>
              ))}
            </div>
            <Link to="/free-tools" className="mt-4 flex items-center justify-center gap-2 rounded-lg border border-border py-2 text-sm font-medium text-muted-foreground hover:border-primary/40 hover:text-primary">
              Open Calculator <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
