import { Link } from 'react-router-dom';
import { featuredGuides } from '@/data/guides';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const monthYear = (d) => {
  const [y, m] = d.split('-');
  return `${MONTHS[Number(m) - 1]} ${y}`;
};

export default function HomeGuides() {
  return (
    <section className="border-t border-border py-16">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="flex items-end justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-primary">Expert Deep Dives</p>
            <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Engineering Tool Guides</h2>
          </div>
          <Link to="/guides" className="hidden font-mono text-xs text-muted-foreground hover:text-primary md:block">
            All guides →
          </Link>
        </div>
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {featuredGuides.slice(0, 3).map((g) => (
            <Link key={g.slug} to={`/guides?open=${g.slug}`} className="group flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30">
              <span className={`self-start rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${g.category}`}>
                {g.category}
              </span>
              <h3 className="mt-3 font-display text-base font-semibold leading-snug group-hover:text-primary">
                {g.title}
              </h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{g.excerpt}</p>
              <div className="mt-4 flex items-center gap-3 font-mono text-xs text-muted-foreground">
                <span>{g.readTime} min read</span>
                <span>·</span>
                <span>Published {monthYear(g.date)}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
