import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Briefcase, ExternalLink, IndianRupee, Globe } from 'lucide-react';
import { jobsTeaser } from '@/data/home';

// Real India engineering job boards — we link to live searches, never invent
// listings, employers, or salaries. Mirrors the honest approach on /jobs.
const indiaBoardTeaser = [
  { name: 'Naukri — Mechanical Engineering', url: 'https://www.naukri.com/mechanical-engineer-jobs', desc: "India's largest board — ME, CAD & CAE roles nationwide" },
  { name: 'LinkedIn Jobs — India', url: 'https://www.linkedin.com/jobs/search/?geoRegion=102713980&keywords=mechanical%20engineer', desc: 'Product design, CAE & R&D roles at OEMs and startups' },
  { name: 'Indeed — India', url: 'https://www.indeed.co.in/mechanical-engineer-jobs', desc: 'Aggregated India listings across auto, aerospace & HVAC' },
];

// Region tabs — the active tab drives which cards render below, so the
// highlighted tab and the displayed content always stay in sync.
const TABS = [
  { id: 'global', label: 'Global Jobs', icon: Globe, to: '/jobs' },
  { id: 'india', label: 'India Jobs', icon: IndianRupee, to: '/jobs?region=india' },
  { id: 'remote', label: 'Remote', icon: Briefcase, to: '/jobs?region=remote' },
];

function JobCard({ job }) {
  return (
    <div className="group flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
      <div className="flex items-start justify-between gap-2">
        <div>
          <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${job.category}`}>
            {job.category === 'cad' ? 'CAD' : job.category.charAt(0).toUpperCase() + job.category.slice(1)}
          </span>
          <Link to="/jobs" className="mt-2 block font-display text-base font-semibold leading-snug group-hover:text-primary">{job.title}</Link>
        </div>
        <Briefcase className="mt-1 h-4 w-4 shrink-0 text-muted-foreground" />
      </div>
      <p className="mt-1 font-mono text-xs text-muted-foreground">{job.company} · {job.location}</p>
      <p className="mt-2 font-mono text-xs text-green-400">{job.salary}</p>
      <p className="mt-1 font-mono text-[10px] text-muted-foreground">Posted {job.posted}</p>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {job.tags.map(t => (
          <Link key={t} to={`/tools?q=${encodeURIComponent(t)}`} className="rounded-full border border-border bg-muted/40 px-2.5 py-0.5 font-mono text-[10px] text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary">{t}</Link>
        ))}
      </div>
    </div>
  );
}

export default function HomeJobsTeaser() {
  // Default to Global so the highlighted tab matches the global cards shown
  // on first paint.
  const [activeTab, setActiveTab] = useState('global');
  const activeTo = TABS.find(t => t.id === activeTab)?.to ?? '/jobs';

  // Region-driven filtering keeps the active tab and the cards in sync.
  // Global → international (US/EU) listings; India → India-based listings
  // with INR (₹) CTC bands; Remote → only listings already marked Remote.
  const visibleJobs = jobsTeaser.filter(j => j.region === activeTab);
  const remoteJobs = jobsTeaser.filter(j => /remote/i.test(j.location));

  return (
    <section className="border-t border-border bg-card/20 py-16">
      <div className="mx-auto max-w-[90rem] px-5">
        <div className="flex items-end justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-accent">Career Opportunities</p>
            <h2 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Engineering Jobs</h2>
          </div>
          <Link to={activeTo} className="hidden font-mono text-xs text-muted-foreground hover:text-primary md:block">
            All job listings →
          </Link>
        </div>

        {/* Region tabs — clicking a tab switches the cards below it */}
        <div className="mt-5 flex flex-wrap items-center gap-2">
          {TABS.map(t => {
            const Icon = t.icon;
            const active = activeTab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveTab(t.id)}
                aria-pressed={active}
                className={`inline-flex min-h-11 items-center rounded-lg border px-4 py-2 font-mono text-xs font-semibold transition-colors active:scale-[0.98] ${
                  active
                    ? 'border-primary/40 bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/30 hover:text-foreground'
                }`}
              >
                <Icon className="mr-2 h-3.5 w-3.5" />
                {t.label}
              </button>
            );
          })}
        </div>

        {/* Global — curated international (US/EU) featured listings */}
        {activeTab === 'global' && (
          <div>
            <p className="mb-4 font-mono text-xs text-muted-foreground">
              {visibleJobs.length} featured position{visibleJobs.length !== 1 ? 's' : ''} · curated international (US/EU)
            </p>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {visibleJobs.map(job => <JobCard key={job.title} job={job} />)}
            </div>
          </div>
        )}

        {/* India — India-based listings with INR (₹) CTC bands, plus live board links */}
        {activeTab === 'india' && (
          <div>
            <p className="mb-4 font-mono text-xs text-muted-foreground">
              {visibleJobs.length} featured position{visibleJobs.length !== 1 ? 's' : ''} · India-based · indicative CTC bands in ₹
            </p>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {visibleJobs.map(job => <JobCard key={job.title} job={job} />)}
            </div>
            <div className="mt-6 rounded-xl border border-border bg-card/40 p-5">
              <p className="font-mono text-xs text-muted-foreground">Search more live India engineering roles on India&rsquo;s top boards:</p>
              <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:flex-wrap">
                {indiaBoardTeaser.map(board => (
                  <a
                    key={board.name}
                    href={board.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-1.5 font-mono text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
                  >
                    {board.name} <ExternalLink className="h-3 w-3" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Remote — only listings already marked Remote; honest empty state otherwise */}
        {activeTab === 'remote' && (
          <div>
            {remoteJobs.length > 0 ? (
              <>
                <p className="mb-4 font-mono text-xs text-muted-foreground">
                  {remoteJobs.length} remote position{remoteJobs.length !== 1 ? 's' : ''} · work from anywhere
                </p>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {remoteJobs.map(job => <JobCard key={job.title} job={job} />)}
                </div>
              </>
            ) : (
              <div className="rounded-xl border border-border bg-card py-16 text-center">
                <Briefcase className="mx-auto h-8 w-8 text-muted-foreground/60" />
                <p className="mt-3 font-display text-lg font-semibold">No remote roles in this preview</p>
                <p className="mt-2 text-sm text-muted-foreground">Browse the full directory for work-from-anywhere engineering roles.</p>
                <Link to="/jobs?region=remote" className="mt-4 inline-flex rounded-lg bg-primary px-5 py-2 font-medium text-primary-foreground">Browse remote jobs →</Link>
              </div>
            )}
          </div>
        )}

        <div className="mt-5 text-center md:hidden">
          <Link to={activeTo} className="font-mono text-sm text-primary hover:underline">Browse all jobs →</Link>
        </div>
      </div>
    </section>
  );
}
