import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, ArrowRight, RotateCcw, Check, ExternalLink, Wallet, Layers, Users } from 'lucide-react';
import { tools, navCategories, categoryLabel } from '@/data/tools';
import { useCurrency } from '@/contexts/CurrencyContext';
import { formatInr, pricePeriod, FX_CAVEAT } from '@/lib/currency';
import ToolLogo from '@/components/ToolLogo';

const SCOPE_OPTIONS = [
  { id: 'solo', label: 'Solo / student', desc: 'Personal projects & learning' },
  { id: 'team', label: 'Small team', desc: 'Startup or SME, 2–25 engineers' },
  { id: 'enterprise', label: 'Enterprise', desc: 'Large org, compliance-driven' },
];

const BUDGET_OPTIONS = [
  { id: 'free', label: 'Free only', max: 0 },
  { id: 'low', label: 'Under $50/mo', max: 50 },
  { id: 'mid', label: 'Under $500/mo', max: 500 },
  { id: 'any', label: 'No budget limit', max: Infinity },
];

function priceLabel(tool, currency) {
  if (tool.pricing.contactForPricing) return 'Contact for pricing';
  if (tool.pricing.paidFrom === 0) return 'Free forever';
  const period = pricePeriod(tool.pricing.paidFrom);
  const usd = `$${tool.pricing.paidFrom}${period}`;
  return currency === 'INR' ? `${usd} (≈${formatInr(tool.pricing.paidFrom)}${period})` : usd;
}

function Step({ n, label }) {
  return (
    <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
      <span className="flex h-4 w-4 items-center justify-center rounded-full bg-primary/15 text-[9px] text-primary">{n}</span>
      {label}
    </span>
  );
}

function OptionButton({ active, onClick, title, desc, icon }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-start gap-3 rounded-xl border p-3.5 text-left transition-all active:scale-[0.99] ${
        active
          ? 'border-primary bg-primary/10'
          : 'border-border bg-card hover:border-primary/40'
      }`}
    >
      {icon && <span className="mt-0.5 shrink-0 text-primary">{icon}</span>}
      <span className="min-w-0">
        <span className="block text-sm font-semibold text-foreground">{title}</span>
        {desc && <span className="block text-xs text-muted-foreground">{desc}</span>}
      </span>
      {active && <Check className="ml-auto mt-0.5 h-4 w-4 shrink-0 text-primary" />}
    </button>
  );
}

export default function HomeAdvisorQuiz() {
  const { currency } = useCurrency();
  const [category, setCategory] = useState(null);
  const [budget, setBudget] = useState(null);
  const [scope, setScope] = useState(null);
  const [submitted, setSubmitted] = useState(false);

  const canSubmit = category && budget && scope;

  const recommendations = useMemo(() => {
    if (!canSubmit) return [];
    const budgetOpt = BUDGET_OPTIONS.find((b) => b.id === budget);
    let list = tools.filter((t) => t.category === category);

    // Budget filter
    if (budgetOpt.id === 'free') {
      list = list.filter((t) => t.pricing.paidFrom === 0 || t.pricing.free);
    } else {
      // include tools whose paidFrom is within budget OR that have a free tier
      list = list.filter(
        (t) => t.pricing.paidFrom <= budgetOpt.max || t.pricing.free || t.pricing.paidFrom === 0,
      );
    }

    // Scope weighting: enterprise scope favours higher-score / industry-standard tools
    list = [...list].sort((a, b) => {
      // free-first when budget is free
      if (budgetOpt.id === 'free') {
        const af = a.pricing.paidFrom === 0 ? 1 : 0;
        const bf = b.pricing.paidFrom === 0 ? 1 : 0;
        if (af !== bf) return bf - af;
      }
      return b.mechengiScore - a.mechengiScore;
    });

    return list.slice(0, 4);
  }, [canSubmit, category, budget, scope]);

  const reset = () => {
    setCategory(null);
    setBudget(null);
    setScope(null);
    setSubmitted(false);
  };

  const selectedCat = navCategories.find((c) => c.id === category);

  return (
    <section id="advisor-quiz" className="scroll-mt-20 border-y border-border bg-card/30">
      <div className="mx-auto max-w-[72rem] px-5 py-12 sm:py-14">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 font-mono text-[10px] text-primary">
            <Sparkles className="h-3 w-3" /> Quick Tool Finder
          </span>
          <h2 className="mt-3 font-display text-2xl font-bold sm:text-3xl">
            Find your tool in 3 quick answers
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            A lightweight recommendation from our independent directory — no sign-up needed.
            For a full AI-guided conversation, use the{' '}
            <Link to="/advisor" className="font-medium text-primary hover:underline">
              AI Engineering Advisor
            </Link>
            .
          </p>
        </div>

        {!submitted ? (
          <div className="mx-auto mt-8 grid max-w-3xl gap-6 md:grid-cols-3">
            {/* Step 1 — category */}
            <div className="space-y-3">
              <Step n={1} label="What do you need?" />
              <div className="space-y-2">
                {navCategories.map((c) => (
                  <OptionButton
                    key={c.id}
                    active={category === c.id}
                    onClick={() => setCategory(c.id)}
                    title={c.label}
                    desc={c.description}
                    icon={<span className="text-base">{c.icon}</span>}
                  />
                ))}
              </div>
            </div>

            {/* Step 2 — budget */}
            <div className="space-y-3">
              <Step n={2} label="Your budget" />
              <div className="space-y-2">
                {BUDGET_OPTIONS.map((b) => (
                  <OptionButton
                    key={b.id}
                    active={budget === b.id}
                    onClick={() => setBudget(b.id)}
                    title={b.label}
                    icon={<Wallet className="h-4 w-4" />}
                  />
                ))}
              </div>
            </div>

            {/* Step 3 — scope */}
            <div className="space-y-3">
              <Step n={3} label="Project scope" />
              <div className="space-y-2">
                {SCOPE_OPTIONS.map((s) => (
                  <OptionButton
                    key={s.id}
                    active={scope === s.id}
                    onClick={() => setScope(s.id)}
                    title={s.label}
                    desc={s.desc}
                    icon={
                      s.id === 'solo' ? (
                        <Users className="h-4 w-4" />
                      ) : s.id === 'team' ? (
                        <Layers className="h-4 w-4" />
                      ) : (
                        <Users className="h-4 w-4" />
                      )
                    }
                  />
                ))}
              </div>
            </div>

            <div className="md:col-span-3">
              <button
                onClick={() => setSubmitted(true)}
                disabled={!canSubmit}
                className="glow-primary mx-auto flex items-center gap-2 rounded-xl bg-primary px-7 py-3 font-display text-sm font-bold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 disabled:shadow-none"
              >
                <Sparkles className="h-4 w-4" /> Recommend tools
              </button>
              {!canSubmit && (
                <p className="mt-2 text-center font-mono text-[10px] text-muted-foreground">
                  Answer all three to get recommendations
                </p>
              )}
            </div>
          </div>
        ) : (
          <div className="mx-auto mt-8 max-w-3xl">
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
              <p className="font-mono text-xs text-muted-foreground">
                Matching{' '}
                <span className="text-primary">{selectedCat?.label}</span> ·{' '}
                <span className="text-primary">{BUDGET_OPTIONS.find((b) => b.id === budget)?.label}</span> ·{' '}
                <span className="text-primary">{SCOPE_OPTIONS.find((s) => s.id === scope)?.label}</span>
              </p>
              <button
                onClick={reset}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 font-mono text-xs text-muted-foreground transition-colors hover:border-foreground hover:text-foreground"
              >
                <RotateCcw className="h-3 w-3" /> Start over
              </button>
            </div>

            {recommendations.length === 0 ? (
              <div className="rounded-xl border border-border bg-muted/20 px-5 py-10 text-center">
                <p className="font-display text-base font-semibold">No tools match those exact filters</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Try broadening your budget, or browse the full{' '}
                  <Link to="/tools" className="font-medium text-primary hover:underline">directory</Link>.
                </p>
              </div>
            ) : (
              <>
                <div className="grid gap-3 sm:grid-cols-2">
                  {recommendations.map((t, i) => (
                    <div
                      key={t.slug}
                      className="flex flex-col rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40"
                    >
                      <div className="flex items-start gap-3">
                        <ToolLogo name={t.name} category={t.category} size="sm" />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            {i === 0 && (
                              <span className="rounded-full bg-accent/15 px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider text-accent">
                                Top match
                              </span>
                            )}
                            <p className="font-display text-sm font-bold leading-tight">{t.name}</p>
                          </div>
                          <p className="font-mono text-[10px] text-muted-foreground">{t.vendor}</p>
                        </div>
                        <span className="font-mono text-[10px] text-muted-foreground">Not Yet Rated</span>
                      </div>
                      <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{t.tagline}</p>
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        <span className="font-mono text-[10px] text-muted-foreground">{priceLabel(t, currency)}</span>
                        {(t.pricing.free || t.pricing.paidFrom === 0) && (
                          <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[9px] font-medium text-green-400">
                            Free tier
                          </span>
                        )}
                      </div>
                      <div className="mt-3 flex gap-2">
                        <Link
                          to={`/tools/${t.slug}`}
                          className="flex-1 rounded-lg border border-border py-1.5 text-center text-xs font-medium transition-colors hover:border-primary/60 hover:text-primary"
                        >
                          View review
                        </Link>
                        <a
                          href={t.affiliateUrl}
                          target="_blank"
                          rel="noopener noreferrer sponsored"
                          className="flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground transition-all hover:opacity-90"
                        >
                          Try <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-5 rounded-xl border border-primary/20 bg-primary/5 p-4 text-center">
                  <p className="text-sm text-muted-foreground">
                    Want a deeper, conversational recommendation with multi-variable constraints?
                  </p>
                  <Link
                    to="/advisor"
                    className="mt-3 inline-flex items-center gap-1.5 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90"
                  >
                    Open the full AI Engineering Advisor <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                  <p className="mt-2 font-mono text-[10px] text-muted-foreground">
                    The full Advisor requires sign-in and a verified email.
                  </p>
                </div>

                {currency === 'INR' && (
                  <p className="mt-3 text-center text-[10px] leading-relaxed text-muted-foreground">
                    {FX_CAVEAT}
                  </p>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
