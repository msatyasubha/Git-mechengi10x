const categoryColors = {
  ai: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
  cad: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
  simulation: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30',
  automation: 'bg-green-500/15 text-green-400 border-green-500/30',
  management: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
  learning: 'bg-pink-500/15 text-pink-400 border-pink-500/30',
  software: 'bg-teal-500/15 text-teal-400 border-teal-500/30',
};

const sizeClass = {
  sm: 'h-10 w-10 text-lg',
  md: 'h-11 w-11 text-xl',
  lg: 'h-12 w-12 text-2xl',
};

// Deterministic per-tool hue so two tools that share an initial never render
// the same tile. Category still sets the border; the fill is unique per name.
function hueFor(name) {
  let h = 0;
  const s = (name || '').toLowerCase();
  for (let i = 0; i < s.length; i += 1) h = (h * 31 + s.charCodeAt(i)) % 360;
  return h;
}

export default function ToolLogo({ name, category, size = 'md' }) {
  const initial = (name || '?').trim().charAt(0).toUpperCase();
  const colorClass = categoryColors[category] || 'bg-muted text-foreground border-border';
  const hue = hueFor(name);
  return (
    <div
      className={`flex shrink-0 items-center justify-center rounded-xl border font-display font-extrabold ${colorClass} ${sizeClass[size] || sizeClass.md}`}
      style={{ backgroundColor: `hsl(${hue} 55% 28% / 0.85)`, color: `hsl(${hue} 80% 82%)` }}
      aria-hidden="true"
      title={name}
    >
      {initial}
    </div>
  );
}
