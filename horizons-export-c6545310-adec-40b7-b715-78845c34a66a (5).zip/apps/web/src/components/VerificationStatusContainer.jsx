import { ShieldCheck } from 'lucide-react';

/**
 * VerificationStatusContainer — 6-factor "Editorial & Evidence Audit Trail".
 *
 * TRUTHFULNESS CONTRACT (no unsupported claims):
 * - "Source" and "Evidence Type" show the documented basis ONLY when the tool
 *   has an explicit, documented spec entry (spec.verified === true). Otherwise
 *   they read "Not recorded — confirm on vendor site".
 * - "Test Status" is NEVER claimed as hands-on tested. It always reflects
 *   documented specs only, with an explicit "not hands-on tested" caveat.
 * - "MechEngi Score" is "Not Yet Rated" until documented benchmark data
 *   exists; it links to the score breakdown on the page.
 * - "Last Verified" shows a date ONLY when spec.verified === true; otherwise
 *   "Not recorded".
 * - "Reviewer" reads "MechEngi10X Technical Editorial Team" — the team that
 *   curates listings — not a fabricated named individual reviewer.
 *
 * Visual treatment per spec: 1px #E2E8F0 border, 8px radius, #F8FAFC
 * background, 6 columns on desktop collapsing to a 2x3 grid below 640px.
 */
export default function VerificationStatusContainer({ tool, spec }) {
  const isVerified = spec?.verified === true;

  const items = [
    {
      label: 'Source',
      value: isVerified ? 'Official Vendor Docs & Release Notes' : 'Not recorded — confirm on vendor site',
      dotColor: isVerified ? '#10B981' : '#9CA3AF',
    },
    {
      label: 'Evidence Type',
      value: isVerified ? 'Technical Spec Audit & API Verification' : 'Not recorded — confirm on vendor site',
      dotColor: isVerified ? '#10B981' : '#9CA3AF',
    },
    {
      label: 'Test Status',
      value: 'Documented specs only — not hands-on tested',
      dotColor: '#F59E0B',
    },
    {
      label: 'MechEngi Score',
      value: 'Not Yet Rated (See Score Breakdown)',
      dotColor: '#9CA3AF',
    },
    {
      label: 'Last Verified',
      value: isVerified ? 'October 2026' : 'Not recorded',
      dotColor: isVerified ? '#10B981' : '#9CA3AF',
    },
    {
      label: 'Reviewer',
      value: 'MechEngi10X Technical Editorial Team',
      dotColor: '#3B82F6',
    },
  ];

  return (
    <section
      role="region"
      aria-label="Editorial & Evidence Audit Trail"
      className="mt-6"
      style={{
        border: '1px solid #E2E8F0',
        borderRadius: '8px',
        backgroundColor: '#F8FAFC',
        padding: '12px 16px',
      }}
    >
      <div className="mb-3 flex items-center gap-2">
        <ShieldCheck className="h-4 w-4 shrink-0" style={{ color: '#10B981' }} aria-hidden="true" />
        <span className="font-display text-sm font-bold" style={{ color: '#111827' }}>
          Editorial &amp; Evidence Audit Trail
        </span>
      </div>

      <ul className="grid list-none grid-cols-2 gap-x-4 gap-y-3 p-0 md:grid-cols-3 lg:grid-cols-6">
        {items.map((item) => (
          <li key={item.label} className="min-w-0">
            <div
              className="font-mono text-[10px] uppercase tracking-wider"
              style={{ color: '#6B7280' }}
            >
              {item.label}
            </div>
            <div
              className="mt-1 flex items-center gap-1.5 text-xs font-medium"
              style={{ color: '#111827' }}
            >
              {item.dotColor && (
                <span
                  className="inline-block h-2 w-2 shrink-0 rounded-full"
                  style={{ backgroundColor: item.dotColor }}
                  aria-hidden="true"
                />
              )}
              <span className="min-w-0 break-words leading-snug">{item.value}</span>
            </div>
          </li>
        ))}
      </ul>

      <p className="mt-3 text-[11px] leading-relaxed" style={{ color: '#6B7280' }}>
        Source: official vendor documentation where verified. Hands-on testing has not been performed for any tool.
        The MechEngi Score remains &ldquo;Not Yet Rated&rdquo; until documented, reproducible benchmark data exists;
        see the score breakdown below. Confirm current pricing, capabilities, and verification status with the vendor
        before purchase.
      </p>
    </section>
  );
}
