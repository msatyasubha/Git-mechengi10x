import { useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';

/**
 * Normalize common model quirks so Markdown + KaTeX parse cleanly:
 * - bare \(...\) / \[...\] already handled by remark-math
 * - double-escaped LaTeX from some models (\\frac → \frac)
 * - ensure blank lines around block math for spacing
 */
function normalizeMathMarkdown(raw) {
  if (!raw || typeof raw !== 'string') return '';

  let text = raw;

  // Un-double-escape common LaTeX command sequences when the model
  // emits literal backslash-backslash (shown as plain text otherwise).
  text = text.replace(/\\\\([a-zA-Z]+)/g, '\\$1');

  // Convert $$ ... $$ already fine; ensure \[ \] and \( \) spacing.
  text = text.replace(/\\\[/g, '\n\n$$\n').replace(/\\\]/g, '\n$$\n\n');
  text = text.replace(/\\\(/g, '$').replace(/\\\)/g, '$');

  // Some models write \sigma = \frac{F}{A} without $ wrappers — leave as-is
  // if already in math; if line looks like pure equation assignment, wrap it.
  text = text.replace(
    /(?:^|\n)([ \t]*)((?:\\[a-zA-Z]+|[A-Za-z])[^\n]{0,120}?=\s*(?:\\frac|\\sqrt|\\sum|\\int)[^\n]+)/gm,
    (match, indent, eq) => {
      const trimmed = eq.trim();
      if (trimmed.includes('$') || trimmed.startsWith('```')) return match;
      return `\n\n${indent}$$\n${trimmed}\n$$\n\n`;
    },
  );

  // Collapse excessive blank lines
  text = text.replace(/\n{4,}/g, '\n\n\n');

  return text;
}

/** Plain-text fallback when KaTeX fails — strip TeX commands into readable form. */
export function latexToPlain(tex) {
  if (!tex) return '';
  let s = String(tex);
  s = s.replace(/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, '($1)/($2)');
  s = s.replace(/\\sqrt\{([^{}]+)\}/g, '√($1)');
  s = s.replace(/\\sum/g, 'Σ');
  s = s.replace(/\\int/g, '∫');
  s = s.replace(/\\partial/g, '∂');
  s = s.replace(/\\infty/g, '∞');
  s = s.replace(/\\times/g, '×');
  s = s.replace(/\\cdot/g, '·');
  s = s.replace(/\\leq/g, '≤');
  s = s.replace(/\\geq/g, '≥');
  s = s.replace(/\\neq/g, '≠');
  s = s.replace(/\\approx/g, '≈');
  s = s.replace(/\\pm/g, '±');
  s = s.replace(/\\sigma/g, 'σ');
  s = s.replace(/\\tau/g, 'τ');
  s = s.replace(/\\alpha/g, 'α');
  s = s.replace(/\\beta/g, 'β');
  s = s.replace(/\\gamma/g, 'γ');
  s = s.replace(/\\delta/g, 'δ');
  s = s.replace(/\\epsilon/g, 'ε');
  s = s.replace(/\\theta/g, 'θ');
  s = s.replace(/\\lambda/g, 'λ');
  s = s.replace(/\\mu/g, 'μ');
  s = s.replace(/\\pi/g, 'π');
  s = s.replace(/\\rho/g, 'ρ');
  s = s.replace(/\\phi/g, 'φ');
  s = s.replace(/\\omega/g, 'ω');
  s = s.replace(/\\Delta/g, 'Δ');
  s = s.replace(/\\Sigma/g, 'Σ');
  s = s.replace(/\\_/g, '_');
  s = s.replace(/\\\{/g, '{').replace(/\\\}/g, '}');
  s = s.replace(/\\left|\\right/g, '');
  s = s.replace(/\\[a-zA-Z]+/g, '');
  s = s.replace(/[{}]/g, '');
  s = s.replace(/\s+/g, ' ').trim();
  return s;
}

function MathFallback({ children, display }) {
  const plain = latexToPlain(typeof children === 'string' ? children : String(children ?? ''));
  if (display) {
    return (
      <div
        className="my-4 overflow-x-auto rounded-xl border border-primary/20 bg-primary/5 px-4 py-3 text-center font-mono text-sm text-foreground"
        role="math"
        aria-label={plain}
      >
        {plain || 'Equation'}
      </div>
    );
  }
  return (
    <code className="rounded bg-muted/60 px-1.5 py-0.5 font-mono text-[0.9em] text-primary" title={plain}>
      {plain || '…'}
    </code>
  );
}

const remarkPlugins = [remarkGfm, remarkMath];
const rehypePlugins = [[rehypeKatex, { throwOnError: false, strict: 'ignore', output: 'html' }]];

export default function MarkdownMessage({ content, isUser, isStreamingTail }) {
  const source = useMemo(() => normalizeMathMarkdown(content), [content]);

  if (!source && !isStreamingTail) return null;

  if (isUser) {
    return (
      <div className="whitespace-pre-wrap break-words">
        {content}
        {isStreamingTail && (
          <span className="ml-0.5 inline-block h-3.5 w-1.5 animate-pulse rounded-sm bg-primary-foreground/80 align-middle" aria-hidden />
        )}
      </div>
    );
  }

  return (
    <div className="advisor-md break-words text-[0.9375rem] leading-relaxed text-foreground">
      <ReactMarkdown
        remarkPlugins={remarkPlugins}
        rehypePlugins={rehypePlugins}
        components={{
          h1: ({ children }) => (
            <h3 className="mb-3 mt-5 border-b border-border pb-2 font-display text-lg font-bold first:mt-0">{children}</h3>
          ),
          h2: ({ children }) => (
            <h3 className="mb-2.5 mt-5 font-display text-base font-bold text-foreground first:mt-0">{children}</h3>
          ),
          h3: ({ children }) => (
            <h4 className="mb-2 mt-4 font-display text-sm font-semibold text-primary first:mt-0">{children}</h4>
          ),
          h4: ({ children }) => (
            <h5 className="mb-1.5 mt-3 font-display text-sm font-semibold text-foreground/90 first:mt-0">{children}</h5>
          ),
          p: ({ children }) => <p className="mb-3 last:mb-0 leading-relaxed text-foreground/95">{children}</p>,
          ul: ({ children }) => <ul className="mb-3 list-disc space-y-1.5 pl-5 last:mb-0 marker:text-primary">{children}</ul>,
          ol: ({ children }) => <ol className="mb-3 list-decimal space-y-1.5 pl-5 last:mb-0 marker:text-primary">{children}</ol>,
          li: ({ children }) => <li className="leading-relaxed pl-0.5">{children}</li>,
          strong: ({ children }) => <strong className="font-semibold text-foreground">{children}</strong>,
          em: ({ children }) => <em className="italic text-foreground/90">{children}</em>,
          a: ({ href, children }) => (
            <a href={href} target="_blank" rel="noopener noreferrer" className="font-medium text-primary underline-offset-2 hover:underline">
              {children}
            </a>
          ),
          blockquote: ({ children }) => (
            <blockquote className="my-3 border-l-2 border-primary/50 bg-muted/30 py-2 pl-4 pr-3 text-sm text-muted-foreground">
              {children}
            </blockquote>
          ),
          hr: () => <hr className="my-4 border-border" />,
          code: ({ className, children, ...props }) => {
            const isBlock = /language-/.test(className || '') || String(children).includes('\n');
            // KaTeX may leave failed math as code — try plain fallback
            const raw = String(children).replace(/\n$/, '');
            if (!isBlock && (raw.includes('\\') || /frac|sigma|tau|sqrt/.test(raw))) {
              return <MathFallback display={false}>{raw}</MathFallback>;
            }
            if (isBlock) {
              return (
                <pre className="my-3 overflow-x-auto rounded-xl border border-border bg-background/80 p-3 font-mono text-xs leading-relaxed text-foreground">
                  <code className={className} {...props}>
                    {children}
                  </code>
                </pre>
              );
            }
            return (
              <code className="rounded bg-muted/70 px-1.5 py-0.5 font-mono text-[0.85em] text-accent" {...props}>
                {children}
              </code>
            );
          },
          pre: ({ children }) => <>{children}</>,
          table: ({ children }) => (
            <div className="my-3 overflow-x-auto rounded-xl border border-border">
              <table className="w-full min-w-[240px] border-collapse text-left text-sm">{children}</table>
            </div>
          ),
          thead: ({ children }) => <thead className="bg-muted/50 text-muted-foreground">{children}</thead>,
          th: ({ children }) => <th className="border-b border-border px-3 py-2 font-mono text-xs font-medium">{children}</th>,
          td: ({ children }) => <td className="border-b border-border/60 px-3 py-2 align-top">{children}</td>,
        }}
      >
        {source}
      </ReactMarkdown>
      {isStreamingTail && (
        <span className="ml-0.5 inline-block h-3.5 w-1.5 animate-pulse rounded-sm bg-primary/80 align-middle" aria-hidden />
      )}
    </div>
  );
}
