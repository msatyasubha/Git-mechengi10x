import { useEffect, useState } from 'react';
import { acceptAllCookies, rejectOptionalCookies, saveConsent, hasConsentDecision, isConsentGranted, onCookiePreferencesRequested, CookieConsentCategory } from '@/lib/cookieConsent';

export default function CookieBanner() {
  const [open, setOpen] = useState(() => !hasConsentDecision());
  const [customize, setCustomize] = useState(false);
  const [choices, setChoices] = useState({ analytics: false, marketing: false, platformAnalytics: false });

  useEffect(() => onCookiePreferencesRequested(() => {
    setChoices({
      analytics: isConsentGranted(CookieConsentCategory.Analytics),
      marketing: isConsentGranted(CookieConsentCategory.Marketing),
      platformAnalytics: isConsentGranted(CookieConsentCategory.PlatformAnalytics),
    });
    setCustomize(true);
    setOpen(true);
  }), []);

  if (!open) return null;
  const finish = (action) => { action(); setOpen(false); setCustomize(false); };
  const options = [
    { key: 'analytics', title: 'Analytics', description: 'Helps us understand site usage.' },
    { key: 'marketing', title: 'Marketing', description: 'Supports ad measurement and personalised advertising.' },
    { key: 'platformAnalytics', title: 'Platform analytics', description: 'Helps Hostinger understand and improve store and checkout experiences without directly identifying you.' },
  ];

  return (
    <section role="dialog" aria-label="Cookie preferences" className="fixed inset-x-4 bottom-4 z-[100] mx-auto max-w-3xl rounded-2xl border border-border bg-card p-5 text-foreground shadow-2xl sm:p-6">
      <h2 className="font-display text-lg font-bold">Your cookie choices</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">Necessary cookies support site functions. With your permission, optional cookies can be used for analytics and marketing. You can change your choices at any time in the footer.</p>
      {customize && (
        <fieldset className="mt-4 space-y-3">
          <legend className="sr-only">Optional cookie categories</legend>
          {options.map((option) => (
            <label key={option.key} className="flex items-start gap-3 text-sm">
              <input type="checkbox" className="mt-1 accent-blue-500" checked={choices[option.key]} onChange={(event) => setChoices((current) => ({ ...current, [option.key]: event.target.checked }))} />
              <span><strong>{option.title}</strong><span className="block text-xs text-muted-foreground">{option.description}</span></span>
            </label>
          ))}
        </fieldset>
      )}
      <div className="mt-5 flex flex-wrap gap-2">
        <button type="button" onClick={() => finish(rejectOptionalCookies)} className="min-h-[44px] rounded-lg border border-border px-4 py-2 text-sm font-semibold hover:border-primary">Reject optional</button>
        <button type="button" onClick={() => finish(acceptAllCookies)} className="min-h-[44px] rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">Accept all</button>
        {customize ? (
          <button type="button" onClick={() => finish(() => saveConsent(choices))} className="min-h-[44px] rounded-lg border border-border px-4 py-2 text-sm font-medium hover:border-primary">Save choices</button>
        ) : (
          <button type="button" onClick={() => setCustomize(true)} className="min-h-[44px] rounded-lg border border-border px-4 py-2 text-sm font-medium hover:border-primary">Customize</button>
        )}
      </div>
    </section>
  );
}
