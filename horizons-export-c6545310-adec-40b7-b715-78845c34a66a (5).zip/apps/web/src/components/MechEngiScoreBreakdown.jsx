import { useState } from 'react';
import { Info, AlertCircle } from 'lucide-react';
import { SCORE_CATEGORIES, hasVerifiedScore } from '@/data/methodology';

function CategoryTooltip({ category }) {
  return (
    <div className="absolute bottom-full left-1/2 z-30 mb-2 w-72 -translate-x-1/2 rounded-xl border border-border bg-popover p-4 text-left shadow-xl">
      <p className="font-display text-sm font-bold text-foreground">{category.name}</p>
      <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-primary">
        Max {category.max} pts · {category.weight}
      </p>
      <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{category.description}</p>
      <p className="mt-2 text-[11px] leading-relaxed text-foreground/70">
        <span className="font-semibold text-foreground">How it&rsquo;s verified: </span>
        {category.howVerified}
      </p>
    </div>
  );
}

function CategoryRow({ category }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="group relative">
      <div className="flex items-center justify-between gap-2">
        <button
          type="button"
          onMouseEnter={() => setOpen(true)}
          onMouseLeave={() => setOpen(false)}
          onFocus={() => setOpen(true)}
          onBlur={() => setOpen(false)}
          onClick={() => setOpen((v) => !v)}
          className="flex items-center gap-1.5 text-left"
          aria-label={`About ${category.name} scoring criteria`}
        >
          <span className="text-sm font-medium text-foreground/90">{category.name}</span>
          <Info className="h-3.5 w-3.5 text-muted-foreground transition-colors group-hover:text-primary" />
        </button>
        <span className="font-mono text-xs text-muted-foreground">
          Up to {category.max} pts
        </span>
      </div>
      <p className="mt-1 text-xs text-muted-foreground">Awaiting benchmark evidence</p>
      {open && <CategoryTooltip category={category} />}
    </div>
  );
}

export default function MechEngiScoreBreakdown({ tool }) {
  const verified = hasVerifiedScore(tool);

  return (
    <section aria-labelledby="mechengi-score-heading" className="rounded-2xl border border-border bg-card p-5 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-4">
        <div>
          <h2 id="mechengi-score-heading" className="font-display text-lg font-bold sm:text-xl">
            MechEngi Score Breakdown
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">
            100-point framework · 8 weighted categories ·{' '}
            <a href="/methodology" className="text-primary hover:underline">View methodology</a>
          </p>
        </div>
        {verified ? (
          <span className="flex h-16 w-16 flex-col items-center justify-center rounded-2xl border border-primary/40 bg-primary/10">
            <span className="font-display text-2xl font-extrabold text-primary">—</span>
            <span className="font-mono text-[9px] text-muted-foreground">/ 100</span>
          </span>
        ) : (
          <span className="flex items-center gap-2 rounded-xl border border-border bg-muted/40 px-3 py-2">
            <AlertCircle className="h-4 w-4 shrink-0 text-muted-foreground" />
            <span className="font-mono text-[11px] leading-tight text-muted-foreground">
              Not Yet Rated
              <span className="block text-[10px]">Awaiting Benchmark Data</span>
            </span>
          </span>
        )}
      </div>

      {/* Honest state banner — no benchmark data has been published yet */}
      <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-amber-500/25 bg-amber-500/5 px-4 py-3">
        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
        <p className="text-xs leading-relaxed text-muted-foreground">
          <span className="font-semibold text-foreground">No benchmark data published yet.</span> The 100-point
          framework below is published and transparent, but no tool has completed hands-on benchmark testing. Per-category
          scores remain empty until documented, reproducible test results exist — we do not invent partial scores.
        </p>
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        {SCORE_CATEGORIES.map((c) => (
          <CategoryRow key={c.id} category={c} />
        ))}
      </div>

      <p className="mt-5 border-t border-border pt-4 text-[11px] leading-relaxed text-muted-foreground">
        Scores are independent of affiliate relationships. When benchmark data is introduced, each category will be
        labelled with its verification source and date. {tool?.name ? `${tool.name}'s ` : 'This tool\u2019s '}
        editorial ranking elsewhere on this page is separate from the benchmark score and is clearly labelled as such.
      </p>
    </section>
  );
}
