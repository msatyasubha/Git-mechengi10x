import { Link } from 'react-router-dom';
import { Star, ExternalLink, MessageSquare } from 'lucide-react';
import ToolLogo from '@/components/ToolLogo';
import PriceText from '@/components/PriceText';
import { Checkbox } from '@/components/ui/checkbox';

const categoryLabel = {
  ai: 'AI Tools',
  cad: 'CAD & Design',
  simulation: 'Simulation',
  automation: 'Automation',
  management: 'Management',
  learning: 'Learning',
  software: 'Software Engineering',
};

function StarRating({ rating }) {
  const full = Math.floor(rating);
  const remainder = rating - full;
  const hasHalf = remainder >= 0.25 && remainder < 0.75;
  const roundUp = remainder >= 0.75;
  return (
    <span className="flex items-center gap-0.5" aria-label={`${rating} out of 5`}>
      {[1, 2, 3, 4, 5].map((s) => {
        const filled = s <= full || (roundUp && s === full + 1);
        const half = hasHalf && s === full + 1;
        return (
          <span key={s} className="relative inline-flex h-3.5 w-3.5">
            <Star className="h-3.5 w-3.5 star-empty" strokeWidth={0} fill="currentColor" />
            {(filled || half) && (
              <span className="absolute inset-0 overflow-hidden" style={{ width: half ? '50%' : '100%' }}>
                <Star className="h-3.5 w-3.5 star-filled fill-current" strokeWidth={0} fill="currentColor" />
              </span>
            )}
          </span>
        );
      })}
    </span>
  );
}

export default function ToolCard({ tool, compact = false, selectable = false, selected = false, onToggleSelect, onReview }) {
  return (
    <div className={`group relative flex flex-col rounded-xl border bg-card p-4 transition-all duration-200 hover:shadow-lg hover:shadow-primary/5 sm:p-5 ${selected ? 'border-primary ring-1 ring-primary/40' : 'border-border hover:border-primary/40'}`}>
      {/* Badge + compare checkbox — in normal flow above the header so they
          never overlap the category label or tool name. */}
      {(tool.badge || selectable) && (
        <div className="mb-3 flex flex-wrap items-center justify-end gap-2">
          {tool.badge && (
            <span className="rounded-full bg-accent/15 px-2.5 py-0.5 font-mono text-[10px] font-medium uppercase tracking-wider text-accent">
              {tool.badge === 'Top Rated' ? 'Editorial Pick' : tool.badge}
            </span>
          )}
          {selectable && (
            <label className="flex cursor-pointer items-center gap-1.5 rounded-full border border-border bg-background/80 px-2 py-1 font-mono text-[10px] text-muted-foreground transition-colors hover:border-primary/50 hover:text-primary">
              <Checkbox
                checked={selected}
                onCheckedChange={() => onToggleSelect?.(tool.slug)}
                aria-label={`Select ${tool.name} for comparison`}
              />
              Compare
            </label>
          )}
        </div>
      )}

      {/* Header */}
      <div className="flex items-start gap-3">
        <ToolLogo name={tool.name} category={tool.category} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${tool.category}`}>
              {categoryLabel[tool.category]}
            </span>
          </div>
          <h3 className="mt-1 font-display text-base font-semibold leading-tight">
            {tool.name}
          </h3>
          <p className="text-xs text-muted-foreground">{tool.vendor}</p>
        </div>
      </div>

      {/* MechEngi Score */}
      <div className="mt-1 flex items-center gap-2">
        <span className="font-mono text-xs text-muted-foreground">Benchmark score pending</span>
        <Link to="/methodology" className="font-mono text-xs text-primary hover:underline">How we evaluate</Link>
      </div>

      {/* Tagline */}
      {!compact && (
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground line-clamp-2">{tool.tagline}</p>
      )}

      {/* Pricing & license */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        {tool.pricing.contactForPricing ? (
          <span className="rounded-full border border-border bg-muted/40 px-2 py-0.5 font-mono text-[10px] font-medium text-muted-foreground">
            Contact for pricing
          </span>
        ) : tool.pricing.free ? (
          <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] font-medium text-green-400">
            Free tier
          </span>
        ) : tool.pricing.paidFrom > 0 ? (
          <span className="rounded-full border border-border bg-muted/40 px-2 py-0.5 font-mono text-[10px] font-medium text-muted-foreground">
            Commercial / Trial Available
          </span>
        ) : (
          <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] font-medium text-green-400">
            Free forever
          </span>
        )}
        {tool.pricing.contactForPricing ? (
          <span className="font-mono text-[10px] text-muted-foreground">{tool.pricing.freeLabel}</span>
        ) : tool.pricing.paidFrom > 0 && (
          <PriceText usd={tool.pricing.paidFrom} className="font-mono text-xs text-muted-foreground" />
        )}
      </div>

      {/* Actions */}
      <div className="mt-4 flex gap-2">
        <Link
          to={`/tools/${tool.slug}`}
          className="flex-1 rounded-lg border border-border py-2 text-center text-sm font-medium transition-colors hover:border-primary/60 hover:bg-primary/5 hover:text-primary"
        >
          View Review<span className="sr-only"> of {tool.name}</span>
        </Link>
        {onReview && (
          <button
            type="button"
            onClick={() => onReview(tool)}
            className="flex items-center gap-1 rounded-lg border border-border px-3 py-2 text-sm font-medium transition-colors hover:border-primary/60 hover:text-primary"
            aria-label={`Write a review for ${tool.name}`}
          >
            <MessageSquare className="h-3.5 w-3.5" />
          </button>
        )}
        <a
          href={tool.affiliateUrl}
          target="_blank"
          rel="noopener noreferrer sponsored"
          className="flex items-center gap-1 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
        >
          Try <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>
    </div>
  );
}

export { StarRating };
