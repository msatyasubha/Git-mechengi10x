import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  Star,
  MessageSquare,
  Send,
  Loader2,
  ShieldCheck,
  Clock,
  UserCheck,
  SlidersHorizontal,
  MailCheck,
} from 'lucide-react';
import pb from '@/lib/pocketbaseClient';

const DISCIPLINES = [
  { value: 'mechanical', label: 'Mechanical' },
  { value: 'piping-flow', label: 'Piping / Flow' },
  { value: 'cad-management', label: 'CAD Management' },
  { value: 'fea-cfd', label: 'FEA / CFD' },
  { value: 'manufacturing', label: 'Manufacturing' },
  { value: 'other', label: 'Other' },
];

const DURATIONS = [
  { value: 'under-6-months', label: '< 6 months' },
  { value: '6-12-months', label: '6–12 months' },
  { value: '1-3-years', label: '1–3 years' },
  { value: '3-plus-years', label: '3+ years' },
];

function RatingSlider({ label, value, onChange }) {
  return (
    <div>
      <div className="flex items-center justify-between">
        <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</label>
        <span className="font-mono text-xs font-semibold text-primary">{value} / 5</span>
      </div>
      <input
        type="range"
        min={0}
        max={5}
        step={1}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-2 h-2 w-full cursor-pointer appearance-none rounded-full bg-muted accent-primary"
        aria-label={`${label} rating`}
      />
    </div>
  );
}

function ReviewCard({ review }) {
  const date = new Date(review.created).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  const discipline = DISCIPLINES.find((d) => d.value === review.discipline)?.label;
  const duration = DURATIONS.find((d) => d.value === review.usage_duration)?.label;
  const name = review.full_name || review.expand?.owner?.name || 'Verified Engineer';
  const jobTitle = review.job_title;
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary">
            {name.charAt(0).toUpperCase()}
          </div>
          <div>
            <p className="text-sm font-medium">{name}</p>
            <p className="text-xs text-muted-foreground">
              {jobTitle ? `${jobTitle}` : ''}
              {discipline ? `${jobTitle ? ' · ' : ''}${discipline}` : ''}
              {duration ? ` · ${duration}` : ''}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5].map((s) => (
            <Star
              key={s}
              className={`h-3.5 w-3.5 ${s <= review.rating ? 'fill-current text-amber-400' : 'text-border'}`}
              strokeWidth={0}
            />
          ))}
        </div>
      </div>
      <p className="mt-2 font-mono text-[10px] text-muted-foreground">{date}</p>
      {review.title && <p className="mt-2 font-semibold">{review.title}</p>}
      {review.body && <p className="mt-2 text-sm leading-relaxed text-foreground/80">{review.body}</p>}
      {(review.pros || review.cons) && (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {review.pros && (
            <div className="rounded-lg border border-green-500/20 bg-green-500/5 p-3">
              <p className="font-mono text-[10px] uppercase tracking-wider text-green-400">Pros</p>
              <p className="mt-1 text-xs leading-relaxed text-foreground/80">{review.pros}</p>
            </div>
          )}
          {review.cons && (
            <div className="rounded-lg border border-red-500/20 bg-red-500/5 p-3">
              <p className="font-mono text-[10px] uppercase tracking-wider text-red-400">Limitations</p>
              <p className="mt-1 text-xs leading-relaxed text-foreground/80">{review.cons}</p>
            </div>
          )}
        </div>
      )}
      {(review.api_rating > 0 || review.stability_rating > 0 || review.pricing_transparency_rating > 0) && (
        <div className="mt-3 flex flex-wrap gap-3 border-t border-border pt-3">
          {review.api_rating > 0 && (
            <span className="font-mono text-[10px] text-muted-foreground">API: {review.api_rating}/5</span>
          )}
          {review.stability_rating > 0 && (
            <span className="font-mono text-[10px] text-muted-foreground">Stability: {review.stability_rating}/5</span>
          )}
          {review.pricing_transparency_rating > 0 && (
            <span className="font-mono text-[10px] text-muted-foreground">Pricing transparency: {review.pricing_transparency_rating}/5</span>
          )}
        </div>
      )}
    </div>
  );
}

export default function ReviewsSection({ toolSlug }) {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [justSubmitted, setJustSubmitted] = useState(false);

  const user = pb.authStore.record;
  const isVerified = !!user?.verified;

  const resendVerification = async () => {
    if (!user?.email) return;
    try {
      await pb.collection('users').requestVerification(user.email);
    } catch (_) {
      // ignore — surface nothing on failure
    }
  };

  const blankForm = {
    rating: 0,
    title: '',
    body: '',
    full_name: '',
    job_title: '',
    work_email: '',
    discipline: '',
    usage_duration: '',
    pros: '',
    cons: '',
    api_rating: 0,
    stability_rating: 0,
    pricing_transparency_rating: 0,
    trust_confirmed: false,
  };
  const [form, setForm] = useState(blankForm);

  const loadReviews = useCallback(async () => {
    try {
      const list = await pb.collection('tool_reviews').getFullList({
        filter: pb.filter('tool_slug = {:s}', { s: toolSlug }),
        sort: '-created',
        expand: 'owner',
        requestKey: `reviews-${toolSlug}`,
      });
      setReviews(list);
    } catch (e) {
      // ignore fetch errors
    } finally {
      setLoading(false);
    }
  }, [toolSlug]);

  useEffect(() => {
    loadReviews();
  }, [loadReviews]);

  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.rating === 0) {
      setError('Please select an overall star rating.');
      return;
    }
    if (!form.work_email.trim()) {
      setError('A professional/work email is required for verification.');
      return;
    }
    if (!form.trust_confirmed) {
      setError('Please confirm the review is based on your actual workplace experience.');
      return;
    }
    setSubmitting(true);
    try {
      await pb.collection('tool_reviews').create({
        tool_slug: toolSlug,
        rating: form.rating,
        title: form.title,
        body: form.body,
        owner: user.id,
        full_name: form.full_name,
        job_title: form.job_title,
        work_email: form.work_email,
        discipline: form.discipline,
        usage_duration: form.usage_duration,
        pros: form.pros,
        cons: form.cons,
        api_rating: form.api_rating,
        stability_rating: form.stability_rating,
        pricing_transparency_rating: form.pricing_transparency_rating,
        trust_confirmed: form.trust_confirmed,
        // status is never set by the client — server default is 'pending'.
      });
      setForm(blankForm);
      setShowForm(false);
      setJustSubmitted(true);
      await loadReviews();
    } catch (err) {
      if (err?.status === 400) {
        setError('You have already submitted a review for this tool.');
      } else {
        setError('Failed to submit review. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="mt-14" id="reviews">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-5">
        <div className="flex items-center gap-4">
          <UserCheck className="h-5 w-5 text-primary" />
          <div>
            <h2 className="font-display text-2xl font-bold">Peer Reviews &amp; Technical Feedback</h2>
            <p className="mt-0.5 text-sm text-muted-foreground">
              Submitted by verified CAD administrators, design engineers, and simulation specialists.
            </p>
          </div>
        </div>
        {reviews.length > 0 && (
          <span className="rounded-full border border-border bg-muted px-3 py-0.5 font-mono text-xs text-muted-foreground">
            {reviews.length} approved review{reviews.length !== 1 ? 's' : ''}
          </span>
        )}
      </div>

      {/* Moderation & verification notice */}
      <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-border bg-muted/20 px-4 py-3 text-xs leading-relaxed text-muted-foreground">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        <p>
          Reviews require a professional email and are <span className="text-foreground">moderated before they appear</span>.
          We do not award verified-reviewer badges, publish aggregate star ratings as fact, or display ratings that have
          not gone through this flow. Work emails are used only for verification and are never shown publicly.
        </p>
      </div>

      {/* Write a review CTA / states */}
      {!loading && (
        <div className="mt-5">
          {!user ? (
            <div className="rounded-xl border border-border bg-muted/30 px-5 py-4 text-sm text-muted-foreground">
              <Link to="/login" className="font-semibold text-primary hover:underline">Sign in</Link> to submit a verified
              technical review and help other engineers.
            </div>
          ) : !isVerified ? (
            <div className="flex items-start gap-2.5 rounded-xl border border-amber-500/25 bg-amber-500/5 px-5 py-3.5 text-sm">
              <MailCheck className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
              <p className="text-muted-foreground">
                <span className="font-semibold text-foreground">Verify your email to submit a peer review.</span>{' '}
                Authenticated peer reviews require a verified email so other engineers can trust the source.
                Check your inbox for the verification link, or{' '}
                <button type="button" onClick={resendVerification} className="font-semibold text-primary hover:underline">
                  resend it
                </button>.
              </p>
            </div>
          ) : justSubmitted ? (
            <div className="flex items-start gap-2.5 rounded-xl border border-amber-500/25 bg-amber-500/5 px-5 py-3.5 text-sm">
              <Clock className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
              <p className="text-muted-foreground">
                <span className="font-semibold text-foreground">Review submitted — pending moderation.</span>
                Our team reviews every submission before it is published. You will not see it on this page until it is
                approved. One review per engineer per tool.
              </p>
            </div>
          ) : !showForm ? (
            <button
              onClick={() => setShowForm(true)}
              className="rounded-xl border border-primary/30 bg-primary/5 px-5 py-3 text-sm font-semibold text-primary transition-colors hover:bg-primary/10"
            >
              Submit a Verified Technical Review
            </button>
          ) : null}

          {showForm && user && (
            <form onSubmit={handleSubmit} className="mt-4 rounded-xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Your Verified Review</h3>

              {/* Identity */}
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">Full Name</label>
                  <input
                    value={form.full_name}
                    onChange={(e) => set('full_name', e.target.value)}
                    maxLength={200}
                    placeholder="e.g. Priya Sharma"
                    className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">Job Title</label>
                  <input
                    value={form.job_title}
                    onChange={(e) => set('job_title', e.target.value)}
                    maxLength={200}
                    placeholder="e.g. Senior Piping Engineer"
                    className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
              </div>

              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Professional / Work Email *
                  </label>
                  <input
                    type="email"
                    value={form.work_email}
                    onChange={(e) => set('work_email', e.target.value)}
                    placeholder="you@company.com"
                    className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                  <p className="mt-1 text-[11px] text-muted-foreground">Used for verification only — never shown publicly.</p>
                </div>
                <div>
                  <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">Primary Discipline</label>
                  <select
                    value={form.discipline}
                    onChange={(e) => set('discipline', e.target.value)}
                    className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm focus:border-primary focus:outline-none"
                  >
                    <option value="">Select…</option>
                    {DISCIPLINES.map((d) => (
                      <option key={d.value} value={d.value}>{d.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="mt-4">
                <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">Software Usage Duration</label>
                <select
                  value={form.usage_duration}
                  onChange={(e) => set('usage_duration', e.target.value)}
                  className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm focus:border-primary focus:outline-none sm:max-w-xs"
                >
                  <option value="">Select…</option>
                  {DURATIONS.map((d) => (
                    <option key={d.value} value={d.value}>{d.label}</option>
                  ))}
                </select>
              </div>

              {/* Overall rating */}
              <div className="mt-4">
                <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">Overall Rating *</label>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => set('rating', s)}
                      className="text-2xl transition-transform hover:scale-110 active:scale-95"
                      aria-label={`Rate ${s} stars`}
                    >
                      <Star
                        className={`h-7 w-7 ${s <= form.rating ? 'fill-current text-amber-400' : 'text-border'}`}
                        strokeWidth={s <= form.rating ? 0 : 1.5}
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Pros & cons */}
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">Pros</label>
                  <textarea
                    value={form.pros}
                    onChange={(e) => set('pros', e.target.value)}
                    maxLength={2000}
                    rows={3}
                    placeholder="What works well for your engineering workflow?"
                    className="w-full resize-none rounded-lg border border-border bg-muted px-3 py-2.5 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">Technical Limitations</label>
                  <textarea
                    value={form.cons}
                    onChange={(e) => set('cons', e.target.value)}
                    maxLength={2000}
                    rows={3}
                    placeholder="What breaks, frustrates, or falls short?"
                    className="w-full resize-none rounded-lg border border-border bg-muted px-3 py-2.5 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
              </div>

              {/* Feature rating sliders */}
              <div className="mt-4 rounded-lg border border-border bg-muted/30 p-4">
                <p className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  <SlidersHorizontal className="h-3.5 w-3.5" /> Verified Feature Ratings (0 = not assessed)
                </p>
                <div className="mt-3 grid gap-4 sm:grid-cols-3">
                  <RatingSlider label="API" value={form.api_rating} onChange={(v) => set('api_rating', v)} />
                  <RatingSlider label="Stability" value={form.stability_rating} onChange={(v) => set('stability_rating', v)} />
                  <RatingSlider label="Pricing Transparency" value={form.pricing_transparency_rating} onChange={(v) => set('pricing_transparency_rating', v)} />
                </div>
              </div>

              {/* Optional headline / body */}
              <div className="mt-4">
                <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted-foreground">Headline (optional)</label>
                <input
                  value={form.title}
                  onChange={(e) => set('title', e.target.value)}
                  maxLength={200}
                  placeholder="e.g. 'Strong for CAD automation, weak documentation'"
                  className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>

              {/* Trust checkbox */}
              <label className="mt-4 flex cursor-pointer items-start gap-2.5 rounded-lg border border-border bg-muted/20 px-3 py-2.5">
                <input
                  type="checkbox"
                  checked={form.trust_confirmed}
                  onChange={(e) => set('trust_confirmed', e.target.checked)}
                  className="mt-0.5 h-4 w-4 accent-primary"
                />
                <span className="text-xs leading-relaxed text-muted-foreground">
                  I confirm this review is based on my actual workplace experience and I have no commercial affiliation
                  with this vendor.
                </span>
              </label>

              {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
              <div className="mt-4 flex gap-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-50"
                >
                  {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  {submitting ? 'Submitting...' : 'Submit Verified Review'}
                </button>
                <button
                  type="button"
                  onClick={() => { setShowForm(false); setError(''); }}
                  className="rounded-lg border border-border px-5 py-2.5 text-sm font-medium transition-colors hover:border-foreground"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* Reviews list / empty state */}
      {loading ? (
        <div className="mt-6 space-y-3">
          {[1, 2].map((i) => (
            <div key={i} className="h-24 animate-pulse rounded-xl border border-border bg-card" />
          ))}
        </div>
      ) : reviews.length === 0 ? (
        <div className="mt-8 rounded-xl border border-dashed border-border bg-muted/20 py-12 text-center">
          <MessageSquare className="mx-auto h-8 w-8 text-muted-foreground/60" />
          <p className="mt-3 font-display text-base font-semibold text-foreground">Community Ratings: Awaiting Verified Reviews</p>
          <p className="mt-1 text-sm text-muted-foreground">No approved peer reviews yet — submissions are moderated before publishing. No fabricated reviews or aggregate ratings.</p>
          {user && isVerified && !justSubmitted && !showForm && (
            <button
              onClick={() => setShowForm(true)}
              className="mt-4 rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
            >
              Submit a Verified Technical Review
            </button>
          )}
        </div>
      ) : (
        <div className="mt-5 space-y-4">
          {reviews.map((r) => <ReviewCard key={r.id} review={r} />)}
        </div>
      )}
    </div>
  );
}
