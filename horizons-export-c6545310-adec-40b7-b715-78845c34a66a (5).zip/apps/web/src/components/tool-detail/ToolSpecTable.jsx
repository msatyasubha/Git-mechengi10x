import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Copy, Check, FileCode2, ShieldAlert, Info } from 'lucide-react';
import { getToolSpec, AUTOMATION_LEVELS, VERIFIED_DATE } from '@/data/toolSpecs';

const TONE_STYLES = {
  green: 'border-green-500/30 bg-green-500/10 text-green-400',
  amber: 'border-amber-500/30 bg-amber-500/10 text-amber-400',
  muted: 'border-border bg-muted/40 text-muted-foreground',
};

function Row({ label, children }) {
  return (
    <div className="grid grid-cols-1 gap-1 border-b border-border/60 px-4 py-3 last:border-0 sm:grid-cols-[200px_1fr] sm:gap-4">
      <dt className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</dt>
      <dd className="text-sm text-foreground/90">{children}</dd>
    </div>
  );
}

function Tag({ children }) {
  return (
    <span className="inline-block rounded-md border border-border bg-muted/50 px-2 py-0.5 font-mono text-[11px] text-foreground/85">
      {children}
    </span>
  );
}

/* Category-aware illustrative automation scripts. Every example is explicitly a
   DRAFT — not production-ready — and points to the macro library / generator. */
function getSampleScript(tool) {
  const slug = tool.slug;
  const cat = tool.category;

  if (slug === 'solidworks') {
    return {
      language: 'VBA (SOLIDWORKS API)',
      code: `' DRAFT EXAMPLE — not production-ready. Verify against your
' SOLIDWORKS API version and run the QA checklist before use.
Sub ExportBomToCSV()
    Dim swApp As Object
    Dim swModel As Object
    Set swApp = Application.SldWorks
    Set swModel = swApp.ActiveDoc
    If swModel Is Nothing Then Exit Sub

    Dim swBomAnn As Object
    ' TODO: resolve the BOM table annotation from the drawing sheet
    ' swBomAnn.SaveAs "C:\\exports\\bom.csv", ...
    Debug.Print "BOM export placeholder for " & swModel.GetTitle
End Sub`,
    };
  }

  if (slug === 'freecad' || slug === 'fusion360') {
    return {
      language: 'Python',
      code: `# DRAFT EXAMPLE — not production-ready. Verify against your
# FreeCAD / Fusion 360 API version and run the QA checklist before use.
import FreeCAD  # or adsk.core for Fusion 360

def export_part_properties(doc_path, out_csv):
    """Read part custom properties and write a CSV row."""
    doc = FreeCAD.open(doc_path)
    rows = []
    for obj in doc.Objects:
        if hasattr(obj, "Shape") and obj.Shape is not None:
            rows.append({
                "label": obj.Label,
                "volume": round(obj.Shape.Volume, 3),
            })
    # TODO: write rows to out_csv with the csv module
    FreeCAD.closeDocument(doc.Name)
    return rows`,
    };
  }

  if (slug === 'onshape') {
    return {
      language: 'FeatureScript',
      code: `// DRAFT EXAMPLE — not production-ready. Verify against the current
// Onshape FeatureScript standard before use.
FeatureScript 2008;
import(path : "onshape/std/geometry.fs", version : "2008.0");

annotation { "Feature Type Name" : "BOM Property Extractor" }
export const myFeature = defineFeature(function(context is Context, id is Id) is Feature
{
    // TODO: iterate parts and write a custom property for downstream ERP export
    println("BOM property extractor placeholder");
});`,
    };
  }

  if (cat === 'cad') {
    return {
      language: 'Python (generic CAD API)',
      code: `# DRAFT EXAMPLE — not production-ready. Adapt to your CAD tool's
# documented API and run the QA checklist before use.
def collect_bom(root_assembly):
    """Walk an assembly tree and collect part metadata for ERP export."""
    bom = []
    for part in root_assembly.parts():
        bom.append({
            "part_number": part.get("part_number", "UNASSIGNED"),
            "quantity": part.quantity,
            "revision": part.get("revision", "-"),
        })
    # TODO: validate part numbers against ERP master before export
    return bom`,
    };
  }

  if (cat === 'simulation') {
    return {
      language: 'Python (solver scripting)',
      code: `# DRAFT EXAMPLE — not production-ready. Verify against your solver's
# scripting API (PyMAPDL, Abaqus Python, PyFoam, etc.) before use.
def run_parametric_sweep(base_case, parameters):
    """Submit a parametric sweep and collect peak stress per run."""
    results = []
    for params in parameters:
        job = base_case.copy_and_edit(params)
        job.submit(wait=True)
        results.append({
            "params": params,
            "peak_stress": job.read_peak_stress(),
        })
    # TODO: validate convergence and mesh quality before trusting results
    return results`,
    };
  }

  if (cat === 'automation') {
    return {
      language: 'JavaScript (n8n code node)',
      code: `// DRAFT EXAMPLE — not production-ready. Validate payload shapes and
// add error handling before deploying to production workflows.
const items = $input.all();
const bom = items.map((item) => ({
  part_number: item.json.part_number ?? 'UNASSIGNED',
  quantity: Number(item.json.quantity) || 0,
  revision: item.json.revision ?? '-',
}));
// TODO: post bom to ERP endpoint with auth + retry logic
return [{ json: { bom, count: bom.length } }];`,
    };
  }

  // Default: no tool-specific script is appropriate.
  return null;
}

function CodeBlock({ language, code }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* clipboard unavailable */
    }
  };
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-[#0F172A]">
      <div className="flex items-center justify-between border-b border-border bg-secondary/40 px-4 py-2">
        <span className="font-mono text-[10px] uppercase tracking-wider text-[#CBD5E1]">{language}</span>
        <button
          onClick={copy}
          className="inline-flex min-h-[36px] items-center gap-1.5 rounded-md border border-border px-2 py-1 font-mono text-[10px] text-[#CBD5E1] transition-colors hover:border-[#60A5FA] hover:text-[#93C5FD] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#60A5FA] focus-visible:outline-offset-2"
        >
          {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="overflow-x-auto px-4 py-4 text-[12px] leading-relaxed">
        <code className="font-mono text-[#F8FAFC]">{code}</code>
      </pre>
    </div>
  );
}

export function ToolSampleScript({ tool }) {
  const sample = getSampleScript(tool);
  if (!sample) return null;
  return (
    <section className="scroll-mt-24">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <h2 className="flex items-center gap-2 font-display text-lg font-bold sm:text-xl">
          <FileCode2 className="h-5 w-5 text-primary" /> Sample Automation Script
        </h2>
        <span className="inline-flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber-400">
          Draft — not production-ready
        </span>
      </div>
      <CodeBlock language={sample.language} code={sample.code} />
      <div className="mt-3 flex items-start gap-2 rounded-lg border border-border bg-muted/30 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
        <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
        <span>
          This is an illustrative draft for reference only — it is not tested or production-ready. Validate it
          against your tool&apos;s current API, run the{' '}
          <Link to="/macro-library" className="text-primary hover:underline">QA checklist</Link>, or{' '}
          <Link to="/macro-generator" className="text-primary hover:underline">generate a tailored macro</Link>.
        </span>
      </div>
    </section>
  );
}

export default function ToolSpecTable({ tool }) {
  const spec = getToolSpec(tool);
  if (!spec) return null;
  const level = AUTOMATION_LEVELS[spec.automation] || AUTOMATION_LEVELS.na;
  const bestFor = (tool.useCases || []).slice(0, 3);

  return (
    <section className="scroll-mt-24">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <h2 className="flex items-center gap-2 font-display text-lg font-bold sm:text-xl">
          <FileCode2 className="h-5 w-5 text-primary" /> Technical Specifications
        </h2>
        <span className="inline-flex items-center gap-1 rounded-full border border-green-500/30 bg-green-500/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-green-400">
          <Check className="h-3 w-3" /> {spec.verified ? VERIFIED_DATE : 'Not tool-verified'}
        </span>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <dl>
          <Row label="Supported File Formats">
            <div className="flex flex-wrap gap-1.5">
              {spec.formats.map((f, i) => (
                <Tag key={i}>{f}</Tag>
              ))}
            </div>
          </Row>
          <Row label="Scripting / API Access">
            <div className="flex flex-wrap gap-1.5">
              {spec.scripting.map((s, i) => (
                <Tag key={i}>{s}</Tag>
              ))}
            </div>
          </Row>
          <Row label="Platform & Deployment">{spec.platform}</Row>
          <Row label="Best Used For">
            {bestFor.length > 0 ? (
              <span>{bestFor.join(' · ')}</span>
            ) : (
              <span className="text-muted-foreground">See review below</span>
            )}
          </Row>
          <Row label="Automation Capability">
            <div className="flex flex-col gap-1.5">
              <span className={`inline-flex w-fit items-center rounded-full border px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider ${TONE_STYLES[level.tone]}`}>
                {level.label}
              </span>
              <span className="text-xs leading-relaxed text-muted-foreground">{level.basis}</span>
            </div>
          </Row>
          <Row label="Verification Date">{spec.verified ? VERIFIED_DATE : 'Pending — contact vendor to confirm'}</Row>
        </dl>
      </div>

      {!spec.verified && (
        <div className="mt-3 flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
          <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-400" />
          <span>
            Some specifications for {tool.name} are drawn from category-level defaults rather than a tool-specific
            audit. Confirm exact format and API support with the vendor before relying on them for integration.
          </span>
        </div>
      )}
    </section>
  );
}
