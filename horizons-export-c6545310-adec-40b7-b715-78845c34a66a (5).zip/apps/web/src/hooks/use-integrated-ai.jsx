import { useCallback, useEffect, useRef, useState } from 'react';
import { toast } from '@/hooks/use-toast';
import { integratedAiClient } from '@/lib/integratedAiClient';
import { pocketbaseClient } from '@/lib/pocketbaseClient';

const IMAGES_COLLECTION = '_integratedAiImages';
const FILE_PATH_RE = /\/api\/files\/[^/]+\/([^/?#]+)\/([^/?#]+)/;
const FILE_TOKEN_TTL_MS = 90_000;

let cachedFileToken = null;
let cachedFileTokenAt = 0;
let pendingFileToken = null;

async function getFileToken() {
	if (cachedFileToken && Date.now() - cachedFileTokenAt < FILE_TOKEN_TTL_MS) {
		return cachedFileToken;
	}

	if (!pendingFileToken) {
		pendingFileToken = (async () => {
			try {
				const token = await pocketbaseClient.files.getToken();
				cachedFileToken = token;
				cachedFileTokenAt = Date.now();

				return token;
			} finally {
				pendingFileToken = null;
			}
		})();
	}

	return pendingFileToken;
}

/**
 * Turns a stored image reference (origin-less path or full URL) into a token-signed URL.
 * Non-PocketBase references (e.g. blob: previews) are returned unchanged.
 *
 * @param {string} reference
 * @returns {Promise<string>}
 */
async function signImageUrl(reference) {
	if (!reference) {
		return reference;
	}

	const match = reference.match(FILE_PATH_RE);

	if (!match) {
		return reference;
	}

	const [, recordId, filename] = match;
	const token = await getFileToken();

	return pocketbaseClient.files.getURL(
		{ id: recordId, collectionName: IMAGES_COLLECTION },
		filename,
		{ token },
	);
}

/**
 * @typedef {object} TextContentBlock
 * @property {string} text
 * @property {'text'} type
 */

/**
 * @typedef {object} ImageContentBlock
 * @property {string} image
 * @property {'image'} type
 */

/**
 * @typedef {TextContentBlock | ImageContentBlock} ContentBlock
 */

/**
 * @typedef {object} SSEEventContent
 * @property {'content'} type
 * @property {{ content: string }} data
 * @property {{ agentName?: string }} [metadata]
 */

/**
 * @typedef {object} SSEEventToolUse
 * @property {'tool_use'} type
 * @property {{ toolId: string, toolName: string, inputParams: Record<string, any> }} data
 * @property {{ agentName?: string }} [metadata]
 */

/**
 * @typedef {object} SSEEventToolResult
 * @property {'tool_result'} type
 * @property {{ toolCallId: string, content: string }} data
 * @property {{ agentName?: string }} [metadata]
 */

/**
 * @typedef {SSEEventContent | SSEEventToolUse | SSEEventToolResult} SSEEventHistory
 */

/**
 * @typedef {object} HistoryMessage
 * @property {string} role
 * @property {string} content
 * @property {string[]} [images]
 * @property {Array<{ id: string, type: string, function: { name: string, arguments: string } }>} [tool_calls]
 * @property {string} [tool_call_id]
 * @property {string} [agent_name]
 */

const MessageRole = Object.freeze({
	User: 'user',
	Assistant: 'assistant',
	Tool: 'tool',
});

const ContentBlockType = Object.freeze({
	Text: 'text',
	Image: 'image',
});

const SSEEventType = Object.freeze({
	Content: 'content',
	Reasoning: 'reasoning',
	ToolUse: 'tool_use',
	ToolResult: 'tool_result',
	Usage: 'usage',
	Error: 'error',
	Done: 'done',
	Completed: 'completed',
});

/**
 * Extracts generated images from tool call results in the message history.
 *
 * @param {object} msg - The message to extract images from
 * @param {Array} history - The full message history
 * @returns {Array} Array of image URLs
 */
function extractGeneratedImages(msg, history) {
	const images = [];
	if (msg.role !== 'assistant') {
		return images;
	}

	const generateImageToolCall = msg.tool_calls?.find(toolCall => toolCall.function.name === 'generate_image');

	if (generateImageToolCall) {
		const generateImageToolCallResult = history.find(historyMessage => historyMessage.role === 'tool' && historyMessage.tool_call_id === generateImageToolCall.id)?.content;
		if (generateImageToolCallResult) {
			images.push(generateImageToolCallResult);
		}
	}

	return images;
}

/**
 * @param {{ message: ContentBlock[] }} params
 * @returns {HistoryMessage}
 */
function mapUserMessage({ message }) {
	const textParts = message.filter(b => b.type === ContentBlockType.Text).map(b => b.text);
	const images = message.filter(b => b.type === ContentBlockType.Image).map(b => b.image);

	return {
		role: MessageRole.User,
		content: textParts.join('\n'),
		...(images.length > 0 && { images }),
	};
}

/**
 * @param {{ message: SSEEventHistory[] }} params
 * @returns {HistoryMessage[]}
 */
function mapAssistantMessages({ message }) {
	/** @type {HistoryMessage[]} */
	const mapped = [];

	if (!Array.isArray(message)) {
		return mapped;
	}

	for (const event of message) {
		if (!event || typeof event !== 'object') continue;

		const agentName = event?.metadata?.agent_name;
		const data = event.data || {};

		if (event.type === SSEEventType.ToolResult) {
			mapped.push({
				role: MessageRole.Tool,
				tool_call_id: data.tool_call_id,
				content: data.content ?? '',
				...(agentName && { agent_name: agentName }),
			});
			continue;
		}

		mapped.push({
			role: MessageRole.Assistant,
			content: typeof data.content === 'string' ? data.content : '',
			...(event.type === SSEEventType.ToolUse && Array.isArray(data.tool_calls) && {
				tool_calls: data.tool_calls.map(toolCall => ({
					id: toolCall.id,
					type: 'function',
					function: {
						name: toolCall.name,
						arguments: JSON.stringify(toolCall.input),
					},
				})),
			}),
			...(agentName && { agent_name: agentName }),
		});
	}

	return mapped;
}

/**
 * Hook for streaming AI chat responses using fetch-based SSE.
 *
 * @example
 * const { messages, isStreaming, sendMessage } = useIntegratedAi();
 *
 * sendMessage('Tell me a joke');
 */
function useIntegratedAi() {
	const [messages, setMessages] = useState([]);
	const [isStreaming, setIsStreaming] = useState(false);
	const [isLoadingHistory, setIsLoadingHistory] = useState(true);
	const [lastError, setLastError] = useState(null);
	const abortControllerRef = useRef(null);
	const turnIdRef = useRef(0);

	useEffect(() => {
		async function loadHistory() {
			try {
				if (!pocketbaseClient.authStore.isValid) {
					setMessages([]);
					return;
				}

				const records = await pocketbaseClient.collection('_integratedAiMessages').getFullList({
					sort: 'created',
				});

				/** @type {HistoryMessage[]} */
				const historyMessages = [];

				for (const record of records) {
					const content = record.content;
					if (!content) continue;

					if (record.role === MessageRole.User) {
						const blocks = Array.isArray(content) ? content : [{ type: 'text', text: String(content) }];
						historyMessages.push(mapUserMessage({ message: blocks }));
						continue;
					}

					if (Array.isArray(content)) {
						historyMessages.push(...mapAssistantMessages({ message: content }));
					} else if (typeof content === 'string') {
						historyMessages.push({ role: MessageRole.Assistant, content });
					}
				}

				const chatMessages = await Promise.all(
					historyMessages
						.filter(msg => msg.role === 'user' || msg.role === 'assistant')
						.map(async (msg) => {
							const rawImages = [...(msg.images || []), ...extractGeneratedImages(msg, historyMessages)];
							const images = await Promise.all(rawImages.map(ref => signImageUrl(ref).catch(() => ref)));

							return {
								role: msg.role,
								content: typeof msg.content === 'string' ? msg.content : '',
								...(images.length > 0 && { images }),
							};
						}),
				);

				setMessages(chatMessages);
			} catch (err) {
				// History is optional — never block the chat composer on a load failure.
				console.warn('AI Advisor history load failed:', err?.message || err);
				setMessages([]);
			} finally {
				setIsLoadingHistory(false);
			}
		}

		loadHistory();
	}, []);

	const pendingContentRef = useRef('');
	const flushRafRef = useRef(0);

	useEffect(() => {
		return () => {
			if (abortControllerRef.current) {
				abortControllerRef.current.abort();
			}
			if (flushRafRef.current) {
				cancelAnimationFrame(flushRafRef.current);
				flushRafRef.current = 0;
			}
			pendingContentRef.current = '';
		};
	}, []);

	const flushPendingContent = useCallback(() => {
		flushRafRef.current = 0;
		const chunk = pendingContentRef.current;
		if (!chunk) return;
		pendingContentRef.current = '';

		setMessages((prev) => {
			const updated = [...prev];
			let lastIdx = updated.length - 1;
			// Prefer the trailing assistant placeholder; never append onto a user bubble.
			if (lastIdx < 0 || updated[lastIdx]?.role !== 'assistant') {
				updated.push({ role: 'assistant', content: chunk });
				return updated;
			}
			const last = updated[lastIdx];
			updated[lastIdx] = {
				...last,
				content: (last.content || '') + chunk,
			};
			return updated;
		});
	}, []);

	const queueContent = useCallback((text) => {
		if (!text) return;
		pendingContentRef.current += text;
		if (flushRafRef.current) return;
		// Coalesce many SSE tokens into one paint per frame — progressive text without flicker.
		flushRafRef.current = requestAnimationFrame(() => {
			flushPendingContent();
		});
	}, [flushPendingContent]);

	const handleSSEEvent = useCallback((parsed) => {
		const eventType = parsed?.type;
		const data = parsed?.data || {};

		// Content tokens: support both delta chunks and full nested payloads.
		if (eventType === SSEEventType.Content || eventType === 'message' || eventType === 'delta') {
			const piece =
				(typeof data.content === 'string' && data.content) ||
				(typeof data.delta === 'string' && data.delta) ||
				(typeof data.text === 'string' && data.text) ||
				(typeof parsed.content === 'string' && parsed.content) ||
				'';
			if (piece) {
				queueContent(piece);
			}
			return;
		}

		if (eventType === SSEEventType.ToolResult) {
			const toolName = data.tool_name || data.toolName;
			const content = data.content;
			const isImageResult = toolName === 'generate_image' && content;

			if (isImageResult) {
				// Flush any buffered text before attaching images so order stays correct.
				if (flushRafRef.current) {
					cancelAnimationFrame(flushRafRef.current);
					flushRafRef.current = 0;
				}
				flushPendingContent();

				const turn = turnIdRef.current;

				signImageUrl(content).then((signed) => {
					if (turnIdRef.current !== turn) {
						return;
					}

					setMessages((prev) => {
						const updated = [...prev];
						const last = updated[updated.length - 1];
						if (!last || last.role !== 'assistant') {
							updated.push({ role: 'assistant', content: '', images: [signed] });
							return updated;
						}
						updated[updated.length - 1] = {
							...last,
							images: [...(last.images || []), signed],
						};

						return updated;
					});
				}).catch(() => {
					// Signing failed; the image is persisted and will be re-signed on history reload.
				});
			}
		}
	}, [flushPendingContent, queueContent]);

	const sendMessage = useCallback(async (userMessage, images = []) => {
		setIsStreaming(true);
		setLastError(null);
		turnIdRef.current += 1;
		pendingContentRef.current = '';
		if (flushRafRef.current) {
			cancelAnimationFrame(flushRafRef.current);
			flushRafRef.current = 0;
		}

		const safeImages = Array.isArray(images) ? images : [];

		setMessages(prev => [
			...prev,
			{
				role: 'user',
				content: userMessage,
				...(safeImages.length > 0 && {
					images: safeImages.map(img => URL.createObjectURL(img)),
				}),
			},
			{ role: 'assistant', content: '' },
		]);

		const abortController = new AbortController();
		abortControllerRef.current = abortController;

		try {
			const response = await integratedAiClient.stream('/integrated-ai/stream', {
				body: { message: [{ text: userMessage, type: 'text' }] },
				signal: abortController.signal,
				images: safeImages,
			});

			const reader = response.body.getReader();
			const decoder = new TextDecoder();
			let buffer = '';

			while (true) {
				const { done, value } = await reader.read();

				if (done) {
					break;
				}

				buffer += decoder.decode(value, { stream: true });

				// SSE events are separated by blank lines; also tolerate lone \n "data:" lines.
				const events = buffer.split(/\n\n/);
				buffer = events.pop() || '';

				for (const event of events) {
					if (!event.trim()) {
						continue;
					}

					const lines = event.split('\n');
					let eventData = '';

					for (const line of lines) {
						if (line.startsWith('data:')) {
							eventData += line.slice(5).trimStart();
						}
					}

					if (!eventData || eventData === '[DONE]') {
						continue;
					}

					let parsed;
					try {
						parsed = JSON.parse(eventData);
					} catch {
						// Incomplete or non-JSON frame — skip.
						continue;
					}

					if (parsed.type === SSEEventType.Error) {
						const errMsg = parsed.data?.content || parsed.message || 'Advisor stream error';
						throw new Error(errMsg);
					}

					if (parsed.type === SSEEventType.Completed || parsed.type === SSEEventType.Done) {
						if (flushRafRef.current) {
							cancelAnimationFrame(flushRafRef.current);
							flushRafRef.current = 0;
						}
						flushPendingContent();
						return;
					}

					handleSSEEvent(parsed);
				}
			}

			// Stream ended without an explicit completed frame — flush leftovers.
			if (flushRafRef.current) {
				cancelAnimationFrame(flushRafRef.current);
				flushRafRef.current = 0;
			}
			flushPendingContent();
		} catch (err) {
			if (flushRafRef.current) {
				cancelAnimationFrame(flushRafRef.current);
				flushRafRef.current = 0;
			}
			// Keep any text already shown; only drop a still-empty placeholder.
			pendingContentRef.current = '';

			if (err.name === 'AbortError') {
				setMessages((prev) => {
					const updated = [...prev];
					const last = updated[updated.length - 1];
					if (last?.role === 'assistant' && !last.content) {
						updated.pop();
					}

					return updated;
				});

				return;
			}

			const friendly =
				err.status === 403
					? (err.message || 'Please verify your email to use the AI Advisor.')
					: err.status === 401
						? (err.message || 'Please sign in again to use the AI Advisor.')
						: (err.message && err.message !== 'Something went wrong!'
							? err.message
							: 'The AI Advisor is temporarily unavailable. Please try again in a moment.');

			setLastError({
				message: friendly,
				status: err.status,
				code: err.code,
			});

			toast({
				variant: 'destructive',
				title: 'Advisor unavailable',
				description: friendly,
			});

			setMessages((prev) => {
				const updated = [...prev];
				const last = updated[updated.length - 1];

				if (last?.role === 'assistant' && !last.content) {
					updated.pop();
				}

				return updated;
			});
		} finally {
			abortControllerRef.current = null;
			setIsStreaming(false);
		}
	}, [flushPendingContent, handleSSEEvent]);

	const clearMessages = useCallback(() => {
		setMessages([]);
		setLastError(null);
	}, []);

	const clearError = useCallback(() => setLastError(null), []);

	return {
		messages,
		isStreaming,
		isLoadingHistory,
		lastError,
		clearError,
		sendMessage,
		clearMessages,
	};
}

export default useIntegratedAi;
export { useIntegratedAi };
