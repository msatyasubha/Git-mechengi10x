import { useCallback, useEffect, useState } from 'react';
import pb from '@/lib/pocketbaseClient';
import { getStoredRef, clearStoredRef } from '@/lib/referral';

export function useAuth() {
    const [user, setUser] = useState(pb.authStore.record);

    useEffect(() => {
        const unsub = pb.authStore.onChange((_t, record) => setUser(record));
        return unsub;
    }, []);

    useEffect(() => {
        const refresh = () => {
            if (pb.authStore.isValid) {
                pb.collection('users')
                    .authRefresh()
                    .then((auth) => setUser(auth.record))
                    .catch(() => {});
            }
        };
        refresh();
        window.addEventListener('focus', refresh);
        return () => window.removeEventListener('focus', refresh);
    }, []);

    const login = useCallback(
        (email, password) => pb.collection('users').authWithPassword(email, password),
        [],
    );

    const signup = useCallback(async (email, password, name) => {
        const referred_by = getStoredRef();
        await pb.collection('users').create({
            email,
            password,
            passwordConfirm: password,
            name,
            ...(referred_by ? { referred_by } : {}),
        });
        clearStoredRef();
        return pb.collection('users').authWithPassword(email, password);
    }, []);

    const logout = useCallback(() => pb.authStore.clear(), []);

    return { user, isAuthed: pb.authStore.isValid && !!user, login, signup, logout };
}

export default useAuth;
