import { createContext, useContext, useEffect, useState, useCallback } from 'react';

// Display-currency preference for India-based visitors. This is a UI display
// toggle only (USD vs approximate INR conversion) — it stores nothing more
// than a local view preference, so localStorage is appropriate here.
const CurrencyContext = createContext({ currency: 'USD', setCurrency: () => {} });

const STORAGE_KEY = 'mechengi-currency';

export function CurrencyProvider({ children }) {
  const [currency, setCurrencyState] = useState(() => {
    if (typeof window === 'undefined') return 'USD';
    try {
      return localStorage.getItem(STORAGE_KEY) === 'INR' ? 'INR' : 'USD';
    } catch {
      return 'USD';
    }
  });

  const setCurrency = useCallback((next) => {
    setCurrencyState(next);
    try {
      localStorage.setItem(STORAGE_KEY, next);
    } catch {
      /* ignore */
    }
  }, []);

  const toggle = useCallback(() => {
    setCurrency(currency === 'INR' ? 'USD' : 'INR');
  }, [currency, setCurrency]);

  // Keep multiple tabs in sync.
  useEffect(() => {
    const onStorage = (e) => {
      if (e.key === STORAGE_KEY && (e.newValue === 'USD' || e.newValue === 'INR')) {
        setCurrencyState(e.newValue);
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  return (
    <CurrencyContext.Provider value={{ currency, setCurrency, toggle }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  return useContext(CurrencyContext);
}
