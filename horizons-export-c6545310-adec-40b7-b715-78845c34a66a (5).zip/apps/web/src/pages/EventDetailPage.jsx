import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams } from 'react-router-dom';
import { Calendar, Clock, Check, ArrowLeft, ArrowRight, Loader2, Send, Users, Video } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { getEventBySlug, events } from '@/data/events';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbaseClient';

const inputCls =
  'min-h-[44px] w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary';

function RegistrationForm({ ev }) {
  const { user, isAuthed } = useAuth();
  const [form, setForm] = useState({
    full_name: user?.name || '',
    email: user?.email || '',
    company: '',
    role: '',
    consent: true,
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const set = (k) => (e) => {
    const val = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm({ ...form, [k]: val });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await pb.collection('event_registrations').create({
        event_slug: ev.slug,
        event_title: ev.title,
        full_name: form.full_name,
        email: form.email,
        company: form.company,
        role: form.role,
        consent: form.consent,
        owner: user?.id || undefined,
      });
      setDone(true);
    } catch (err) {
      setError(err?.response?.message || err?.message || 'Registration failed. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
          <Check className="h-7 w-7 text-primary" />
        </div>
        <h3 className="mt-5 font-display text-xl font-bold">You're registered</h3>
        <p className="mx-auto mt-3 max-w-sm text-sm text-muted-foreground">
          We'll send a confirmation and reminders to <span className="text-foreground">{form.email}</span> — one week
          and one day before the event. Add it to your calendar below.
        </p>
        <Link to="/profile" className="mt-6 inline-block rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
          View your events
        </Link>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 sm:p-8">
      <h3 className="font-display text-xl font-bold">Register for this webinar</h3>
      <p className="mt-1 text-sm text-muted-foreground">Free to attend. Limited to {ev.capacity} seats.</p>

      {!isAuthed && (
        <p className="mt-4 rounded-lg border border-border bg-muted/30 p-3 text-xs text-muted-foreground">
          <Link to="/login" className="text-primary hover:underline">Sign in</Link> to track this event in your profile, or register as a guest below.
        </p>
      )}

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div className="flex flex-col gap-1.5">
          <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Full name *</label>
          <input required value={form.full_name} onChange={set('full_name')} className={inputCls} />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Email *</label>
          <input required type="email" value={form.email} onChange={set('email')} className={inputCls} />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Company</label>
          <input value={form.company} onChange={set('company')} className={inputCls} />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Role</label>
          <input value={form.role} onChange={set('role')} placeholder="e.g. Mechanical Engineer" className={inputCls} />
        </div>
      </div>

      <label className="mt-4 flex items-start gap-2 text-xs text-muted-foreground">
        <input type="checkbox" checked={form.consent} onChange={set('consent')} className="mt-0.5" />
        Send me event reminders and the MechEngi 10X weekly newsletter. I can unsubscribe anytime.
      </label>

      {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

      <button
        type="submit"
        disabled={busy}
        className="glow-primary mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60"
      >
        {busy ? <><Loader2 className="h-4 w-4 animate-spin" /> Registering…</> : <><Send className="h-4 w-4" /> Register free</>}
      </button>
    </form>
  );
}

export default function EventDetailPage() {
  const { slug } = useParams();
  const ev = getEventBySlug(slug);

  if (!ev) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet><title>Event not found — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
        <SiteHeader />
        <div className="mx-auto max-w-md px-5 py-32 text-center">
          <h1 className="font-display text-2xl font-bold">Event not found</h1>
          <Link to="/events" className="mt-4 inline-block text-primary hover:underline">← Back to events</Link>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const others = events.filter((e) => e.slug !== ev.slug).slice(0, 3);
  const eventEnd = new Date(`${ev.date}T${ev.time}:00Z`);
  const durationMinutes = Number.parseInt(ev.duration, 10);
  const finished = Number.isFinite(eventEnd.getTime()) && Number.isFinite(durationMinutes) && eventEnd.getTime() + durationMinutes * 60000 < Date.now();

  // Build a simple Google Calendar link
  const gcalText = `${ev.title} — MechEngi 10X Webinar`;
  const gcalUrl = `https://www.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(gcalText)}&dates=${ev.date.replace(/-/g, '')}T${ev.time.replace(':', '')}00/${ev.date.replace(/-/g, '')}T${String(Number(ev.time.split(':')[0]) + 1).padStart(2, '0')}${ev.time.split(':')[1]}00&details=${encodeURIComponent(ev.description)}`;

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{ev.title} — MechEngi 10X Webinar</title>
        <meta name="description" content={`Explore the ${ev.title} webinar topic. Check the listed date and availability; speaker and sponsor details are unverified.`} />
        {finished && <meta name="robots" content="noindex, follow" />}
        <link rel="canonical" href={`https://mechengi10x.com/events/${ev.slug}`} />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-12">
          <nav className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            <Link to="/events" className="hover:text-foreground">Events</Link>
            <span>/</span>
            <span className="text-foreground">{ev.title}</span>
          </nav>
          <div className="mt-6 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
            <div>
              <span className="inline-flex rounded-md border border-primary/30 bg-primary/10 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-primary">
                {ev.category}
              </span>
              <h1 className="mt-4 font-display text-3xl font-bold leading-tight sm:text-4xl">{ev.title}</h1>
              <p className="mt-4 max-w-xl text-lg text-muted-foreground">{ev.description}</p>
              <div className="mt-6 flex flex-wrap items-center gap-5 font-mono text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5"><Calendar className="h-4 w-4" /> {ev.date}</span>
                <span className="flex items-center gap-1.5"><Clock className="h-4 w-4" /> {ev.time} {ev.timezone} · {ev.duration}</span>
                <span className="flex items-center gap-1.5"><Users className="h-4 w-4" /> {ev.capacity} seats</span>
              </div>
              <div className="mt-6 rounded-xl border border-border bg-card p-4">
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Listed speaker — unverified</p>
                <p className="mt-1 font-display font-semibold">{ev.speaker}</p>
                <p className="text-sm text-muted-foreground">{ev.speakerRole}</p>
              </div>
            </div>

            <div>
              {finished ? (
                <div className="rounded-2xl border border-border bg-card p-6 text-sm leading-relaxed text-muted-foreground">
                  <p className="font-display text-lg font-semibold text-foreground">Listed date has passed</p>
                  <p className="mt-2">Registration is closed. This listing’s speaker and sponsor details have not been independently verified.</p>
                  <Link to="/events" className="mt-4 inline-block text-primary hover:underline">Browse webinar topics</Link>
                </div>
              ) : <RegistrationForm ev={ev} />}
              {!finished && <a
                href={gcalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 flex items-center justify-center gap-2 rounded-xl border border-border px-5 py-3 text-sm font-medium hover:border-primary/40 hover:text-primary"
              >
                <Calendar className="h-4 w-4" /> Add to Google Calendar
              </a>}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-5 py-12">
        <h2 className="font-display text-2xl font-bold">What you'll learn</h2>
        <ul className="mt-5 space-y-3">
          {ev.learningPoints.map((p) => (
            <li key={p} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4">
              <Check className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
              <span className="text-sm text-foreground/90">{p}</span>
            </li>
          ))}
        </ul>
        {ev.sponsor && (
          <div className="mt-8 rounded-xl border border-primary/30 bg-primary/5 p-5 text-center">
            <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Listed sponsor — unverified</p>
            <p className="mt-1 font-display text-lg font-bold">{ev.sponsor.name}</p>
          </div>
        )}
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-12">
        <h2 className="font-display text-2xl font-bold">More events</h2>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {others.map((o) => (
            <Link key={o.slug} to={`/events/${o.slug}`} className="group rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/40">
              <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{o.date} · {o.time}</p>
              <h3 className="mt-2 font-display font-semibold group-hover:text-primary">{o.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{o.description}</p>
            </Link>
          ))}
        </div>
        <div className="mt-8">
          <Link to="/events" className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-3.5 w-3.5" /> All events
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
