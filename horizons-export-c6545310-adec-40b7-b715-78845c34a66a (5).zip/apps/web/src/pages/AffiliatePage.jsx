import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { DollarSign, MousePointerClick, Users, TrendingUp, Loader2, LogIn, Copy, Check, Download } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbaseClient';

function makeCode(email) {
  if (!email) return '';
  const base = email.split('@')[0].replace(/[^a-z0-9]/gi, '').toLowerCase().slice(0, 6);
  return `ME10X-${base || 'eng'}-${Math.random().toString(36).slice(2, 6)}`.toUpperCase();
}

export default function AffiliatePage() {
  const { user, isAuthed } = useAuth();
  const [aff, setAff] = useState(null);
  const [clicks, setClicks] = useState([]);
  const [referrals, setReferrals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    async function load() {
      if (!isAuthed) {
        setLoading(false);
        return;
      }
      try {
        let records = await pb.collection('affiliates').getFullList({ sort: '-created' });
        let record = records[0];
        if (!record) {
          record = await pb.collection('affiliates').create({
            referral_code: makeCode(user?.email),
            status: 'active',
            total_clicks: 0,
            total_signups: 0,
            total_conversions: 0,
            pending_balance: 0,
            paid_out: 0,
            currency: 'USD',
            owner: user.id,
          });
        }
        setAff(record);
        const [c, r] = await Promise.all([
          pb.collection('affiliate_clicks').getFullList({ filter: `referral_code = "${record.referral_code}"`, sort: '-created' }).catch(() => []),
          pb.collection('referrals').getFullList({ sort: '-created' }).catch(() => []),
        ]);
        setClicks(c);
        setReferrals(r);
      } catch (err) {
        setError(err?.message || 'Could not load affiliate data.');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [isAuthed, user]);

  const link = aff ? `${window.location.origin}/?ref=${aff.referral_code}` : '';

  const copyLink = () => {
    navigator.clipboard?.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const exportCsv = () => {
    const rows = [['Date', 'Event', 'Status', 'Reward']];
    referrals.forEach((r) => rows.push([r.created, r.event_type, r.status, r.reward_amount || 0]));
    const csv = rows.map((row) => row.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'affiliate-earnings.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!isAuthed) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet>
          <title>Affiliate Dashboard — MechEngi 10X</title>
          <meta name="description" content="Earn commissions by referring engineers to MechEngi 10X premium courses and memberships. Track clicks, conversions, and payouts." />
          <meta name="robots" content="noindex, follow" />
        </Helmet>
        <SiteHeader />
        <div className="mx-auto max-w-md px-5 py-32 text-center">
          <LogIn className="mx-auto h-10 w-10 text-primary" />
          <h1 className="mt-4 font-display text-2xl font-bold">Sign in to your affiliate dashboard</h1>
          <div className="mt-6 flex justify-center gap-3">
            <Link to="/login" className="rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">Sign in</Link>
            <Link to="/signup" className="rounded-xl border border-border px-6 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">Create account</Link>
          </div>
        </div>
        <SiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Affiliate Dashboard — MechEngi 10X</title>
        <meta name="description" content="Earn commissions by referring engineers to MechEngi 10X premium courses and memberships. Track clicks, conversions, and payouts." />
        <meta name="robots" content="noindex, follow" />
      </Helmet>
      <SiteHeader />

      <div className="mx-auto max-w-[72rem] px-5 py-12">
        <div className="flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-primary" />
          <p className="font-mono text-xs uppercase tracking-wider text-primary">Affiliate Program</p>
        </div>
        <h1 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Affiliate Dashboard</h1>
        <p className="mt-2 max-w-xl text-sm text-muted-foreground">
          Earn 20% on every premium course sale and 30% on membership subscriptions you refer. Payouts monthly once you reach $50.
        </p>

        {loading ? (
          <div className="mt-10 flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading your affiliate data…
          </div>
        ) : error ? (
          <div className="mt-10 rounded-2xl border border-destructive/40 bg-destructive/10 p-6 text-sm text-destructive">{error}</div>
        ) : aff ? (
          <div className="mt-8 space-y-6">
            {/* Stats */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Stat icon={MousePointerClick} label="Total clicks" value={aff.total_clicks || clicks.length} />
              <Stat icon={Users} label="Signups" value={aff.total_signups || 0} />
              <Stat icon={TrendingUp} label="Conversions" value={aff.total_conversions || 0} />
              <Stat icon={DollarSign} label="Pending balance" value={`$${Number(aff.pending_balance || 0).toFixed(2)}`} />
            </div>

            {/* Referral link */}
            <div className="rounded-2xl border border-border bg-card p-6">
              <h2 className="font-display text-lg font-semibold">Your referral link</h2>
              <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                <input readOnly value={link} className="min-h-[44px] flex-1 rounded-md border border-input bg-background px-3 font-mono text-xs outline-none" />
                <button onClick={copyLink} className="flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
                  {copied ? <><Check className="h-4 w-4" /> Copied</> : <><Copy className="h-4 w-4" /> Copy</>}
                </button>
              </div>
              <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Code: {aff.referral_code}</p>
            </div>

            {/* Earnings breakdown */}
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="rounded-2xl border border-border bg-card p-5">
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Pending</p>
                <p className="mt-1 font-display text-2xl font-bold text-primary">${Number(aff.pending_balance || 0).toFixed(2)}</p>
              </div>
              <div className="rounded-2xl border border-border bg-card p-5">
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Paid out</p>
                <p className="mt-1 font-display text-2xl font-bold">${Number(aff.paid_out || 0).toFixed(2)}</p>
              </div>
              <div className="rounded-2xl border border-border bg-card p-5">
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Lifetime earnings</p>
                <p className="mt-1 font-display text-2xl font-bold">${(Number(aff.pending_balance || 0) + Number(aff.paid_out || 0)).toFixed(2)}</p>
              </div>
            </div>

            {/* Referral history */}
            <div className="rounded-2xl border border-border bg-card p-6">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-semibold">Referral history</h2>
                {referrals.length > 0 && (
                  <button onClick={exportCsv} className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-primary hover:underline">
                    <Download className="h-3.5 w-3.5" /> Export CSV
                  </button>
                )}
              </div>
              {referrals.length === 0 ? (
                <p className="mt-4 text-sm text-muted-foreground">No referrals yet. Share your link to start earning.</p>
              ) : (
                <div className="mt-4 space-y-2">
                  {referrals.map((r) => (
                    <div key={r.id} className="flex items-center justify-between rounded-xl border border-border bg-muted/30 p-3 text-sm">
                      <span className="capitalize">{r.event_type?.replace('_', ' ')}</span>
                      <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{r.status}</span>
                      <span className="font-display font-bold text-primary">${Number(r.reward_amount || 0).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <p className="text-xs text-muted-foreground">
              By participating you agree to our <Link to="/legal" className="text-primary hover:underline">terms</Link>. Commissions apply to paid courses and memberships only.
            </p>
          </div>
        ) : null}
      </div>

      <SiteFooter />
    </div>
  );
}

function Stat({ icon: Icon, label, value }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <Icon className="h-5 w-5 text-primary" />
      <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-2xl font-bold">{value}</p>
    </div>
  );
}
