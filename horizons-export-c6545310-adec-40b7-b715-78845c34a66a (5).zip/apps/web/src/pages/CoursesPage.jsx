import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Clock, ArrowRight, GraduationCap } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { courses } from '@/data/courses';

const categories = ['All', 'AI Tools', 'CAD', 'Simulation', 'Automation', 'Management'];

export default function CoursesPage() {
  const [cat, setCat] = useState('All');
  const filtered = cat === 'All' ? courses : courses.filter((c) => c.category === cat);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Premium Engineering Courses — MechEngi 10X</title>
        <meta name="description" content="Hands-on courses for mechanical engineers: AI tools, CAD productivity, FEA essentials, Python automation, and engineering project management." />
      </Helmet>

      <SiteHeader />

      {/* Hero */}
      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <GraduationCap className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Premium Courses</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            Learn the skills that 10X your engineering output
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            Explore proposed engineering course outlines. Course availability and launch dates are not confirmed; open a course to email your interest.
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`rounded-full border px-4 py-1.5 font-mono text-xs uppercase tracking-wider transition-colors ${
                cat === c ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-foreground/40 hover:text-foreground'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </section>

      {/* Course grid */}
      <section className="mx-auto max-w-[90rem] px-5 pb-20">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((c) => (
            <Link
              key={c.slug}
              to={`/courses/${c.slug}`}
              className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all hover:-translate-y-1 hover:border-primary/40"
            >
              <div className="relative h-40" style={{ background: c.cover }}>
                <span className="absolute left-4 top-4 flex h-10 w-10 items-center justify-center rounded-xl bg-background/80 text-xl backdrop-blur">
                  {c.icon}
                </span>
                <span className={`absolute right-4 top-4 rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider backdrop-blur ${c.accent}`}>
                  {c.category}
                </span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  <span>{c.level}</span>
                  <span>·</span>
                  <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {c.duration}</span>
                </div>
                <h2 className="mt-3 font-display text-lg font-bold leading-snug group-hover:text-primary">{c.title}</h2>
                <p className="mt-2 flex-1 text-sm text-muted-foreground line-clamp-2">{c.subtitle}</p>
                <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
                  <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                    <span>Course outline</span>
                  </div>
                  <span className="font-display text-lg font-bold text-primary">${c.price}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-2xl px-5 py-16 text-center">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">Not sure which course is right?</h2>
          <p className="mx-auto mt-3 max-w-md text-muted-foreground">
            Ask the AI Advisor for a personalized recommendation based on your role and goals.
          </p>
          <Link to="/advisor" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3 font-semibold text-primary-foreground hover:opacity-90">
            Ask the Advisor <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
