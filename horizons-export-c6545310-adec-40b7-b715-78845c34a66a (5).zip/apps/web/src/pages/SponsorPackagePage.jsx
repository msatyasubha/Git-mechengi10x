import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { Check, ArrowLeft, ArrowRight, Loader2, Send } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { getPackageById, sponsorshipPackages, budgetRanges } from '@/data/sponsorshipPackages';
import pb from '@/lib/pocketbaseClient';

function InquiryForm({ pkg }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    company_name: '',
    contact_name: '',
    email: '',
    phone: '',
    website: '',
    company_description: '',
    interested_packages: pkg ? pkg.name : '',
    budget_range: pkg ? `$${pkg.price.toLocaleString()} (${pkg.period})` : '',
    message: '',
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await pb.collection('sponsor_inquiries').create(form);
      setDone(true);
    } catch (err) {
      setError(err?.response?.message || err?.message || 'Submission failed. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
          <Check className="h-7 w-7 text-primary" />
        </div>
        <h3 className="mt-5 font-display text-xl font-bold">Inquiry received</h3>
        <p className="mx-auto mt-3 max-w-sm text-sm text-muted-foreground">
          Thanks, {form.contact_name || 'there'}. Our partnerships team will review your inquiry and reply to
          <span className="text-foreground"> {form.email}</span> as soon as we can.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link to="/sponsor" className="rounded-xl border border-border px-5 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">
            Back to sponsorship
          </Link>
          <Link to="/sponsor/dashboard" className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
            Sponsor dashboard
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 sm:p-8">
      <h3 className="font-display text-xl font-bold">Sponsorship inquiry</h3>
      <p className="mt-1 text-sm text-muted-foreground">Fill this in and we'll send a tailored proposal.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label="Company name *" >
          <input required value={form.company_name} onChange={set('company_name')} className={inputCls} />
        </Field>
        <Field label="Contact name *">
          <input required value={form.contact_name} onChange={set('contact_name')} className={inputCls} />
        </Field>
        <Field label="Work email *">
          <input required type="email" value={form.email} onChange={set('email')} className={inputCls} />
        </Field>
        <Field label="Phone">
          <input value={form.phone} onChange={set('phone')} className={inputCls} />
        </Field>
        <Field label="Website">
          <input type="url" placeholder="https://" value={form.website} onChange={set('website')} className={inputCls} />
        </Field>
        <Field label="Budget range">
          <select value={form.budget_range} onChange={set('budget_range')} className={inputCls}>
            <option value="">Select…</option>
            {budgetRanges.map((b) => (
              <option key={b} value={b}>{b}</option>
            ))}
          </select>
        </Field>
      </div>

      <div className="mt-4">
        <Field label="Interested package">
          <select value={form.interested_packages} onChange={set('interested_packages')} className={inputCls}>
            <option value="">Select a package…</option>
            {sponsorshipPackages.map((p) => (
              <option key={p.id} value={p.name}>{p.name}</option>
            ))}
          </select>
        </Field>
      </div>

      <div className="mt-4">
        <Field label="Company / tool description">
          <textarea rows={3} value={form.company_description} onChange={set('company_description')} className={`${inputCls} resize-none`} />
        </Field>
      </div>

      <div className="mt-4">
        <Field label="Message">
          <textarea rows={4} value={form.message} onChange={set('message')} placeholder="What are your goals? Timeline? Anything we should know." className={`${inputCls} resize-none`} />
        </Field>
      </div>

      {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

      <button
        type="submit"
        disabled={busy}
        className="glow-primary mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60"
      >
        {busy ? <><Loader2 className="h-4 w-4 animate-spin" /> Sending…</> : <><Send className="h-4 w-4" /> Submit inquiry</>}
      </button>
      <p className="mt-3 text-center font-mono text-[10px] text-muted-foreground">
        By submitting you agree to our <Link to="/sponsor/terms" className="text-primary hover:underline">sponsorship terms</Link>.
      </p>
    </form>
  );
}

const inputCls =
  'min-h-[44px] w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary';

function Field({ label, children }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}

export default function SponsorPackagePage() {
  const { slug } = useParams();
  const { pathname } = useLocation();
  const fromPath = pathname.split('/').filter(Boolean).pop();
  const pkg = getPackageById(slug || fromPath);

  if (!pkg) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet><title>Package not found — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
        <SiteHeader />
        <div className="mx-auto max-w-md px-5 py-32 text-center">
          <h1 className="font-display text-2xl font-bold">Package not found</h1>
          <Link to="/sponsor" className="mt-4 inline-block text-primary hover:underline">← Back to sponsorship</Link>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const others = sponsorshipPackages.filter((p) => p.id !== pkg.id);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{pkg.name} Sponsorship — MechEngi 10X</title>
        <meta name="description" content={pkg.summary} />
        <link rel="canonical" href={`https://mechengi10x.com/sponsor/${pkg.id}`} />
      </Helmet>

      <SiteHeader />

      {/* Breadcrumb + header */}
      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-12">
          <nav className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            <Link to="/sponsor" className="hover:text-foreground">Sponsorship</Link>
            <span>/</span>
            <span className="text-foreground">{pkg.name}</span>
          </nav>
          <div className="mt-6 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
            <div>
              <span className={`inline-flex rounded-md border px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider ${pkg.accent}`}>
                {pkg.name}
              </span>
              <h1 className="mt-4 font-display text-4xl font-bold leading-tight sm:text-5xl">{pkg.tagline}</h1>
              <p className="mt-5 max-w-xl text-lg text-muted-foreground">{pkg.summary}</p>
              <div className="mt-6 flex items-baseline gap-2">
                <span className="font-display text-4xl font-bold text-primary">${pkg.price.toLocaleString()}</span>
                <span className="text-sm text-muted-foreground">{pkg.period}</span>
              </div>
              <p className="mt-3 text-sm text-muted-foreground"><span className="text-foreground">Best for:</span> {pkg.bestFor}</p>
            </div>

            {/* ROI card */}
            <div className="rounded-2xl border border-border bg-card p-6">
              <h3 className="font-display font-semibold">Illustrative performance projection</h3>
              <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Indicative targets, not historical sponsor data</p>
              <div className="mt-5 space-y-4">
                {pkg.roi.map((r) => (
                  <div key={r.metric} className="flex items-center justify-between border-b border-border pb-3 last:border-0">
                    <span className="text-sm text-muted-foreground">{r.metric}</span>
                    <span className="font-display text-xl font-bold text-primary">{r.value}</span>
                  </div>
                ))}
              </div>
              <p className="mt-4 rounded-lg border border-border bg-muted/30 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
                These figures are illustrative projections of what a sponsorship could deliver, not measured results
                from past campaigns. Actual performance depends on your tool, creative, and audience fit.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Deliverables + benefits */}
      <section className="mx-auto max-w-[90rem] px-5 py-16">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-2xl font-bold">What's included</h2>
            <ul className="mt-5 space-y-3">
              {pkg.deliverables.map((d) => (
                <li key={d} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4">
                  <Check className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <span className="text-sm text-foreground/90">{d}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold">Why it works</h2>
            <ul className="mt-5 space-y-3">
              {pkg.benefits.map((b) => (
                <li key={b} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4">
                  <ArrowRight className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
                  <span className="text-sm text-foreground/90">{b}</span>
                </li>
              ))}
            </ul>
            <div className="mt-6 rounded-xl border border-primary/30 bg-primary/5 p-5">
              <p className="text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">Editorial independence:</span> Sponsorship buys
                placement and exposure — never a changed score or a guaranteed positive review.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Inquiry form */}
      <section className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-2xl px-5 py-16">
          <InquiryForm pkg={pkg} />
        </div>
      </section>

      {/* Other packages */}
      <section className="mx-auto max-w-[90rem] px-5 py-16">
        <h2 className="font-display text-2xl font-bold">Other packages</h2>
        <div className="mt-6 grid gap-6 md:grid-cols-2">
          {others.map((p) => (
            <Link key={p.id} to={`/sponsor/${p.id}`} className="flex items-center justify-between rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/40">
              <div>
                <span className={`inline-flex rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ${p.accent}`}>{p.name}</span>
                <p className="mt-2 font-display text-lg font-semibold">{p.tagline}</p>
                <p className="mt-1 text-sm text-muted-foreground">${p.price.toLocaleString()}{p.period}</p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground" />
            </Link>
          ))}
        </div>
        <div className="mt-8">
          <Link to="/sponsor" className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-3.5 w-3.5" /> All packages
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
