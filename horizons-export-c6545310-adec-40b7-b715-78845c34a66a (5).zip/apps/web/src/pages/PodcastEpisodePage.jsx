import { Helmet } from 'react-helmet';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Play, FileText, ArrowRight } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { getEpisodeBySlug, podcastEpisodes } from '@/data/podcast';

export default function PodcastEpisodePage() {
  const { slug } = useParams();
  const e = getEpisodeBySlug(slug);

  if (!e) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet><title>Episode not found — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
        <SiteHeader />
        <div className="mx-auto max-w-md px-5 py-32 text-center">
          <h1 className="font-display text-2xl font-bold">Episode not found</h1>
          <Link to="/podcast" className="mt-4 inline-block text-primary hover:underline">← Back to podcast</Link>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const others = podcastEpisodes.filter((x) => x.slug !== e.slug).slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{e.title} — Engineering Podcast Topic | MechEngi 10X</title>
        <meta name="description" content={`Explore ${e.title}, an engineering podcast topic outline. Audio and guest details are not verified on this site.`} />
        <meta name="robots" content="noindex, follow" />
        <link rel="canonical" href={`https://mechengi10x.com/podcast/${e.slug}`} />
      </Helmet>

      <SiteHeader />

      <div className="mx-auto max-w-3xl px-5 py-10">
        <Link to="/podcast" className="inline-flex items-center gap-1.5 font-mono text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" /> All episodes
        </Link>

        <div className="mt-6 flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
          <span>Topic {String(e.number).padStart(2, '0')}</span>
          <span>·</span>
          <span>{e.category}</span>
        </div>

        <h1 className="mt-3 font-display text-3xl font-bold leading-tight sm:text-4xl">{e.title}</h1>

        <div className="mt-6 rounded-2xl border border-border bg-card p-5 text-sm leading-relaxed text-muted-foreground">
          Audio is not available on this site. This page is a topic outline; the guest details, events and outcomes have not been independently verified.
        </div>

        <div className="mt-6 rounded-xl border border-border bg-muted/30 p-4">
          <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Listed guest — unverified</p>
          <p className="mt-1 font-display font-semibold">{e.guest}</p>
          <p className="text-sm text-muted-foreground">{e.guestRole}</p>
        </div>

        <div className="mt-8">
          <h2 className="font-display text-xl font-bold">Show notes</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{e.description}</p>
        </div>

        <div className="mt-8 rounded-2xl border border-border bg-card p-6">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            <h2 className="font-display text-lg font-semibold">Topic outline</h2>
          </div>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{e.transcript}</p>
        </div>


      </div>

      <section className="mx-auto max-w-3xl px-5 py-10">
        <h2 className="font-display text-xl font-bold">More episodes</h2>
        <div className="mt-4 space-y-3">
          {others.map((o) => (
            <Link key={o.slug} to={`/podcast/${o.slug}`} className="group flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40">
              <Play className="h-5 w-5 shrink-0 text-primary/60" />
              <div className="min-w-0 flex-1">
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Topic {String(o.number).padStart(2, '0')}</p>
                <p className="truncate font-display font-semibold group-hover:text-primary">{o.title}</p>
              </div>
              <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground" />
            </Link>
          ))}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
