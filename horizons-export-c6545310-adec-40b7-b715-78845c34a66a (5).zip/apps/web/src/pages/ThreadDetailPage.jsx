import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2, Reply, Trash2, LogIn, MessageSquare, Pin } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbaseClient';

const catBadge = {
  general: 'badge-management',
  'ai-tools': 'badge-ai',
  cad: 'badge-cad',
  simulation: 'badge-simulation',
  automation: 'badge-automation',
  management: 'badge-management',
  jobs: 'badge-learning',
  courses: 'badge-learning',
};

function timeAgo(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const s = Math.floor((Date.now() - d.getTime()) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  if (s < 604800) return `${Math.floor(s / 86400)}d ago`;
  return d.toLocaleDateString();
}

export default function ThreadDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAuthed, user } = useAuth();
  const [thread, setThread] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [draft, setDraft] = useState('');
  const [busy, setBusy] = useState(false);

  async function loadAll() {
    setLoading(true);
    try {
      const t = await pb.collection('forum_threads').getOne(id, { expand: 'owner' });
      setThread(t);
      const p = await pb.collection('forum_posts').getFullList({
        filter: `thread = "${id}"`,
        sort: 'created',
        expand: 'owner',
      });
      setPosts(p);
      // Increment views once
      pb.collection('forum_threads').update(id, { views: (t.views || 0) + 1 }).catch(() => {});
    } catch (err) {
      setError(err?.message || 'Thread not found.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const submitReply = async (e) => {
    e.preventDefault();
    if (!draft.trim()) return;
    setBusy(true);
    try {
      const rec = await pb.collection('forum_posts').create({
        body: draft.trim(),
        thread: id,
        owner: user.id,
      }, { expand: 'owner' });
      setPosts((prev) => [...prev, { ...rec, expand: { owner: user } }]);
      setDraft('');
    } catch (err) {
      setError(err?.response?.message || err?.message || 'Could not post reply.');
    } finally {
      setBusy(false);
    }
  };

  const deleteThread = async () => {
    if (!confirm('Delete this thread and all replies?')) return;
    try {
      await pb.collection('forum_threads').delete(id);
      navigate('/forum');
    } catch (err) {
      setError(err?.message || 'Could not delete thread.');
    }
  };

  const deletePost = async (postId) => {
    if (!confirm('Delete this reply?')) return;
    try {
      await pb.collection('forum_posts').delete(postId);
      setPosts((prev) => prev.filter((p) => p.id !== postId));
    } catch (err) {
      setError(err?.message || 'Could not delete reply.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <SiteHeader />
        <div className="flex items-center gap-2 px-5 py-20 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading thread…
        </div>
        <SiteFooter />
      </div>
    );
  }

  if (error || !thread) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet><title>Thread unavailable — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
        <SiteHeader />
        <div className="mx-auto max-w-md px-5 py-32 text-center">
          <h1 className="font-display text-2xl font-bold">{error || 'Thread not found'}</h1>
          <Link to="/forum" className="mt-4 inline-block text-primary hover:underline">← Back to forum</Link>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const isOwner = user && thread.owner === user.id;

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{thread.title} — MechEngi 10X Forum</title>
        <meta name="description" content={thread.body.slice(0, 155)} />
        <link rel="canonical" href={`https://mechengi10x.com/forum/${thread.id}`} />
      </Helmet>

      <SiteHeader />

      <div className="mx-auto max-w-3xl px-5 py-10">
        <Link to="/forum" className="inline-flex items-center gap-1.5 font-mono text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" /> All threads
        </Link>

        {/* Thread */}
        <article className="mt-6 rounded-2xl border border-border bg-card p-6">
          <div className="flex items-center gap-2">
            {thread.pinned && <Pin className="h-4 w-4 text-accent" />}
            {thread.category && <span className={`rounded border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ${catBadge[thread.category] || 'badge-management'}`}>{thread.category}</span>}
          </div>
          <h1 className="mt-3 font-display text-2xl font-bold sm:text-3xl">{thread.title}</h1>
          <div className="mt-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-primary">
              {(thread.expand?.owner?.name || thread.expand?.owner?.email || 'A')[0].toUpperCase()}
            </span>
            <span>{thread.expand?.owner?.name || thread.expand?.owner?.email || 'engineer'}</span>
            <span>· {timeAgo(thread.created)}</span>
          </div>
          <div className="mt-5 whitespace-pre-wrap text-sm leading-relaxed text-foreground/90">{thread.body}</div>
          {isOwner && (
            <div className="mt-6 border-t border-border pt-4">
              <button onClick={deleteThread} className="inline-flex items-center gap-1.5 text-xs text-destructive hover:underline">
                <Trash2 className="h-3.5 w-3.5" /> Delete thread
              </button>
            </div>
          )}
        </article>

        {/* Replies */}
        <div className="mt-8">
          <h2 className="font-display text-lg font-semibold">{posts.length} {posts.length === 1 ? 'reply' : 'replies'}</h2>

          {posts.length === 0 ? (
            <div className="mt-4 rounded-2xl border border-border bg-card p-8 text-center">
              <MessageSquare className="mx-auto h-8 w-8 text-muted-foreground" />
              <p className="mt-3 text-sm text-muted-foreground">No replies yet. Be the first to respond.</p>
            </div>
          ) : (
            <div className="mt-4 space-y-3">
              {posts.map((p) => (
                <div key={p.id} className="rounded-2xl border border-border bg-card p-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                      <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-primary">
                        {(p.expand?.owner?.name || p.expand?.owner?.email || 'A')[0].toUpperCase()}
                      </span>
                      <span>{p.expand?.owner?.name || p.expand?.owner?.email || 'engineer'}</span>
                      <span>· {timeAgo(p.created)}</span>
                    </div>
                    {user && p.owner === user.id && (
                      <button onClick={() => deletePost(p.id)} className="text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                  <div className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-foreground/90">{p.body}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Reply box */}
        <div className="mt-8">
          {isAuthed ? (
            <form onSubmit={submitReply} className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Your reply</h3>
              <textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                rows={4}
                maxLength={5000}
                placeholder="Share your thoughts…"
                className="mt-3 w-full resize-none rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
              {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
              <button
                type="submit"
                disabled={busy || !draft.trim()}
                className="mt-3 flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-60"
              >
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Reply className="h-4 w-4" />} Post reply
              </button>
            </form>
          ) : (
            <div className="rounded-2xl border border-border bg-card p-6 text-center">
              <LogIn className="mx-auto h-8 w-8 text-primary" />
              <p className="mt-3 text-sm text-muted-foreground">Sign in to join the discussion.</p>
              <div className="mt-4 flex justify-center gap-3">
                <Link to="/login" className="rounded-xl bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90">Sign in</Link>
                <Link to="/signup" className="rounded-xl border border-border px-5 py-2 text-sm font-medium hover:border-primary/40 hover:text-primary">Create account</Link>
              </div>
            </div>
          )}
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
