import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { TrendingUp, ArrowRight, FileText, Download } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { caseStudies, caseStudyCategories, getCaseStudiesByCategory } from '@/data/caseStudies';

export default function CaseStudiesPage() {
  const [cat, setCat] = useState('all');
  const filtered = getCaseStudiesByCategory(cat);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Case Studies & Workflow Examples | MechEngi 10X</title>
        <meta name="description" content="Explore engineering workflow examples involving CAD, simulation, AI and automation. Reported results and ROI figures are not independently verified." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <TrendingUp className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Case Studies</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            Engineering workflows and ROI examples
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            Explore examples involving AI, CAD, simulation, and automation. The named teams, quotations,
            results and ROI figures have not been independently verified; do not treat them as endorsements or benchmarks.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="flex flex-wrap gap-2">
          {caseStudyCategories.map((c) => (
            <button
              key={c.id}
              onClick={() => setCat(c.id)}
              className={`rounded-full border px-4 py-1.5 font-mono text-xs uppercase tracking-wider transition-colors ${
                cat === c.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-foreground/40 hover:text-foreground'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 pb-20">
        <div className="grid gap-6 md:grid-cols-2">
          {filtered.map((cs) => (
            <Link
              key={cs.slug}
              to={`/case-studies/${cs.slug}`}
              className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all hover:-translate-y-1 hover:border-primary/40"
            >
              <div className="relative h-36" style={{ background: cs.cover }}>
                <span className="absolute left-4 top-4 rounded-md border border-white/20 bg-background/70 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider backdrop-blur">
                  {cs.industry}
                </span>
                <span className="absolute right-4 top-4 flex items-center gap-1 rounded-md bg-background/70 px-2 py-1 font-mono text-[10px] uppercase tracking-wider backdrop-blur">
                  <FileText className="h-3 w-3" /> {cs.readTime} min
                </span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <p className="font-mono text-[10px] uppercase tracking-wider text-primary">{cs.client} · {cs.tool}</p>
                <h2 className="mt-2 font-display text-lg font-bold leading-snug group-hover:text-primary">{cs.title}</h2>
                <p className="mt-2 flex-1 text-sm text-muted-foreground line-clamp-3">{cs.challenge}</p>
                <div className="mt-4 grid grid-cols-2 gap-2 border-t border-border pt-4">
                  {cs.results.slice(0, 2).map((r) => (
                    <div key={r.metric}>
                      <p className="font-display text-lg font-bold text-primary">{r.value}</p>
                      <p className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">{r.metric}</p>
                    </div>
                  ))}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-2xl px-5 py-16 text-center">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">Want a case study on your tool?</h2>
          <p className="mx-auto mt-3 max-w-md text-muted-foreground">
            Exclusive Review sponsors get a deep, independent case study. Ask the AI Advisor if it fits your goals.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link to="/sponsor/exclusive-review" className="glow-primary inline-flex items-center gap-2 rounded-xl bg-primary px-2 py-3 font-semibold text-primary-foreground hover:opacity-90">
              Explore Exclusive Review <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/advisor" className="rounded-xl border border-border px-7 py-3 font-semibold hover:border-primary/40 hover:text-primary">
              Ask the Advisor
            </Link>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
