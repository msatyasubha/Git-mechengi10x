import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Workflow, Copy, Check, AlertTriangle, ListChecks, Wrench, ArrowRight } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

/* ── Copy-to-clipboard code block with language tabs ─────────────────── */
function CodeBlock({ tabs, label }) {
  const [active, setActive] = useState(Object.keys(tabs)[0]);
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(tabs[active].code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // clipboard may be blocked; ignore
    }
  };

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-[#0F172A]">
      <div className="flex items-center justify-between border-b border-slate-700/60 bg-[#0F172A] px-3 py-2">
        <div className="flex gap-1">
          {Object.entries(tabs).map(([key, t]) => (
            <button
              key={key}
              onClick={() => setActive(key)}
              className={`rounded-md px-3 py-1 font-mono text-[11px] uppercase tracking-wider transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#60A5FA] focus-visible:outline-offset-2 ${
                active === key
                  ? 'bg-slate-700 text-[#93C5FD]'
                  : 'text-[#CBD5E1] hover:text-[#F8FAFC]'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <button
          onClick={copy}
          className="flex items-center gap-1.5 rounded-md border border-slate-700 px-2.5 py-1 font-mono text-[11px] text-[#CBD5E1] transition-colors hover:border-[#60A5FA] hover:text-[#93C5FD] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#60A5FA] focus-visible:outline-offset-2"
          aria-label={`Copy ${label} code`}
        >
          {copied ? <Check className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="overflow-x-auto p-4 text-[12px] leading-relaxed">
        <code className="font-mono text-[#F8FAFC]">{tabs[active].code}</code>
      </pre>
    </div>
  );
}

const DISCLAIMER =
  'Automation rules verify formatting and CAD compliance; they do not replace licensed professional engineering design verification.';

const WORKFLOWS = [
  {
    id: 'cad-drawing-qa',
    icon: Wrench,
    badgeClass: 'cad',
    category: 'CAD Automation & Drawing QA',
    title: 'Automated SOLIDWORKS Drawing QA Check',
    problem:
      'Manual 2D drawing reviews consume 15–20 minutes per sheet and miss dangling dimensions or unconstrained sketch states. (This figure is user-provided illustrative context, not a measured benchmark.)',
    tools: ['SOLIDWORKS', 'VBA Macro Engine', 'JSON Rule Engine'],
    checkpoints: [
      'Zero dangling dimensions',
      'Title block attributes populated',
      'Sheet scale verified',
    ],
    code: {
      vba: {
        label: 'VBA',
        code: `' ILLUSTRATIVE DRAFT — not production-ready.
' Scans drawing views, verifies sheet scale, and logs
' unconstrained sketch entities to a JSON file.
' Requires the SOLIDWORKS type library. Test on a copy
' before any production use.

Sub AuditDrawingQA()
    Dim swApp As Object
    Dim swModel As Object
    Dim swDraw As Object
    Dim vSheetName As Variant
    Dim i As Integer
    Dim issues As String
    issues = "["

    Set swApp = Application.SldWorks
    Set swModel = swApp.ActiveDoc
    If swModel Is Nothing Then Exit Sub
    If swModel.GetType <> 3 Then Exit Sub ' swDocDRAWING

    Set swDraw = swModel
    vSheetName = swDraw.GetSheetNames

    For i = 0 To UBound(vSheetName)
        Dim swSheet As Object
        Set swSheet = swDraw.Sheet(vSheetName(i))

        ' 1. Verify sheet scale
        Dim scaleStr As String
        scaleStr = swSheet.Scale
        If InStr(scaleStr, "1:1") = 0 Then
            issues = issues & "{""sheet"":""" & vSheetName(i) & _
                     """,""issue"":""non-1:1 scale: " & scaleStr & """},"
        End If

        ' 2. Check title block attributes
        Dim vViews As Variant
        vViews = swSheet.GetViews
        ' (attribute-population check omitted for brevity)

        ' 3. Flag unconstrained sketch entities
        ' (traverse sketch relations; log dangling dims)
    Next i

    If Right(issues, 1) = "," Then issues = Left(issues, Len(issues) - 1)
    issues = issues & "]"

    ' Write JSON report
    Dim f As Integer
    f = FreeFile
    Open "C:\\Temp\\drawing_qa_report.json" For Output As #f
    Print #f, issues
    Close #f
End Sub`,
      },
    },
  },
  {
    id: 'cad-to-erp-bom',
    icon: Workflow,
    badgeClass: 'automation',
    category: 'CAD-to-ERP BOM Integration',
    title: 'n8n Webhook Pipeline for BOM Data Extraction',
    problem:
      'Re-keying CAD Bill of Materials (BOM) into ERP systems causes inventory errors and order delays. (Illustrative context supplied by the requester; not a measured error rate.)',
    tools: ['SOLIDWORKS PDM / Onshape API', 'n8n', 'REST API Webhook'],
    checkpoints: [
      'BOM line items map 1:1 to ERP part records',
      'Revision and quantity validated before insert',
      'Failed rows logged for review',
    ],
    code: {
      json: {
        label: 'JSON',
        code: `{
  "name": "BOM to ERP Pipeline",
  "nodes": [
    {
      "name": "Webhook (BOM Payload)",
      "type": "n8n-nodes-base.webhook",
      "parameters": {
        "path": "bom-ingest",
        "httpMethod": "POST"
      }
    },
    {
      "name": "Validate Line Items",
      "type": "n8n-nodes-base.function",
      "parameters": {
        "functionCode": "const rows = items[0].json.lineItems || []; return rows.map(r => ({ json: { partNumber: r.partNumber, revision: r.revision, qty: r.qty, description: r.description } }));"
      }
    },
    {
      "name": "POST to ERP",
      "type": "n8n-nodes-base.httpRequest",
      "parameters": {
        "method": "POST",
        "url": "https://erp.example.com/api/bom",
        "authentication": "headerAuth"
      }
    }
  ],
  "connections": {
    "Webhook (BOM Payload)": { "main": [[{ "node": "Validate Line Items", "type": "main", "index": 0 }]] },
    "Validate Line Items": { "main": [[{ "node": "POST to ERP", "type": "main", "index": 0 }]] }
  }
}`,
      },
    },
  },
  {
    id: 'fea-mesh-convergence',
    icon: ListChecks,
    badgeClass: 'simulation',
    category: 'FEA & Simulation Quality Control',
    title: 'Mesh Convergence & Solver Audit Checklist',
    problem:
      'Inconsistent meshing parameters produce divergent stress values in FEA reports. (Illustrative context; not a measured divergence rate.)',
    tools: ['OpenFOAM', 'CalculiX', 'ANSYS'],
    checkpoints: [
      'Mesh refined until result change < 5% between iterations',
      'Element quality metrics above solver threshold',
      'Boundary conditions and material properties documented',
    ],
    code: {
      python: {
        label: 'Python',
        code: `# ILLUSTRATIVE DRAFT — not production-ready.
# Skeleton for a mesh-convergence audit report generator.
# Run and validate against your own solver output before use.

import json
from pathlib import Path

def convergence_report(runs):
    """runs: list of dicts with mesh_density and max_stress."""
    deltas = []
    for a, b in zip(runs, runs[1:]):
        change = abs(b["max_stress"] - a["max_stress"]) / a["max_stress"]
        deltas.append(change)
    converged = deltas and deltas[-1] < 0.05
    return {
        "iterations": len(runs),
        "delta_between_last_two": deltas[-1] if deltas else None,
        "converged": converged,
        "note": "Draft check only — verify against certified solver output.",
    }

if __name__ == "__main__":
    sample = [
        {"mesh_density": "coarse", "max_stress": 210.0},
        {"mesh_density": "medium", "max_stress": 198.0},
        {"mesh_density": "fine",   "max_stress": 196.5},
    ]
    report = convergence_report(sample)
    Path("mesh_convergence_report.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))`,
      },
    },
  },
];

export default function WorkflowsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Workflow Library & Automation Templates — MechEngi 10X</title>
        <meta name="description" content="Copyable engineering automation workflows: SOLIDWORKS drawing QA, CAD-to-ERP BOM integration via n8n, and FEA mesh convergence auditing. Illustrative drafts with clear safety limits." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Workflow className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Workflow Library</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-3xl font-bold leading-tight sm:text-4xl md:text-5xl">
            Engineering Workflow Library &amp; Automation Templates
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            Copyable, developer-focused automation templates for the three highest-friction engineering workflows:
            drawing QA, CAD-to-ERP BOM handoff, and FEA mesh convergence. Every snippet is an illustrative draft — test
            on a copy before any production use.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
        <div className="space-y-12">
          {WORKFLOWS.map((wf) => {
            const Icon = wf.icon;
            return (
              <article key={wf.id} className="rounded-2xl border border-border bg-card p-6 sm:p-8">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="min-w-0">
                    <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${wf.badgeClass}`}>
                      {wf.category}
                    </span>
                    <h2 className="mt-2 font-display text-xl font-bold sm:text-2xl">{wf.title}</h2>
                  </div>
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" />
                  </span>
                </div>

                <div className="mt-5 grid gap-6 lg:grid-cols-[1fr_1.2fr]">
                  <div className="space-y-5">
                    <div>
                      <h3 className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Problem</h3>
                      <p className="mt-1.5 text-sm leading-relaxed text-foreground/85">{wf.problem}</p>
                    </div>
                    <div>
                      <h3 className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Required Tools</h3>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {wf.tools.map((t) => (
                          <span key={t} className="rounded-lg border border-border bg-muted/40 px-2.5 py-1 text-xs text-foreground/85">{t}</span>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Validation Checkpoints</h3>
                      <ul className="mt-2 space-y-1.5">
                        {wf.checkpoints.map((c) => (
                          <li key={c} className="flex items-start gap-2 text-sm">
                            <Check className="mt-0.5 h-4 w-4 shrink-0 text-green-400" />
                            <span className="text-foreground/85">{c}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div>
                    <CodeBlock tabs={wf.code} label={wf.title} />
                  </div>
                </div>

                <div className="mt-5 flex items-start gap-2.5 rounded-xl border border-amber-500/25 bg-amber-500/5 px-4 py-3">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    <span className="font-semibold text-foreground">Disclaimer: </span>
                    {DISCLAIMER} These templates are illustrative drafts, not production-ready code, and have not been
                    validated against the named checks unless you run and test them yourself.
                  </p>
                </div>
              </article>
            );
          })}
        </div>

        {/* AI Drawing QA & GD&T guide CTA */}
        <div className="mt-12 overflow-hidden rounded-2xl border border-primary/25 bg-primary/5 p-6 sm:p-8">
          <div className="flex items-center gap-2">
            <Workflow className="h-5 w-5 text-primary" />
            <span className="font-mono text-[10px] uppercase tracking-widest text-primary">Technical Workflow Guide</span>
          </div>
          <h2 className="mt-3 font-display text-xl font-bold sm:text-2xl">
            AI-Assisted Drawing Review &amp; GD&amp;T Verification
          </h2>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
            A conceptual reference pipeline combining CAD/DWG extraction, a Python GD&amp;T rule engine, and a
            vision-capable multimodal LLM to assist 2D drawing QA — dimension constraints, title-block attributes,
            and GD&amp;T callouts. Illustrative architecture and verification questions, not a shipped or
            validated integration.
          </p>
          <Link
            to="/workflows/ai-drawing-qa-gdt"
            className="mt-4 inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
          >
            Explore the GD&amp;T QA workflow <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-12 rounded-2xl border border-border bg-card p-6 text-center">
          <h2 className="font-display text-lg font-bold">Need a workflow tailored to your stack?</h2>
          <p className="mx-auto mt-2 max-w-xl text-sm text-muted-foreground">
            Our team builds custom CAD automation and CAD-to-ERP integration workflows for engineering teams.
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-3">
            <Link
              to="/workflows/solidworks-bom-n8n"
              className="inline-flex items-center gap-2 rounded-xl border border-primary/40 bg-primary/10 px-5 py-2.5 text-sm font-semibold text-primary transition-all hover:bg-primary/20 active:scale-[0.98]"
            >
              SOLIDWORKS BOM → n8n → Excel QA <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/erp-integration"
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
            >
              Explore CAD-to-ERP consulting <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
