import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Calculator, Ruler, Layers, Zap, ArrowRight, ExternalLink } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { freeTools } from '@/data/tools';
import ToolCard from '@/components/ToolCard';

// ── Simple Unit Converter (working) ──────────────────
const CONVERSIONS = {
  Length: [
    { label: 'mm → in', fn: (v) => v / 25.4, unit: 'in' },
    { label: 'in → mm', fn: (v) => v * 25.4, unit: 'mm' },
    { label: 'm → ft', fn: (v) => v * 3.28084, unit: 'ft' },
    { label: 'ft → m', fn: (v) => v / 3.28084, unit: 'm' },
    { label: 'km → mi', fn: (v) => v * 0.621371, unit: 'mi' },
  ],
  Pressure: [
    { label: 'kPa → psi', fn: (v) => v * 0.145038, unit: 'psi' },
    { label: 'psi → kPa', fn: (v) => v / 0.145038, unit: 'kPa' },
    { label: 'bar → psi', fn: (v) => v * 14.5038, unit: 'psi' },
    { label: 'MPa → ksi', fn: (v) => v * 0.145038, unit: 'ksi' },
    { label: 'Pa → psi', fn: (v) => v * 0.000145038, unit: 'psi' },
  ],
  Force: [
    { label: 'N → lbf', fn: (v) => v * 0.224809, unit: 'lbf' },
    { label: 'lbf → N', fn: (v) => v / 0.224809, unit: 'N' },
    { label: 'kN → kip', fn: (v) => v * 0.224809, unit: 'kip' },
    { label: 'N → kgf', fn: (v) => v / 9.80665, unit: 'kgf' },
  ],
  Temperature: [
    { label: '°C → °F', fn: (v) => (v * 9) / 5 + 32, unit: '°F' },
    { label: '°F → °C', fn: (v) => ((v - 32) * 5) / 9, unit: '°C' },
    { label: '°C → K', fn: (v) => v + 273.15, unit: 'K' },
    { label: 'K → °C', fn: (v) => v - 273.15, unit: '°C' },
  ],
  Torque: [
    { label: 'Nm → lb·ft', fn: (v) => v * 0.737562, unit: 'lb·ft' },
    { label: 'lb·ft → Nm', fn: (v) => v / 0.737562, unit: 'Nm' },
    { label: 'Nm → lb·in', fn: (v) => v * 8.85075, unit: 'lb·in' },
  ],
  Stress: [
    { label: 'MPa → ksi', fn: (v) => v * 0.145038, unit: 'ksi' },
    { label: 'ksi → MPa', fn: (v) => v / 0.145038, unit: 'MPa' },
    { label: 'GPa → Msi', fn: (v) => v * 0.145038, unit: 'Msi' },
  ],
};

function UnitConverter() {
  const cats = Object.keys(CONVERSIONS);
  const [cat, setCat] = useState(cats[0]);
  const [conv, setConv] = useState(0);
  const [input, setInput] = useState('');

  const selected = CONVERSIONS[cat][conv];
  const result = input !== '' && !isNaN(Number(input))
    ? selected.fn(Number(input))
    : null;

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="flex items-center gap-2 mb-5">
        <Calculator className="h-5 w-5 text-primary" />
        <h3 className="font-display text-lg font-bold">Engineering Unit Converter</h3>
        <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] text-green-400 ml-auto">Live</span>
      </div>

      {/* Category tabs */}
      <div className="flex flex-wrap gap-1.5 mb-4">
        {cats.map((c) => (
          <button
            key={c}
            onClick={() => { setCat(c); setConv(0); setInput(''); }}
            className={`rounded-full border px-3 py-1 font-mono text-[10px] transition-colors ${cat === c ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'}`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Conversion selector */}
      <div className="mb-4">
        <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Conversion</label>
        <select
          value={conv}
          onChange={(e) => { setConv(Number(e.target.value)); setInput(''); }}
          className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm focus:border-primary focus:outline-none"
        >
          {CONVERSIONS[cat].map((c, i) => (
            <option key={i} value={i}>{c.label}</option>
          ))}
        </select>
      </div>

      {/* Input */}
      <div className="mb-4">
        <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Value</label>
        <input
          type="number"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter value…"
          className="h-11 w-full rounded-lg border border-border bg-muted px-3 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      {/* Result */}
      <div className={`rounded-xl border px-4 py-3 transition-all ${result !== null ? 'border-primary/30 bg-primary/5' : 'border-border bg-muted/30'}`}>
        <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Result</p>
        {result !== null ? (
          <p className="font-display text-2xl font-bold text-primary">
            {result % 1 === 0 ? result.toFixed(0) : result.toFixed(6).replace(/\.?0+$/, '')} <span className="text-lg">{selected.unit}</span>
          </p>
        ) : (
          <p className="text-muted-foreground text-sm">Enter a value above</p>
        )}
      </div>
    </div>
  );
}

// ── Reynolds Number Calculator (working) ───────────
const FLUID_PRESETS = {
  Water: { rho: '998.2', mu: '0.001002' },
  Air: { rho: '1.225', mu: '0.0000181' },
  Custom: null,
};

function Field({ label, value, onChange }) {
  return (
    <div>
      <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="0"
        className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm focus:border-primary focus:outline-none"
      />
    </div>
  );
}

function ReynoldsCalculator() {
  const [preset, setPreset] = useState('Water');
  const [rho, setRho] = useState('998.2');
  const [mu, setMu] = useState('0.001002');
  const [v, setV] = useState('');
  const [d, setD] = useState('');

  const applyPreset = (name) => {
    setPreset(name);
    if (FLUID_PRESETS[name]) {
      setRho(FLUID_PRESETS[name].rho);
      setMu(FLUID_PRESETS[name].mu);
    }
  };

  const rhoN = parseFloat(rho);
  const muN = parseFloat(mu);
  const vN = parseFloat(v);
  const dN = parseFloat(d);
  const re = rhoN > 0 && muN > 0 && vN >= 0 && dN > 0 ? (rhoN * vN * dN) / muN : null;
  const regime = re === null ? null : re < 2300 ? 'Laminar' : re <= 4000 ? 'Transitional' : 'Turbulent';

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="flex items-center gap-2 mb-5">
        <Calculator className="h-5 w-5 text-primary" />
        <h3 className="font-display text-lg font-bold">Reynolds Number Calculator</h3>
        <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] text-green-400 ml-auto">Live</span>
      </div>
      <div className="flex flex-wrap gap-1.5 mb-4">
        {Object.keys(FLUID_PRESETS).map((p) => (
          <button
            key={p}
            onClick={() => applyPreset(p)}
            className={`rounded-full border px-3 py-1 font-mono text-[10px] transition-colors ${preset === p ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'}`}
          >
            {p}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Density (kg/m³)" value={rho} onChange={setRho} />
        <Field label="Viscosity (Pa·s)" value={mu} onChange={setMu} />
        <Field label="Velocity (m/s)" value={v} onChange={setV} />
        <Field label="Diameter (m)" value={d} onChange={setD} />
      </div>
      <div className={`mt-4 rounded-xl border px-4 py-3 transition-all ${re !== null ? 'border-primary/30 bg-primary/5' : 'border-border bg-muted/30'}`}>
        <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Reynolds Number</p>
        {re !== null ? (
          <div className="flex items-baseline gap-3">
            <p className="font-display text-2xl font-bold text-primary">{re.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
            <span className={`rounded-full px-2 py-0.5 font-mono text-[10px] ${regime === 'Laminar' ? 'bg-blue-500/10 text-blue-400' : regime === 'Transitional' ? 'bg-amber-500/10 text-amber-400' : 'bg-green-500/10 text-green-400'}`}>{regime}</span>
          </div>
        ) : (
          <p className="text-muted-foreground text-sm">Enter velocity and diameter to compute Re.</p>
        )}
      </div>
    </div>
  );
}

// ── Placeholder calculator cards ─────────────────────
const PLANNED_TOOLS = [
  { icon: '📏', title: 'Advanced Beam Deflection', desc: 'Additional support and load cases beyond the current simply-supported beam calculator.', status: 'coming-soon' },
  { icon: '🔩', title: 'Advanced Bolt Torque', desc: 'Expanded metric and imperial fastener options beyond the current approximate torque calculator.', status: 'coming-soon' },
  { icon: '🌡️', title: 'Material Selector', desc: 'Not ready: a selector needs traceable grade-specific material properties and validated selection criteria. Use authoritative material specifications and qualified review in the meantime.', status: 'coming-soon' },
  { icon: '🔬', title: 'Stress Concentration Factor', desc: 'Look up Kt values for common geometry features — holes, notches, fillets — and apply to nominal stress calculations.', status: 'coming-soon' },
  { icon: '💧', title: 'Advanced Pipe Flow', desc: 'Expanded pipe-flow cases beyond the current Darcy–Weisbach pressure-drop calculator.', status: 'coming-soon' },
  { icon: '⚙️', title: 'Advanced Gear Trains', desc: 'Helical and planetary gear cases beyond the current ideal spur-gear calculator.', status: 'coming-soon' },
  { icon: '🔋', title: 'Spring Rate Calculator', desc: 'Compute spring constant, deflection, and stress for compression, tension, and torsion springs from wire diameter and coil count.', status: 'coming-soon' },
];

export default function FreeToolsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Free Engineering Tools & Calculators — MechEngi 10X</title>
        <meta name="description" content="Use a free engineering unit converter and Reynolds number calculator, and explore engineering software and additional calculators." />
      </Helmet>

      <SiteHeader />

      <div className="border-b border-border bg-card/30 py-10">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="flex items-center gap-2 mb-3">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Calculator className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">No sign-up required</p>
          </div>
          <h1 className="font-display text-3xl font-bold sm:text-4xl">Free Engineering Tools</h1>
          <p className="mt-2 max-w-xl text-muted-foreground">
            Online calculators, converters, and utilities for practicing engineers. No registration, no ads, no paywalls — just tools that work.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Link to="/calculators" className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/5 px-3 py-1.5 font-mono text-[11px] text-primary hover:bg-primary/10">
              <Calculator className="h-3.5 w-3.5" /> Engineering Calculators (CSV/JSON/PDF export)
            </Link>
            <Link to="/resources" className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 font-mono text-[11px] text-muted-foreground hover:border-primary/30 hover:text-primary">
              Resource Library
            </Link>
            <Link to="/macro-generator" className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 font-mono text-[11px] text-muted-foreground hover:border-primary/30 hover:text-primary">
              CAD Python Macro Generator (draft code)
            </Link>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[90rem] px-5 py-10">

        {/* Live tool: Unit Converter */}
        <div className="mb-12">
          <p className="mb-4 font-mono text-xs uppercase tracking-widest text-primary">Available Now</p>
          <div className="grid gap-6 lg:grid-cols-2 lg:items-center">
            <UnitConverter />
            <ReynoldsCalculator />
          </div>
          <p className="mt-5 text-sm text-muted-foreground">Beam deflection and approximate bolt torque calculators are available with their assumptions and sources.</p>
          <Link to="/calculators" className="mt-3 inline-flex min-h-[44px] items-center rounded-xl border border-primary/40 px-4 text-sm font-medium text-primary hover:bg-primary/10">Open engineering calculators →</Link>
        </div>

        {/* Coming soon calculators */}
        <div className="mb-12">
          <p className="mb-4 font-mono text-xs uppercase tracking-widest text-muted-foreground">Coming Soon</p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {PLANNED_TOOLS.map((t) => (
              <div key={t.title} className="rounded-xl border border-border bg-card p-5 opacity-70">
                <div className="mb-3 flex items-center justify-between">
                  <span className="text-2xl">{t.icon}</span>
                  <span className="rounded-full border border-border px-2.5 py-0.5 font-mono text-[10px] text-muted-foreground">Coming Soon</span>
                </div>
                <h3 className="font-display text-sm font-bold">{t.title}</h3>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{t.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Free software tools */}
        <div>
          <div className="mb-6 flex items-end justify-between">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-green-400">Zero Cost</p>
              <h2 className="mt-1 font-display text-2xl font-bold">Free Engineering Software</h2>
            </div>
            <Link to="/tools?free=1" className="hidden font-mono text-xs text-muted-foreground hover:text-primary md:block">
              All free tools →
            </Link>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {freeTools.map((tool) => (
              <ToolCard key={tool.slug} tool={tool} />
            ))}
          </div>
        </div>

        {/* Suggest a tool */}
        <div className="mt-12 rounded-2xl border border-primary/20 bg-primary/5 p-8 text-center">
          <Zap className="mx-auto mb-3 h-8 w-8 text-primary" />
          <h3 className="font-display text-xl font-bold">Suggest a Calculator</h3>
          <p className="mx-auto mt-2 max-w-md text-muted-foreground">
            Which engineering calculation do you run repeatedly that should be here? Let us know and we'll build it.
          </p>
          <a
            href="mailto:hello@mechengi10x.com?subject=Calculator%20Request"
            className="mt-5 inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground hover:opacity-90"
          >
            Suggest a Tool <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
