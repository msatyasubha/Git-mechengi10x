import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams, useNavigate } from 'react-router-dom';
import {
  ExternalLink, CheckCircle, XCircle, ArrowLeft, ChevronRight,
  ArrowRight, Clock, ShieldCheck, AlertTriangle, Ruler,
} from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { getReviewBySlug, reviews } from '@/data/reviews';
import { trackAffiliateClick } from '@/lib/analytics';

const categoryBadge = {
  ai: 'AI Tools',
  cad: 'CAD & Design',
  simulation: 'Simulation',
  automation: 'Automation',
  management: 'Engineering Management',
  learning: 'Learning',
};

const categoryPath = {
  ai: '/ai-tools',
  cad: '/tools?cat=cad',
  simulation: '/tools?cat=simulation',
  automation: '/tools?cat=automation',
  management: '/tools?cat=management',
  learning: '/tools?cat=learning',
};

const verdictTone = {
  Great: { color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/30' },
  Good: { color: 'text-primary', bg: 'bg-primary/10', border: 'border-primary/30' },
  Weak: { color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30' },
};

/** MechEngi Score ring on the /100 scale (matches homepage format). */
const TOC = [
  { id: 'overview', label: 'Overview' },
  { id: 'testing', label: 'Engineering Testing' },
  { id: 'scores', label: 'Editorial Topics' },
  { id: 'pricing', label: 'Pricing' },
  { id: 'pros-cons', label: 'Pros & Cons' },
  { id: 'alternatives', label: 'Alternatives' },
  { id: 'verdict', label: 'Verdict' },
  { id: 'faq', label: 'FAQ' },
];

function scrollTo(id) {
  const el = document.getElementById(id);
  if (el) {
    const top = el.getBoundingClientRect().top + window.scrollY - 80;
    window.scrollTo({ top, behavior: 'smooth' });
  }
}

export default function ReviewDetailPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const review = getReviewBySlug(slug);
  const [activeAnchor, setActiveAnchor] = useState('overview');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  // Track active TOC section while scrolling
  useEffect(() => {
    if (!review?.scoreCriteria) return;
    const handler = () => {
      const scrollY = window.scrollY + 120;
      let current = TOC[0].id;
      for (const item of TOC) {
        const el = document.getElementById(item.id);
        if (el && el.offsetTop <= scrollY) current = item.id;
      }
      setActiveAnchor(current);
    };
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, [review]);

  if (!review) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet><title>Review not found — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
        <SiteHeader />
        <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
          <p className="font-display text-2xl font-bold">Review not found</p>
          <button onClick={() => navigate('/reviews')} className="text-primary hover:underline">
            Back to all reviews
          </button>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const catLabel = categoryBadge[review.category] || review.category;
  const catPath = categoryPath[review.category] || '/reviews';
  const related = reviews.filter((r) => r.slug !== slug && r.category === review.category).slice(0, 3);
  const isRich = Boolean(review.scoreCriteria);

  const articleSchema = {
    '@context': 'https://schema.org',
    // An editorial article is safer than publishing unsupported offer, operating
    // system, or review-rating data for every software product.
    '@type': 'Article',
    author: { '@type': 'Organization', name: 'MechEngi 10X' },
    publisher: { '@type': 'Organization', name: 'MechEngi 10X', url: 'https://mechengi10x.com' },
    url: `https://mechengi10x.com/reviews/${review.slug}`,
    headline: review.seoTitle,
    description: review.metaDescription,
  };

  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: review.faq.map((item) => ({
      '@type': 'Question',
      name: item.q,
      acceptedAnswer: { '@type': 'Answer', text: item.a },
    })),
  };

  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://mechengi10x.com' },
      { '@type': 'ListItem', position: 2, name: catLabel, item: `https://mechengi10x.com${catPath}` },
      { '@type': 'ListItem', position: 3, name: review.name, item: `https://mechengi10x.com/reviews/${review.slug}` },
    ],
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{review.seoTitle} | MechEngi 10X</title>
        <meta name="description" content={review.metaDescription} />
        <link rel="canonical" href={`https://mechengi10x.com/reviews/${review.slug}`} />
        <meta property="og:title" content={`${review.seoTitle} | MechEngi 10X`} />
        <meta property="og:description" content={review.metaDescription} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={`https://mechengi10x.com/reviews/${review.slug}`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={`${review.seoTitle} | MechEngi 10X`} />
        <meta name="twitter:description" content={review.metaDescription} />
      </Helmet>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />

      <SiteHeader />

      {/* Breadcrumb */}
      <div className="border-b border-border bg-card/30 py-3">
        <div className="mx-auto flex max-w-[72rem] flex-wrap items-center gap-1.5 px-5 font-mono text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Home</Link>
          <ChevronRight className="h-3 w-3 shrink-0" />
          <Link to={catPath} className="hover:text-foreground">{catLabel}</Link>
          <ChevronRight className="h-3 w-3 shrink-0" />
          <span className="max-w-[200px] truncate text-foreground">{review.name}</span>
        </div>
      </div>

      <div className="mx-auto max-w-[72rem] px-5 py-8 lg:py-12">
        <div className="grid gap-10 lg:grid-cols-[1fr_240px]">
          {/* Main */}
          <main className="min-w-0">
            {/* ── Header ─────────────────────────────────────────── */}
            <header>
              <div className="flex flex-wrap items-start gap-4">
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-border bg-card text-3xl">
                  {review.logoEmoji}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${review.category}`}>
                      {catLabel}
                    </span>
                    {review.badge && (
                      <span className="rounded-full bg-accent/15 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-accent">
                        {review.badge}
                      </span>
                    )}
                  </div>
                  <h1 className="mt-2 font-display text-2xl font-extrabold leading-tight sm:text-3xl lg:text-[2.5rem] lg:leading-[1.1]">
                    {review.seoTitle}
                  </h1>
                </div>
              </div>

              {/* Metadata row */}
              <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-2 font-mono text-[11px] text-muted-foreground sm:text-xs">
                <span className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5 shrink-0" />
                  {review.wordCount ? `~${review.wordCount.toLocaleString()} words` : `${review.readTime} min read`}
                </span>
                <span className="hidden text-border sm:inline">|</span>
                <span>
                  Reviewed {review.reviewedDate || review.date}
                  {review.testedModel ? ` — model assessed: ${review.testedModel}` : ''}
                </span>
                <span className="hidden text-border sm:inline">|</span>
                <span>MechEngi 10X Team</span>
                {isRich && (
                  <>
                    <span className="hidden text-border sm:inline">|</span>
                    <span className="flex items-center gap-1 text-amber-400">
                      <ShieldCheck className="h-3.5 w-3.5 shrink-0" /> Editorial review — hands-on testing not yet performed
                    </span>
                  </>
                )}
              </div>

              <p className="mt-4 rounded-xl border border-border bg-muted/20 px-4 py-3 text-xs leading-relaxed text-muted-foreground">This editorial review includes historical details and illustrative assessments. Product claims, pricing and comparative statements should be checked against current vendor sources; numeric MechEngi scores await documented benchmarks.</p>

              {/* Hero verdict box */}
              <div className="mt-6 rounded-2xl border border-primary/20 bg-primary/5 p-5 sm:p-6">
                <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
                  <div className="flex shrink-0 items-center gap-4">
                    <div className="flex h-20 w-20 flex-col items-center justify-center rounded-full border border-border bg-muted/40 text-center">
                      <span className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">Not Yet</span>
                      <span className="font-mono text-[10px] font-semibold text-muted-foreground">Rated</span>
                    </div>
                    <div className="sm:hidden">
                      <p className="font-mono text-[11px] text-muted-foreground">Editorial assessment pending</p>
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">MechEngi 10X Verdict</p>
                    <p className="mt-1 text-base font-medium leading-snug text-foreground sm:text-lg">
                      {review.oneLineVerdict || review.verdict}
                    </p>
                    <div className="mt-3 hidden items-center gap-3 sm:flex">
                      <span className="font-mono text-xs text-muted-foreground">Editorial assessment pending — no fabricated ratings</span>
                    </div>
                    <div className="mt-4 flex flex-wrap items-center gap-3">
                      <span className="rounded-full border border-border bg-card px-3 py-1.5 font-mono text-xs">
                        {review.pricing.free ? 'Free tier available' : 'No free tier'}
                        {review.pricing.paidFrom > 0 ? ` · $${review.pricing.paidFrom}/mo Pro` : ''}
                      </span>
                      <a
                        href={review.affiliateUrl}
                        target="_blank"
                        rel="noopener noreferrer sponsored"
                        onClick={() => trackAffiliateClick(review.slug, review.name, 'review-hero')}
                        className="glow-primary flex min-h-[44px] items-center gap-1.5 rounded-xl bg-primary px-5 py-2.5 font-display text-sm font-bold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
                      >
                        Try {review.name} <ExternalLink className="h-4 w-4" />
                      </a>
                    </div>
                    <p className="mt-2 font-mono text-[11px] text-muted-foreground">
                      We may earn a commission — scores are independent.
                    </p>
                  </div>
                </div>
              </div>
            </header>

            {isRich ? (
              <RichBody review={review} />
            ) : (
              <SimpleBody review={review} related={related} catLabel={catLabel} />
            )}

            <div className="mt-10">
              <Link to="/reviews" className="flex min-h-[44px] items-center gap-2 font-mono text-sm text-muted-foreground hover:text-primary">
                <ArrowLeft className="h-4 w-4" /> Back to all reviews
              </Link>
            </div>
          </main>

          {/* Sidebar — TOC + CTA */}
          <aside className="lg:sticky lg:top-24 lg:h-fit space-y-5">
            {isRich && (
              <nav className="rounded-2xl border border-border bg-card p-4" aria-label="Table of contents">
                <p className="mb-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">On this page</p>
                <ul className="space-y-1">
                  {TOC.map((item) => (
                    <li key={item.id}>
                      <button
                        type="button"
                        onClick={() => scrollTo(item.id)}
                        className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm transition-colors ${
                          activeAnchor === item.id
                            ? 'bg-primary/10 font-medium text-primary'
                            : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                        }`}
                      >
                        <ChevronRight className="h-3.5 w-3.5 shrink-0" />
                        {item.label}
                      </button>
                    </li>
                  ))}
                </ul>
              </nav>
            )}

            {/* CTA card */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{review.logoEmoji}</span>
                <div className="min-w-0">
                  <p className="truncate font-display font-bold">{review.name}</p>
                  <p className="truncate text-xs text-muted-foreground">{review.vendor}</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                {review.pricing.free ? (
                  <div className="flex items-center justify-between rounded-lg bg-green-500/10 px-3 py-2">
                    <span className="font-mono text-xs text-green-400">Free tier</span>
                    <span className="max-w-[55%] truncate text-right text-xs text-muted-foreground">{review.pricing.freeLabel}</span>
                  </div>
                ) : null}
                {review.pricing.paidFrom > 0 && (
                  <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2">
                    <span className="font-mono text-xs">Paid from</span>
                    <span className="font-mono text-xs font-semibold">${review.pricing.paidFrom}/mo</span>
                  </div>
                )}
                <p className="pt-1 text-xs text-muted-foreground">{review.pricing.paidLabel}</p>
              </div>
              <a
                href={review.affiliateUrl}
                target="_blank"
                rel="noopener noreferrer sponsored"
                onClick={() => trackAffiliateClick(review.slug, review.name, 'review-sidebar')}
                className="mt-4 flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
              >
                Try {review.name} <ExternalLink className="h-4 w-4" />
              </a>
              <p className="affiliate-disclosure mt-2 text-center font-mono text-[11px] text-muted-foreground">
                Affiliate link — we earn a commission at no extra cost to you
              </p>
              <Link
                to="/advisor"
                className="mt-3 flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-border py-2.5 text-sm font-medium transition-colors hover:border-primary/40 hover:text-primary"
              >
                Ask AI Advisor for alternatives
              </Link>
            </div>

            {/* Related reviews */}
            {related.length > 0 && (
              <div className="rounded-2xl border border-border bg-card p-5">
                <p className="mb-3 font-display font-bold">More {catLabel} Reviews</p>
                <div className="space-y-3">
                  {related.map((r) => (
                    <Link key={r.slug} to={`/reviews/${r.slug}`} className="group flex items-center gap-3">
                      <span className="text-xl">{r.logoEmoji}</span>
                      <div className="min-w-0">
                        <p className="text-sm font-medium leading-snug group-hover:text-primary">{r.name}</p>
                        <p className="text-xs text-muted-foreground">Editorial review</p>
                      </div>
                    </Link>
                  ))}
                </div>
                <Link to="/reviews" className="mt-4 flex items-center gap-1 font-mono text-xs text-primary hover:underline">
                  All reviews <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
            )}
          </aside>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}

/* ── Rich in-depth body (new template) ──────────────────────────── */
/* ── DFM & Standards section (rendered only for reviews with dfmStandards data) ─── */
const dfmStatusTone = {
  documented: { color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/30' },
  partial: { color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30' },
  'not-documented': { color: 'text-muted-foreground', bg: 'bg-muted/40', border: 'border-border' },
};

function DfmStandardsSection({ review }) {
  const dfm = review.dfmStandards;
  if (!dfm) return null;
  return (
    <section id="dfm-standards" className="scroll-mt-24">
      <h2 className="flex items-center gap-2 font-display text-xl font-bold sm:text-2xl">
        <Ruler className="h-5 w-5 text-accent" /> DFM &amp; Standards
      </h2>
      <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{dfm.intro}</p>
      <div className="mt-5 space-y-3">
        {dfm.criteria.map((c, i) => {
          const tone = dfmStatusTone[c.status] || dfmStatusTone['not-documented'];
          return (
            <div key={i} className="rounded-xl border border-border bg-card p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="font-display text-sm font-bold sm:text-base">{c.label}</h3>
                <span className={`rounded-full border px-2.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider ${tone.color} ${tone.bg} ${tone.border}`}>
                  {c.status === 'not-documented' ? 'Not documented' : c.status === 'documented' ? 'Documented' : 'Partial'}
                </span>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-foreground/85">{c.body}</p>
            </div>
          );
        })}
      </div>
      <p className="mt-4 rounded-lg border border-border bg-muted/30 px-3 py-2 font-mono text-[11px] leading-relaxed text-muted-foreground">
        {dfm.evidence}
      </p>
    </section>
  );
}

function RichBody({ review }) {
  return (
    <div className="mt-10 space-y-10">
      {/* Editorial assessment */}
      <section id="scorecard" className="scroll-mt-24">
        <h2 className="font-display text-xl font-bold sm:text-2xl">Editorial Assessment</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          These legacy qualitative topics do not map directly to the current weighted MechEngi Score framework. They are editorial discussion, not benchmark results or a calculated rating. Tap a row to jump to its discussion.
        </p>
        <p className="mt-2 rounded-lg border border-amber-500/30 bg-amber-500/5 px-3 py-2 text-[11px] leading-relaxed text-amber-400">
          Not Yet Rated &mdash; these are draft editorial judgments, not validated hands-on benchmark scores. No numeric per-category score is assigned until documented, reproducible benchmark data exists. See our{' '}
          <Link to="/methodology" className="underline hover:no-underline">100-point framework</Link>.
        </p>
        <div className="mt-5 overflow-hidden rounded-2xl border border-border">
          {/* Desktop table */}
          <table className="hidden w-full sm:table">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Criterion</th>
                <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Assessment</th>
              </tr>
            </thead>
            <tbody>
              {review.scoreCriteria.map((c) => (
                <tr
                  key={c.key}
                  onClick={() => scrollTo(c.anchor === 'testing' ? 'testing' : 'scores')}
                  className="cursor-pointer border-b border-border transition-colors last:border-0 hover:bg-muted/30"
                >
                  <td className="px-4 py-3.5 text-sm font-medium">{c.label}</td>
                  <td className="px-4 py-3.5 text-sm text-muted-foreground">{c.justification}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {/* Mobile stacked list */}
          <ul className="sm:hidden">
            {review.scoreCriteria.map((c) => (
              <li
                key={c.key}
                onClick={() => scrollTo(c.anchor === 'testing' ? 'testing' : 'scores')}
                className="cursor-pointer border-b border-border p-4 transition-colors last:border-0 active:bg-muted/40"
              >
                <span className="text-sm font-medium">{c.label}</span>
                <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{c.justification}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Overview */}
      <section id="overview" className="scroll-mt-24">
        <h2 className="font-display text-xl font-bold sm:text-2xl">Overview</h2>
        <p className="mt-4 text-sm leading-relaxed text-foreground/85 sm:text-base">{review.overview}</p>
      </section>

      {/* How We Tested */}
      <section id="testing" className="scroll-mt-24">
        <h2 className="flex items-center gap-2 font-display text-xl font-bold sm:text-2xl">
          <ShieldCheck className="h-5 w-5 text-primary" /> How We Tested
        </h2>
        <div className="mt-4 flex items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/5 px-4 py-3">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
          <p className="text-[11px] leading-relaxed text-amber-400">
            Illustrative assessment scenario &mdash; not a performed hands-on benchmark. The workflow below describes
            the engineering tasks we use to form our editorial judgment, based on documented tool capabilities. A
            formal, reproducible benchmark has not yet been run or published for this tool.
          </p>
        </div>
        <p className="mt-4 text-sm leading-relaxed text-foreground/85 sm:text-base">{review.howWeTested}</p>
      </section>

      {/* Engineering use cases */}
      <section id="use-cases" className="scroll-mt-24">
        <h2 className="font-display text-xl font-bold sm:text-2xl">Engineering Use Cases</h2>
        <p className="mt-1 text-sm text-muted-foreground">Illustrative worked examples showing where the tool tends to succeed or struggle.</p>
        <div className="mt-5 space-y-4">
          {review.engineeringUseCases.map((uc, i) => {
            const tone = verdictTone[uc.verdict] || verdictTone.Good;
            return (
              <div key={i} className="rounded-2xl border border-border bg-card p-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="font-display text-base font-bold sm:text-lg">{uc.title}</h3>
                  <span className={`rounded-full border px-2.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider ${tone.color} ${tone.bg} ${tone.border}`}>
                    {uc.verdict}
                  </span>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-foreground/85">{uc.body}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Scores deep-dive */}
      <section id="scores" className="scroll-mt-24">
        <h2 className="font-display text-xl font-bold sm:text-2xl">Editorial Topics Deep-Dive</h2>
        <div className="mt-5 space-y-5">
          {review.scoresDeepDive.map((s, i) => (
            <div key={i} className="border-l-2 border-primary/30 pl-4">
              <h3 className="font-display text-base font-bold sm:text-lg">{s.label}</h3>
              <p className="mt-2 text-sm leading-relaxed text-foreground/85">{s.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* DFM & Standards */}
      <DfmStandardsSection review={review} />

      {/* Pricing */}
      <section id="pricing" className="scroll-mt-24">
        <h2 className="font-display text-xl font-bold sm:text-2xl">Pricing</h2>
        <div className="mt-5 overflow-hidden rounded-2xl border border-border">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/40">
                <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Tier</th>
                <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Price</th>
                <th className="hidden px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground sm:table-cell">What you get</th>
              </tr>
            </thead>
            <tbody>
              {review.pricingTiers.map((t) => (
                <tr key={t.tier} className="border-b border-border last:border-0">
                  <td className="px-4 py-3.5 text-sm font-medium">{t.tier}</td>
                  <td className="px-4 py-3.5 font-mono text-sm font-semibold text-primary">{t.price}</td>
                  <td className="hidden px-4 py-3.5 text-sm text-muted-foreground sm:table-cell">{t.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {/* mobile detail rows */}
          <ul className="sm:hidden">
            {review.pricingTiers.map((t) => (
              <li key={t.tier} className="border-t border-border p-4 first:border-0">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{t.tier}</span>
                  <span className="font-mono text-sm font-semibold text-primary">{t.price}</span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{t.detail}</p>
              </li>
            ))}
          </ul>
        </div>
        <p className="mt-4 text-sm leading-relaxed text-foreground/85">{review.pricingAssessment}</p>
        <p className="mt-2 font-mono text-[11px] text-muted-foreground">
          Pricing recorded {review.lastVerified}. Confirm current tiers on the vendor site before buying.
        </p>
      </section>

      {/* Pros & Cons */}
      <section id="pros-cons" className="scroll-mt-24">
        <h2 className="font-display text-xl font-bold sm:text-2xl">Pros &amp; Cons</h2>
        <div className="mt-5 grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-green-500/20 bg-green-500/5 p-5">
            <h3 className="flex items-center gap-2 font-display font-bold text-green-400">
              <CheckCircle className="h-4 w-4" /> Pros
            </h3>
            <ul className="mt-3 space-y-2.5">
              {review.pros.slice(0, 5).map((p, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-green-500" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-5">
            <h3 className="flex items-center gap-2 font-display font-bold text-red-400">
              <XCircle className="h-4 w-4" /> Cons
            </h3>
            <ul className="mt-3 space-y-2.5">
              {review.cons.slice(0, 5).map((c, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-500" />
                  <span>{c}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Alternatives */}
      <section id="alternatives" className="scroll-mt-24">
        <h2 className="font-display text-xl font-bold sm:text-2xl">Alternatives</h2>
        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          {review.alternatives.map((alt) => (
            <div key={alt.slug} className="flex flex-col rounded-xl border border-border bg-card p-5">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{alt.logoEmoji}</span>
                <p className="font-display text-base font-bold">{alt.name}</p>
              </div>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">{alt.reason}</p>
              <div className="mt-4 flex flex-col gap-2">
                <Link to={`/reviews/${alt.reviewSlug}`} className="flex min-h-[40px] items-center justify-center gap-1.5 rounded-lg border border-border px-3 py-2 text-xs font-medium transition-colors hover:border-primary/60 hover:text-primary">
                  Read review <ArrowRight className="h-3 w-3" />
                </Link>
                {alt.comparisonSlug && (
                  <Link to={`/comparisons/${alt.comparisonSlug}`} className="flex min-h-[40px] items-center justify-center gap-1.5 rounded-lg bg-muted/50 px-3 py-2 text-xs font-medium transition-colors hover:bg-muted hover:text-primary">
                    Head-to-head comparison
                  </Link>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Verdict */}
      <section id="verdict" className="scroll-mt-24">
        <h2 className="font-display text-xl font-bold sm:text-2xl">Verdict</h2>
        <div className="mt-5 rounded-2xl border border-primary/20 bg-primary/5 p-5 sm:p-6">
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-display text-3xl font-extrabold text-muted-foreground">Not Yet Rated</span>
            <span className="font-mono text-xs text-muted-foreground">MechEngi Score · independent of affiliate status</span>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-foreground/85 sm:text-base">{review.verdict}</p>

          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl border border-green-500/20 bg-green-500/5 p-4">
              <h3 className="flex items-center gap-2 font-display text-sm font-bold text-green-400">
                <CheckCircle className="h-4 w-4" /> Choose {review.name} if…
              </h3>
              <ul className="mt-3 space-y-2">
                {review.verdictPersonas.chooseIf.map((p, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-green-500" />
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
              <h3 className="flex items-center gap-2 font-display text-sm font-bold text-amber-400">
                <AlertTriangle className="h-4 w-4" /> Skip it if…
              </h3>
              <ul className="mt-3 space-y-2">
                {review.verdictPersonas.skipIf.map((p, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-500" />
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="scroll-mt-24">
        <h2 className="font-display text-xl font-bold sm:text-2xl">FAQ</h2>
        <div className="mt-5 space-y-3">
          {review.faq.map((item, i) => (
            <div key={i} className="rounded-xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">{item.q}</h3>
              <p className="mt-2 text-sm leading-relaxed text-foreground/80">{item.a}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Last verified */}
      <div className="border-t border-border pt-5">
        <p className="font-mono text-[11px] text-muted-foreground">
          Pricing and features recorded {review.lastVerified}. Spotted an error?{' '}
          <a href="mailto:hello@mechengi10x.com" className="text-primary hover:underline">Report it →</a>
        </p>
      </div>
    </div>
  );
}

/* ── Simple fallback body (reviews without the new rich fields) ─── */
function SimpleBody({ review, related, catLabel }) {
  return (
    <div className="mt-8 space-y-8">
      <section>
        <p className="text-base leading-relaxed text-muted-foreground lg:text-lg">{review.summary}</p>
      </section>

      <section>
        <h2 className="mb-4 font-display text-xl font-bold">Pros &amp; Cons</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-green-500/20 bg-green-500/5 p-5">
            <h3 className="flex items-center gap-2 font-display font-bold text-green-400">
              <CheckCircle className="h-4 w-4" /> Advantages
            </h3>
            <ul className="mt-3 space-y-2">
              {review.pros.map((p, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-green-500" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-5">
            <h3 className="flex items-center gap-2 font-display font-bold text-red-400">
              <XCircle className="h-4 w-4" /> Limitations
            </h3>
            <ul className="mt-3 space-y-2">
              {review.cons.map((c, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-500" />
                  <span>{c}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="grid gap-5 md:grid-cols-2">
        <div className="rounded-xl border border-border bg-card p-5">
          <h2 className="font-display text-lg font-bold">Best For</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            {review.bestFor.map((b, i) => (
              <span key={i} className={`rounded-lg border px-3 py-1 text-sm badge-${review.category}`}>{b}</span>
            ))}
          </div>
        </div>
        <div className="rounded-xl border border-border bg-card p-5">
          <h2 className="font-display text-lg font-bold">Engineering Use Cases</h2>
          <ul className="mt-4 space-y-2">
            {review.useCases.map((u, i) => (
              <li key={i} className="flex items-center gap-2 text-sm">
                <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                {u}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <DfmStandardsSection review={review} />

      <section>
        <h2 className="mb-4 font-display text-xl font-bold">Final Recommendation</h2>
        <div className="rounded-xl border border-primary/20 bg-primary/5 p-5">
          <p className="leading-relaxed text-foreground/80">{review.verdict}</p>
        </div>
      </section>

      <section>
        <h2 className="mb-4 font-display text-xl font-bold">Frequently Asked Questions</h2>
        <div className="space-y-3">
          {review.faq.map((item, i) => (
            <div key={i} className="rounded-xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">{item.q}</h3>
              <p className="mt-2 text-sm leading-relaxed text-foreground/80">{item.a}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h3 className="mb-3 font-display font-bold">Related Resources</h3>
        <div className="flex flex-wrap gap-2">
          {review.internalLinks.map((link, i) => (
            <Link key={i} to={link.to} className="rounded-lg border border-border bg-muted/40 px-3 py-1.5 font-mono text-xs text-muted-foreground transition-colors hover:border-primary/30 hover:text-primary">
              {link.text}
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
