import { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import {
  Calculator,
  Download,
  FileText,
  BookOpen,
  Info,
  ChevronDown,
  ChevronRight,
  ArrowRight,
} from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { exportCsv, exportJson, exportPdfReport, buildPayload } from '@/lib/exportUtils';

/* ───────────────────────────────────────────────────────────
   Shared building blocks
   ─────────────────────────────────────────────────────────── */

function NumField({ label, value, onChange, unit, placeholder = '0' }) {
  return (
    <div>
      <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
        {label} {unit && <span className="text-foreground/40">({unit})</span>}
      </label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
      />
    </div>
  );
}

function ResultRow({ label, value, unit, accent }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-border/60 py-2 last:border-0">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className={`font-mono text-sm tabular-nums ${accent ? 'text-primary font-semibold' : 'text-foreground'}`}>
        {value} <span className="text-muted-foreground">{unit}</span>
      </span>
    </div>
  );
}

function ExportBar({ rows, payload, pdf, disabled }) {
  const base = 'flex items-center gap-1.5 rounded-lg border px-3 py-1.5 font-mono text-[11px] transition-colors';
  return (
    <div className="mt-4 flex flex-wrap gap-2">
      <button
        disabled={disabled}
        onClick={() => exportCsv(rows, payload.filename + '.csv', { title: payload.calculator, timestamp: new Date().toLocaleString() })}
        className={`${base} border-border text-muted-foreground hover:border-primary/40 hover:text-primary disabled:opacity-40`}
      >
        <Download className="h-3 w-3" /> CSV
      </button>
      <button
        disabled={disabled}
        onClick={() => exportJson(buildPayload(payload), payload.filename + '.json')}
        className={`${base} border-border text-muted-foreground hover:border-primary/40 hover:text-primary disabled:opacity-40`}
      >
        <Download className="h-3 w-3" /> JSON
      </button>
      <button
        disabled={disabled}
        onClick={() => exportPdfReport({ ...pdf, rows })}
        className={`${base} border-border text-muted-foreground hover:border-primary/40 hover:text-primary disabled:opacity-40`}
      >
        <FileText className="h-3 w-3" /> PDF
      </button>
    </div>
  );
}

function FormulaDoc({ formula, plain, source, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="mt-4 rounded-xl border border-border bg-muted/20">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center gap-2 px-4 py-2.5 text-left text-xs font-medium text-muted-foreground hover:text-foreground"
      >
        {open ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
        <BookOpen className="h-3.5 w-3.5 text-primary" />
        Formula & source documentation
      </button>
      {open && (
        <div className="border-t border-border px-4 py-3 text-xs leading-relaxed text-muted-foreground">
          <p className="mb-2 font-mono text-[11px] text-foreground">{formula}</p>
          <p className="mb-2"><span className="font-semibold text-foreground/80">In plain English:</span> {plain}</p>
          <p className="rounded-md bg-background/50 px-2.5 py-1.5"><span className="font-semibold text-foreground/80">Source:</span> {source}</p>
        </div>
      )}
    </div>
  );
}

function CalcShell({ icon, title, tagline, children, live = true }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="mb-5 flex items-center gap-2">
        <span className="text-xl">{icon}</span>
        <h3 className="font-display text-lg font-bold">{title}</h3>
        {live && (
          <span className="ml-auto rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] text-green-400">Live</span>
        )}
      </div>
      {tagline && <p className="mb-4 text-xs text-muted-foreground">{tagline}</p>}
      {children}
    </div>
  );
}

const num = (v) => parseFloat(v);

/* ───────────────────────────────────────────────────────────
   1. Unit Converter (with export)
   ─────────────────────────────────────────────────────────── */
const CONVERSIONS = {
  Length: [
    { label: 'mm → in', fn: (v) => v / 25.4, unit: 'in' },
    { label: 'in → mm', fn: (v) => v * 25.4, unit: 'mm' },
    { label: 'm → ft', fn: (v) => v * 3.28084, unit: 'ft' },
    { label: 'ft → m', fn: (v) => v / 3.28084, unit: 'm' },
    { label: 'km → mi', fn: (v) => v * 0.621371, unit: 'mi' },
  ],
  Pressure: [
    { label: 'kPa → psi', fn: (v) => v * 0.145038, unit: 'psi' },
    { label: 'psi → kPa', fn: (v) => v / 0.145038, unit: 'kPa' },
    { label: 'bar → psi', fn: (v) => v * 14.5038, unit: 'psi' },
    { label: 'MPa → ksi', fn: (v) => v * 0.145038, unit: 'ksi' },
  ],
  Force: [
    { label: 'N → lbf', fn: (v) => v * 0.224809, unit: 'lbf' },
    { label: 'lbf → N', fn: (v) => v / 0.224809, unit: 'N' },
    { label: 'kN → kip', fn: (v) => v * 0.224809, unit: 'kip' },
    { label: 'N → kgf', fn: (v) => v / 9.80665, unit: 'kgf' },
  ],
  Temperature: [
    { label: '°C → °F', fn: (v) => (v * 9) / 5 + 32, unit: '°F' },
    { label: '°F → °C', fn: (v) => ((v - 32) * 5) / 9, unit: '°C' },
    { label: '°C → K', fn: (v) => v + 273.15, unit: 'K' },
    { label: 'K → °C', fn: (v) => v - 273.15, unit: '°C' },
  ],
  Torque: [
    { label: 'Nm → lb·ft', fn: (v) => v * 0.737562, unit: 'lb·ft' },
    { label: 'lb·ft → Nm', fn: (v) => v / 0.737562, unit: 'Nm' },
    { label: 'Nm → lb·in', fn: (v) => v * 8.85075, unit: 'lb·in' },
  ],
  Stress: [
    { label: 'MPa → ksi', fn: (v) => v * 0.145038, unit: 'ksi' },
    { label: 'ksi → MPa', fn: (v) => v / 0.145038, unit: 'MPa' },
    { label: 'GPa → Msi', fn: (v) => v * 0.145038, unit: 'Msi' },
  ],
};

function UnitConverter() {
  const cats = Object.keys(CONVERSIONS);
  const [cat, setCat] = useState(cats[0]);
  const [conv, setConv] = useState(0);
  const [input, setInput] = useState('');
  const selected = CONVERSIONS[cat][conv];
  const result = input !== '' && !isNaN(Number(input)) ? selected.fn(Number(input)) : null;
  const fmt = (r) => (r % 1 === 0 ? r.toFixed(0) : r.toFixed(6).replace(/\.?0+$/, ''));

  const rows = result !== null
    ? [{ label: 'Input', value: input, unit: selected.label.split('→')[0].trim() }, { label: 'Converted', value: fmt(result), unit: selected.unit }]
    : [];

  return (
    <CalcShell icon="📐" title="Unit Converter" tagline="Length, pressure, force, temperature, torque and stress — using standard SI/imperial conversion factors.">
      <div className="flex flex-wrap gap-1.5 mb-4">
        {cats.map((c) => (
          <button key={c} onClick={() => { setCat(c); setConv(0); setInput(''); }}
            className={`rounded-full border px-3 py-1 font-mono text-[10px] transition-colors ${cat === c ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'}`}>{c}</button>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Conversion</label>
          <select value={conv} onChange={(e) => { setConv(Number(e.target.value)); setInput(''); }}
            className="h-10 w-full rounded-lg border border-border bg-muted px-3 text-sm focus:border-primary focus:outline-none">
            {CONVERSIONS[cat].map((c, i) => <option key={i} value={i}>{c.label}</option>)}
          </select>
        </div>
        <NumField label="Value" value={input} onChange={setInput} />
      </div>
      <div className={`mt-4 rounded-xl border px-4 py-3 ${result !== null ? 'border-primary/30 bg-primary/5' : 'border-border bg-muted/30'}`}>
        <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Result</p>
        {result !== null
          ? <p className="font-display text-2xl font-bold text-primary">{fmt(result)} <span className="text-lg">{selected.unit}</span></p>
          : <p className="text-sm text-muted-foreground">Enter a value above</p>}
      </div>
      <ExportBar
        disabled={result === null}
        rows={rows}
        payload={{ calculator: 'Unit Converter', filename: 'unit-conversion', inputs: { conversion: selected.label, value: input }, results: { converted: result } }}
        pdf={{ title: 'Unit Conversion Record', subtitle: selected.label, formula: `${selected.label} (conversion factor may be rounded)`, source: 'NIST Guide for the Use of the International System of Units (SI), SP 811.' }}
      />
      <FormulaDoc
        formula={`${selected.label} — uses SI/imperial conversion factors.`}
        plain="Some conversion factors are rounded and the displayed result is rounded. Check the precision required for your application against an authoritative source."
        source="NIST Special Publication 811 — Guide for the Use of the International System of Units (SI)."
      />
    </CalcShell>
  );
}

/* ───────────────────────────────────────────────────────────
   2. Reynolds Number
   ─────────────────────────────────────────────────────────── */
const FLUID_PRESETS = {
  Water: { rho: '998.2', mu: '0.001002' },
  Air: { rho: '1.225', mu: '0.0000181' },
  Custom: null,
};

function ReynoldsCalculator() {
  const [preset, setPreset] = useState('Water');
  const [rho, setRho] = useState('998.2');
  const [mu, setMu] = useState('0.001002');
  const [v, setV] = useState('');
  const [d, setD] = useState('');
  const applyPreset = (name) => { setPreset(name); if (FLUID_PRESETS[name]) { setRho(FLUID_PRESETS[name].rho); setMu(FLUID_PRESETS[name].mu); } };
  const rhoN = num(rho), muN = num(mu), vN = num(v), dN = num(d);
  const re = rhoN > 0 && muN > 0 && vN >= 0 && dN > 0 ? (rhoN * vN * dN) / muN : null;
  const regime = re === null ? null : re < 2300 ? 'Laminar' : re <= 4000 ? 'Transitional' : 'Turbulent';
  const rows = re !== null
    ? [
        { label: 'Density ρ', value: rho, unit: 'kg/m³' },
        { label: 'Dynamic viscosity μ', value: mu, unit: 'Pa·s' },
        { label: 'Velocity v', value: v, unit: 'm/s' },
        { label: 'Characteristic length D', value: d, unit: 'm' },
        { label: 'Reynolds number Re', value: re.toLocaleString(undefined, { maximumFractionDigits: 0 }), unit: '—' },
        { label: 'Flow regime', value: regime, unit: '' },
      ]
    : [];

  return (
    <CalcShell icon="🌊" title="Reynolds Number" tagline="Predict laminar / transitional / turbulent flow regime for internal pipe flow.">
      <div className="flex flex-wrap gap-1.5 mb-4">
        {Object.keys(FLUID_PRESETS).map((p) => (
          <button key={p} onClick={() => applyPreset(p)}
            className={`rounded-full border px-3 py-1 font-mono text-[10px] transition-colors ${preset === p ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'}`}>{p}</button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-3">
        <NumField label="Density ρ" value={rho} onChange={setRho} unit="kg/m³" />
        <NumField label="Viscosity μ" value={mu} onChange={setMu} unit="Pa·s" />
        <NumField label="Velocity v" value={v} onChange={setV} unit="m/s" />
        <NumField label="Diameter D" value={d} onChange={setD} unit="m" />
      </div>
      <div className={`mt-4 rounded-xl border px-4 py-3 ${re !== null ? 'border-primary/30 bg-primary/5' : 'border-border bg-muted/30'}`}>
        <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Reynolds Number</p>
        {re !== null
          ? <div className="flex items-baseline gap-3">
              <p className="font-display text-2xl font-bold text-primary">{re.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
              <span className={`rounded-full px-2 py-0.5 font-mono text-[10px] ${regime === 'Laminar' ? 'bg-blue-500/10 text-blue-400' : regime === 'Transitional' ? 'bg-amber-500/10 text-amber-400' : 'bg-green-500/10 text-green-400'}`}>{regime}</span>
            </div>
          : <p className="text-sm text-muted-foreground">Enter velocity and diameter to compute Re.</p>}
      </div>
      <ExportBar
        disabled={re === null}
        rows={rows}
        payload={{ calculator: 'Reynolds Number', filename: 'reynolds-number', inputs: { rho, mu, v, d }, results: { Re: re, regime } }}
        pdf={{ title: 'Reynolds Number Calculation', subtitle: 'Internal pipe flow regime prediction', formula: 'Re = (ρ · v · D) / μ', source: 'Munson, B.R., Fundamentals of Fluid Mechanics. Regime thresholds: Re < 2300 laminar, 2300–4000 transitional, > 4000 turbulent (ISO/ASME convention).' }}
      />
      <FormulaDoc
        formula="Re = (ρ · v · D) / μ"
        plain="Re equals density (ρ) times velocity (v) times characteristic length (D), divided by dynamic viscosity (μ). It is the ratio of inertial to viscous forces — dimensionless."
        source="Munson, Fundamentals of Fluid Mechanics; regime thresholds per ISO/ASME pipe-flow convention."
      />
    </CalcShell>
  );
}

/* ───────────────────────────────────────────────────────────
   3. Beam Deflection (simply-supported, central point load)
   ─────────────────────────────────────────────────────────── */
function BeamDeflectionCalculator() {
  const [load, setLoad] = useState('');
  const [length, setLength] = useState('');
  const [e, setE] = useState('200000');
  const [i, setI] = useState('');
  const P = num(load), L = num(length), En = num(e), In = num(i);
  const valid = P > 0 && L > 0 && En > 0 && In > 0;
  // Simply supported beam, point load P at midspan:
  // δ_max = P·L³ / (48·E·I); M_max = P·L/4.
  // E is entered in MPa; convert to Pa to match N, m and m⁴.
  const delta = valid ? (P * Math.pow(L, 3)) / (48 * En * 1e6 * In) : null;
  const moment = valid ? (P * L) / 4 : null;
  const rows = valid
    ? [
        { label: 'Point load P', value: load, unit: 'N' },
        { label: 'Span L', value: length, unit: 'm' },
        { label: 'Young\'s modulus E', value: e, unit: 'MPa' },
        { label: 'Second moment I', value: i, unit: 'm⁴' },
        { label: 'Max deflection δ', value: delta.toExponential(4), unit: 'm' },
        { label: 'Max bending moment M', value: moment.toFixed(3), unit: 'N·m' },
      ]
    : [];

  return (
    <CalcShell icon="📏" title="Beam Deflection" tagline="Simply-supported beam, central point load — max deflection and bending moment (Euler–Bernoulli).">
      <p className="mb-4 text-xs leading-relaxed text-muted-foreground">Assumes a prismatic, linearly elastic, simply supported beam, a central point load and small deflections. Shear deflection, self-weight and other loads are excluded. Verify against applicable codes before design sign-off.</p>
      <div className="grid grid-cols-2 gap-3">
        <NumField label="Point load P" value={load} onChange={setLoad} unit="N" />
        <NumField label="Span L" value={length} onChange={setLength} unit="m" />
        <NumField label="Modulus E" value={e} onChange={setE} unit="MPa" />
        <NumField label="Moment I" value={i} onChange={setI} unit="m⁴" />
      </div>
      <div className={`mt-4 rounded-xl border px-4 py-3 ${valid ? 'border-primary/30 bg-primary/5' : 'border-border bg-muted/30'}`}>
        <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Result</p>
        {valid
          ? <div className="space-y-1">
              <ResultRow label="Max deflection δ" value={delta.toExponential(4)} unit="m" accent />
              <ResultRow label="Max bending moment M" value={moment.toFixed(3)} unit="N·m" />
            </div>
          : <p className="text-sm text-muted-foreground">Enter all four values to compute deflection.</p>}
      </div>
      <ExportBar
        disabled={!valid}
        rows={rows}
        payload={{ calculator: 'Beam Deflection (simply-supported, central point load)', filename: 'beam-deflection', inputs: { P: load, L: length, E: e, I: i }, results: { delta, moment } }}
        pdf={{ title: 'Beam Deflection Calculation', subtitle: 'Simply-supported beam, central point load (Euler–Bernoulli)', formula: 'δ_max = P·L³ / (48·E·I); E in Pa (input MPa × 10⁶)\nM_max = P·L / 4', source: 'Gere & Timoshenko, Mechanics of Materials. Assumes linear-elastic, small-deflection, prismatic beam.' }}
      />
      <FormulaDoc
        formula="δ_max = P·L³ / (48·E·I)   |   M_max = P·L / 4"
        plain="For a simply-supported beam of span L with a central point load P, maximum deflection is P·L³ divided by 48·E·I. The input modulus E is converted from MPa to Pa before calculation. Maximum bending moment is P·L/4 at midspan."
        source="Gere & Timoshenko, Mechanics of Materials. Valid for linear-elastic, small-deflection, prismatic beams."
      />
    </CalcShell>
  );
}

/* ───────────────────────────────────────────────────────────
   4. Bolt Torque / Preload
   ─────────────────────────────────────────────────────────── */
function BoltTorqueCalculator() {
  const [preload, setPreload] = useState('');
  const [dia, setDia] = useState('');
  const [factor, setFactor] = useState('');
  const Fi = num(preload), d = num(dia), K = num(factor);
  const torque = Fi > 0 && d > 0 && K > 0 ? K * Fi * d : null;
  const rows = torque !== null
    ? [
        { label: 'Target preload Fi', value: preload, unit: 'N' },
        { label: 'Nominal bolt diameter d', value: dia, unit: 'm' },
        { label: 'Torque factor K', value: K.toFixed(3), unit: '—' },
        { label: 'Required torque T', value: torque.toFixed(3), unit: 'N·m' },
      ]
    : [];

  return (
    <CalcShell icon="🔩" title="Bolt Torque" tagline="Preliminary torque estimate using a supplied, application-specific nut factor. Not suitable for critical joint sign-off.">
      <div className="grid grid-cols-2 gap-3">
        <NumField label="Target preload Fi" value={preload} onChange={setPreload} unit="N" />
        <NumField label="Bolt diameter d" value={dia} onChange={setDia} unit="m" />
        <NumField label="Nut factor K (from testing or vendor)" value={factor} onChange={setFactor} />
      </div>
      <div className={`mt-4 rounded-xl border px-4 py-3 ${torque !== null ? 'border-primary/30 bg-primary/5' : 'border-border bg-muted/30'}`}>
        <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Required Torque</p>
        {torque !== null
          ? <p className="font-display text-2xl font-bold text-primary">{torque.toFixed(3)} <span className="text-lg">N·m</span></p>
          : <p className="text-sm text-muted-foreground">Enter preload, diameter, and a positive nut factor.</p>}
      </div>
      <ExportBar
        disabled={torque === null}
        rows={rows}
        payload={{ calculator: 'Bolt Torque', filename: 'bolt-torque', inputs: { Fi: preload, d: dia, K: factor }, results: { K, torque } }}
        pdf={{ title: 'Bolt Torque Calculation', subtitle: 'Torque–tension (short-form)', formula: 'T = K · Fi · d', source: 'Bickford, An Introduction to the Design and Behavior of Bolted Joints (short-form torque–tension relation). K depends on joint conditions. Verify against VDI 2230 or vendor specification.' }}
      />
      <FormulaDoc
        formula="T = K · Fi · d"
        plain="Torque T equals the supplied nut factor K times target preload Fi and nominal diameter d. K depends on thread and bearing friction, geometry, lubrication and surface condition; use a measured or vendor-specified value. This approximation does not guarantee preload."
        source="Bickford, An Introduction to the Design and Behavior of Bolted Joints. Approximate — verify against VDI 2230 or the fastener vendor's spec for critical joints."
      />
    </CalcShell>
  );
}

/* ───────────────────────────────────────────────────────────
   5. Gear Ratio
   ─────────────────────────────────────────────────────────── */
function GearRatioCalculator() {
  const [n1, setN1] = useState('');
  const [n2, setN2] = useState('');
  const [inputRpm, setInputRpm] = useState('');
  const [inputTorque, setInputTorque] = useState('');
  const N1 = num(n1), N2 = num(n2), rpm = num(inputRpm), Tq = num(inputTorque);
  const ratio = N1 > 0 && N2 > 0 ? N2 / N1 : null;
  const outRpm = ratio && rpm > 0 ? rpm / ratio : null;
  const outTorque = ratio && Tq > 0 ? Tq * ratio : null;
  const rows = ratio !== null
    ? [
        { label: 'Driver teeth N1', value: n1, unit: 'teeth' },
        { label: 'Driven teeth N2', value: n2, unit: 'teeth' },
        { label: 'Gear ratio', value: ratio.toFixed(3), unit: '—' },
        ...(outRpm !== null ? [{ label: 'Output speed', value: outRpm.toFixed(2), unit: 'rpm' }] : []),
        ...(outTorque !== null ? [{ label: 'Output torque', value: outTorque.toFixed(3), unit: 'N·m' }] : []),
      ]
    : [];

  return (
    <CalcShell icon="⚙️" title="Gear Ratio" tagline="Spur-gear train ratio, output speed, and output torque from tooth counts.">
      <div className="grid grid-cols-2 gap-3">
        <NumField label="Driver teeth N1" value={n1} onChange={setN1} unit="teeth" />
        <NumField label="Driven teeth N2" value={n2} onChange={setN2} unit="teeth" />
        <NumField label="Input speed" value={inputRpm} onChange={setInputRpm} unit="rpm" />
        <NumField label="Input torque" value={inputTorque} onChange={setInputTorque} unit="N·m" />
      </div>
      <div className={`mt-4 rounded-xl border px-4 py-3 ${ratio !== null ? 'border-primary/30 bg-primary/5' : 'border-border bg-muted/30'}`}>
        <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Result</p>
        {ratio !== null
          ? <div className="space-y-1">
              <ResultRow label="Gear ratio (N2/N1)" value={ratio.toFixed(3)} unit="—" accent />
              {outRpm !== null && <ResultRow label="Output speed" value={outRpm.toFixed(2)} unit="rpm" />}
              {outTorque !== null && <ResultRow label="Output torque" value={outTorque.toFixed(3)} unit="N·m" />}
            </div>
          : <p className="text-sm text-muted-foreground">Enter driver and driven tooth counts.</p>}
      </div>
      <ExportBar
        disabled={ratio === null}
        rows={rows}
        payload={{ calculator: 'Gear Ratio', filename: 'gear-ratio', inputs: { N1: n1, N2: n2, inputRpm, inputTorque }, results: { ratio, outRpm, outTorque } }}
        pdf={{ title: 'Gear Ratio Calculation', subtitle: 'Spur gear train (ideal, no losses)', formula: 'i = N2 / N1\nω_out = ω_in / i\nT_out = T_in · i', source: 'Shigley, Mechanical Engineering Design. Ideal ratio — efficiency losses not included.' }}
      />
      <FormulaDoc
        formula="i = N2 / N1   |   ω_out = ω_in / i   |   T_out = T_in · i"
        plain="The gear ratio i is the driven tooth count N2 divided by the driver tooth count N1. Output speed drops by the ratio; output torque rises by the ratio (power conserved, ideal case with no friction losses)."
        source="Shigley, Mechanical Engineering Design. Ideal — does not include efficiency losses."
      />
    </CalcShell>
  );
}

/* ───────────────────────────────────────────────────────────
   6. Direct Stress σ = F/A
   ─────────────────────────────────────────────────────────── */
function StressCalculator() {
  const [force, setForce] = useState('');
  const [area, setArea] = useState('');
  const F = num(force), A = num(area);
  const stress = F > 0 && A > 0 ? F / A : null;
  const rows = stress !== null
    ? [
        { label: 'Force F', value: force, unit: 'N' },
        { label: 'Cross-section A', value: area, unit: 'm²' },
        { label: 'Normal stress σ', value: stress.toExponential(4), unit: 'Pa' },
        { label: 'Normal stress σ', value: (stress / 1e6).toFixed(6), unit: 'MPa' },
      ]
    : [];

  return (
    <CalcShell icon="🔬" title="Direct Stress" tagline="Uniaxial normal stress σ = F/A with automatic Pa → MPa conversion.">
      <div className="grid grid-cols-2 gap-3">
        <NumField label="Force F" value={force} onChange={setForce} unit="N" />
        <NumField label="Area A" value={area} onChange={setArea} unit="m²" />
      </div>
      <div className={`mt-4 rounded-xl border px-4 py-3 ${stress !== null ? 'border-primary/30 bg-primary/5' : 'border-border bg-muted/30'}`}>
        <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Result</p>
        {stress !== null
          ? <div className="space-y-1">
              <ResultRow label="σ (Pa)" value={stress.toExponential(4)} unit="Pa" accent />
              <ResultRow label="σ (MPa)" value={(stress / 1e6).toFixed(6)} unit="MPa" />
            </div>
          : <p className="text-sm text-muted-foreground">Enter force and area.</p>}
      </div>
      <ExportBar
        disabled={stress === null}
        rows={rows}
        payload={{ calculator: 'Direct Stress', filename: 'direct-stress', inputs: { F: force, A: area }, results: { stress_Pa: stress, stress_MPa: stress ? stress / 1e6 : null } }}
        pdf={{ title: 'Direct Stress Calculation', subtitle: 'Uniaxial normal stress', formula: 'σ = F / A', source: 'Hibbeler, Mechanics of Materials. Uniform stress assumption over the section.' }}
      />
      <FormulaDoc
        formula="σ = F / A"
        plain="Normal stress σ equals the axial force F divided by the cross-sectional area A, in pascals (1 Pa = 1 N/m²). Assumes uniform stress distribution over the section."
        source="Hibbeler, Mechanics of Materials."
      />
    </CalcShell>
  );
}

/* ───────────────────────────────────────────────────────────
   7. Pipe Flow — Darcy–Weisbach (Swamee–Jain friction factor)
   ─────────────────────────────────────────────────────────── */
function PipeFlowCalculator() {
  const [flow, setFlow] = useState(''); // m³/s
  const [dia, setDia] = useState(''); // m
  const [len, setLen] = useState(''); // m
  const [rho, setRho] = useState('998.2');
  const [mu, setMu] = useState('0.001002');
  const [eps, setEps] = useState('0.000045'); // m, drawn tubing roughness
  const Q = num(flow), D = num(dia), L = num(len), rhoN = num(rho), muN = num(mu), epsN = num(eps);
  const valid = Q > 0 && D > 0 && L > 0 && rhoN > 0 && muN > 0 && epsN >= 0;
  const A = valid ? (Math.PI * D * D) / 4 : null;
  const v = A ? Q / A : null;
  const Re = v ? (rhoN * v * D) / muN : null;
  // Laminar and turbulent regimes use different friction factors. The
  // transitional range is intentionally left without a pressure estimate.
  const f = Re && Re < 2300 ? 64 / Re : Re && Re > 4000 ? 0.25 / Math.pow(Math.log10(epsN / (3.7 * D) + 5.74 / Math.pow(Re, 0.9)), 2) : null;
  const dp = f && v ? (f * L * rhoN * v * v) / (2 * D) : null; // Pa
  const rows = dp !== null
    ? [
        { label: 'Flow rate Q', value: flow, unit: 'm³/s' },
        { label: 'Diameter D', value: dia, unit: 'm' },
        { label: 'Length L', value: len, unit: 'm' },
        { label: 'Velocity v', value: v.toFixed(4), unit: 'm/s' },
        { label: 'Reynolds Re', value: Re.toLocaleString(undefined, { maximumFractionDigits: 0 }), unit: '—' },
        { label: 'Darcy f', value: f.toFixed(5), unit: '—' },
        { label: 'Pressure drop Δp', value: dp.toFixed(2), unit: 'Pa' },
      ]
    : [];

  return (
    <CalcShell icon="💧" title="Pipe Pressure Drop" tagline="Darcy–Weisbach pressure drop: 64/Re for laminar flow and Swamee–Jain for turbulent flow.">
      <div className="grid grid-cols-2 gap-3">
        <NumField label="Flow rate Q" value={flow} onChange={setFlow} unit="m³/s" />
        <NumField label="Diameter D" value={dia} onChange={setDia} unit="m" />
        <NumField label="Length L" value={len} onChange={setLen} unit="m" />
        <NumField label="Roughness ε" value={eps} onChange={setEps} unit="m" />
        <NumField label="Density ρ" value={rho} onChange={setRho} unit="kg/m³" />
        <NumField label="Viscosity μ" value={mu} onChange={setMu} unit="Pa·s" />
      </div>
      <div className={`mt-4 rounded-xl border px-4 py-3 ${dp !== null ? 'border-primary/30 bg-primary/5' : 'border-border bg-muted/30'}`}>
        <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Result</p>
        {dp !== null
          ? <div className="space-y-1">
              <ResultRow label="Velocity v" value={v.toFixed(4)} unit="m/s" />
              <ResultRow label="Reynolds Re" value={Re.toLocaleString(undefined, { maximumFractionDigits: 0 })} unit="—" />
              <ResultRow label="Darcy f" value={f.toFixed(5)} unit="—" />
              <ResultRow label="Pressure drop Δp" value={dp.toFixed(2)} unit="Pa" accent />
            </div>
          : <p className="text-sm text-muted-foreground">{Re && Re >= 2300 && Re <= 4000 ? 'Transitional flow: a reliable friction factor cannot be estimated with this calculator. Use a suitable validated method.' : 'Enter flow, diameter, and length (defaults are water at 20 °C).'}</p>}
      </div>
      <ExportBar
        disabled={dp === null}
        rows={rows}
        payload={{ calculator: 'Pipe Pressure Drop (Darcy–Weisbach)', filename: 'pipe-pressure-drop', inputs: { Q: flow, D: dia, L: len, eps, rho, mu }, results: { v, Re, f, dp } }}
        pdf={{ title: 'Pipe Pressure Drop Calculation', subtitle: 'Darcy–Weisbach pressure drop', formula: 'Δp = f · (L/D) · (ρ·v²/2)\nLaminar: f = 64/Re; turbulent: Swamee–Jain', source: 'Swamee & Jain (1976), explicit Colebrook approximation for turbulent flow. Laminar pipe flow: f = 64/Re. Transitional flow is not estimated.' }}
      />
      <FormulaDoc
        formula="Δp = f · (L/D) · (ρ·v²/2)   |   laminar: f = 64/Re   |   turbulent: f = 0.25 / [log₁₀( ε/(3.7·D) + 5.74/Re^0.9 )]²"
        plain="Pressure drop Δp equals the Darcy friction factor f times (L/D) times the dynamic pressure (ρ·v²/2). For laminar flow f = 64/Re; for turbulent flow Swamee–Jain approximates the Colebrook–White equation. This calculator does not estimate transitional flow."
        source="Swamee & Jain (1976), J. Hydraul. Div. ASCE. Swamee–Jain is used for turbulent flow (Re > 4000); laminar flow uses f = 64/Re."
      />
    </CalcShell>
  );
}

/* ───────────────────────────────────────────────────────────
   Page
   ─────────────────────────────────────────────────────────── */

const CALC_NAV = [
  { id: 'units', label: 'Unit Converter' },
  { id: 'reynolds', label: 'Reynolds Number' },
  { id: 'beam', label: 'Beam Deflection' },
  { id: 'bolt', label: 'Bolt Torque' },
  { id: 'gear', label: 'Gear Ratio' },
  { id: 'stress', label: 'Direct Stress' },
  { id: 'pipe', label: 'Pipe Pressure Drop' },
];

export default function CalculatorsPage() {
  const [active, setActive] = useState('units');
  const calc = useMemo(() => {
    switch (active) {
      case 'reynolds': return <ReynoldsCalculator />;
      case 'beam': return <BeamDeflectionCalculator />;
      case 'bolt': return <BoltTorqueCalculator />;
      case 'gear': return <GearRatioCalculator />;
      case 'stress': return <StressCalculator />;
      case 'pipe': return <PipeFlowCalculator />;
      default: return <UnitConverter />;
    }
  }, [active]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Calculators — Beam, Flow, Stress, Gear, Bolt | MechEngi 10X</title>
        <meta name="description" content="Explore free engineering calculators for unit conversion, beam deflection, flow, stress, gears and bolt torque, with formulas and export options." />
      </Helmet>

      <SiteHeader />

      <div className="border-b border-border bg-card/30 py-10">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="flex items-center gap-2 mb-3">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Calculator className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Documented formulas · Exportable results</p>
          </div>
          <h1 className="font-display text-3xl font-bold sm:text-4xl">Engineering Calculators</h1>
          <p className="mt-2 max-w-2xl text-muted-foreground">
            Real engineering calculations with documented formulas and sources. Export every result as CSV, JSON, or a
            print-ready PDF calculation record for independent review — no sign-up, no paywall.
          </p>
          <div className="mt-4 flex items-start gap-2 rounded-lg border border-border bg-muted/30 px-3 py-2 text-[11px] text-muted-foreground max-w-2xl">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
            <span>
              Calculators use standard textbook formulas (Hibbeler, Shigley, Munson, Gere & Timoshenko) and SI/imperial
              conversion factors, some of which are rounded. Each tool lists its formula and source. Results are for engineering
              reference — verify against your design code before sign-off.
            </span>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
          {/* Sidebar nav */}
          <aside className="lg:sticky lg:top-20 lg:self-start">
            <p className="mb-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Calculators</p>
            <nav className="flex flex-wrap gap-1.5 lg:flex-col">
              {CALC_NAV.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setActive(c.id)}
                  className={`rounded-lg border px-3 py-2 text-left text-sm transition-colors ${
                    active === c.id
                      ? 'border-primary/40 bg-primary/10 text-primary'
                      : 'border-border text-muted-foreground hover:border-primary/30 hover:text-foreground'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </nav>
            <div className="mt-6 hidden rounded-xl border border-border bg-card p-4 lg:block">
              <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Export formats</p>
              <ul className="mt-2 space-y-1.5 text-xs text-muted-foreground">
                <li><span className="font-mono text-primary">CSV</span> — spreadsheet import</li>
                <li><span className="font-mono text-primary">JSON</span> — structured / API</li>
                <li><span className="font-mono text-primary">PDF</span> — print-ready record</li>
              </ul>
            </div>
          </aside>

          {/* Active calculator */}
          <div className="min-w-0">
            <div className="mx-auto max-w-2xl">{calc}</div>

            {/* Consultancy CTA — custom calculation automation */}
            <div className="mx-auto mt-10 max-w-2xl overflow-hidden rounded-2xl border border-green-500/30 bg-[hsl(222_45%_7%)] p-6 sm:p-8">
              <div className="flex items-center gap-2">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-green-500/15">
                  <Calculator className="h-4 w-4 text-green-400" />
                </span>
                <span className="font-mono text-[10px] uppercase tracking-widest text-green-400">Custom Automation</span>
              </div>
              <h2 className="mt-4 font-display text-xl font-bold text-white sm:text-2xl">
                Automate This Calculation in SOLIDWORKS
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-white/80">
                We build custom VBA macros, JSON data processors, and automated QA routines for engineering teams.
              </p>
              <p className="mt-3 text-sm leading-relaxed text-white/70">
                Need custom engineering calculations automated in SOLIDWORKS? Request a custom macro or CAD-to-ERP
                workflow audit.
              </p>
              <Link
                to="/stack-consulting#consult"
                className="mt-5 inline-flex min-h-[48px] items-center gap-2 rounded-xl bg-green-500 px-6 py-3 font-semibold text-white shadow-lg shadow-green-500/20 transition-all hover:bg-green-400 active:scale-[0.98]"
              >
                Book an Automation Audit <ArrowRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="mx-auto mt-10 max-w-2xl rounded-2xl border border-border bg-card p-6">
              <h2 className="font-display text-lg font-bold">Accuracy & verification</h2>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                <li className="flex gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />Every formula is shown inline with its plain-English explanation and textbook source.</li>
                <li className="flex gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />Some unit conversions use rounded factors; confirm precision against an authoritative reference.</li>
                <li className="flex gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />Each calculator states its assumptions and the regime where it is valid.</li>
                <li className="flex gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />Results are generated locally in your browser — no data leaves your device.</li>
              </ul>
              <p className="mt-4 text-xs text-muted-foreground">
                These tools are engineering reference aids, not a substitute for code-compliant design verification. Always
                confirm results against the applicable design standard (ASME, ISO, Eurocode, etc.) before sign-off.
              </p>
            </div>

            <div className="mx-auto mt-6 max-w-2xl text-center">
              <Link to="/free-tools" className="inline-flex items-center gap-1.5 font-mono text-xs text-muted-foreground hover:text-primary">
                Browse free engineering software <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
