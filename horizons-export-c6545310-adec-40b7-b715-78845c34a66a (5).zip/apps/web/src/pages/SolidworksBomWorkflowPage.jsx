import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Workflow, Copy, Check, AlertTriangle, ListChecks, ArrowRight, ArrowLeft, FileJson, Webhook } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

/* ── Copy-to-clipboard code block ─────────────────────────── */
function CodeBlock({ code, label, lang = 'text' }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // clipboard may be blocked; ignore
    }
  };
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-[#0F172A]">
      <div className="flex items-center justify-between border-b border-slate-700/60 bg-[#0F172A] px-3 py-2">
        <span className="font-mono text-[11px] uppercase tracking-wider text-[#CBD5E1]">{lang} · {label}</span>
        <button
          onClick={copy}
          className="flex items-center gap-1.5 rounded-md border border-slate-700 px-2.5 py-1 font-mono text-[11px] text-[#CBD5E1] transition-colors hover:border-[#60A5FA] hover:text-[#93C5FD] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#60A5FA] focus-visible:outline-offset-2"
          aria-label={`Copy ${label} code`}
        >
          {copied ? <Check className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="overflow-x-auto p-4 text-[12px] leading-relaxed">
        <code className="font-mono text-[#F8FAFC] whitespace-pre">{code}</code>
      </pre>
    </div>
  );
}

const VBA_CODE = `' ILLUSTRATIVE DRAFT — not production-ready. Test on a copy before any production use.
' Extracts a flat BOM from the active SOLIDWORKS assembly to bom_output.json.
' Requires the SOLIDWORKS type library. Run from the SOLIDWORKS VBA editor.
' Assumptions: an assembly is open; components expose custom properties
' "PartNumber", "Description", "Material". Adjust property names to match
' your template. Credential/security: this macro only writes a local JSON
' file — it does not transmit data. Review the output before sending it to
' any webhook or ERP system.

Option Explicit

Sub ExportBomToJson()
    Dim swApp As Object
    Dim swModel As Object
    Dim swAssy As Object
    Dim vComps As Variant
    Dim i As Long
    Dim lines As String

    Set swApp = Application.SldWorks
    Set swModel = swApp.ActiveDoc
    If swModel Is Nothing Then Exit Sub
    If swModel.GetType <> 2 Then Exit Sub ' swDocASSEMBLY

    Set swAssy = swModel
    vComps = swAssy.GetComponents(False)
    If IsEmpty(vComps) Then Exit Sub

    lines = ""
    For i = 0 To UBound(vComps)
        Dim swComp As Object
        Set swComp = vComps(i)

        Dim partNo As String, desc As String, material As String
        partNo = ReadCustomProp(swComp, "PartNumber")
        desc = ReadCustomProp(swComp, "Description")
        material = ReadCustomProp(swComp, "Material")

        Dim qty As Long
        qty = 1 ' flat BOM; group/sum upstream of ERP if needed

        Dim name As String
        name = swComp.Name2

        lines = lines & "{" & _
          """part_number"":""" & EscapeJson(partNo) & """," & _
          """description"":""" & EscapeJson(desc) & """," & _
          """material"":""" & EscapeJson(material) & """," & _
          """quantity"":" & qty & "," & _
          """component"":""" & EscapeJson(name) & """" & _
          "},"
    Next i

    If Len(lines) > 0 Then lines = Left(lines, Len(lines) - 1)
    Dim json As String
    json = "{""assembly"":""" & EscapeJson(swModel.GetTitle) & """,""line_items"":[" & lines & "]}"

    Dim f As Integer
    f = FreeFile
    Open "C:\\Temp\\bom_output.json" For Output As #f
    Print #f, json
    Close #f
    swApp.SendMsgToUser "BOM written to C:\\Temp\\bom_output.json"
End Sub

Private Function ReadCustomProp(swComp As Object, propName As String) As String
    On Error Resume Next
    Dim swModel As Object
    Set swModel = swComp.GetModelDoc2
    If swModel Is Nothing Then
        ReadCustomProp = ""
        Exit Function
    End If
    Dim valOut As String
    valOut = ""
    swModel.Extension.CustomPropertyManager("").Get2 propName, valOut, valOut
    ReadCustomProp = valOut
End Function

Private Function EscapeJson(s As String) As String
    If IsNull(s) Then s = ""
    s = Replace(s, "\", "\\")
    s = Replace(s, """", "\""")
    s = Replace(s, vbCr, " ")
    s = Replace(s, vbLf, " ")
    EscapeJson = s
End Function`;

const JSON_SCHEMA = `{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "SOLIDWORKS BOM Export",
  "type": "object",
  "required": ["assembly", "line_items"],
  "properties": {
    "assembly": {
      "type": "string",
      "description": "Title of the source SOLIDWORKS assembly document."
    },
    "line_items": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["part_number", "quantity"],
        "properties": {
          "part_number": { "type": "string" },
          "description":  { "type": "string" },
          "material":    { "type": "string" },
          "quantity":    { "type": "integer", "minimum": 1 },
          "component":   { "type": "string", "description": "SOLIDWORKS component reference name." }
        }
      }
    }
  }
}`;

const N8N_NODE = `{
  "name": "SOLIDWORKS BOM -> Excel QA",
  "nodes": [
    {
      "parameters": {
        "path": "bom-ingest",
        "httpMethod": "POST",
        "responseMode": "responseNode"
      },
      "name": "Webhook (BOM Payload)",
      "type": "n8n-nodes-base.webhook",
      "typeVersion": 1,
      "position": [240, 300]
    },
    {
      "parameters": {
        "functionCode": "const items = $input.all();\\nconst rows = (items[0] && items[0].json && items[0].json.line_items) || [];\\nreturn rows.map(r => ({ json: { part_number: r.part_number || '', description: r.description || '', material: r.material || '', quantity: Number(r.quantity) || 0, component: r.component || '' } }));"
      },
      "name": "Format Line Items",
      "type": "n8n-nodes-base.function",
      "typeVersion": 1,
      "position": [460, 300]
    },
    {
      "parameters": {
        "operation": "append",
        "file": "/data/bom_qa_workbook.xlsx"
      },
      "name": "Append to Excel QA Workbook",
      "type": "n8n-nodes-base.excel",
      "typeVersion": 1,
      "position": [680, 300]
    },
    {
      "parameters": {
        "respondWith": "json",
        "responseBody": "={ \\"status\\": \\"received\\", \\"line_items\\": {{ $json.quantity || 0 }} }"
      },
      "name": "Respond",
      "type": "n8n-nodes-base.respondToWebhook",
      "typeVersion": 1,
      "position": [900, 300]
    }
  ],
  "connections": {
    "Webhook (BOM Payload)": { "main": [[{ "node": "Format Line Items", "type": "main", "index": 0 }]] },
    "Format Line Items": { "main": [[{ "node": "Append to Excel QA Workbook", "type": "main", "index": 0 }]] },
    "Append to Excel QA Workbook": { "main": [[{ "node": "Respond", "type": "main", "index": 0 }]] }
  }
}`;

const CHECKLIST = [
  'Line-item count in the Excel QA report matches the assembly component count.',
  'Every line item has a non-empty Part Number; blanks are flagged for review.',
  'Quantities are positive integers; zero or negative values are rejected.',
  'Material and Description fields are present (warn, do not block, if empty).',
  'Revision/configuration of the source assembly is recorded with the export.',
  'The JSON payload was sent over HTTPS to an authenticated n8n webhook endpoint.',
  'Failed rows are logged to a review queue rather than silently dropped.',
  'A human reviewer signs off the QA workbook before any ERP insert.',
];

const DISCLAIMER =
  'This macro workflow automates BOM data extraction and formatting. It does not replace licensed professional engineering design sign-off, drawing verification, or certified BOM/ERP validation. The VBA macro is an illustrative draft — test it on a copy of your data before any production use. Confirm custom-property names, webhook authentication, and ERP field mapping against your own template and security policy.';

export default function SolidworksBomWorkflowPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Automating SOLIDWORKS BOM Extraction → JSON → n8n → Excel QA Reports — MechEngi 10X</title>
        <meta name="description" content="A deep technical workflow for automating SOLIDWORKS BOM extraction to JSON, piping it through an n8n webhook, and producing an Excel QA report. Copyable VBA macro, JSON schema, and n8n node config with validation checklist and safety disclaimer." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Workflow className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">High-Moat Workflow</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-3xl font-bold leading-tight sm:text-4xl md:text-5xl">
            Automating SOLIDWORKS BOM Extraction → JSON → n8n → Excel QA Reports
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            A copyable, developer-focused pipeline that extracts a Bill of Materials from a SOLIDWORKS assembly,
            emits a typed JSON payload, ingests it through an n8n webhook, and produces an Excel QA report for
            human sign-off. Every code block is an illustrative draft — test on a copy before production use.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
        {/* Overview & architecture */}
        <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
          <div className="space-y-4">
            <h2 className="font-display text-xl font-bold sm:text-2xl">Overview &amp; System Architecture</h2>
            <p className="text-sm leading-relaxed text-foreground/85">
              Re-keying a CAD Bill of Materials into ERP or QA systems is slow and error-prone. This workflow
              removes the manual handoff: a SOLIDWORKS VBA macro iterates the active assembly, extracts part
              number, description, material, quantity, and custom properties, and writes a typed JSON file. An
              n8n webhook receives the payload, formats the line items, and appends them to an Excel QA workbook
              for human review before any ERP insert.
            </p>
            <div className="rounded-2xl border border-border bg-card p-5">
              <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Pipeline</p>
              <ol className="mt-3 space-y-2 text-sm">
                <li className="flex items-start gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" /><span><span className="font-medium text-foreground">VBA Macro</span> — iterates assembly components, reads custom properties, writes <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">bom_output.json</code>.</span></li>
                <li className="flex items-start gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" /><span><span className="font-medium text-foreground">Local JSON</span> — typed payload validated against the JSON schema below.</span></li>
                <li className="flex items-start gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" /><span><span className="font-medium text-foreground">n8n Webhook</span> — receives the HTTP POST, formats line items, appends to Excel.</span></li>
                <li className="flex items-start gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" /><span><span className="font-medium text-foreground">Excel QA Report</span> — human-reviewed workbook signed off before ERP insert.</span></li>
              </ol>
            </div>
          </div>
          <div className="rounded-2xl border border-border bg-card p-5">
            <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Assumptions, credentials &amp; limitations</p>
            <ul className="mt-3 space-y-2 text-sm leading-relaxed text-muted-foreground">
              <li>• A SOLIDWORKS assembly is open with components exposing custom properties named <span className="font-mono text-xs text-foreground">PartNumber</span>, <span className="font-mono text-xs text-foreground">Description</span>, <span className="font-mono text-xs text-foreground">Material</span>. Adjust names to match your template.</li>
              <li>• The macro writes a local file only — it does not transmit data. Sending the JSON to n8n is a separate, authenticated step.</li>
              <li>• The n8n webhook must use HTTPS and authentication (header secret / OAuth). Never expose an unauthenticated ingestion endpoint.</li>
              <li>• Excel append assumes a workbook with matching columns; map fields explicitly before any ERP insert.</li>
              <li>• Quantities are flat (1 per component occurrence). Group/sum upstream of ERP if your workflow requires consolidated quantities.</li>
              <li>• Application/API limits: SOLIDWORKS API behavior and property access can vary by release and license tier — confirm on your version.</li>
            </ul>
          </div>
        </div>

        {/* Step 1 — VBA */}
        <div className="mt-14">
          <h2 className="flex items-center gap-2 font-display text-xl font-bold sm:text-2xl">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 font-mono text-sm text-primary">1</span>
            SOLIDWORKS VBA Macro
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Illustrative draft — iterates assembly components, extracts Part Number, Description, Material, Quantity,
            and the component reference, then writes <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">bom_output.json</code>. Not production-ready; test on a copy.
          </p>
          <div className="mt-4">
            <CodeBlock code={VBA_CODE} label="bom_export.swp" lang="VBA" />
          </div>
        </div>

        {/* Step 2 — JSON schema */}
        <div className="mt-14">
          <h2 className="flex items-center gap-2 font-display text-xl font-bold sm:text-2xl">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 font-mono text-sm text-primary">2</span>
            <FileJson className="h-5 w-5 text-primary" /> JSON Output Schema
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            The structure emitted by the macro and expected by the n8n webhook.
          </p>
          <div className="mt-4">
            <CodeBlock code={JSON_SCHEMA} label="bom_output.json" lang="JSON Schema" />
          </div>
        </div>

        {/* Step 3 — n8n node */}
        <div className="mt-14">
          <h2 className="flex items-center gap-2 font-display text-xl font-bold sm:text-2xl">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 font-mono text-sm text-primary">3</span>
            <Webhook className="h-5 w-5 text-primary" /> n8n Webhook Node Configuration
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Copyable n8n workflow JSON: a webhook receives the POST payload, a function node formats the line items,
            an Excel node appends to the QA workbook, and a respond node acknowledges receipt. Import via n8n
            &ldquo;Import from Clipboard&rdquo;.
          </p>
          <div className="mt-4">
            <CodeBlock code={N8N_NODE} label="n8n workflow" lang="JSON" />
          </div>
        </div>

        {/* Step 4 — validation & disclaimer */}
        <div className="mt-14">
          <h2 className="flex items-center gap-2 font-display text-xl font-bold sm:text-2xl">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 font-mono text-sm text-primary">4</span>
            <ListChecks className="h-5 w-5 text-primary" /> Validation &amp; Disclaimer
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Step-by-step Excel QA verification checklist to run before any ERP insert.
          </p>
          <ul className="mt-4 space-y-2 rounded-2xl border border-border bg-card p-5">
            {CHECKLIST.map((c) => (
              <li key={c} className="flex items-start gap-2 text-sm">
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-green-400" />
                <span className="text-foreground/85">{c}</span>
              </li>
            ))}
          </ul>
          <div className="mt-5 flex items-start gap-2.5 rounded-xl border border-amber-500/25 bg-amber-500/5 px-4 py-3">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
            <p className="text-xs leading-relaxed text-muted-foreground">
              <span className="font-semibold text-foreground">Disclaimer: </span>
              {DISCLAIMER}
            </p>
          </div>
        </div>

        <div className="mt-12 rounded-2xl border border-border bg-card p-6 text-center">
          <h2 className="font-display text-lg font-bold">More engineering workflows</h2>
          <p className="mx-auto mt-2 max-w-xl text-sm text-muted-foreground">
            Browse the full workflow library for CAD QA, CAD-to-ERP, and FEA mesh convergence templates.
          </p>
          <Link
            to="/workflows"
            className="mt-4 inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
          >
            View workflow library <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="mt-10">
          <Link
            to="/workflows"
            className="inline-flex min-h-[44px] items-center gap-2 font-mono text-sm text-muted-foreground hover:text-primary"
          >
            <ArrowLeft className="h-4 w-4" /> Back to workflow library
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
