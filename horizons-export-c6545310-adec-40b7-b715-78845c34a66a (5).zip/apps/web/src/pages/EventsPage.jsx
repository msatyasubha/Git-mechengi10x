import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Calendar, Clock, Video, ArrowRight, Users } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { events, eventCategories, getEventsByCategory } from '@/data/events';

export default function EventsPage() {
  const [cat, setCat] = useState('all');
  const filtered = getEventsByCategory(cat);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Webinar Topics & Events | MechEngi 10X</title>
        <meta name="description" content="Explore engineering webinar topics covering AI, CAD, simulation and automation. Check each listing’s date and availability before registering." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Video className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Webinar Topics</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            Engineering webinar topics
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            Explore webinar topics on engineering tools and workflows. Listed dates and speaker or sponsor details
            have not been independently verified. Check the date and availability before registering.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="flex flex-wrap gap-2">
          {eventCategories.map((c) => (
            <button
              key={c.id}
              onClick={() => setCat(c.id)}
              className={`rounded-full border px-4 py-1.5 font-mono text-xs uppercase tracking-wider transition-colors ${
                cat === c.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-foreground/40 hover:text-foreground'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 pb-20">
        <div className="grid gap-6 md:grid-cols-2">
          {filtered.map((ev) => (
            <Link
              key={ev.slug}
              to={`/events/${ev.slug}`}
              className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all hover:-translate-y-1 hover:border-primary/40"
            >
              <div className="relative h-32" style={{ background: ev.cover }}>
                {ev.sponsor && (
                  <span className="absolute right-4 top-4 rounded-md bg-background/80 px-2 py-1 font-mono text-[10px] uppercase tracking-wider backdrop-blur">
                    Listed sponsor (unverified): {ev.sponsor.name}
                  </span>
                )}
              </div>
              <div className="flex flex-1 flex-col p-5">
                <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {ev.date}</span>
                  <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {ev.time} {ev.timezone}</span>
                </div>
                <h2 className="mt-3 font-display text-lg font-bold leading-snug group-hover:text-primary">{ev.title}</h2>
                <p className="mt-2 flex-1 text-sm text-muted-foreground line-clamp-2">{ev.description}</p>
                <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
                  <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{ev.speaker}</span>
                  <span className="flex items-center gap-1 font-mono text-[10px] uppercase tracking-wider text-primary">
                    View details <ArrowRight className="h-3.5 w-3.5" />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
