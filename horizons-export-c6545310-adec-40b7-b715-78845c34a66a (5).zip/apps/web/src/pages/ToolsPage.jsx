import { useState, useEffect, useMemo, useDeferredValue, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { useSearchParams, Link } from 'react-router-dom';
import { Search, SlidersHorizontal, Zap } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import ToolCard from '@/components/ToolCard';
import CompareTray, { MAX_SELECT } from '@/components/CompareTray';
import ReviewModal from '@/components/ReviewModal';
import { categories, tools } from '@/data/tools';
import { trackSearch } from '@/lib/analytics';
import { useCurrency } from '@/contexts/CurrencyContext';
import { FX_CAVEAT } from '@/lib/currency';

const sortOptions = [
  { id: 'score', label: 'Editorial Pick' },
  { id: 'name', label: 'Name A–Z' },
  { id: 'price-asc', label: 'Price: Low to High' },
];

const CATEGORY_SEO = {
  ai: { title: 'AI Tools for Engineers Directory — MechEngi 10X', desc: 'Explore AI assistants and coding copilots for engineering workflows, with tool profiles, pricing context and unrated score status.' },
  cad: { title: 'CAD & 3D Design Software Directory — MechEngi 10X', desc: 'Explore CAD platforms including SOLIDWORKS, Fusion 360, Onshape and FreeCAD, with specifications and pricing context.' },
  simulation: { title: 'Simulation & FEA Engineering Software Directory — MechEngi 10X', desc: 'Explore FEA, CFD and thermal simulation software with tool profiles, specifications and pricing context.' },
  automation: { title: 'Engineering Automation Tools Directory — MechEngi 10X', desc: 'Explore automation tools including Zapier, Make and n8n for engineering workflows, with pricing context and use cases.' },
  management: { title: 'Engineering Management Software Directory — MechEngi 10X', desc: 'Explore project and knowledge management tools for engineering teams, with use cases and pricing context.' },
  learning: { title: 'Engineering Learning & Courses Directory — MechEngi 10X', desc: 'Explore engineering learning platforms including Coursera, Udemy and MIT OpenCourseWare.' },
  software: { title: 'Software Engineering Tools Directory — MechEngi 10X', desc: 'Explore developer tools including VS Code, Docker, Kubernetes and Git for engineering workflows.' },
};

export default function ToolsPage() {
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState(params.get('q') || '');
  const [sort, setSort] = useState('score');
  const { currency } = useCurrency();
  const [selected, setSelected] = useState([]);
  const [reviewTool, setReviewTool] = useState(null);

  const toggleSelect = (slug) => {
    setSelected((prev) => {
      if (prev.includes(slug)) return prev.filter((s) => s !== slug);
      if (prev.length >= MAX_SELECT) return prev; // ignore beyond max
      return [...prev, slug];
    });
  };

  // Instant client-side search: the input stays responsive while the heavy
  // filter/sort pass runs on the deferred value (React 18 useDeferredValue).
  const deferredQuery = useDeferredValue(query);
  const searching = deferredQuery !== query;
  const searchRef = useRef(null);

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === '/' && document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA' && document.activeElement?.tagName !== 'SELECT') {
        e.preventDefault();
        searchRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const activeCat = params.get('cat') || 'all';
  const seo = activeCat !== 'all' ? CATEGORY_SEO[activeCat] : null;
  // Search and category parameters filter this directory; the unfiltered page is canonical.
  const canonical = 'https://mechengi10x.com/tools';
  const freeOnly = params.get('free') === '1';
  const freeTierOnly = params.get('freetier') === '1';

  const setCategory = (id) => {
    const next = new URLSearchParams(params);
    if (id === 'all') next.delete('cat');
    else next.set('cat', id);
    next.delete('q');
    setQuery('');
    setParams(next);
  };

  const filtered = useMemo(() => {
    let list = tools;
    if (activeCat !== 'all') list = list.filter((t) => t.category === activeCat);
    // Free only = $0/year true cost (not "has a free tier" of a paid product)
    if (freeOnly) list = list.filter((t) => (t.pricing?.paidFrom ?? 0) === 0 && !t.pricing?.contactForPricing);
    // Free tier = tools that offer any free tier (including freemium)
    if (freeTierOnly) list = list.filter((t) => t.pricing?.free || (t.pricing?.paidFrom ?? 0) === 0);
    if (deferredQuery.trim()) {
      const q = deferredQuery.toLowerCase();
      list = list.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.tagline.toLowerCase().includes(q) ||
          t.vendor.toLowerCase().includes(q) ||
          t.category.includes(q)
      );
    }
    if (deferredQuery.trim()) trackSearch(deferredQuery.trim(), list.length);
    return [...list].sort((a, b) => {
      // Until benchmarks exist, surface featured entries without using legacy numeric scores.
      if (sort === 'score') return Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || a.name.localeCompare(b.name);
      if (sort === 'name') return a.name.localeCompare(b.name);
      if (sort === 'price-asc') return (a.pricing.paidFrom ?? Infinity) - (b.pricing.paidFrom ?? Infinity);
      return 0;
    });
  }, [activeCat, freeOnly, freeTierOnly, deferredQuery, sort]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{seo ? seo.title : 'Engineering Tools Directory — MechEngi 10X'}</title>
        <meta name="description" content={seo ? seo.desc : `Browse ${tools.length}+ engineering software tools across AI, CAD, simulation, automation, management, and learning. Filter by category, price, and free tier.`} />
        <link rel="canonical" href={canonical} />
      </Helmet>

      <SiteHeader />

      {/* Page header */}
      <div className="border-b border-border bg-card/30 py-10">
        <div className="mx-auto max-w-[90rem] px-5">
          <h1 className="font-display text-3xl font-bold sm:text-4xl">Engineering Tools Directory</h1>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <p className="text-muted-foreground">{tools.length} tools reviewed across {categories.length - 1} categories.</p>
            <div className="flex flex-wrap gap-2">
              <Link to="/wizard" className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/5 px-3 py-1 font-mono text-[10px] text-primary hover:bg-primary/10">
                <Zap className="h-3 w-3" /> Find the Right Tool
              </Link>
              <Link to="/emerging-tools" className="inline-flex items-center gap-1.5 rounded-full border border-amber-500/30 bg-amber-500/5 px-3 py-1 font-mono text-[10px] text-amber-400 hover:bg-amber-500/10">
                Emerging AI Tools
              </Link>
              <Link to="/about#methodology" className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1 font-mono text-[10px] text-muted-foreground hover:border-primary/30 hover:text-primary">
                Score Methodology
              </Link>
            </div>
          </div>
          {currency === 'INR' && (
            <p className="mt-3 max-w-2xl rounded-lg border border-border bg-muted/30 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
              {FX_CAVEAT}
            </p>
          )}

          {/* Search + Sort row */}
          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                ref={searchRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search tools by name, category, or use case…  (press / to focus)"
                className="search-bar h-11 w-full rounded-xl border border-border bg-card pl-10 pr-16 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
              <kbd className="pointer-events-none absolute right-3 top-1/2 hidden -translate-y-1/2 items-center gap-0.5 rounded-md border border-border bg-muted/60 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground sm:flex">
                <span className="text-[9px]">⌘</span>K
              </kbd>
            </div>
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4 shrink-0 text-muted-foreground" />
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                className="h-11 rounded-xl border border-border bg-card px-3 text-sm focus:border-primary focus:outline-none"
              >
                {sortOptions.map((o) => (
                  <option key={o.id} value={o.id}>{o.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Category filter */}
          <div className="mt-4 flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setCategory(c.id)}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                  activeCat === c.id
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/30 hover:text-foreground'
                }`}
              >
                {c.label}
              </button>
            ))}
            <button
              onClick={() => {
                const next = new URLSearchParams(params);
                if (freeOnly) next.delete('free');
                else next.set('free', '1');
                if (freeOnly) next.delete('freetier');
                setParams(next);
              }}
              className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                freeOnly
                  ? 'border-green-500/40 bg-green-500/10 text-green-400'
                  : 'border-border text-muted-foreground hover:border-green-500/30'
              }`}
            >
              Free only
            </button>
            <button
              onClick={() => {
                const next = new URLSearchParams(params);
                if (freeTierOnly) next.delete('freetier');
                else next.set('freetier', '1');
                if (freeTierOnly) next.delete('free');
                setParams(next);
              }}
              className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                freeTierOnly
                  ? 'border-green-500/40 bg-green-500/10 text-green-400'
                  : 'border-border text-muted-foreground hover:border-green-500/30'
              }`}
            >
              Has free tier
            </button>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className={`mx-auto max-w-[90rem] px-5 py-10 ${selected.length > 0 ? 'pb-32' : ''}`}>
        {filtered.length > 0 ? (
          <>
            <p className={`mb-6 font-mono text-xs ${searching ? 'text-primary' : 'text-muted-foreground'}`}>
              {searching ? 'Filtering…' : `${filtered.length} tool${filtered.length !== 1 ? 's' : ''} found`}
            </p>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filtered.map((tool) => (
                <ToolCard
                  key={tool.slug}
                  tool={tool}
                  selectable
                  selected={selected.includes(tool.slug)}
                  onToggleSelect={toggleSelect}
                  onReview={setReviewTool}
                />
              ))}
            </div>
          </>
        ) : (
          <div className="py-24 text-center">
            <p className="font-display text-xl font-semibold">No tools found</p>
            <p className="mt-2 text-muted-foreground">Try adjusting your search or filters.</p>
            <button
              onClick={() => { setQuery(''); setParams({}); }}
              className="mt-4 rounded-xl bg-primary px-6 py-2 font-medium text-primary-foreground"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>

      <SiteFooter />

      {/* Floating compare tray + matrix */}
      <CompareTray
        selected={selected}
        tools={tools}
        onRemove={(slug) => setSelected((p) => p.filter((s) => s !== slug))}
        onClear={() => setSelected([])}
      />

      {/* Community review modal */}
      <ReviewModal tool={reviewTool} open={!!reviewTool} onOpenChange={(v) => !v && setReviewTool(null)} />
    </div>
  );
}
