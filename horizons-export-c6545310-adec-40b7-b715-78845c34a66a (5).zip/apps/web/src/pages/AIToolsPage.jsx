import { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useSearchParams } from 'react-router-dom';
import { Search, ArrowRight, Zap, ExternalLink } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { aiToolProfiles, aiToolProfileCategories } from '@/data/aiToolProfiles';

function ProfileCard({ profile }) {
  return (
    <article className="group flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
      <div className="flex items-start gap-3">
        <span className="text-3xl">{profile.logoEmoji}</span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 font-mono text-[10px] text-primary">
              {aiToolProfileCategories.find(c => c.id === profile.category)?.label || profile.category}
            </span>
            {profile.badge && (
              <span className="rounded-full bg-accent/15 px-2 py-0.5 font-mono text-[10px] text-accent">
                {profile.badge}
              </span>
            )}
          </div>
          <h2 className="mt-1 font-display text-base font-bold leading-snug group-hover:text-primary">
            {profile.name}
          </h2>
          <p className="text-xs text-muted-foreground">{profile.vendor}</p>
        </div>
        <div className="flex flex-col items-end gap-1 shrink-0">
          <span className="font-mono text-[10px] text-muted-foreground">Not Yet Rated</span>
          <span className="font-mono text-[9px] text-muted-foreground/70">MechEngi Score</span>
        </div>
      </div>

      <p className="mt-3 line-clamp-2 flex-1 text-sm leading-relaxed text-muted-foreground">
        {profile.intro}
      </p>

      <div className="mt-3 flex items-center gap-2">
        <span className="font-mono text-[10px] text-muted-foreground">Editorial assessment pending — no fabricated ratings.</span>
      </div>

      <div className="mt-3 flex items-center gap-2">
        <span className={`rounded-full px-2 py-0.5 font-mono text-[10px] ${profile.pricing.free ? 'bg-green-500/10 text-green-400' : 'bg-muted text-muted-foreground'}`}>
          {profile.pricing.free ? 'Free tier' : `From $${profile.pricing.paidFrom}/mo`}
        </span>
      </div>

      <div className="mt-4 flex gap-2">
        <Link
          to={`/ai-tools/${profile.slug}`}
          className="flex-1 rounded-lg border border-border py-2 text-center font-mono text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
        >
          Full Profile<span className="sr-only">: {profile.name}</span>
        </Link>
        <a
          href={profile.affiliateUrl}
          target="_blank"
          rel="noopener noreferrer sponsored"
          className="flex items-center gap-1 rounded-lg bg-primary px-3 py-2 font-mono text-xs text-primary-foreground hover:opacity-90"
        >
          Try <ExternalLink className="h-3 w-3" />
        </a>
      </div>
    </article>
  );
}

export default function AIToolsPage() {
  const [query, setQuery] = useState('');
  const [params, setParams] = useSearchParams();
  const requestedCat = params.get('cat');
  const activeCat = aiToolProfileCategories.some((category) => category.id === requestedCat) ? requestedCat : 'all';
  const setActiveCat = (category) => {
    const next = new URLSearchParams(params);
    if (category === 'all') next.delete('cat');
    else next.set('cat', category);
    setParams(next);
  };

  const filtered = useMemo(() => {
    let list = aiToolProfiles;
    if (activeCat !== 'all') list = list.filter(p => p.category === activeCat);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.vendor.toLowerCase().includes(q) ||
        p.tagline.toLowerCase().includes(q) ||
        p.primaryKeyword.toLowerCase().includes(q)
      );
    }
    return list;
  }, [activeCat, query]);

  const featuredProfiles = aiToolProfiles.filter(p => p.featured);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Best AI Tools for Engineers — Complete Guide | MechEngi 10X</title>
        <meta
          name="description"
          content="Independent reviews of the best AI tools for mechanical engineers. ChatGPT, Claude, Gemini, Copilot, and more — with engineering-specific use cases, pros, cons, and pricing."
        />
      </Helmet>

      {/* JSON-LD: CollectionPage */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": "Best AI Tools for Engineers",
        "description": "Independent reviews of AI tools for mechanical and engineering professionals.",
        "url": "https://mechengi10x.com/ai-tools",
        "breadcrumb": {
          "@type": "BreadcrumbList",
          "itemListElement": [
            { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://mechengi10x.com" },
            { "@type": "ListItem", "position": 2, "name": "AI Tools for Engineers", "item": "https://mechengi10x.com/ai-tools" },
          ]
        }
      })}} />

      <SiteHeader />

      {/* Hero */}
      <section className="border-b border-border bg-card/20 py-14">
        <div className="mx-auto max-w-[72rem] px-5">
          <nav className="mb-4 flex items-center gap-1.5 font-mono text-xs text-muted-foreground">
            <Link to="/" className="hover:text-foreground">Home</Link>
            <span>/</span>
            <span className="text-foreground">AI Tools for Engineers</span>
          </nav>
          <div className="flex items-start gap-3">
            <span className="mt-1 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/20">
              <Zap className="h-5 w-5 text-primary" />
            </span>
            <div>
              <span className="font-mono text-xs uppercase tracking-widest text-primary">AI Tool Profiles</span>
              <h1 className="mt-1 font-display text-3xl font-extrabold sm:text-4xl lg:text-5xl">
                Best AI Tools for Engineers
              </h1>
              <p className="mt-3 max-w-2xl text-lg text-muted-foreground">
                Independent, engineer-focused reviews of the most important AI tools for engineers. ChatGPT for calculations, Claude for documentation, Gemini for Google Workspace, and more — with honest pros, cons, and real engineering use cases.
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-6 flex flex-wrap gap-6">
            {[
              { value: `${aiToolProfiles.length}`, label: 'AI Tool Profiles' },
              { value: '100%', label: 'Vendor-Independent' },
              { value: '6', label: 'Categories' },
            ].map(s => (
              <div key={s.label}>
                <p className="font-display text-2xl font-extrabold text-primary">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Search */}
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <div className="relative max-w-md flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search AI tools for engineering..."
                className="h-11 w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          </div>

          {/* Category filters */}
          <div className="mt-4 flex flex-wrap gap-2">
            {aiToolProfileCategories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCat(cat.id)}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                  activeCat === cat.id
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/30 hover:text-foreground'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured */}
      {activeCat === 'all' && !query && (
        <section className="border-b border-border py-12">
          <div className="mx-auto max-w-[90rem] px-5">
            <p className="font-mono text-xs uppercase tracking-widest text-primary">Editor Picks</p>
            <h2 className="mt-1 font-display text-2xl font-bold">Featured AI Tools for Engineers</h2>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {featuredProfiles.map(p => <ProfileCard key={p.slug} profile={p} />)}
            </div>
          </div>
        </section>
      )}

      {/* All results */}
      <section className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="mb-5 flex items-center justify-between">
          <p className="font-mono text-xs text-muted-foreground">
            {filtered.length} AI tool profile{filtered.length !== 1 ? 's' : ''} found
          </p>
        </div>
        {filtered.length > 0 ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map(p => <ProfileCard key={p.slug} profile={p} />)}
          </div>
        ) : (
          <div className="py-20 text-center">
            <p className="font-display text-xl font-semibold">No profiles found</p>
            <p className="mt-2 text-muted-foreground">Try adjusting your search or category filter.</p>
            <button onClick={() => { setQuery(''); setActiveCat('all'); }} className="mt-4 rounded-xl bg-primary px-6 py-2 font-medium text-primary-foreground">
              Clear filters
            </button>
          </div>
        )}
      </section>

      {/* Topic cluster links */}
      <section className="border-t border-border bg-card/20 py-12">
        <div className="mx-auto max-w-[72rem] px-5">
          <h2 className="font-display text-xl font-bold">Explore the AI Tools Topic Cluster</h2>
          <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { to: '/wizard', label: 'Find the Right AI Tool', desc: '3-step recommendation wizard' },
              { to: '/compare', label: 'Compare AI Tools', desc: 'Side-by-side feature comparisons' },
              { to: '/guides', label: 'AI Engineering Guides', desc: 'In-depth strategy guides' },
              { to: '/advisor', label: 'AI Engineering Advisor', desc: 'Chat with our AI for recommendations' },
            ].map(l => (
              <Link key={l.to} to={l.to} className="group flex flex-col rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:bg-primary/5">
                <p className="font-display font-semibold group-hover:text-primary">{l.label}</p>
                <p className="mt-1 text-xs text-muted-foreground">{l.desc}</p>
                <ArrowRight className="mt-2 h-4 w-4 text-muted-foreground opacity-0 transition-all group-hover:translate-x-1 group-hover:text-primary group-hover:opacity-100" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
