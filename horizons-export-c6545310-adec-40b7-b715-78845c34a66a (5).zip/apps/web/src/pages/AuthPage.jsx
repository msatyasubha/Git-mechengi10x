import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { useAuth } from '@/hooks/use-auth';

const AuthPage = ({ mode }) => {
    const isSignup = mode === 'signup';
    const { login, signup } = useAuth();
    const navigate = useNavigate();
    const [form, setForm] = useState({ name: '', email: '', password: '' });
    const [error, setError] = useState('');
    const [busy, setBusy] = useState(false);
    const [done, setDone] = useState(false);

    const onSubmit = async (e) => {
        e.preventDefault();
        setBusy(true);
        setError('');
        try {
            if (isSignup) {
                await signup(form.email, form.password, form.name);
                setDone(true);
            } else {
                await login(form.email, form.password);
                navigate('/advisor');
            }
        } catch (err) {
            setError(err?.message || 'Something went wrong.');
        } finally {
            setBusy(false);
        }
    };

    return (
        <div className="min-h-screen bg-background">
            <Helmet>
                <title>{isSignup ? 'Create your MechEngi 10X account' : 'Sign in to MechEngi 10X'}</title>
                <meta name="description" content={isSignup ? 'Create a free MechEngi 10X account to use the AI Engineering Advisor, save tools and join the community forum.' : 'Sign in to MechEngi 10X to continue discovering engineering tools, chatting with the AI Advisor, and joining the community.'} />
                <meta name="robots" content="noindex, follow" />
            </Helmet>
            <SiteHeader />
            <div className="dot-grid min-h-[calc(100dvh-4rem)] px-5 py-20">
                <div className="mx-auto max-w-md border border-border bg-card p-8">
                    <h1 className="font-display text-2xl font-bold tracking-tight">
                        {isSignup ? 'Create your account' : 'Welcome back'}
                    </h1>
                    {done ? (
                        <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
                            Account created. Check your inbox and click the verification link, then sign in to
                            start using the AI Advisor, community forum, and saved tools.
                        </p>
                    ) : (
                        <form onSubmit={onSubmit} className="mt-7 space-y-5">
                            {isSignup && (
                                <div className="flex flex-col gap-2">
                                    <label htmlFor="name" className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Name</label>
                                    <input
                                        id="name"
                                        value={form.name}
                                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                                        className="min-h-[44px] rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary"
                                    />
                                </div>
                            )}
                            <div className="flex flex-col gap-2">
                                <label htmlFor="email" className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Email</label>
                                <input
                                    id="email"
                                    type="email"
                                    required
                                    value={form.email}
                                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                                    className="min-h-[44px] rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary"
                                />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label htmlFor="password" className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Password</label>
                                <input
                                    id="password"
                                    type="password"
                                    required
                                    minLength={8}
                                    value={form.password}
                                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                                    className="min-h-[44px] rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary"
                                />
                            </div>
                            {error && <p className="text-sm text-destructive">{error}</p>}
                            <button
                                type="submit"
                                disabled={busy}
                                className="glow-primary min-h-[48px] w-full rounded-md bg-primary font-mono text-xs uppercase tracking-widest text-primary-foreground disabled:opacity-60 active:scale-[0.98]"
                            >
                                {busy ? 'Working…' : isSignup ? 'Create account' : 'Sign in'}
                            </button>
                        </form>
                    )}
                    <p className="mt-6 text-sm text-muted-foreground">
                        {isSignup ? 'Already have an account? ' : 'New here? '}
                        <Link to={isSignup ? '/login' : '/signup'} className="text-accent hover:underline">
                            {isSignup ? 'Sign in' : 'Create one'}
                        </Link>
                    </p>
                </div>
            </div>
            <SiteFooter />
        </div>
    );
};

export default AuthPage;
