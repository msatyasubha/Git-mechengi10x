import { Helmet } from 'react-helmet';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ExternalLink, CheckCircle, XCircle, ArrowLeft, User, Building2, Ruler } from 'lucide-react';
import { useEffect, useMemo } from 'react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import ToolCard from '@/components/ToolCard';
import ReviewsSection from '@/components/tool-detail/ReviewsSection';
import ToolSpecTable, { ToolSampleScript } from '@/components/tool-detail/ToolSpecTable';
import MechEngiScoreBreakdown from '@/components/MechEngiScoreBreakdown';
import VerificationStatusContainer from '@/components/VerificationStatusContainer';
import RelatedWorkflowsWidget from '@/components/RelatedWorkflowsWidget';
import { getToolBySlug, getRelatedTools, categoryLabel } from '@/data/tools';
import { getDfmStandards, DFM_CRITERIA, DFM_STATUS } from '@/data/dfmStandards';
import { getToolSpec } from '@/data/toolSpecs';
import { trackToolView, trackAffiliateClick } from '@/lib/analytics';
import { useCurrency } from '@/contexts/CurrencyContext';
import { formatInr, FX_CAVEAT } from '@/lib/currency';

function buildVerdict(tool) {
  const best = tool.useCases?.[0] || categoryLabel[tool.category] || 'engineering work';
  const skipHint = tool.cons?.[0]
    ? ` Skip it if ${tool.cons[0].charAt(0).toLowerCase()}${tool.cons[0].slice(1)}`.replace(/\.$/, '') + '.'
    : '';
  if (tool.pricing.paidFrom === 0) {
    return `${tool.name} is a strong free pick for ${best.toLowerCase()}. ${tool.tagline} Worth trying before you pay for a commercial alternative.${skipHint}`;
  }
  return `${tool.name} is a solid option for engineers who need ${best.toLowerCase()}. ${tool.tagline} Compare pricing against your workflow before committing.${skipHint}`;
}

function buildBestForLines(tool) {
  const roleHints = {
    ai: 'Engineers',
    cad: 'Mechanical / design engineers',
    simulation: 'Simulation & analysis engineers',
    automation: 'Automation-minded engineers',
    management: 'Engineering managers and team leads',
    learning: 'Students and engineers upskilling',
    software: 'Software & DevOps engineers',
  };
  const role = roleHints[tool.category] || 'Engineers';
  const lines = (tool.useCases || []).slice(0, 4).map((goal) => `${role} who need ${goal.toLowerCase()}`);
  if (lines.length === 0) {
    lines.push(`${role} who need ${categoryLabel[tool.category]?.toLowerCase() || 'better tooling'}`);
  }
  return lines;
}

/* ── Verification badge & structured data ─────────────── */
const CATEGORY_DISCIPLINES = {
  cad: ['Mechanical CAD / Machine Design', 'Parametric 3D Modeling', 'Drawing & GD&T Automation'],
  simulation: ['FEA / Structural Analysis', 'CFD / Thermal Simulation', 'Multiphysics Coupling'],
  ai: ['Engineering Documentation', 'Code & Scripting Assistance', 'Calculation Verification'],
  automation: ['Workflow Automation', 'CAD-to-ERP Integration', 'Data Pipelines'],
  management: ['Project & Program Management', 'Engineering Documentation', 'Team Coordination'],
  learning: ['Engineering Education', 'Skills Development', 'Certification Prep'],
  software: ['Software Development', 'DevOps & Infrastructure', 'Code Quality & Review'],
};

const CATEGORY_SCHEMA = {
  cad: 'DesignApplication',
  simulation: 'DesignApplication',
  ai: 'BusinessApplication',
  automation: 'BusinessApplication',
  management: 'BusinessApplication',
  learning: 'EducationalApplication',
  software: 'DeveloperApplication',
};

function extractOS(platform) {
  if (!platform) return null;
  const lower = platform.toLowerCase();
  const oses = [];
  if (lower.includes('windows')) oses.push('Windows');
  if (lower.includes('macos')) oses.push('macOS');
  if (lower.includes('linux')) oses.push('Linux');
  if (lower.includes('ipad')) oses.push('iPadOS');
  if (lower.includes('android')) oses.push('Android');
  return oses.length ? oses.join(', ') : null;
}

function buildSoftwareSchema(tool, spec) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: tool.name,
    applicationCategory: CATEGORY_SCHEMA[tool.category] || 'BusinessApplication',
    publisher: { '@type': 'Organization', name: tool.vendor },
    // `tagline` is the one-line summary shown in the page H1 — always visible.
    description: tool.tagline,
  };
  // operatingSystem is derived only from the documented platform string.
  const os = extractOS(spec?.platform);
  if (os) schema.operatingSystem = os;
  // Offers: include only when a concrete numeric price is actually displayed
  // on the page. "Contact vendor for pricing" tools omit offers rather than
  // fabricate a number.
  if (!tool.pricing.contactForPricing && typeof tool.pricing.paidFrom === 'number') {
    schema.offers = {
      '@type': 'Offer',
      price: tool.pricing.paidFrom,
      priceCurrency: 'USD',
    };
  }
  return schema;
}

export default function ToolDetailPage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const tool = getToolBySlug(slug);
  const { currency } = useCurrency();

  useEffect(() => {
    if (tool) trackToolView(tool.slug, tool.name, tool.category);
  }, [tool]);

  const verdict = useMemo(() => (tool ? buildVerdict(tool) : ''), [tool]);
  const bestForLines = useMemo(() => (tool ? buildBestForLines(tool) : []), [tool]);
  const whatIs = useMemo(() => {
    if (!tool) return '';
    const sentences = tool.description.split(/(?<=\.)\s+/).filter(Boolean);
    return sentences.slice(0, 3).join(' ');
  }, [tool]);

  const spec = tool ? getToolSpec(tool) : null;
  const jsonLd = useMemo(() => (tool ? buildSoftwareSchema(tool, spec) : null), [tool, spec]);
  const disciplines = tool ? CATEGORY_DISCIPLINES[tool.category] || [] : [];

  if (!tool) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet><title>Tool not found — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
        <SiteHeader />
        <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 px-5 text-center">
          <p className="font-display text-2xl font-bold">Tool not found</p>
          <button onClick={() => navigate('/tools')} className="text-primary hover:underline">
            Back to all tools
          </button>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const related = getRelatedTools(tool);
  const dfm = getDfmStandards(tool.slug);
  const dfmRelevant = ['cad', 'simulation'].includes(tool.category);
  const oneLineVerdict = tool.tagline;
  const isAnnual = tool.pricing.paidFrom >= 100;
  const priceUnit = isAnnual ? '/yr' : '/mo';
  // Heavy CAD / FEA / PLM tools are normally purchased through enterprise
  // sales or a value-added reseller — surface the B2B request flow there.
  const isEnterpriseTool = ['cad', 'simulation', 'management'].includes(tool.category);

  return (
    <div className="min-h-screen overflow-x-clip bg-background">
      <Helmet>
        <title>
          {tool.seoTitle ? `${tool.seoTitle} | MechEngi 10X` : `${tool.name} Review — ${oneLineVerdict} | MechEngi 10X`}
        </title>
        <meta
          name="description"
          content={tool.seoMetaDescription || `${tool.name} by ${tool.vendor}: explore its features, pricing, limitations and alternatives for engineering. MechEngi Score not yet rated.`}
        />
        <link rel="canonical" href={`https://mechengi10x.com/tools/${tool.slug}`} />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>

      <SiteHeader />

      {/* Breadcrumb */}
      <div className="border-b border-border bg-card/30 py-3 sm:py-4">
        <div className="mx-auto flex max-w-[72rem] flex-wrap items-center gap-1.5 px-4 font-mono text-xs text-muted-foreground sm:px-5">
          <Link to="/" className="hover:text-foreground">Home</Link>
          <span>/</span>
          <Link to="/tools" className="hover:text-foreground">Tools</Link>
          <span>/</span>
          <Link to={`/tools?cat=${tool.category}`} className="hover:text-foreground">
            {categoryLabel[tool.category]}
          </Link>
          <span>/</span>
          <span className="truncate text-foreground">{tool.name}</span>
        </div>
      </div>

      <article className="mx-auto max-w-[72rem] px-4 py-6 sm:px-5 sm:py-8 md:py-10">
        {/* ── Title block ─────────────────────────────── */}
        <header className="min-w-0">
          <div className="flex flex-wrap items-start gap-3 sm:gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-border bg-card text-2xl sm:h-14 sm:w-14 sm:text-3xl">
              {tool.logoEmoji}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${tool.category}`}>
                  {categoryLabel[tool.category]}
                </span>
                {tool.badge && (
                  <span className="rounded-full bg-accent/15 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-accent">
                    {tool.badge === 'Top Rated' ? 'Editorial Pick' : tool.badge}
                  </span>
                )}
                {dfm && (
                  <span className="rounded-full bg-accent/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-accent">
                    DFM &amp; Standards: Evaluated
                  </span>
                )}
              </div>
              <h1 className="mt-2 break-words font-display text-xl font-extrabold leading-snug sm:text-2xl md:text-3xl lg:text-4xl">
                {tool.name} Review — {oneLineVerdict}
              </h1>
            </div>
          </div>

          {/* Score | stars | vendor */}
          <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-2 text-sm sm:gap-x-4">
            <span className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/40 px-2.5 py-1 font-mono text-[11px] text-muted-foreground">
              MechEngi Score: Not Yet Rated
            </span>
            <span className="text-muted-foreground">
              By <span className="font-medium text-foreground">{tool.vendor}</span>
            </span>
          </div>

          <div className="mt-3">
            <p className="text-xs text-muted-foreground">Editorial ranking only — benchmark data pending. See the score breakdown below.</p>
          </div>
        </header>

        {/* ── Verification Status Container ─────────────────── */}
        <VerificationStatusContainer tool={tool} spec={spec} />

        <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_300px]">
          <div className="min-w-0 space-y-8 sm:space-y-10">
            {/* ── Technical Specifications ─────────────── */}
            <ToolSpecTable tool={tool} />

            {/* ── MechEngi Score Breakdown ─────────────── */}
            <MechEngiScoreBreakdown tool={tool} />

            {/* ── What is ─────────────────────────────── */}
            <section>
              <h2 className="font-display text-lg font-bold sm:text-xl">What is {tool.name}?</h2>
              <p className="mt-3 text-sm leading-relaxed text-foreground/85 sm:text-base">
                {whatIs}
              </p>
            </section>

            {/* ── Supported Engineering Disciplines ──── */}
            <section>
              <h2 className="font-display text-lg font-bold sm:text-xl">Supported Engineering Disciplines</h2>
              <ul className="mt-4 flex flex-wrap gap-2">
                {disciplines.map((d) => (
                  <li key={d} className="rounded-lg border border-border bg-card px-3 py-1.5 text-sm text-foreground/85">
                    {d}
                  </li>
                ))}
              </ul>
            </section>

            {/* ── Pros ────────────────────────────────── */}
            <section>
              <h2 className="flex items-center gap-2 font-display text-lg font-bold text-green-400 sm:text-xl">
                <CheckCircle className="h-5 w-5" /> Pros
              </h2>
              <ul className="mt-4 space-y-3 rounded-2xl border border-green-500/20 bg-green-500/5 p-4 sm:p-5">
                {tool.pros.slice(0, 5).map((p, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm">
                    <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-green-500" />
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            </section>

            {/* ── Cons ────────────────────────────────── */}
            <section>
              <h2 className="flex items-center gap-2 font-display text-lg font-bold text-red-400 sm:text-xl">
                <XCircle className="h-5 w-5" /> Cons
              </h2>
              <ul className="mt-4 space-y-3 rounded-2xl border border-red-500/20 bg-red-500/5 p-4 sm:p-5">
                {tool.cons.slice(0, 4).map((c, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm">
                    <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />
                    <span>{c}</span>
                  </li>
                ))}
              </ul>
            </section>

            {/* ── Pricing ─────────────────────────────── */}
            <section>
              <h2 className="font-display text-lg font-bold sm:text-xl">Pricing</h2>
              <div className="mt-4 space-y-3 rounded-2xl border border-border bg-card p-4 sm:p-5">
                <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                  <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
                    Free tier
                  </span>
                  <span className="text-sm">
                    {tool.pricing.paidFrom === 0 ? (
                      <span className="text-green-400">
                        Yes{tool.pricing.freeLabel ? ` — ${tool.pricing.freeLabel}` : ' — fully free'}
                      </span>
                    ) : tool.pricing.free ? (
                      <span className="text-green-400">
                        Yes{tool.pricing.freeLabel ? ` — ${tool.pricing.freeLabel}` : ''}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">No free tier — Commercial / Trial Available</span>
                    )}
                  </span>
                </div>
                <div className="h-px bg-border" />
                <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                  <span className="font-mono text-xs uppercase tracking-wider text-muted-foreground">
                    Paid plans
                  </span>
                  <span className="text-sm font-medium">
                    {tool.pricing.contactForPricing ? (
                      <a
                        href={tool.affiliateUrl}
                        target="_blank"
                        rel="noopener noreferrer sponsored"
                        className="text-primary hover:underline"
                      >
                        Contact vendor for current commercial pricing
                      </a>
                    ) : tool.pricing.paidFrom === 0 ? (
                      <span className="text-green-400">$0 / year — free forever</span>
                    ) : (
                      <>
                        From ${tool.pricing.paidFrom}
                        {priceUnit}
                        {currency === 'INR' && (
                          <span className="text-muted-foreground"> (≈{formatInr(tool.pricing.paidFrom)}{priceUnit})</span>
                        )}
                      </>
                    )}
                  </span>
                </div>
                {tool.pricing.paidLabel && (
                  <p className="text-sm leading-relaxed text-muted-foreground">{tool.pricing.paidLabel}</p>
                )}
                {currency === 'INR' && tool.pricing.paidFrom > 0 && (
                  <p className="rounded-lg border border-border bg-muted/30 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
                    {FX_CAVEAT}
                  </p>
                )}
              </div>
            </section>

            {/* ── Security & Data Considerations ──────── */}
            <section>
              <h2 className="font-display text-lg font-bold sm:text-xl">Security &amp; Data Considerations</h2>
              <div className="mt-4 rounded-2xl border border-border bg-card p-4 sm:p-5">
                <p className="text-sm leading-relaxed text-muted-foreground">
                  Deployment model: <span className="font-medium text-foreground">{spec?.platform || 'Not documented'}</span>.
                  Security and data-handling specifics — cloud vs. local storage options, ISO/IEC 27001 compliance
                  status, and local file encryption support — vary by license tier and release and have not been
                  independently audited by MechEngi 10X. Confirm the current security posture and any compliance
                  certifications directly with the vendor before deployment in regulated environments.
                </p>
              </div>
            </section>

            {/* ── Best For ────────────────────────────── */}
            <section>
              <h2 className="flex items-center gap-2 font-display text-lg font-bold sm:text-xl">
                <User className="h-5 w-5 text-primary" /> Best For
              </h2>
              <ul className="mt-4 space-y-2.5 rounded-2xl border border-border bg-card p-4 sm:p-5">
                {bestForLines.map((line, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-sm">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                    <span>
                      <span className="font-medium text-foreground">{line.split(' who need ')[0]}</span>
                      {' who need '}
                      <span className="text-primary">{line.split(' who need ')[1]}</span>
                      <span className="text-muted-foreground"> — matches Wizard recommendations</span>
                    </span>
                  </li>
                ))}
              </ul>
              <div className="mt-3 flex flex-wrap gap-2">
                {tool.useCases.map((u, i) => (
                  <span key={i} className={`rounded-lg border px-3 py-1 text-xs sm:text-sm badge-${tool.category}`}>
                    {u}
                  </span>
                ))}
              </div>
            </section>

            {/* ── DFM & Standards ───────────────────── */}
            {dfmRelevant && (
              <section>
                <h2 className="flex items-center gap-2 font-display text-lg font-bold sm:text-xl">
                  <Ruler className="h-5 w-5 text-accent" /> DFM &amp; Standards
                </h2>
                {dfm ? (
                  <>
                    <div className="mt-4 overflow-hidden rounded-2xl border border-border bg-card">
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-border bg-muted/40 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                              <th className="px-4 py-3 text-left">Criterion</th>
                              <th className="px-4 py-3 text-left">Status</th>
                              <th className="px-4 py-3 text-left">Notes</th>
                            </tr>
                          </thead>
                          <tbody>
                            {DFM_CRITERIA.map((c) => {
                              const item = dfm.criteria[c.id];
                              const st = DFM_STATUS[item.status];
                              return (
                                <tr key={c.id} className="border-b border-border last:border-0">
                                  <td className="px-4 py-3 text-sm font-medium">{c.label}</td>
                                  <td className="px-4 py-3">
                                    <span className={`rounded-full border px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider ${st.color} ${st.bg} ${st.border}`}>
                                      {st.label}
                                    </span>
                                  </td>
                                  <td className="px-4 py-3 text-sm leading-relaxed text-muted-foreground">{item.note}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <p className="mt-3 rounded-lg border border-border bg-muted/30 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
                      {dfm.evidence} Hands-on DFM stress testing (weldments, nonlinear FEA, large BOMs, drawing
                      creation) is defined in our{' '}
                      <Link to="/resources" className="text-primary hover:underline">Shop-Floor Benchmark Framework</Link>{' '}
                      — no results have been run or published yet.
                    </p>
                  </>
                ) : (
                  <div className="mt-4 rounded-2xl border border-border bg-muted/20 p-4 text-sm leading-relaxed text-muted-foreground sm:p-5">
                    <span className="font-medium text-foreground">Not yet evaluated — planned.</span> We are rolling
                    out DFM &amp; standards evaluation (GD&amp;T callouts, tolerance stack-up, casting draft angles,
                    sheet-metal bend relief, weldment cut lists, piping/flow-line standards, and ISO/ASME drawing
                    compliance) across the CAD/CAE directory. No DFM badge or score is shown for this tool until the
                    evaluation is documented from vendor evidence.
                  </div>
                )}
              </section>
            )}

            {/* ── Verdict ─────────────────────────────── */}
            <section>
              <h2 className="font-display text-lg font-bold sm:text-xl">Verdict</h2>
              <div className="mt-4 rounded-2xl border border-primary/20 bg-primary/5 p-4 sm:p-5">
                <div className="mb-3 flex flex-wrap items-center gap-3">
                  <span className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-muted/40 px-2.5 py-1 font-mono text-[11px] text-muted-foreground">
                    Not Yet Rated — Awaiting Benchmark Data
                  </span>
                  <span className="font-mono text-xs text-muted-foreground">MechEngi 10X Verdict</span>
                </div>
                <p className="text-sm leading-relaxed text-foreground/85 sm:text-base">{verdict}</p>
              </div>
            </section>

            {/* ── Try CTA ─────────────────────────────── */}
            <a
              href={tool.affiliateUrl}
              target="_blank"
              rel="noopener noreferrer sponsored"
              onClick={() => trackAffiliateClick(tool.slug, tool.name, 'review-verdict')}
              className="glow-primary flex min-h-[52px] w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-display text-base font-bold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
            >
              Try {tool.name} <ExternalLink className="h-4 w-4" />
            </a>
            <p className="affiliate-disclosure -mt-6 text-center font-mono text-[10px] text-foreground/70">
              Affiliate link — we earn a commission at no extra cost to you
            </p>

            {/* ── Enterprise quote / VAR introduction CTA ── */}
            {isEnterpriseTool && (
              <section className="rounded-2xl border border-accent/30 bg-accent/5 p-4 sm:p-5">
                <div className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-accent" />
                  <h2 className="font-display text-lg font-bold">Buying for a team?</h2>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  Multi-seat, network, or enterprise licensing for {tool.name} is normally quoted rather than checked
                  out. Request an enterprise quote or a value-added reseller (VAR) introduction through our team —
                  free, no obligation, and pricing stays between you and the vendor.
                </p>
                <Link
                  to={`/enterprise-quote?tool=${tool.slug}`}
                  className="mt-4 flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl border border-accent/40 bg-accent/10 px-6 py-3 font-semibold text-accent transition-all hover:bg-accent/20 active:scale-[0.98] sm:w-auto sm:px-8"
                >
                  <Building2 className="h-4 w-4" /> Request Enterprise Quote / VAR Introduction
                </Link>
              </section>
            )}

            {/* Key features (supporting) */}
            <section>
              <h2 className="font-display text-lg font-bold">Key Features</h2>
              <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                {tool.features.map((f, i) => (
                  <li key={i} className="flex items-center gap-2 rounded-lg border border-border bg-card/60 px-3 py-2 text-sm">
                    <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                    {f}
                  </li>
                ))}
              </ul>
            </section>

            <ToolSampleScript tool={tool} />

            <ReviewsSection toolSlug={tool.slug} />
          </div>

          {/* Sticky sidebar */}
          <aside className="lg:sticky lg:top-24 lg:h-fit">
            <div className="rounded-2xl border border-border bg-card p-4 sm:p-5">
              <div className="flex items-center justify-between gap-2">
                <span className="min-w-0 truncate font-display text-base font-bold">{tool.name}</span>
                <span className="shrink-0 rounded-lg border border-border bg-muted/40 px-2 py-0.5 font-mono text-[10px] text-muted-foreground">
                  Not Yet Rated
                </span>
              </div>

              <div className="mt-4 space-y-2">
                {(tool.pricing.free || tool.pricing.paidFrom === 0) && (
                  <div className="flex items-center justify-between gap-2 rounded-lg bg-green-500/10 px-3 py-2">
                    <span className="font-mono text-xs text-green-400">Free tier</span>
                    <span className="max-w-[55%] truncate text-right text-xs text-muted-foreground">
                      {tool.pricing.freeLabel || '$0/yr'}
                    </span>
                  </div>
                )}
                {tool.pricing.contactForPricing ? (
                  <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2">
                    <span className="font-mono text-xs text-foreground">Commercial</span>
                    <span className="font-mono text-xs font-semibold text-muted-foreground">Contact vendor</span>
                  </div>
                ) : tool.pricing.paidFrom > 0 ? (
                  <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2">
                    <span className="font-mono text-xs text-foreground">Paid from</span>
                    <span className="font-mono text-xs font-semibold">
                      ${tool.pricing.paidFrom}
                      {priceUnit}
                      {currency === 'INR' && (
                        <span className="block text-[10px] font-normal text-muted-foreground">≈{formatInr(tool.pricing.paidFrom)}{priceUnit}</span>
                      )}
                    </span>
                  </div>
                ) : (
                  <div className="flex items-center justify-between rounded-lg bg-green-500/10 px-3 py-2">
                    <span className="font-mono text-xs text-green-400">Cost / year</span>
                    <span className="font-mono text-xs font-semibold text-green-400">$0</span>
                  </div>
                )}
                <p className="pt-1 text-xs text-muted-foreground">{tool.pricing.paidLabel}</p>
              </div>

              <a
                href={tool.affiliateUrl}
                target="_blank"
                rel="noopener noreferrer sponsored"
                onClick={() => trackAffiliateClick(tool.slug, tool.name, 'sidebar')}
                className="mt-4 flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
              >
                Try {tool.name} <ExternalLink className="h-4 w-4" />
              </a>
              <p className="affiliate-disclosure mt-2 text-center font-mono text-[10px] text-foreground/70">
                Affiliate link — we earn a commission at no extra cost to you
              </p>

              <Link
                to="/wizard"
                className="mt-3 flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-border py-2.5 text-sm font-medium transition-colors hover:border-primary/40 hover:text-primary"
              >
                Find tools via Wizard
              </Link>
              <Link
                to="/advisor"
                className="mt-2 flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-border py-2.5 text-sm font-medium transition-colors hover:border-primary/40 hover:text-primary"
              >
                Ask AI Advisor for alternatives
              </Link>
              {isEnterpriseTool && (
                <Link
                  to={`/enterprise-quote?tool=${tool.slug}`}
                  className="mt-2 flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl border border-accent/40 bg-accent/10 py-2.5 text-sm font-medium text-accent transition-colors hover:bg-accent/20"
                >
                  <Building2 className="h-4 w-4" /> Enterprise Quote / VAR
                </Link>
              )}
            </div>

            <RelatedWorkflowsWidget category={tool.category} className="mt-4" />
          </aside>
        </div>

        {/* Related tools */}
        {related.length > 0 && (
          <div className="mt-12 sm:mt-14">
            <h2 className="font-display text-xl font-bold sm:text-2xl">
              Related {categoryLabel[tool.category]} Tools
            </h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3">
              {related.map((t) => (
                <ToolCard key={t.slug} tool={t} />
              ))}
            </div>
          </div>
        )}

        <div className="mt-10">
          <Link
            to="/tools"
            className="inline-flex min-h-[44px] items-center gap-2 font-mono text-sm text-muted-foreground hover:text-primary"
          >
            <ArrowLeft className="h-4 w-4" /> Back to all tools
          </Link>
        </div>
      </article>

      <SiteFooter />
    </div>
  );
}
