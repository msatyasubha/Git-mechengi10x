import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { AlertTriangle, ClipboardCheck, Mail, ArrowRight, Clock } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

const STEPS = [
  { n: 1, title: 'Report the issue', body: 'Email hello@mechengi10x.com with the tool name, the specific field in question (price, file format, API endpoint, license type), and a link to the official vendor source where possible.' },
  { n: 2, title: 'We verify against the source', body: 'Our team checks the report against the vendor\u2019s official documentation. We do not change a published value without a reliable source.' },
  { n: 3, title: 'Correction is published', body: 'Once verified, the corrected value is published and the affected page is annotated with an update timestamp.' },
];

export default function CorrectionsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Factual Corrections & Error Reporting Policy — MechEngi 10X</title>
        <meta name="description" content="A transparent protocol for reporting software feature inaccuracies, outdated pricing, or incorrect license details on MechEngi 10X. Reports are routed to hello@mechengi10x.com." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 sm:py-20">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <ClipboardCheck className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Corrections Policy</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-3xl font-bold leading-tight sm:text-4xl md:text-5xl">
            Factual Corrections &amp; Error Reporting Policy
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            Engineering software changes fast — pricing shifts, APIs deprecate, file formats evolve. This is the
            protocol for reporting an inaccuracy and how we handle it.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
        <div className="grid gap-5 md:grid-cols-3">
          {STEPS.map((s) => (
            <div key={s.n} className="rounded-2xl border border-border bg-card p-6">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 font-mono text-sm font-bold text-primary">
                {s.n}
              </span>
              <h2 className="mt-4 font-display text-base font-bold">{s.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
            </div>
          ))}
        </div>

        {/* SLA — presented as a proposed target, not a guaranteed commitment */}
        <div className="mt-10 flex items-start gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/5 p-5">
          <Clock className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
          <div>
            <h2 className="font-display text-base font-bold text-foreground">Response time &amp; version log (proposed)</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              Our target is to review and publish confirmed corrections promptly, with an explicit update timestamp on
              the affected page. A public version/update log is a <span className="font-semibold text-foreground">proposed policy</span>{' '}
              we are working toward — it is not yet a guaranteed service-level commitment. Until it is operational,
              reports are routed to hello@mechengi10x.com and handled as quickly as we can verify them, without a
              guaranteed response window.
            </p>
          </div>
        </div>

        {/* What we correct */}
        <div className="mt-10 max-w-2xl">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">What we correct</h2>
          <ul className="mt-5 space-y-2.5">
            {[
              'Outdated or incorrect software pricing',
              'Incorrect file-format support or API documentation',
              'Mislabelled license types (commercial vs. free / open-source)',
              'Incorrect deployment model or platform support',
              'Broken or outdated vendor links',
            ].map((item) => (
              <li key={item} className="flex items-start gap-2.5 text-sm">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                <span className="text-foreground/85">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact callout */}
        <div className="mt-10 flex flex-col items-start gap-3 rounded-2xl border border-primary/30 bg-primary/5 p-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
            <div>
              <h2 className="font-display text-lg font-bold">Report an inaccuracy</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Engineers and software vendors alike can report updates directly. Include the tool name, the field in
                question, and a link to the official source.
              </p>
            </div>
          </div>
          <a
            href="mailto:hello@mechengi10x.com"
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
          >
            <Mail className="h-4 w-4" /> hello@mechengi10x.com
          </a>
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/methodology" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
            100-point evaluation framework <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/editorial-policy" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
            Editorial guidelines <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/disclosures" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
            Commercial disclosures <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
