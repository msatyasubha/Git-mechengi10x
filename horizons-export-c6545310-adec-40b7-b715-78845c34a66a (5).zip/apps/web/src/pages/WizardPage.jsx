import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowRight, ArrowLeft, CheckCircle, ExternalLink, Zap, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import ToolLogo from '@/components/ToolLogo';
import { tools } from '@/data/tools';
import { trackWizardComplete } from '@/lib/analytics';
import { useCurrency } from '@/contexts/CurrencyContext';
import { formatInr, pricePeriod } from '@/lib/currency';

const ROLES = [
  { id: 'me', label: 'Mechanical Engineer', icon: '⚙️' },
  { id: 'ee', label: 'Electrical / Electronics Engineer', icon: '⚡' },
  { id: 'sw', label: 'Software / Automation Engineer', icon: '💻' },
  { id: 'mgr', label: 'Engineering Manager / Team Lead', icon: '📊' },
  { id: 'student', label: 'Student / Academic', icon: '🎓' },
  { id: 'startup', label: 'Entrepreneur / Startup Founder', icon: '🚀' },
  { id: 'other', label: 'Other / Multi-discipline', icon: '🔧' },
];

const GOALS = [
  { id: 'cad', label: 'CAD & 3D Modeling', icon: '📐', cats: ['cad'] },
  { id: 'sim', label: 'FEA / CFD Simulation', icon: '🔬', cats: ['simulation'] },
  { id: 'automate', label: 'Automate Repetitive Tasks', icon: '🔄', cats: ['automation'] },
  { id: 'pm', label: 'Manage Engineering Projects', icon: '📋', cats: ['management'] },
  { id: 'learn', label: 'Learn New Engineering Skills', icon: '📚', cats: ['learning'] },
  { id: 'ai', label: 'AI-Assisted Technical Work', icon: '🤖', cats: ['ai'] },
  { id: 'docs', label: 'Engineering Documentation', icon: '📝', cats: ['management', 'ai'] },
  { id: 'data', label: 'Data Analysis & Processing', icon: '📈', cats: ['ai', 'automation'] },
  { id: 'dev', label: 'Software Development & DevOps', icon: '💻', cats: ['software'] },
];

const BUDGETS = [
  { id: 'free', label: 'Free only', sub: 'Open source & free tiers', max: 0 },
  { id: 'low', label: 'Up to $20/month', sub: 'Entry-level tools', max: 20 },
  { id: 'mid', label: '$20–$100/month', sub: 'Professional tier', max: 100 },
  { id: 'high', label: 'Over $100/month', sub: 'Enterprise grade', max: 99999 },
  { id: 'any', label: 'No budget limit', sub: 'Show me everything', max: 99999 },
];

const ROLE_WEIGHTS = {
  me:      { cad: 1.2, simulation: 1.25, ai: 1.0, learning: 1.05, software: 0.95 },
  ee:      { ai: 1.15, automation: 1.2, simulation: 1.1, software: 1.05 },
  sw:      { automation: 1.25, ai: 1.2, management: 1.05, software: 1.3 },
  mgr:     { management: 1.3, automation: 1.1, ai: 1.05, software: 1.0 },
  student: { learning: 1.2, cad: 1.1, simulation: 1.15, ai: 1.05, software: 1.1 },
  startup: { automation: 1.15, ai: 1.2, management: 1.1, cad: 1.05, software: 1.15 },
};

const GOAL_REASONS = {
  cad:      'Best for your CAD & 3D Modeling needs',
  sim:      'Ideal for FEA / CFD simulation workflows',
  automate: 'Top pick for workflow automation',
  pm:       'Recommended for project management',
  learn:    'Perfect for professional upskilling',
  ai:       'Top AI tool for engineering tasks',
  docs:     'Great for engineering documentation',
  data:     'Excellent for data analysis workflows',
  dev:      'Top pick for software development & DevOps',
};

/** Normalize tool price to monthly USD. paidFrom >= 100 is treated as annual. */
function monthlyCost(t) {
  const p = t.pricing?.paidFrom ?? 0;
  if (p === 0) return 0;
  return p >= 100 ? p / 12 : p;
}

/** True free = $0 paid plan (open source / free forever). */
function isTrulyFree(t) {
  return (t.pricing?.paidFrom ?? 0) === 0;
}

function isOpenSourceFree(t) {
  return isTrulyFree(t) && (t.pricing?.model === 'free' || /open source/i.test(t.pricing?.freeLabel || '') || /open source/i.test(t.vendor || ''));
}

/**
 * Goal category is the primary signal. Non-matching categories are heavily
 * penalized so FEA/CFD never ranks a CAD modeler or a learning site first.
 */
function recommendTools(role, goal, budget) {
  const goalDef = GOALS.find((g) => g.id === goal);
  const goalCats = goalDef?.cats || [];
  const weights = ROLE_WEIGHTS[role] || {};
  const max = BUDGETS.find((b) => b.id === budget)?.max ?? 99999;

  const inBudget = (t) => {
    if (budget === 'free') {
      // "Free only" means genuinely free tools (paidFrom === 0) — full stop.
      // Paid tools with a limited free/student tier (e.g. ANSYS Student,
      // SOLIDWORKS student license) are deliberately EXCLUDED because their
      // commercial price contradicts the "free only" promise. Showing a
      // $1,295/yr or $4,000/yr product as a free-only top match breaks the
      // brand's core promise of keeping recommendations precise.
      return isTrulyFree(t);
    }
    if (budget === 'high' || budget === 'any') return true;
    const monthly = monthlyCost(t);
    return monthly === 0 || monthly <= max;
  };

  const scored = tools
    .filter(inBudget)
    .map((t) => {
      const catMatch = goalCats.includes(t.category);
      let score = Number(t.mechengiScore) || 70;

      if (catMatch) {
        score *= 3.2;
      } else {
        // Strong penalty so off-category tools cannot outrank real matches
        score *= 0.22;
      }

      score *= weights[t.category] || 1.0;

      if (budget === 'free' && isTrulyFree(t) && catMatch) score *= 1.25;

      if (t.featured && catMatch) score *= 1.06;

      return { tool: t, score, catMatch };
    });

  const matches = scored.filter((s) => s.catMatch).sort((a, b) => b.score - a.score);
  // Only ever show genuine goal-category matches — never pad with off-category
  // tools, so an FEA/CFD request can never surface FreeCAD or MIT OpenCourseWare.
  if (matches.length === 0) return [];
  const top = matches.slice(0, 5);

  // Present match scores out of 100 with best match landing in the 92–97 band
  const rawMax = Math.max(...top.map((r) => r.score), 1);
  const withScores = top.map((r) => {
    const ratio = r.score / rawMax;
    const matchScore = Math.round(72 + ratio * 25); // 72–97
    return { tool: r.tool, matchScore: Math.min(97, Math.max(72, matchScore)), catMatch: r.catMatch };
  });

  withScores.sort((a, b) => b.matchScore - a.matchScore);
  // Keep a clear descending ladder so #1 reads as a strong top match
  if (withScores[0]) withScores[0].matchScore = Math.max(withScores[0].matchScore, 94);
  for (let i = 1; i < withScores.length; i += 1) {
    const cap = withScores[i - 1].matchScore - 2;
    if (withScores[i].matchScore > cap) withScores[i].matchScore = Math.max(70, cap);
  }

  return withScores;
}

function reasonFor(tool, goalId, index) {
  const goalDef = GOALS.find((g) => g.id === goalId);
  const goalLabel = goalDef?.label || 'your goal';
  const isFree = (tool.pricing?.paidFrom ?? 0) === 0;
  const pool = [];
  if (isFree) pool.push(`Best free option for ${goalLabel}`);
  if (tool.featured) pool.push(`Editor's choice for ${goalLabel}`);
  if (tool.pricing?.free && !isFree) pool.push(`Best freemium pick for ${goalLabel}`);
  pool.push(`Great fit for ${goalLabel}`);
  pool.push(`Solid alternative for ${goalLabel}`);
  pool.push(`Worth comparing for ${goalLabel}`);
  return pool[Math.min(index, pool.length - 1)] || `Recommended for ${goalLabel}`;
}

const steps = ['Your Role', 'Your Goal', 'Budget'];

function ProgressBar({ step }) {
  return (
    <div className="mx-auto mb-8 max-w-lg">
      <div className="flex items-center justify-between text-center">
        {steps.map((s, i) => (
          <div key={s} className="flex flex-1 flex-col items-center gap-1.5">
            <div className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold transition-all ${
              i < step ? 'bg-green-500 text-white' : i === step ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
            }`}>
              {i < step ? <CheckCircle className="h-4 w-4" /> : i + 1}
            </div>
            <span className={`hidden font-mono text-[10px] uppercase tracking-wider sm:block ${i === step ? 'text-primary' : 'text-muted-foreground'}`}>
              {s}
            </span>
          </div>
        ))}
      </div>
      <div className="relative mt-2 h-1 rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-primary transition-all duration-500"
          style={{ width: `${Math.min(100, (step / (steps.length - 1)) * 100)}%` }}
        />
      </div>
    </div>
  );
}

function OptionGrid({ options, selected, onSelect, cols = 2 }) {
  return (
    <div className={`grid gap-3 ${cols === 1 ? 'grid-cols-1' : cols === 3 ? 'sm:grid-cols-3' : 'sm:grid-cols-2'}`}>
      {options.map((opt) => (
        <button
          key={opt.id}
          type="button"
          onClick={() => onSelect(opt.id)}
          className={`flex min-h-[56px] items-center gap-3 rounded-xl border p-4 text-left transition-all active:scale-[0.98] ${
            selected === opt.id
              ? 'border-primary bg-primary/10 ring-1 ring-primary'
              : 'border-border bg-card hover:border-primary/40 hover:bg-primary/5'
          }`}
        >
          <span className="text-2xl shrink-0" aria-hidden="true">{opt.icon}</span>
          <div className="min-w-0">
            <p className="font-display text-sm font-semibold leading-snug">{opt.label}</p>
            {opt.sub && <p className="mt-0.5 text-xs text-muted-foreground">{opt.sub}</p>}
          </div>
          {selected === opt.id && (
            <CheckCircle className="ml-auto h-4 w-4 shrink-0 text-primary" />
          )}
        </button>
      ))}
    </div>
  );
}

function ScoreRing({ score }) {
  const size = 52;
  const stroke = 4;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const pct = Math.min(100, Math.max(0, score)) / 100;
  const offset = c * (1 - pct);

  return (
    <div className="relative flex h-[52px] w-[52px] items-center justify-center" title={`Match score ${score} out of 100`}>
      <svg width={size} height={size} className="-rotate-90" aria-hidden="true">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="hsl(220 18% 30%)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="hsl(var(--primary))"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-sm font-extrabold leading-none text-primary">{score}</span>
        <span className="font-mono text-[8px] leading-none text-muted-foreground">/100</span>
      </div>
    </div>
  );
}

function pricingBadge(tool, currency) {
  if (isTrulyFree(tool) || tool.pricing?.model === 'free') {
    return (
      <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] text-green-400">
        {isOpenSourceFree(tool) || /open source/i.test(tool.pricing?.freeLabel || '') ? 'Free & open source' : 'Free'}
      </span>
    );
  }
  const period = pricePeriod(tool.pricing.paidFrom);
  return (
    <>
      {tool.pricing.free && (
        <span className="rounded-full bg-green-500/10 px-2 py-0.5 font-mono text-[10px] text-green-400">Has free tier</span>
      )}
      <span className="font-mono text-xs text-muted-foreground">
        From <span className="text-foreground">${tool.pricing.paidFrom}</span>{period}
        {currency === 'INR' && <span className="text-muted-foreground"> (≈{formatInr(tool.pricing.paidFrom)}{period})</span>}
      </span>
    </>
  );
}

function ResultCard({ item, index, goalId }) {
  const { tool, matchScore } = item;
  const { currency } = useCurrency();
  const reason = reasonFor(tool, goalId, index);
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08 }}
      className="flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 sm:flex-row sm:items-start sm:gap-5"
    >
      <div className="flex shrink-0 items-center gap-3 sm:flex-col sm:items-center sm:gap-2">
        <ToolLogo name={tool.name} category={tool.category} size="lg" />
        <div className="hidden sm:block">
          <ScoreRing score={matchScore} />
          <p className="mt-1 text-center font-mono text-[9px] text-muted-foreground">Match</p>
        </div>
        <div className="flex items-center gap-2 sm:hidden">
          <ScoreRing score={matchScore} />
          <span className="font-mono text-[10px] text-muted-foreground">match</span>
        </div>
      </div>
      <div className="mt-3 min-w-0 flex-1 sm:mt-0">
        {/* Name + (desktop) stars */}
        <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-1">
          <div className="min-w-0">
            {index === 0 && (
              <span className="mb-1 inline-block rounded-full bg-primary/15 px-2 py-0.5 font-mono text-[10px] font-semibold text-primary">
                Top match
              </span>
            )}
            <h3 className="font-display text-lg font-bold">{tool.name}</h3>
            <p className="text-xs text-muted-foreground">{tool.vendor}</p>
          </div>
          <div className="hidden text-right sm:block">
            <p className="mt-0.5 text-right font-mono text-[10px] text-muted-foreground">Editorial assessment pending</p>
          </div>
        </div>
        <p className="mt-2 hidden text-sm leading-relaxed text-muted-foreground sm:block">{tool.tagline}</p>
        {/* Reason line */}
        <div className="mt-2 flex items-center gap-1.5">
          <CheckCircle className="h-3.5 w-3.5 shrink-0 text-green-500" />
          <span className="text-xs font-medium text-green-400">{reason}</span>
        </div>
        {/* Editorial status (mobile, after reason) */}
        <div className="mt-2 flex items-center gap-2 sm:hidden">
          <span className="font-mono text-[10px] text-muted-foreground">Editorial assessment pending</span>
        </div>
        {/* Pricing chip */}
        <div className="mt-2 flex flex-wrap items-center gap-2">
          {pricingBadge(tool, currency)}
        </div>
        {/* CTA buttons — full-width on mobile */}
        <div className="mt-4 flex flex-col gap-2 sm:flex-row">
          <Link
            to={`/tools/${tool.slug}`}
            className="flex min-h-[44px] flex-1 items-center justify-center rounded-lg border border-border px-3 py-2 text-center text-sm font-medium transition-colors hover:border-primary/60 hover:text-primary"
          >
            Full Review
          </Link>
          <a
            href={tool.affiliateUrl}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-all hover:opacity-90 sm:flex-initial sm:px-4"
          >
            <span className="truncate">Try {tool.name}</span> <ExternalLink className="h-3.5 w-3.5 shrink-0" />
          </a>
        </div>
      </div>
    </motion.div>
  );
}

export default function WizardPage() {
  const [step, setStep] = useState(0);
  const [role, setRole] = useState('');
  const [goal, setGoal] = useState('');
  const [budget, setBudget] = useState('');
  const [results, setResults] = useState([]);
  const { currency } = useCurrency();

  // Show an approximate INR monthly equivalent alongside USD budget bands for
  // India-based visitors. Conversion is approximate (see lib/currency.js).
  const inrMo = (usd) => `${formatInr(usd)}/mo`;
  const budgetOptions = BUDGETS.map((b) => {
    if (currency !== 'INR') return b;
    let sub = b.sub;
    if (b.id === 'low') sub = `${b.sub} · ≈${inrMo(20)}`;
    else if (b.id === 'mid') sub = `${b.sub} · ≈${inrMo(20)}–${inrMo(100)}`;
    else if (b.id === 'high') sub = `${b.sub} · ≈${inrMo(100)}+`;
    return { ...b, sub };
  });

  const canNext = [role, goal, budget][step] !== '';

  const handleNext = () => {
    if (step === 2) {
      const recs = recommendTools(role, goal, budget);
      setResults(recs);
      trackWizardComplete(role, goal, budget, recs.length);
      setStep(3);
    } else {
      setStep(step + 1);
    }
  };

  // Auto-advance on question steps 0 and 1 after a short highlight delay.
  // Step 2 (budget) keeps an explicit "Get Recommendations" button.
  const handleSelect = (id) => {
    if (step === 0) setRole(id);
    else if (step === 1) setGoal(id);
    else if (step === 2) setBudget(id);
    if (step === 0 || step === 1) {
      window.setTimeout(() => setStep(step + 1), 400);
    }
  };

  const reset = () => {
    setStep(0);
    setRole('');
    setGoal('');
    setBudget('');
    setResults([]);
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Find the Right Engineering Tool — MechEngi 10X Recommendation Wizard</title>
        <meta name="description" content="Answer 3 quick questions and get personalized engineering tool recommendations matched to your role, goals, and budget. No account needed." />
      </Helmet>

      <SiteHeader />

      <div className="mx-auto max-w-[56rem] px-5 py-8 pb-28 sm:py-12 md:pb-12">
        <div className="mb-6 text-center sm:mb-10">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs text-primary">
            <Zap className="h-3.5 w-3.5" />
            Tool Recommendation Wizard
          </div>
          <h1 className="font-display text-3xl font-extrabold sm:text-4xl">
            Find Your Perfect <span className="whitespace-nowrap">Engineering Tool</span>
          </h1>
          <p className="mx-auto mt-3 max-w-md text-muted-foreground">
            Answer 3 quick questions. Get 5 personalized tool recommendations with honest scores and pricing. No account needed.
          </p>
        </div>

        <ProgressBar step={step} />
        {step < 3 && (
          <p className="mx-auto mt-2 mb-8 max-w-lg text-center font-mono text-xs text-muted-foreground">
            Question {step + 1} of 3
          </p>
        )}

        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div key="step0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h2 className="mb-5 text-center font-display text-xl font-bold sm:mb-6">What is your role?</h2>
              <OptionGrid options={ROLES} selected={role} onSelect={handleSelect} cols={2} />
            </motion.div>
          )}

          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h2 className="mb-5 text-center font-display text-xl font-bold sm:mb-6">What is your primary goal?</h2>
              <OptionGrid options={GOALS} selected={goal} onSelect={handleSelect} cols={2} />
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h2 className="mb-5 text-center font-display text-xl font-bold sm:mb-6">What is your budget?</h2>
              <OptionGrid options={budgetOptions.filter((b) => b.id !== 'any')} selected={budget} onSelect={handleSelect} cols={2} />
              <div className="mt-3">
                <OptionGrid options={[budgetOptions.find((b) => b.id === 'any')]} selected={budget} onSelect={handleSelect} cols={1} />
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
              <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <h2 className="font-display text-xl font-bold">Your Top Tool Matches</h2>
                  <p className="text-sm text-muted-foreground break-words">
                    Based on: {ROLES.find((r) => r.id === role)?.label} · {GOALS.find((g) => g.id === goal)?.label} · {BUDGETS.find((b) => b.id === budget)?.label}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={reset}
                  className="flex min-h-[44px] shrink-0 items-center justify-center gap-1.5 self-start rounded-lg border border-border px-3 py-2 font-mono text-xs text-muted-foreground hover:border-foreground/40 hover:text-foreground"
                >
                  <RotateCcw className="h-3.5 w-3.5" /> Restart
                </button>
              </div>

              {results.length > 0 ? (
                <div className="flex flex-col gap-4">
                  {results.map((item, i) => (
                    <ResultCard key={item.tool.slug} item={item} index={i} goalId={goal} />
                  ))}
                </div>
              ) : (
                <div className="rounded-xl border border-border py-16 text-center">
                  <p className="font-display text-lg font-semibold">No tools match your exact criteria</p>
                  <p className="mt-2 text-muted-foreground">Try relaxing your budget to see more options.</p>
                  <button type="button" onClick={reset} className="mt-4 rounded-xl bg-primary px-6 py-2.5 font-medium text-primary-foreground">
                    Try Again
                  </button>
                </div>
              )}

              {results.length > 0 && (
                <p className="mt-4 text-center font-mono text-[11px] text-muted-foreground">
                  Recommendations based on published specs — verify current pricing with vendors.
                </p>
              )}

              <div className="mt-8 rounded-xl border border-border bg-card/50 p-5 text-center">
                <p className="text-sm text-muted-foreground">
                  Not seeing what you need? Browse the full directory or use our AI Advisor.
                </p>
                <div className="mt-3 flex flex-wrap justify-center gap-3">
                  <Link to="/tools" className="rounded-lg border border-border px-5 py-2 text-sm font-medium hover:border-primary/40 hover:text-primary">
                    Browse All Tools
                  </Link>
                  <Link to="/compare" className="rounded-lg border border-border px-5 py-2 text-sm font-medium hover:border-primary/40 hover:text-primary">
                    Compare Tools
                  </Link>
                  <Link to="/advisor" className="rounded-lg bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
                    Ask AI Advisor
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {step < 3 && (
          <>
          {/* Desktop inline nav (auto-advance on steps 0–1, explicit Get Recommendations on step 2) */}
          <div className="mt-8 hidden items-center justify-between gap-2 md:flex">
            <button
              type="button"
              onClick={() => setStep(Math.max(0, step - 1))}
              disabled={step === 0}
              className="flex min-h-[44px] items-center gap-2 rounded-xl border border-foreground/30 px-4 py-2.5 font-medium text-foreground transition-colors hover:border-foreground hover:bg-foreground/5 disabled:opacity-0 sm:px-5"
            >
              <ArrowLeft className="h-4 w-4" /> Back
            </button>
            {step === 2 ? (
              <button
                type="button"
                onClick={handleNext}
                disabled={!canNext}
                className={`flex min-h-[44px] items-center gap-2 rounded-xl bg-primary px-4 py-2.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-30 sm:px-6 ${canNext ? 'glow-primary' : ''}`}
              >
                Get Recommendations <ArrowRight className="h-4 w-4" />
              </button>
            ) : (
              <span className="font-mono text-xs text-muted-foreground">Tap an option to continue</span>
            )}
          </div>

          {/* Hint line (desktop) */}
          <p className="mt-3 hidden text-center font-mono text-[11px] text-muted-foreground md:block">
            {step < 2 ? 'Tap an option to continue.' : !canNext ? 'Choose a budget to continue.' : ''}
          </p>

          {/* Mobile sticky footer bar */}
          <div className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 backdrop-blur-md md:hidden">
            <div className="mx-auto flex max-w-[56rem] items-center justify-between gap-2 px-5 py-3">
              <button
                type="button"
                onClick={() => setStep(Math.max(0, step - 1))}
                disabled={step === 0}
                className="flex min-h-[44px] items-center gap-2 rounded-xl border border-foreground/30 px-4 py-2.5 font-medium text-foreground transition-colors hover:border-foreground hover:bg-foreground/5 disabled:opacity-0"
              >
                <ArrowLeft className="h-4 w-4" /> Back
              </button>
              {step === 2 ? (
                <button
                  type="button"
                  onClick={handleNext}
                  disabled={!canNext}
                  className={`flex min-h-[44px] items-center gap-2 rounded-xl bg-primary px-5 py-2.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-30 ${canNext ? 'glow-primary' : ''}`}
                >
                  Get Recommendations <ArrowRight className="h-4 w-4" />
                </button>
              ) : (
                <span className="font-mono text-[11px] text-muted-foreground">Tap an option →</span>
              )}
            </div>
          </div>
          </>
        )}

        <p className="affiliate-disclosure mt-8 text-center font-mono text-[10px] text-foreground/70">
          Affiliate disclosure: &quot;Try&quot; buttons may earn MechEngi 10X a commission at no extra cost to you.
        </p>
      </div>

      <SiteFooter />
    </div>
  );
}
