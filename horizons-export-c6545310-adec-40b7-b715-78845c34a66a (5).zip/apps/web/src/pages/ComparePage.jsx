import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { CheckCircle, XCircle, ExternalLink, ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import ToolLogo from '@/components/ToolLogo';
import { getToolBySlug, categories, tools } from '@/data/tools';
import { comparisons as detailedComparisons } from '@/data/comparisons';
import { emergingTools } from '@/data/emergingTools';
import { useCurrency } from '@/contexts/CurrencyContext';
import { formatInr, pricePeriod } from '@/lib/currency';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const monthYear = (d) => {
  const [y, m] = d.split('-');
  return `${MONTHS[Number(m) - 1]} ${y}`;
};

const comparisons = [
  { title: 'ChatGPT vs Claude for Engineers', slugs: ['chatgpt', 'claude'], category: 'ai' },
  { title: 'SOLIDWORKS vs Fusion 360', slugs: ['solidworks', 'fusion360'], category: 'cad' },
  { title: 'FreeCAD vs Fusion 360', slugs: ['freecad', 'fusion360'], category: 'cad' },
  { title: 'Fusion 360 vs Onshape', slugs: ['fusion360', 'onshape'], category: 'cad' },
  { title: 'ANSYS vs COMSOL Multiphysics', slugs: ['ansys', 'comsol'], category: 'simulation' },
  { title: 'SimScale vs ANSYS Mechanical', slugs: ['simscale', 'ansys'], category: 'simulation' },
  { title: 'Zapier vs Make vs n8n', slugs: ['zapier', 'make'], category: 'automation' },
  { title: 'Notion vs Jira for Engineering', slugs: ['notion', 'jira'], category: 'management' },
  { title: 'Asana vs Monday.com', slugs: ['asana', 'monday'], category: 'management' },
  { title: 'Coursera vs Udemy for Engineers', slugs: ['coursera', 'udemy'], category: 'learning' },
  { title: 'VS Code vs IntelliJ IDEA', slugs: ['vscode', 'intellij-idea'], category: 'software' },
  { title: 'Docker vs Kubernetes', slugs: ['docker', 'kubernetes'], category: 'software' },
  { title: 'GitHub vs Postman for API Work', slugs: ['github', 'postman'], category: 'software' },
  { title: 'GitHub Copilot vs Cursor', slugs: ['github-copilot', 'cursor'], category: 'ai' },
  { title: 'ChatGPT vs Google Gemini', slugs: ['chatgpt', 'gemini'], category: 'ai' },
  { title: 'AutoCAD vs SOLIDWORKS', slugs: ['autocad', 'solidworks'], category: 'cad' },
  { title: 'CATIA vs Siemens NX', slugs: ['catia', 'siemens-nx'], category: 'cad' },
  { title: 'Abaqus vs ANSYS Mechanical', slugs: ['abaqus', 'ansys'], category: 'simulation' },
  { title: 'MATLAB vs Python (Jupyter)', slugs: ['matlab-simulink', 'jupyter'], category: 'simulation' },
  { title: 'Jira vs Linear', slugs: ['jira', 'linear'], category: 'management' },
];

const categoryLabel = {
  ai: 'AI Tools',
  cad: 'CAD & Design',
  simulation: 'Simulation',
  automation: 'Automation',
  management: 'Engineering Management',
  learning: 'Learning',
  software: 'Software Engineering',
};

// Feature rows for detailed comparison
function buildFeatureRows(a, b, currency) {
  const startPrice = (t) => {
    if (t.pricing.contactForPricing) return 'Contact for pricing';
    if (t.pricing.paidFrom === 0) return 'Free';
    const period = pricePeriod(t.pricing.paidFrom);
    const usd = `$${t.pricing.paidFrom}${period}`;
    return currency === 'INR' ? `${usd} (≈${formatInr(t.pricing.paidFrom)}${period})` : usd;
  };
  return [
    {
      section: 'Scores',
      rows: [
        {
          label: 'MechEngi Score',
          valA: 'Not Yet Rated',
          valB: 'Not Yet Rated',
          winA: false,
          winB: false,
          tie: true,
          neutral: true,
        },

      ],
    },
    {
      section: 'Pricing',
      rows: [
        {
          label: 'Free Tier',
          valA: a.pricing.free ? (a.pricing.freeLabel || 'Yes') : 'No free tier',
          valB: b.pricing.free ? (b.pricing.freeLabel || 'Yes') : 'No free tier',
          winA: a.pricing.free && !b.pricing.free,
          winB: b.pricing.free && !a.pricing.free,
          tie: a.pricing.free === b.pricing.free,
        },
        {
          label: 'Starting Price',
          valA: startPrice(a),
          valB: startPrice(b),
          winA: !a.pricing.contactForPricing && !b.pricing.contactForPricing && a.pricing.paidFrom <= b.pricing.paidFrom,
          winB: !a.pricing.contactForPricing && !b.pricing.contactForPricing && b.pricing.paidFrom < a.pricing.paidFrom,
          tie: a.pricing.paidFrom === b.pricing.paidFrom,
        },
        {
          label: 'Pricing Model',
          valA: a.pricing.paidLabel || '—',
          valB: b.pricing.paidLabel || '—',
          neutral: true,
        },
      ],
    },
    {
      section: 'Category',
      rows: a.category === b.category ? [
        {
          label: 'Category',
          valA: categoryLabel[a.category],
          valB: categoryLabel[b.category],
          neutral: true,
        },
        {
          label: 'Best For',
          valA: a.useCases.slice(0, 2).join(', '),
          valB: b.useCases.slice(0, 2).join(', '),
          neutral: true,
        },
      ] : [],
    },
  ].filter((s) => s.rows.length > 0);
}

function FeatureRow({ row }) {
  const cellBase = 'px-3 py-3.5 text-sm align-top sm:px-4 sm:py-4';
  return (
    <tr className="border-b border-border last:border-0">
      <td className={`${cellBase} w-1/3 font-mono text-xs text-muted-foreground`}>{row.label}</td>
      <td className={`${cellBase} border-l border-border`}>
        <span className={`flex items-start gap-1.5 ${row.winA && !row.neutral ? 'text-green-400' : ''}`}>
          {row.winA && !row.neutral && <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />}
          {row.valA}
        </span>
      </td>
      <td className={`${cellBase} border-l border-border`}>
        <span className={`flex items-start gap-1.5 ${row.winB && !row.neutral ? 'text-green-400' : ''}`}>
          {row.winB && !row.neutral && <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />}
          {row.valB}
        </span>
      </td>
    </tr>
  );
}

function ComparisonTable({ slugA, slugB }) {
  const a = getToolBySlug(slugA);
  const b = getToolBySlug(slugB);
  const { currency } = useCurrency();
  if (!a || !b) return null;

  const sections = buildFeatureRows(a, b, currency);

  return (
    <div className="overflow-hidden rounded-2xl border border-border">
      {/* Sticky header */}
      <div className="grid grid-cols-[1fr_1fr_1fr] border-b border-border bg-card/80">
        <div className="p-3 sm:p-4 flex items-end">
          <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Feature</span>
        </div>
        {[a, b].map((tool) => (
          <div key={tool.slug} className="border-l border-border p-3 sm:p-4">
            <div className="flex items-center gap-2">
              <ToolLogo name={tool.name} category={tool.category} size="sm" />
              <div className="min-w-0">
                <p className="font-display text-sm font-bold leading-tight sm:text-base">{tool.name}</p>
                <p className="hidden font-mono text-xs text-muted-foreground sm:block">{tool.vendor}</p>
              </div>
            </div>
            {/* Score pills */}
            <div className="mt-2 flex flex-wrap gap-1.5">
              <span className="rounded-full border border-border bg-muted/40 px-2 py-0.5 font-mono text-[10px] text-muted-foreground">
                Not Yet Rated
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Sections */}
      {sections.map((section) => (
        <div key={section.section}>
          <div className="bg-muted/40 px-3 py-2 sm:px-4">
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{section.section}</span>
          </div>
          <table className="w-full">
            <tbody>
              {section.rows.map((row) => (
                <FeatureRow key={row.label} row={row} />
              ))}
            </tbody>
          </table>
        </div>
      ))}

      {/* Feature bullets comparison */}
      <div className="bg-muted/40 px-3 py-2 sm:px-4">
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Key Features</span>
      </div>
      <div className="grid grid-cols-[1fr_1fr_1fr] border-b border-border">
        <div className="p-3 sm:p-4 font-mono text-xs text-muted-foreground">Features</div>
        {[a, b].map((tool) => (
          <div key={tool.slug} className="border-l border-border p-3 sm:p-4">
            <ul className="space-y-1.5">
              {tool.features.slice(0, 5).map((f, i) => (
                <li key={i} className="flex items-start gap-1.5 text-xs">
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* CTA row */}
      <div className="grid grid-cols-[1fr_1fr_1fr] bg-muted/30">
        <div className="p-3 sm:p-4 font-mono text-xs text-muted-foreground flex items-center">Try it</div>
        {[a, b].map((tool, idx) => (
          <div key={tool.slug} className="border-l border-border p-3 sm:p-4">
            <a
              href={tool.affiliateUrl}
              target="_blank"
              rel="noopener noreferrer sponsored"
              className={`flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold transition-all hover:opacity-90 ${
                idx === 0
                  ? 'bg-primary text-primary-foreground'
                  : 'border border-border hover:border-primary/40 hover:text-primary'
              }`}
            >
              Try {tool.name} <ExternalLink className="h-3 w-3 shrink-0" />
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProsConsCards({ slugA, slugB }) {
  const a = getToolBySlug(slugA);
  const b = getToolBySlug(slugB);
  if (!a || !b) return null;

  return (
    <div className="mt-8 grid gap-5 md:grid-cols-2">
      {[a, b].map((tool) => (
        <div key={tool.slug} className="rounded-2xl border border-border bg-card p-5 md:p-6">
          <div className="flex items-center gap-3 border-b border-border pb-4">
            <ToolLogo name={tool.name} category={tool.category} size="sm" />
            <div>
              <p className="font-display text-base font-bold md:text-lg">{tool.name}</p>
              <p className="font-mono text-[10px] text-muted-foreground">Not Yet Rated</p>
            </div>
            <span className="ml-auto font-display text-xl font-extrabold text-muted-foreground md:text-2xl">—</span>
          </div>

          <div className="mt-4 space-y-2">
            <p className="font-mono text-[10px] uppercase tracking-wider text-green-400">Pros</p>
            {tool.pros.slice(0, 3).map((p, i) => (
              <div key={i} className="flex items-start gap-2 text-sm">
                <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-green-500" />
                {p}
              </div>
            ))}
            <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-red-400">Cons</p>
            {tool.cons.slice(0, 2).map((c, i) => (
              <div key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />
                {c}
              </div>
            ))}
          </div>

          <div className="mt-5 flex gap-2">
            <Link
              to={`/tools/${tool.slug}`}
              className="flex-1 rounded-lg border border-border py-2 text-center text-sm font-medium transition-colors hover:border-primary/60 hover:text-primary"
            >
              Full Review
            </Link>
            <a
              href={tool.affiliateUrl}
              target="_blank"
              rel="noopener noreferrer sponsored"
              className="flex items-center gap-1 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-all hover:opacity-90"
            >
              Try <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function ComparePage() {
  const [activeComp, setActiveComp] = useState(comparisons[0]);
  const [activeCat, setActiveCat] = useState('all');

  const visibleComps = activeCat === 'all' ? comparisons : comparisons.filter((c) => c.category === activeCat);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Tool Comparisons — MechEngi 10X</title>
        <meta name="description" content="Side-by-side comparisons of the best engineering software tools. SOLIDWORKS vs Fusion 360, ANSYS vs COMSOL, ChatGPT vs Claude, Zapier vs Make, and more." />
      </Helmet>

      <SiteHeader />

      {/* Header */}
      <div className="border-b border-border bg-card/30 py-8 md:py-10">
        <div className="mx-auto max-w-[72rem] px-5">
          <h1 className="font-display text-2xl font-bold sm:text-3xl md:text-4xl">Tool Comparisons</h1>
          <p className="mt-2 text-muted-foreground">
            Side-by-side breakdowns to help you choose the right tool for your engineering workflow.
          </p>

          {/* Category filter */}
          <div className="mt-5 flex flex-wrap gap-2">
            <button
              onClick={() => setActiveCat('all')}
              className={`rounded-full border px-3 py-1.5 font-mono text-xs transition-colors sm:px-4 ${activeCat === 'all' ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'}`}
            >
              All
            </button>
            {categories.slice(1).map((c) => (
              <button
                key={c.id}
                onClick={() => setActiveCat(c.id)}
                className={`rounded-full border px-3 py-1.5 font-mono text-xs transition-colors sm:px-4 ${activeCat === c.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'}`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[72rem] px-5 py-8 md:py-10">
        {/* Comparison selector — scrollable cards */}
        <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {visibleComps.map((c) => {
            const toolA = getToolBySlug(c.slugs[0]);
            const toolB = getToolBySlug(c.slugs[1]);
            const isActive = activeComp.title === c.title;
            return (
              <button
                key={c.title}
                onClick={() => setActiveComp(c)}
                className={`flex items-center gap-3 rounded-xl border p-3.5 text-left transition-all sm:p-4 ${
                  isActive ? 'border-primary bg-primary/5' : 'border-border bg-card hover:border-primary/30'
                }`}
              >
                <span className="text-xl">{toolA?.logoEmoji}</span>
                <span className="text-xs text-muted-foreground font-mono">vs</span>
                <span className="text-xl">{toolB?.logoEmoji}</span>
                <div className="min-w-0 flex-1">
                  <p className="font-display text-sm font-semibold leading-tight">{c.title}</p>
                  <span className={`mt-1 inline-block rounded-md border px-1.5 py-0.5 font-mono text-[10px] uppercase badge-${c.category}`}>
                    {categoryLabel[c.category]}
                  </span>
                </div>
                {isActive && <ArrowRight className="h-4 w-4 shrink-0 text-primary" />}
              </button>
            );
          })}
        </div>

        {/* Active comparison */}
        <div className="mt-10">
          <h2 className="mb-5 font-display text-xl font-bold md:text-2xl">{activeComp.title}</h2>

          {/* Scrollable table wrapper for mobile */}
          <div className="overflow-x-auto rounded-2xl">
            <div className="min-w-[420px]">
              <ComparisonTable slugA={activeComp.slugs[0]} slugB={activeComp.slugs[1]} />
            </div>
          </div>

          {/* Pros & cons cards */}
          <ProsConsCards slugA={activeComp.slugs[0]} slugB={activeComp.slugs[1]} />
        </div>

        {/* Detailed Comparison Articles */}
        <div className="mt-14">
          <h2 className="font-display text-xl font-bold md:text-2xl">In-Depth Comparison Guides</h2>
          <p className="mt-1 text-muted-foreground text-sm">Long-form comparison articles with feature tables, pricing, and engineering-specific recommendations.</p>
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {detailedComparisons.map((c) => (
              <Link key={c.slug} to={`/comparisons/${c.slug}`}
                className="group flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
                <span className={`self-start rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${c.category}`}>
                  {categoryLabel[c.category] || c.category}
                </span>
                <h3 className="mt-2 font-display text-base font-semibold leading-snug group-hover:text-primary">{c.title}</h3>
                <p className="mt-2 flex-1 text-xs leading-relaxed text-muted-foreground line-clamp-3">{c.excerpt}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="font-mono text-xs text-muted-foreground">{c.readTime} min read · Published {monthYear(c.date)}</span>
                  <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 transition-all group-hover:translate-x-1 group-hover:text-primary group-hover:opacity-100" />
                </div>
              </Link>
            ))}
          </div>
          <p className="mt-5 text-center text-sm text-muted-foreground">
            Can't find your matchup?{' '}
            <Link to="/advisor" className="font-medium text-primary hover:underline">Ask the AI Advisor →</Link>
          </p>
        </div>

        {/* Emerging AI coding agents — verified status, no invented scores */}
        <div className="mt-14">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-primary">Actively Developing</p>
              <h2 className="mt-1 font-display text-xl font-bold md:text-2xl">Emerging AI Coding Agents</h2>
              <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
                New and rapidly evolving AI coding agents and agentic IDEs. We compare verified status, pricing, and
                free tiers — <span className="text-foreground">no invented scores</span>, because these tools are too
                new to rate honestly.
              </p>
            </div>
            <Link to="/emerging-tools" className="inline-flex shrink-0 items-center gap-1.5 self-start rounded-xl border border-border px-4 py-2 font-mono text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary sm:self-auto">
              Full emerging list <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>

          <div className="mt-5 overflow-x-auto rounded-2xl border border-border">
            <div className="min-w-[640px]">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/40">
                    <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Tool</th>
                    <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Status</th>
                    <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Free Tier</th>
                    <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Paid From</th>
                    <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Last Verified</th>
                    <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Visit</th>
                  </tr>
                </thead>
                <tbody>
                  {emergingTools.map((t) => {
                    const statusLabel =
                      t.status === 'ga' ? 'Generally Available' :
                      t.status === 'public-beta' ? 'Public Beta' : 'Early Access';
                    const statusCls =
                      t.status === 'ga' ? 'text-green-400' :
                      t.status === 'public-beta' ? 'text-amber-400' : 'text-primary';
                    return (
                      <tr key={t.slug} className="border-b border-border last:border-0">
                        <td className="px-4 py-3.5">
                          <div className="flex items-center gap-2">
                            <span className="text-xl">{t.logoEmoji}</span>
                            <div className="min-w-0">
                              <p className="font-display text-sm font-bold leading-tight">{t.name}</p>
                              <p className="text-[11px] text-muted-foreground">{t.vendor}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3.5">
                          <span className={`font-mono text-xs ${statusCls}`}>{statusLabel}</span>
                        </td>
                        <td className="px-4 py-3.5">
                          <span className={`font-mono text-xs ${t.pricing.free ? 'text-green-400' : 'text-muted-foreground'}`}>
                            {t.pricing.free ? 'Yes' : 'No'}
                          </span>
                        </td>
                        <td className="px-4 py-3.5 font-mono text-xs text-muted-foreground">
                          {t.pricing.free ? 'Free / usage-based' : `$${t.pricing.paidFrom}/mo`}
                        </td>
                        <td className="px-4 py-3.5 font-mono text-xs text-muted-foreground">{t.lastVerified}</td>
                        <td className="px-4 py-3.5">
                          <a
                            href={t.officialUrl}
                            target="_blank"
                            rel="noopener noreferrer sponsored"
                            className="inline-flex items-center gap-1 rounded-lg border border-border px-2.5 py-1.5 font-mono text-[11px] text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
                          >
                            Site <ExternalLink className="h-3 w-3" />
                          </a>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
          <p className="mt-3 text-[11px] text-muted-foreground/80">
            Availability and pricing for developing tools change frequently. Confirm on the vendor’s official site before purchasing.
          </p>
        </div>

        {/* AI Advisor CTA */}
        <div className="mt-12 rounded-2xl border border-primary/20 bg-primary/5 p-6 text-center md:p-8">
          <p className="font-display text-lg font-bold md:text-xl">Still unsure? Let AI decide for you.</p>
          <p className="mt-2 text-sm text-muted-foreground md:text-base">Tell our AI Advisor your workflow and it'll recommend the right tool instantly.</p>
          <Link to="/advisor" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 font-semibold text-primary-foreground hover:opacity-90 md:px-8">
            Ask AI Advisor
          </Link>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
