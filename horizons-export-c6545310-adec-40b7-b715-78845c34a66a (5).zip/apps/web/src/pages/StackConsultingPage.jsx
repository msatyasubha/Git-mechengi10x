import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import {
  Layers,
  Check,
  Loader2,
  Send,
  Boxes,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import pb from '@/lib/pocketbaseClient';

const inputCls =
  'min-h-[44px] w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary';

function Field({ label, children }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}

/* Lead capture form — writes to PocketBase stack_consulting_inquiries.
   Public create, admin-only read (same pattern as consultation_inquiries). */

function StackConsultingForm() {
  const [form, setForm] = useState({
    contact_name: '',
    email: '',
    company: '',
    role: '',
    discipline: '',
    current_stack: '',
    team_size: '',
    budget_range: '',
    goals: '',
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await pb.collection('stack_consulting_inquiries').create(form);
      setDone(true);
    } catch (err) {
      setError(err?.response?.message || err?.message || 'Submission failed. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
          <Check className="h-7 w-7 text-primary" />
        </div>
        <h3 className="mt-5 font-display text-xl font-bold">Request received</h3>
        <p className="mx-auto mt-3 max-w-sm text-sm text-muted-foreground">
          Thanks, {form.contact_name || 'there'}. We'll review your stack details and reply to
          <span className="text-foreground"> {form.email}</span> to schedule your
          stack review call.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link
            to="/wizard"
            className="inline-flex items-center gap-2 rounded-xl border border-border px-5 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary"
          >
            Try the tool wizard <ArrowRight className="h-4 w-4" />
          </Link>
          <Link
            to="/advisor"
            className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90"
          >
            Ask the AI Advisor
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 sm:p-8">
      <h3 className="font-display text-xl font-bold">Request a custom stack review</h3>
      <p className="mt-1 text-sm text-muted-foreground">
        Tell us what you work with today. We'll reply to schedule a call.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label="Your name *">
          <input required value={form.contact_name} onChange={set('contact_name')} className={inputCls} />
        </Field>
        <Field label="Work email *">
          <input required type="email" value={form.email} onChange={set('email')} className={inputCls} />
        </Field>
        <Field label="Company">
          <input value={form.company} onChange={set('company')} className={inputCls} />
        </Field>
        <Field label="Your role">
          <input placeholder="e.g. Design engineer, CAE lead" value={form.role} onChange={set('role')} className={inputCls} />
        </Field>
        <Field label="Discipline">
          <input placeholder="e.g. Mechanical, Automotive, Aerospace" value={form.discipline} onChange={set('discipline')} className={inputCls} />
        </Field>
        <Field label="Team size">
          <select value={form.team_size} onChange={set('team_size')} className={inputCls}>
            <option value="">Prefer not to say</option>
            <option>Solo</option>
            <option>2–5</option>
            <option>6–20</option>
            <option>20+</option>
          </select>
        </Field>
      </div>

      <div className="mt-4">
        <Field label="Current software stack *">
          <textarea
            required
            rows={3}
            value={form.current_stack}
            onChange={set('current_stack')}
            placeholder="e.g. SOLIDWORKS + ANSYS + Excel trackers, exploring FreeCAD and n8n…"
            className={`${inputCls} resize-none`}
          />
        </Field>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <Field label="Budget range">
          <select value={form.budget_range} onChange={set('budget_range')} className={inputCls}>
            <option value="">Prefer not to say</option>
            <option>Free / open-source only</option>
            <option>Under $50/mo</option>
            <option>$50–200/mo</option>
            <option>$200–500/mo</option>
            <option>$500+/mo</option>
            <option>INR budget (discuss on call)</option>
          </select>
        </Field>
        <Field label="What are you trying to improve?">
          <input placeholder="e.g. Cut licence costs, automate BOM export" value={form.goals} onChange={set('goals')} className={inputCls} />
        </Field>
      </div>

      {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

      <button
        type="submit"
        disabled={busy}
        className="glow-primary mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60"
      >
        {busy ? <><Loader2 className="h-4 w-4 animate-spin" /> Sending…</> : <><Send className="h-4 w-4" /> Request stack review</>}
      </button>
      <p className="mt-3 text-center font-mono text-[10px] text-muted-foreground">
        This form books a consulting call — no account is created and no software is purchased.
      </p>
    </form>
  );
}

const STEPS = [
  {
    n: '01',
    title: 'You share your stack',
    body: 'CAD, simulation, automation, and management tools you use today — including licences you already pay for and the spreadsheets holding it all together.',
  },
  {
    n: '02',
    title: 'We map the gaps',
    body: 'A 45-minute call plus a written follow-up: where your stack overlaps, what is missing, and which free or open-source tools could replace paid licences you under-use.',
  },
  {
    n: '03',
    title: 'You get a written recommendation',
    body: 'A vendor-neutral shortlist with pricing (USD and INR where relevant), migration effort notes, and an honest "keep what you have" verdict where that is the right answer.',
  },
];

export default function StackConsultingPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Custom Software Stack Consulting for Engineering Teams — MechEngi 10X</title>
        <meta
          name="description"
          content="Vendor-neutral software stack reviews for engineers and engineering teams. Tell us your CAD, simulation, automation, and management tools — get a written recommendation with honest tradeoffs. Free initial consultation call."
        />
      </Helmet>

      <SiteHeader />

      {/* Hero */}
      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-20 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Layers className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Consulting · Phase 1 Service</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            Get a custom engineering <span className="text-primary">software stack review</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            Tell us what you use today. We review your CAD, simulation, automation, and management stack and send a
            written, vendor-neutral recommendation — including free and open-source alternatives where they genuinely fit.
          </p>

          <div className="mx-auto mt-10 flex max-w-2xl items-start justify-center gap-3 rounded-xl border border-amber-500/30 bg-amber-500/5 px-5 py-3 text-left">
            <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">Honest scope:</span> this is a consulting service run by
              the MechEngi 10X team. We do not resell licences, take referral commissions on recommendations we make in
              consulting, or claim vendor partnerships we do not have.
            </p>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-[90rem] px-5 py-20">
        <div className="mb-12 text-center">
          <p className="font-mono text-xs uppercase tracking-wider text-primary">How it works</p>
          <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Three steps, no sales pitch</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {STEPS.map((s) => (
            <div key={s.n} className="rounded-2xl border border-border bg-card p-6">
              <span className="font-mono text-xs text-primary">{s.n}</span>
              <h3 className="mt-2 font-display text-lg font-semibold">{s.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
            </div>
          ))}
        </div>
        <div className="mx-auto mt-10 flex max-w-3xl items-start gap-3 rounded-2xl border border-border bg-card/60 px-5 py-4">
          <Boxes className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
          <p className="text-sm leading-relaxed text-muted-foreground">
            Prefer a self-serve route first? The{' '}
            <Link to="/wizard" className="text-primary hover:underline">tool wizard</Link>,{' '}
            <Link to="/advisor" className="text-primary hover:underline">AI Advisor</Link>, and{' '}
            <Link to="/compare" className="text-primary hover:underline">comparison pages</Link> cover most
            single-tool decisions for free.
          </p>
        </div>
      </section>

      {/* Form */}
      <section id="consult" className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-20">
          <div className="mx-auto mb-10 max-w-2xl text-center">
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Talk to our team</p>
            <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Book your stack review</h2>
            <p className="mt-4 text-lg leading-relaxed text-foreground/90">
              The first consultation call is free. We only suggest paid tools when free ones will not do the job.
            </p>
          </div>
          <div className="mx-auto max-w-2xl">
            <StackConsultingForm />
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
