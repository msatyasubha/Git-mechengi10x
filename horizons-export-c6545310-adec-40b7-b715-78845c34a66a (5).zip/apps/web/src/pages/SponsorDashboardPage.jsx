import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { LayoutDashboard, LogIn, Loader2, Building2, DollarSign, Calendar, TrendingUp } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbaseClient';

const pkgLabels = {
  'featured-tool': 'Featured Tool',
  'exclusive-review': 'Exclusive Review',
  'webinar-sponsorship': 'Webinar Sponsorship',
};

const statusColors = {
  pending: 'badge-management',
  paid: 'badge-automation',
  overdue: 'badge-learning',
  refunded: 'badge-cad',
};

export default function SponsorDashboardPage() {
  const { user, isAuthed } = useAuth();
  const [sponsor, setSponsor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function load() {
      if (!isAuthed) {
        setLoading(false);
        return;
      }
      try {
        const records = await pb.collection('sponsors').getFullList({ sort: '-created' });
        setSponsor(records[0] || null);
      } catch (err) {
        setError(err?.message || 'Could not load your sponsorship.');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [isAuthed]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Sponsor Dashboard — MechEngi 10X</title>
        <meta name="description" content="View your active sponsorship package, performance metrics, and renewal status." />
        <meta name="robots" content="noindex, follow" />
      </Helmet>
      <SiteHeader />

      <div className="mx-auto max-w-[72rem] px-5 py-12">
        <div className="flex items-center gap-2">
          <LayoutDashboard className="h-5 w-5 text-primary" />
          <p className="font-mono text-xs uppercase tracking-wider text-primary">Sponsor Portal</p>
        </div>
        <h1 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Sponsor Dashboard</h1>

        {!isAuthed ? (
          <div className="mt-10 rounded-2xl border border-border bg-card p-10 text-center">
            <LogIn className="mx-auto h-10 w-10 text-primary" />
            <h2 className="mt-4 font-display text-xl font-bold">Sign in to view your dashboard</h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              If your company sponsors MechEngi 10X, sign in with the email we have on file to see your package
              details and performance.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link to="/login" className="rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">Sign in</Link>
              <Link to="/sponsor" className="rounded-xl border border-border px-6 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">Become a sponsor</Link>
            </div>
          </div>
        ) : loading ? (
          <div className="mt-10 flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading your sponsorship…
          </div>
        ) : error ? (
          <div className="mt-10 rounded-2xl border border-destructive/40 bg-destructive/10 p-6 text-sm text-destructive">{error}</div>
        ) : !sponsor ? (
          <div className="mt-10 rounded-2xl border border-border bg-card p-10 text-center">
            <Building2 className="mx-auto h-10 w-10 text-muted-foreground" />
            <h2 className="mt-4 font-display text-xl font-bold">No active sponsorship found</h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              There's no sponsorship record linked to your account yet. Submit an inquiry and our team will set
              up your portal access.
            </p>
            <Link to="/sponsor/featured-tool" className="mt-6 inline-block rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
              Start an inquiry
            </Link>
          </div>
        ) : (
          <div className="mt-8 space-y-6">
            {/* Overview card */}
            <div className="rounded-2xl border border-border bg-card p-6">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Company</p>
                  <h2 className="mt-1 font-display text-2xl font-bold">{sponsor.company_name}</h2>
                  <p className="mt-1 text-sm text-muted-foreground">{sponsor.contact_name} · {sponsor.email}</p>
                </div>
                <span className={`inline-flex rounded-md border px-3 py-1 font-mono text-[10px] uppercase tracking-wider ${statusColors[sponsor.payment_status] || 'badge-management'}`}>
                  {sponsor.payment_status || 'pending'}
                </span>
              </div>
            </div>

            {/* Stat grid */}
            <div className="grid gap-4 sm:grid-cols-3">
              <StatCard icon={Building2} label="Package" value={pkgLabels[sponsor.package_type] || sponsor.package_type || '—'} />
              <StatCard icon={DollarSign} label="Investment" value={sponsor.investment_amount ? `$${Number(sponsor.investment_amount).toLocaleString()}` : '—'} />
              <StatCard icon={Calendar} label="Period" value={sponsor.start_date && sponsor.end_date ? `${sponsor.start_date.slice(0,10)} → ${sponsor.end_date.slice(0,10)}` : '—'} />
            </div>

            {/* Performance metrics */}
            <div className="rounded-2xl border border-border bg-card p-6">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                <h3 className="font-display text-lg font-semibold">Performance metrics</h3>
              </div>
              {sponsor.performance_metrics ? (
                <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {Object.entries(sponsor.performance_metrics).map(([k, v]) => (
                    <div key={k} className="rounded-xl border border-border bg-muted/30 p-4">
                      <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{k}</p>
                      <p className="mt-1 font-display text-2xl font-bold text-primary">{String(v)}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="mt-4 text-sm text-muted-foreground">Metrics are reported monthly. Your first report will appear here once your package goes live.</p>
              )}
            </div>

            {/* Renewal */}
            <div className="flex items-center justify-between rounded-2xl border border-border bg-card p-6">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Renewal status</p>
                <p className="mt-1 font-display text-lg font-semibold capitalize">{sponsor.renewal_status || 'new'}</p>
              </div>
              <Link to="/sponsor/featured-tool" className="rounded-xl border border-border px-5 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">
                Renew / upgrade
              </Link>
            </div>
          </div>
        )}
      </div>

      <SiteFooter />
    </div>
  );
}

function StatCard({ icon: Icon, label, value }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <Icon className="h-5 w-5 text-primary" />
      <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-lg font-bold">{value}</p>
    </div>
  );
}
