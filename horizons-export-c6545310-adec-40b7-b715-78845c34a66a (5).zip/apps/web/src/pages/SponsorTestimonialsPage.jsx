import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Quote, ArrowRight } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { sponsorTestimonials } from '@/data/sponsorshipPackages';

export default function SponsorTestimonialsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Sponsor Case Studies — MechEngi 10X</title>
        <meta name="description" content="Explore illustrative sponsorship scenarios and learn how MechEngi 10X presents potential outcomes. These are not verified sponsor testimonials." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 text-center">
          <Quote className="mx-auto h-8 w-8 text-primary" />
          <h1 className="mt-4 font-display text-4xl font-bold sm:text-5xl">Illustrative sponsorship scenarios</h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            The scenarios below are illustrative examples of the outcomes a sponsorship is designed to drive &mdash;
            not verified testimonials or measured results from named companies. We do not claim that any organization
            listed has endorsed or sponsored MechEngi 10X.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-16">
        <div className="space-y-8">
          {sponsorTestimonials.map((t) => (
            <div key={t.company} className="rounded-2xl border border-border bg-card p-7 sm:p-9">
              <div className="grid gap-8 lg:grid-cols-[1.5fr_1fr]">
                <div>
                  <div className="flex items-center gap-3">
                    <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 font-display text-base font-bold text-primary">
                      {t.logo}
                    </span>
                    <div>
                      <p className="font-display text-xl font-bold">{t.company}</p>
                      <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{t.author}</p>
                    </div>
                  </div>
                  <p className="mt-5 font-display text-lg leading-relaxed text-foreground/90">“{t.quote}”</p>
                </div>
                <div className="rounded-xl border border-border bg-muted/30 p-5">
                  <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Results</p>
                  <div className="mt-4 space-y-4">
                    {t.results.map((r) => (
                      <div key={r.metric} className="flex items-center justify-between border-b border-border pb-3 last:border-0">
                        <span className="text-sm text-muted-foreground">{r.metric}</span>
                        <span className="font-display text-2xl font-bold text-primary">{r.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 rounded-2xl border border-primary/30 bg-primary/5 p-8 text-center">
          <h2 className="font-display text-2xl font-bold">Ready to explore sponsorship?</h2>
          <p className="mx-auto mt-3 max-w-md text-sm text-muted-foreground">
            Tell us about your tool and we'll recommend the package that fits your goals.
          </p>
          <Link to="/sponsor" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3 font-semibold text-primary-foreground hover:opacity-90">
            Explore packages <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
