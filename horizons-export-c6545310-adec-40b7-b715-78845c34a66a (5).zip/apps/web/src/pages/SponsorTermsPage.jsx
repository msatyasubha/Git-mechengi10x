import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Shield, FileText, Scale } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

const sections = [
  {
    icon: Shield,
    title: 'Editorial independence',
    body: 'Sponsorship purchases placement, exposure, and access to our audience — never a guaranteed positive review or a modified MechEngi Score. All sponsored tools are scored with the same 7-criteria methodology as non-sponsored tools. If a sponsored tool scores poorly, the score stands. We will, however, present the tool to our audience so engineers can judge for themselves.',
  },
  {
    icon: FileText,
    title: 'Disclosure',
    body: 'Every sponsored placement is clearly labeled as "Sponsored" or "Partner" on the page where it appears. Our affiliate disclosure page lists all active commercial relationships. We never present paid placement as organic editorial content.',
  },
  {
    icon: Scale,
    title: 'Refunds & cancellations',
    body: 'Featured Tool and Webinar Sponsorship are eligible for a pro-rated refund within the first 14 days if we have not yet delivered the placement or event. Exclusive Reviews are non-refundable once the review process has begun, as engineering time has been committed. Cancellation of an active placement stops future billing but does not refund the current period.',
  },
  {
    icon: FileText,
    title: 'Content approval',
    body: 'For Exclusive Reviews, sponsors may review factual accuracy (pricing, feature lists, specs) before publication, but may not alter the reviewer\'s opinion, score, or pros/cons. For Webinar Sponsorships, the sponsor approves the topic and demo segment; MechEngi 10X approves the educational content and final agenda.',
  },
  {
    icon: Shield,
    title: 'Exclusivity',
    body: 'Featured Tool placement is non-exclusive — multiple tools may be featured in a category. Exclusive Reviews are exclusive within the tool\'s direct comparison set for 60 days. Webinar Sponsorships are exclusive to one sponsor per event.',
  },
  {
    icon: Scale,
    title: 'Performance guarantees',
    body: 'We report honest performance metrics (impressions, clicks, conversions) monthly. We do not guarantee specific conversion numbers, as outcomes depend on your tool\'s market fit, landing page, and offer. The ROI figures on our package pages are averages from past sponsors, not promises.',
  },
];

export default function SponsorTermsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Sponsorship Terms — MechEngi 10X</title>
        <meta name="description" content="The terms, editorial independence policy, and refund policy for sponsoring MechEngi 10X." />
      </Helmet>

      <SiteHeader />

      <article className="mx-auto max-w-3xl px-5 py-16">
        <div className="flex items-center gap-2">
          <Scale className="h-5 w-5 text-primary" />
          <p className="font-mono text-xs uppercase tracking-wider text-primary">Sponsorship</p>
        </div>
        <h1 className="mt-1 font-display text-4xl font-bold">Sponsorship Terms & Policy</h1>
        <p className="mt-4 text-muted-foreground">
          Last updated: {new Date().getFullYear()}. These terms govern all sponsorship relationships with MechEngi 10X.
          By submitting an inquiry or purchasing a package, you agree to them.
        </p>

        <nav className="mt-8 rounded-2xl border border-border bg-card p-5">
          <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">On this page</p>
          <ul className="mt-3 grid gap-2 sm:grid-cols-2">
            {sections.map((s, i) => (
              <li key={s.title}>
                <a href={`#sec-${i}`} className="text-sm text-muted-foreground hover:text-primary">{s.title}</a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="mt-10 space-y-10">
          {sections.map((s, i) => (
            <section key={s.title} id={`sec-${i}`} className="scroll-mt-24">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                  <s.icon className="h-4 w-4 text-primary" />
                </span>
                <h2 className="font-display text-xl font-bold">{s.title}</h2>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-foreground/90">{s.body}</p>
            </section>
          ))}
        </div>

        <div className="mt-12 rounded-2xl border border-primary/30 bg-primary/5 p-6 text-center">
          <p className="text-sm text-muted-foreground">Questions about these terms?</p>
          <Link to="/sponsor/featured-tool" className="mt-3 inline-block rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
            Contact our partnerships team
          </Link>
        </div>
      </article>

      <SiteFooter />
    </div>
  );
}
