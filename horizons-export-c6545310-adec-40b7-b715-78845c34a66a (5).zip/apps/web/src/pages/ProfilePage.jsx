import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { User, LogIn, Loader2, Bookmark, Award, Calendar, Crown, ArrowRight, Trash2, Download } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbaseClient';
import { badges, getLevel } from '@/data/badges';
import { getToolBySlug } from '@/data/tools';
import { getReviewBySlug } from '@/data/reviews';

export default function ProfilePage() {
  const { user, isAuthed } = useAuth();
  const [saved, setSaved] = useState([]);
  const [badgesRecs, setBadgesRecs] = useState([]);
  const [events, setEvents] = useState([]);
  const [membership, setMembership] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function load() {
      if (!isAuthed) {
        setLoading(false);
        return;
      }
      try {
        const [savedRecs, badgeRecs, eventRecs, memberRecs] = await Promise.all([
          pb.collection('saved_tools').getFullList({ sort: '-created' }),
          pb.collection('user_badges').getFullList({ sort: '-created' }),
          pb.collection('event_registrations').getFullList({ sort: '-created' }),
          pb.collection('memberships').getFullList({ sort: '-created' }),
        ]);
        setSaved(savedRecs);
        setBadgesRecs(badgeRecs);
        setEvents(eventRecs);
        setMembership(memberRecs[0] || null);
      } catch (err) {
        setError(err?.message || 'Could not load your profile.');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [isAuthed]);

  const unsave = async (id) => {
    try {
      await pb.collection('saved_tools').delete(id);
      setSaved((prev) => prev.filter((s) => s.id !== id));
    } catch (err) {
      setError(err?.message || 'Could not remove item.');
    }
  };

  const exportCsv = () => {
    const rows = [['Type', 'Slug', 'Saved At']];
    saved.forEach((s) => rows.push([s.tool_type, s.tool_slug, s.created]));
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mechengi-saved-tools.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const totalPoints = badgesRecs.reduce((sum, b) => sum + (b.points || 0), 0);
  const { current, next } = getLevel(totalPoints);
  const earnedBadgeIds = new Set(badgesRecs.map((b) => b.badge_id));

  // Award badges based on activity (client-side, persisted to user_badges).
  useEffect(() => {
    if (!isAuthed || !user) return;
    const earned = new Set(badgesRecs.map((b) => b.badge_id));
    const toAward = [];
    if (saved.length >= 1 && !earned.has('first-save')) toAward.push('first-save');
    if (saved.length >= 5 && !earned.has('collector')) toAward.push('collector');
    if (saved.length >= 20 && !earned.has('archivist')) toAward.push('archivist');
    if (events.length >= 1 && !earned.has('event-attendee')) toAward.push('event-attendee');
    if (membership && !earned.has('member')) toAward.push('member');
    if (toAward.length === 0) return;
    const badgeMap = Object.fromEntries(badges.map((b) => [b.id, b]));
    toAward.forEach((id) => {
      const b = badgeMap[id];
      if (!b) return;
      pb.collection('user_badges')
        .create({ badge_id: id, points: b.points, owner: user.id })
        .then((rec) => setBadgesRecs((prev) => [...prev, rec]))
        .catch(() => {});
    });
  }, [isAuthed, user, saved, events, membership, badgesRecs]);

  if (!isAuthed) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet>
          <title>Your Profile — MechEngi 10X</title>
          <meta name="description" content="View your saved tools, badges, registered events, and membership in your MechEngi 10X profile." />
          <meta name="robots" content="noindex, follow" />
        </Helmet>
        <SiteHeader />
        <div className="mx-auto max-w-md px-5 py-32 text-center">
          <LogIn className="mx-auto h-10 w-10 text-primary" />
          <h1 className="mt-4 font-display text-2xl font-bold">Sign in to view your profile</h1>
          <p className="mt-2 text-sm text-muted-foreground">Track saved tools, badges, events, and membership.</p>
          <div className="mt-6 flex justify-center gap-3">
            <Link to="/login" className="rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">Sign in</Link>
            <Link to="/signup" className="rounded-xl border border-border px-6 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">Create account</Link>
          </div>
        </div>
        <SiteFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Your Profile — MechEngi 10X</title>
        <meta name="description" content="View your saved tools, badges, registered events, and membership in your MechEngi 10X profile." />
        <meta name="robots" content="noindex, follow" />
      </Helmet>
      <SiteHeader />

      <div className="mx-auto max-w-[72rem] px-5 py-12">
        <div className="flex items-center gap-2">
          <User className="h-5 w-5 text-primary" />
          <p className="font-mono text-xs uppercase tracking-wider text-primary">Your Profile</p>
        </div>
        <h1 className="mt-1 font-display text-3xl font-bold sm:text-4xl">{user?.name || 'Engineer'}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{user?.email}</p>

        {loading ? (
          <div className="mt-10 flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading your profile…
          </div>
        ) : error ? (
          <div className="mt-10 rounded-2xl border border-destructive/40 bg-destructive/10 p-6 text-sm text-destructive">{error}</div>
        ) : (
          <div className="mt-8 space-y-8">
            {/* Level + membership */}
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="rounded-2xl border border-border bg-card p-5">
                <Award className="h-5 w-5 text-primary" />
                <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Level</p>
                <p className="mt-1 font-display text-lg font-bold">{current.name}</p>
                <p className="text-xs text-muted-foreground">{totalPoints} points{next ? ` · ${next.min - totalPoints} to ${next.name}` : ''}</p>
              </div>
              <div className="rounded-2xl border border-border bg-card p-5">
                <Crown className="h-5 w-5 text-primary" />
                <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Membership</p>
                <p className="mt-1 font-display text-lg font-bold capitalize">{membership?.plan || 'Free'}</p>
                {membership?.status && <p className="text-xs text-muted-foreground capitalize">{membership.status}</p>}
                {!membership && <Link to="/membership" className="text-xs text-primary hover:underline">Upgrade →</Link>}
              </div>
              <div className="rounded-2xl border border-border bg-card p-5">
                <Bookmark className="h-5 w-5 text-primary" />
                <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Saved items</p>
                <p className="mt-1 font-display text-lg font-bold">{saved.length}</p>
                <p className="text-xs text-muted-foreground">{badgesRecs.length} badges earned</p>
              </div>
            </div>

            {/* Saved tools */}
            <div className="rounded-2xl border border-border bg-card p-6">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-semibold">Saved tools & reviews</h2>
                {saved.length > 0 && (
                  <button onClick={exportCsv} className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-primary hover:underline">
                    <Download className="h-3.5 w-3.5" /> Export CSV
                  </button>
                )}
              </div>
              {saved.length === 0 ? (
                <p className="mt-4 text-sm text-muted-foreground">No saved items yet. Browse <Link to="/tools" className="text-primary hover:underline">tools</Link> or <Link to="/reviews" className="text-primary hover:underline">reviews</Link> and bookmark them.</p>
              ) : (
                <div className="mt-4 space-y-2">
                  {saved.map((s) => {
                    const isReview = s.tool_type === 'review';
                    const item = isReview ? getReviewBySlug(s.tool_slug) : getToolBySlug(s.tool_slug);
                    const to = isReview ? `/reviews/${s.tool_slug}` : `/tools/${s.tool_slug}`;
                    return (
                      <div key={s.id} className="flex items-center justify-between rounded-xl border border-border bg-muted/30 p-3">
                        <Link to={to} className="min-w-0 flex-1 truncate text-sm font-medium hover:text-primary">
                          {item?.name || s.tool_slug} <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">· {s.tool_type}</span>
                        </Link>
                        <button onClick={() => unsave(s.id)} className="ml-3 text-muted-foreground hover:text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Badges */}
            <div className="rounded-2xl border border-border bg-card p-6">
              <h2 className="font-display text-lg font-semibold">Badges</h2>
              <div className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
                {badges.map((b) => {
                  const earned = earnedBadgeIds.has(b.id);
                  return (
                    <div key={b.id} className={`flex flex-col items-center rounded-xl border p-3 text-center ${earned ? 'border-primary/40 bg-primary/5' : 'border-border opacity-50'}`}>
                      <span className="text-2xl">{b.icon}</span>
                      <p className="mt-1 text-[11px] font-medium leading-tight">{b.name}</p>
                      <p className="mt-0.5 font-mono text-[9px] text-muted-foreground">{b.points} pts</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Registered events */}
            <div className="rounded-2xl border border-border bg-card p-6">
              <h2 className="font-display text-lg font-semibold">Your registered events</h2>
              {events.length === 0 ? (
                <p className="mt-4 text-sm text-muted-foreground">No registrations yet. <Link to="/events" className="text-primary hover:underline">Browse events →</Link></p>
              ) : (
                <div className="mt-4 space-y-2">
                  {events.map((e) => (
                    <Link key={e.id} to={`/events/${e.event_slug}`} className="flex items-center gap-3 rounded-xl border border-border bg-muted/30 p-3 hover:border-primary/40">
                      <Calendar className="h-4 w-4 text-primary" />
                      <span className="flex-1 truncate text-sm font-medium">{e.event_title}</span>
                      <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{e.created?.slice(0, 10)}</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-3">
              <Link to="/affiliate" className="flex items-center gap-2 rounded-xl border border-border px-5 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">
                Affiliate dashboard <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/referral" className="flex items-center gap-2 rounded-xl border border-border px-5 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">
                Referral program <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/membership" className="flex items-center gap-2 rounded-xl border border-border px-5 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">
                Membership <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        )}
      </div>

      <SiteFooter />
    </div>
  );
}
