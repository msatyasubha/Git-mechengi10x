import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams } from 'react-router-dom';
import { Clock, PlayCircle, Check, ArrowRight, ChevronDown, ChevronUp, Lock } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { getCourseBySlug, courses } from '@/data/courses';
import { useAuth } from '@/hooks/use-auth';

export default function CourseDetailPage() {
  const { slug } = useParams();
  const course = getCourseBySlug(slug);
  const { isAuthed } = useAuth();
  const [openModule, setOpenModule] = useState(0);

  if (!course) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet><title>Course not found — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
        <SiteHeader />
        <div className="mx-auto max-w-md px-5 py-32 text-center">
          <h1 className="font-display text-2xl font-bold">Course not found</h1>
          <Link to="/courses" className="mt-4 inline-block text-primary hover:underline">← Back to courses</Link>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const others = courses.filter((c) => c.slug !== course.slug).slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{course.title} — MechEngi 10X Course</title>
        <meta name="description" content={course.subtitle} />
        <link rel="canonical" href={`https://mechengi10x.com/courses/${course.slug}`} />
      </Helmet>

      <SiteHeader />

      {/* Hero */}
      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-12">
          <nav className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            <Link to="/courses" className="hover:text-foreground">Courses</Link>
            <span>/</span>
            <span className="text-foreground">{course.category}</span>
          </nav>

          <div className="mt-6 grid gap-10 lg:grid-cols-[1.5fr_1fr]">
            <div>
              <span className={`inline-flex rounded-md border px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider ${course.accent}`}>
                {course.category}
              </span>
              <h1 className="mt-4 font-display text-4xl font-bold leading-tight sm:text-5xl">{course.title}</h1>
              <p className="mt-4 max-w-xl text-lg text-muted-foreground">{course.subtitle}</p>

              <div className="mt-6 flex flex-wrap items-center gap-5 font-mono text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5"><Clock className="h-4 w-4" /> {course.duration}</span>
                <span className="flex items-center gap-1.5"><PlayCircle className="h-4 w-4" /> {course.lessons} lessons</span>
              </div>

              <div className="mt-6 rounded-xl border border-border bg-card p-4">
                <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Listed instructor — availability unconfirmed</p>
                <p className="mt-1 font-display font-semibold">{course.instructor.name}</p>
                <p className="text-sm text-muted-foreground">{course.instructor.role}</p>
              </div>
            </div>

            {/* Enroll card */}
            <div className="rounded-2xl border border-border bg-card p-6">
              <div className="flex items-baseline gap-2">
                <span className="font-display text-4xl font-bold text-primary">${course.price}</span>
                <span className="text-sm text-muted-foreground">listed price · inquire for availability</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">Proposed course outline · {course.lessons} lessons. Availability and delivery are not confirmed.</p>

              <a
                href={`mailto:hello@mechengi10x.com?subject=${encodeURIComponent(`Course interest: ${course.title}`)}&body=${encodeURIComponent(`Hello, I am interested in updates about ${course.title}.`)}`}
                className="glow-primary mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
              >
                Email your interest <ArrowRight className="h-4 w-4" />
              </a>
              <p className="mt-3 rounded-lg border border-border bg-muted/30 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
                This opens your email app to contact our team. It is an inquiry, not enrollment or payment; no cohort or launch date is confirmed.
              </p>
              <Link to="/advisor" className="mt-3 block w-full rounded-xl border border-border px-6 py-3 text-center font-medium text-muted-foreground hover:border-primary/40 hover:text-primary">
                Ask if this course fits me
              </Link>

              <ul className="mt-6 space-y-2.5 border-t border-border pt-5">
                {['Proposed project-based curriculum', 'Ask about availability and delivery', 'Contact: hello@mechengi10x.com'].map((b) => (
                  <li key={b} className="flex items-start gap-2 text-sm text-foreground/90">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> {b}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* What you'll learn */}
      <section className="mx-auto max-w-[90rem] px-5 py-16">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-2xl font-bold">What you'll learn</h2>
            <ul className="mt-5 space-y-3">
              {course.outcomes.map((o) => (
                <li key={o} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4">
                  <Check className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <span className="text-sm text-foreground/90">{o}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold">About this course</h2>
            <p className="mt-5 text-sm leading-relaxed text-muted-foreground">{course.description}</p>
          </div>
        </div>
      </section>

      {/* Curriculum */}
      <section className="border-y border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-16">
          <h2 className="font-display text-2xl font-bold">Curriculum</h2>
          <p className="mt-2 text-sm text-muted-foreground">{course.modules.length} modules · {course.lessons} lessons · {course.duration}</p>

          <div className="mt-8 space-y-3">
            {course.modules.map((m, i) => (
              <div key={m.title} className="overflow-hidden rounded-xl border border-border bg-card">
                <button
                  onClick={() => setOpenModule(openModule === i ? -1 : i)}
                  className="flex w-full items-center justify-between px-5 py-4 text-left"
                >
                  <div className="flex items-center gap-3">
                    <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 font-mono text-xs font-bold text-primary">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className="font-display font-semibold">{m.title}</span>
                  </div>
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <span className="font-mono text-[10px] uppercase tracking-wider">{m.lessons.length} lessons</span>
                    {openModule === i ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </div>
                </button>
                {openModule === i && (
                  <ul className="border-t border-border">
                    {m.lessons.map((l, j) => (
                      <li key={l} className="flex items-center gap-3 px-5 py-3 text-sm text-muted-foreground hover:bg-muted/30">
                        <Lock className="h-4 w-4 text-muted-foreground/60" />
                        <span>{l}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>

          {!isAuthed && (
            <div className="mt-8 rounded-xl border border-primary/30 bg-primary/5 p-5 text-center">
              <p className="text-sm text-muted-foreground">
                <Lock className="mr-1.5 inline h-3.5 w-3.5" /> Sign in to join the community. The curriculum above is an outline, not a lesson preview.
              </p>
              <Link to="/signup" className="mt-3 inline-block rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
                Create free account
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* More courses */}
      <section className="mx-auto max-w-[90rem] px-5 py-16">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-bold">More courses</h2>
          <Link to="/courses" className="inline-flex items-center gap-1.5 font-mono text-xs uppercase tracking-wider text-primary hover:underline">
            All courses <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {others.map((c) => (
            <Link key={c.slug} to={`/courses/${c.slug}`} className="group rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/40">
              <span className="text-2xl">{c.icon}</span>
              <h3 className="mt-3 font-display font-semibold group-hover:text-primary">{c.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{c.subtitle}</p>
              <p className="mt-3 font-display font-bold text-primary">${c.price}</p>
            </Link>
          ))}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
