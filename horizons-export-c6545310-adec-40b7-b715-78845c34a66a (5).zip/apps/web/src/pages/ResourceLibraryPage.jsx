import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import {
  FileText,
  Download,
  Code2,
  BookOpen,
  Wrench,
  ExternalLink,
  Info,
  Search,
  ShieldCheck,
} from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

// Honest resource catalogue. Items marked "external" link to real, verifiable
// public resources; "template" items are downloadable starter files we ship
// in-repo. We do NOT fabricate benchmarks, endorsements, or availability.
const RESOURCES = [
  {
    category: 'Templates & Cheat Sheets',
    items: [
      {
        type: 'template',
        icon: FileText,
        title: 'FEA Setup Checklist (Markdown)',
        desc: 'A plain-text checklist for setting up a linear static FEA run: geometry prep, mesh quality targets, boundary conditions, material assignment, and result sanity checks.',
        format: '.md',
        href: '/downloads/fea-setup-checklist.md',
      },
      {
        type: 'template',
        icon: FileText,
        title: 'Engineering Unit Conversion Table (CSV)',
        desc: 'A reference table of SI ↔ imperial conversion factors for length, pressure, force, torque, stress, and temperature. Confirm precision against the applicable standard.',
        format: '.csv',
        href: '/downloads/unit-conversion-table.csv',
      },
      {
        type: 'template',
        icon: Code2,
        title: 'Python Beam Deflection Snippet',
        desc: 'A minimal, commented Python function for simply-supported beam deflection under a central point load (δ = PL³/48EI). Ready to paste into a Jupyter notebook.',
        format: '.py',
        href: '/downloads/beam_deflection.py',
      },
      {
        type: 'template',
        icon: FileText,
        title: 'Design Review Sign-off Template (Markdown)',
        desc: 'A structured sign-off template capturing assumptions, inputs, calculation references, and reviewer sign-off lines for design documentation.',
        format: '.md',
        href: '/downloads/design-review-signoff.md',
      },
    ],
  },
  {
    category: 'Integration Guides',
    items: [
      {
        type: 'template',
        icon: FileText,
        title: 'The Complete CAD-to-ERP Integration Checklist for Manufacturing Teams',
        desc: 'A vendor-neutral, 9-section checklist for planning a CAD/design-tool to ERP bridge: gateway selection (n8n, Make, Zapier, custom REST API), webhook design, OAuth 2.0, schema mapping, retries, alerting, security, and rollout testing.',
        format: '.md',
        href: '/downloads/cad-to-erp-integration-checklist.md',
      },
      {
        type: 'guide',
        icon: Wrench,
        title: 'Exporting Calculator Results to CAD & PLM',
        desc: 'How to take CSV/JSON exports from our calculators into common engineering workflows — spreadsheet hand-off, PLM note attachment, and STEP-neutral documentation.',
        format: 'Guide',
        href: '/downloads/export-to-cad-guide.md',
      },
      {
        type: 'guide',
        icon: Code2,
        title: 'Automation Pipeline Patterns (n8n / Make / Zapier)',
        desc: 'Reference patterns for piping calculator JSON output into automation tools — webhook shape, field mapping, and where to validate units before downstream use.',
        format: 'Guide',
        href: '/downloads/automation-pipeline-guide.md',
      },
      {
        type: 'guide',
        icon: Code2,
        title: 'Automation Macro & Script Repository',
        desc: 'A searchable library of copy-paste automation scripts for FreeCAD, Fusion 360, and SOLIDWORKS — batch exports, backups, renames, and reports. Community submissions are reviewed before publication and labelled unverified until moderated.',
        format: 'Library',
        href: '/macro-library',
      },
    ],
  },
  {
    category: 'CAD Benchmark Suite',
    items: [
      {
        type: 'template',
        icon: FileText,
        title: 'CAD Benchmark Suite — README & Instructions',
        desc: 'How to run the community FreeCAD benchmark harness on your own hardware, what it measures, licensing (MIT), and its honest verification status. No published results — you run it and record your own.',
        format: '.md',
        href: '/downloads/cad-benchmark-suite/README.md',
      },
      {
        type: 'template',
        icon: Code2,
        title: 'FreeCAD Benchmark Script (Python)',
        desc: 'A transparent timing harness for common CAD operations — document creation, primitives, boolean fuse/cut, STEP export/import, and tessellation. Draft community tool, MIT-licensed, not independently audited.',
        format: '.py',
        href: '/downloads/cad-benchmark-suite/benchmark_freecad.py',
      },
      {
        type: 'template',
        icon: FileText,
        title: 'Benchmark Results Template (CSV)',
        desc: 'A blank CSV template for recording your own benchmark runs — hardware, FreeCAD version, workload size, and median timings. Self-reported, unverified results.',
        format: '.csv',
        href: '/downloads/cad-benchmark-suite/results-template.csv',
      },
      {
        type: 'template',
        icon: Code2,
        title: 'Open 1,000-Part Assembly Benchmark (Python)',
        desc: 'A transparent timing harness that programmatically builds a configurable 1,000-part assembly (alternating boxes and cylinders on a grid) and times assembly build, full recompute, document save, STEP export, and tessellation on your own workstation hardware. MIT-licensed, community-run — no published results.',
        format: '.py',
        href: '/downloads/cad-benchmark-suite/assembly_benchmark_1000.py',
      },
      {
        type: 'template',
        icon: FileText,
        title: 'Assembly Benchmark Results Template (CSV)',
        desc: 'A blank CSV template for recording your own assembly benchmark runs — CPU, RAM, GPU, OS, storage, FreeCAD version, part count, and per-phase timings. Self-reported, unverified results.',
        format: '.csv',
        href: '/downloads/cad-benchmark-suite/assembly-results-template.csv',
      },
      {
        type: 'template',
        icon: FileText,
        title: 'Shop-Floor Benchmark Framework (Weldments, Nonlinear FEA, BOMs, Drawings)',
        desc: 'A documented, repeatable stress-test specification for comparing CAD/CAE tools on shop-floor workloads: weldment modeling and cut lists, nonlinear FEA on a thin-walled housing, 1,000-part BOM generation with eBOM → mBOM transformation, drawing creation, full rebuild time, memory usage, and workflow friction. Framework only — no results published, none claimed as run.',
        format: '.md',
        href: '/downloads/cad-benchmark-suite/shop-floor-benchmark-framework.md',
      },
      {
        type: 'template',
        icon: FileText,
        title: 'Shop-Floor Benchmark Results Template (CSV)',
        desc: 'A blank CSV template for recording your own shop-floor benchmark runs — hardware, tool version, license tier, per-workload medians, peak memory, supported/not-supported status, and friction notes. Self-reported, unverified results.',
        format: '.csv',
        href: '/downloads/cad-benchmark-suite/shop-floor-results-template.csv',
      },
      {
        type: 'guide',
        icon: ShieldCheck,
        title: 'Benchmark Suite License & Source Notes',
        desc: 'MIT license text for the suite, FreeCAD trademark and LGPL-2.1+ attribution, and the honest verification status: community draft, no published benchmark results.',
        format: 'Guide',
        href: '/downloads/cad-benchmark-suite/LICENSE-NOTES.md',
      },
    ],
  },
  {
    category: 'Curated External References',
    items: [
      {
        type: 'external',
        icon: BookOpen,
        title: 'NIST SP 811 — Guide for the Use of SI',
        desc: 'Authoritative reference for SI units and conversions; some factors in our calculators are rounded.',
        format: 'External',
        href: 'https://www.nist.gov/pml/special-publication-811',
      },
      {
        type: 'external',
        icon: BookOpen,
        title: 'Engineering ToolBox — Engineering Resources',
        desc: 'Free reference data for material properties, friction factors, and fluid properties used as defaults in our calculators.',
        format: 'External',
        href: 'https://www.engineeringtoolbox.com/',
      },
      {
        type: 'external',
        icon: BookOpen,
        title: 'NPTEL / SWAYAM — Free Engineering Courses',
        desc: 'Free, verified Indian engineering courseware (IIT/NIT) covering mechanics of materials, fluid mechanics, and machine design.',
        format: 'External',
        href: 'https://nptel.ac.in/',
      },
    ],
  },
];

const CATEGORIES = ['All', ...RESOURCES.map((r) => r.category)];

function ResourceCard({ item }) {
  const Icon = item.icon;
  const isExternal = item.type === 'external';
  const isTemplate = item.type === 'template';
  return (
    <a
      href={item.href}
      target={isExternal ? '_blank' : undefined}
      rel={isExternal ? 'noopener noreferrer' : undefined}
      className="group flex flex-col rounded-2xl border border-border bg-card p-5 transition-all hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5"
    >
      <div className="mb-3 flex items-center justify-between">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-muted">
          <Icon className="h-5 w-5 text-primary" />
        </span>
        <span className={`rounded-full border px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider ${
          isTemplate ? 'border-green-500/30 bg-green-500/10 text-green-400'
          : isExternal ? 'border-blue-500/30 bg-blue-500/10 text-blue-400'
          : 'border-accent/30 bg-accent/10 text-accent'
        }`}>
          {item.format}
        </span>
      </div>
      <h3 className="font-display text-base font-semibold leading-snug group-hover:text-primary">{item.title}</h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{item.desc}</p>
      <span className="mt-4 flex items-center gap-1.5 font-mono text-[11px] text-muted-foreground group-hover:text-primary">
        {isExternal ? <><ExternalLink className="h-3 w-3" /> Open reference</>
        : isTemplate ? <><Download className="h-3 w-3" /> Download</>
        : <><FileText className="h-3 w-3" /> Read guide</>}
      </span>
    </a>
  );
}

export default function ResourceLibraryPage() {
  const [cat, setCat] = useState('All');
  const [q, setQ] = useState('');

  const filtered = RESOURCES
    .filter((r) => cat === 'All' || r.category === cat)
    .flatMap((r) => r.items)
    .filter((it) => !q || it.title.toLowerCase().includes(q.toLowerCase()) || it.desc.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Free Engineering Resource Library — Templates, Cheat Sheets & Guides | MechEngi 10X</title>
        <meta name="description" content="Free downloadable engineering templates, unit conversion tables, FEA checklists, integration guides, and curated external references. No sign-up, no paywall." />
      </Helmet>

      <SiteHeader />

      <div className="border-b border-border bg-card/30 py-10">
        <div className="mx-auto max-w-[90rem] px-5">
          <div className="flex items-center gap-2 mb-3">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <BookOpen className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Free · No sign-up</p>
          </div>
          <h1 className="font-display text-3xl font-bold sm:text-4xl">Engineering Resource Library</h1>
          <p className="mt-2 max-w-2xl text-muted-foreground">
            Downloadable templates, cheat sheets, and integration guides for engineering workflows — plus curated,
            verifiable external references. Everything here is free and openly licensed.
          </p>
          <div className="mt-4 flex items-start gap-2 rounded-lg border border-border bg-muted/30 px-3 py-2 text-[11px] text-muted-foreground max-w-2xl">
            <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
            <span>
              We do not fabricate benchmarks, endorsements, or availability. External links point to real public
              sources (NIST, NPTEL, Engineering ToolBox). Templates are starter files — verify all values against your
              design code before use.
            </span>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search resources…"
              className="h-11 w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                  cat === c ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {filtered.length > 0 ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((it) => <ResourceCard key={it.title} item={it} />)}
          </div>
        ) : (
          <div className="rounded-xl border border-border py-20 text-center">
            <p className="font-display text-lg font-semibold">No resources match your search</p>
            <button onClick={() => { setQ(''); setCat('All'); }} className="mt-4 rounded-lg border border-border px-5 py-2 text-sm hover:border-primary/50">
              Clear filters
            </button>
          </div>
        )}

        <div className="mt-14 rounded-2xl border border-border bg-card p-7">
          <div className="flex items-center gap-2">
            <Info className="h-5 w-5 text-primary" />
            <h2 className="font-display text-xl font-bold">Peer verification & community scripts</h2>
          </div>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground">
            Verified-engineer peer reviews and an open-source script template gallery are on our roadmap. We will not
            publish peer-review badges or community scripts until a real verification workflow is in place — no
            fabricated endorsements, no unverified "expert" labels.
          </p>
          <div className="mt-5 grid gap-4 sm:grid-cols-3">
            <div className="rounded-xl border border-border bg-muted/20 p-4">
              <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Status</p>
              <p className="mt-1 text-sm font-medium text-amber-400">Planned — not yet live</p>
            </div>
            <div className="rounded-xl border border-border bg-muted/20 p-4">
              <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">What it will be</p>
              <p className="mt-1 text-sm text-foreground">Verified-engineer peer reviews with disclosed credentials</p>
            </div>
            <div className="rounded-xl border border-border bg-muted/20 p-4">
              <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Today</p>
              <p className="mt-1 text-sm text-foreground">Open community ratings on tool pages (clearly labelled)</p>
            </div>
          </div>
          <p className="mt-5 text-sm text-muted-foreground">
            Want to contribute a script template or be a verified reviewer?{' '}
            <a href="mailto:hello@mechengi10x.com?subject=Verified%20Reviewer" className="text-primary hover:underline">
              Get in touch
            </a>{' '}
            — we are building this with real engineers, not placeholders.
          </p>
        </div>

        <div className="mt-10 text-center">
          <Link to="/calculators" className="inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3 font-semibold text-primary-foreground hover:opacity-90">
            Open Engineering Calculators <FileText className="h-4 w-4" />
          </Link>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
