import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Check, ArrowRight, Sparkles, BarChart3, Users, Shield } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { sponsorshipPackages, sponsorTestimonials } from '@/data/sponsorshipPackages';

export default function SponsorPage() {
  const [hovered, setHovered] = useState(null);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Sponsor MechEngi 10X — Reach Practicing Mechanical Engineers</title>
        <meta name="description" content="Put your engineering tool in front of practicing mechanical engineers. Choose Featured Tool placement, an Exclusive Review, or a co-hosted Webinar Sponsorship." />
      </Helmet>

      <SiteHeader />

      {/* Hero */}
      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-20 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Sponsorship Program</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            Put your tool in front of <span className="text-primary">thousands of</span> mechanical engineers
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            MechEngi 10X is the independent discovery platform engineers trust to choose software.
            Sponsor a placement, an expert review, or a webinar — and reach a high-intent, technical audience.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a href="#packages" className="glow-primary rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]">
              View Packages
            </a>
            <a href="#inquiry" className="rounded-xl border border-border px-8 py-3 font-semibold transition-colors hover:border-primary/40 hover:text-primary">
              Talk to Us
            </a>
          </div>

          {/* Trust stats */}
          <div className="mx-auto mt-14 grid max-w-3xl grid-cols-2 gap-4 sm:grid-cols-4">
            {[
              { value: '80+', label: 'Tools reviewed' },
              { value: '100%', label: 'Independent' },
              { value: '7', label: 'Categories' },
              { value: 'Quarterly', label: 'Score updates' },
            ].map((s) => (
              <div key={s.label} className="rounded-xl border border-border bg-card/50 p-4">
                <p className="font-display text-2xl font-bold text-primary">{s.value}</p>
                <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{s.label}</p>
              </div>
            ))}
          </div>

          <div className="mx-auto mt-10 flex max-w-2xl items-center justify-center gap-3 rounded-xl border border-primary/30 bg-primary/5 px-5 py-3 text-center">
            <Shield className="h-5 w-5 shrink-0 text-primary" />
            <p className="font-display text-sm font-semibold text-foreground">Sponsors never influence scores or rankings.</p>
          </div>
        </div>
      </section>

      {/* Packages */}
      <section id="packages" className="mx-auto max-w-[90rem] px-5 py-20">
        <div className="mb-12 text-center">
          <h2 className="font-display text-3xl font-bold sm:text-4xl">Three ways to sponsor</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Each package is transparent about what you get and the audience it reaches. No hidden fees, no vanity metrics.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {sponsorshipPackages.map((pkg) => (
            <div
              key={pkg.id}
              onMouseEnter={() => setHovered(pkg.id)}
              onMouseLeave={() => setHovered(null)}
              className={`relative flex flex-col rounded-2xl border bg-card p-7 transition-all ${
                pkg.popular ? 'border-primary/50 shadow-lg shadow-primary/10' : 'border-border'
              } ${hovered === pkg.id ? '-translate-y-1' : ''}`}
            >
              {pkg.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-primary-foreground">
                  Most Popular
                </span>
              )}
              <span className={`inline-flex w-fit rounded-md border px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider ${pkg.accent}`}>
                {pkg.name}
              </span>
              <p className="mt-4 text-sm text-muted-foreground">{pkg.tagline}</p>
              <div className="mt-5 flex items-baseline gap-1">
                <span className="font-display text-4xl font-bold">${pkg.price.toLocaleString()}</span>
                <span className="text-sm text-muted-foreground">{pkg.period}</span>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{pkg.summary}</p>

              <ul className="mt-6 flex-1 space-y-2.5">
                {pkg.deliverables.map((d) => (
                  <li key={d} className="flex items-start gap-2.5 text-sm">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    <span className="text-foreground/90">{d}</span>
                  </li>
                ))}
              </ul>

              <Link
                to={`/sponsor/${pkg.id}`}
                className={`mt-7 flex items-center justify-center gap-2 rounded-xl px-5 py-3 font-semibold transition-all active:scale-[0.98] ${
                  pkg.popular
                    ? 'glow-primary bg-primary text-primary-foreground hover:opacity-90'
                    : 'border border-border hover:border-primary/40 hover:text-primary'
                }`}
              >
                Explore {pkg.name} <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Why sponsor */}
      <section className="border-y border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-20">
          <div className="mb-12 text-center">
            <h2 className="font-display text-3xl font-bold sm:text-4xl">Why engineers trust MechEngi 10X</h2>
            <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
              Sponsorship gets you reach. Our editorial standards get you credibility.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {[
              { icon: BarChart3, title: 'Independent scoring', body: 'Every tool is assessed against a transparent 100-point, 8-category MechEngi Score framework. Sponsorship never changes a score.' },
              { icon: Users, title: 'A real engineering audience', body: 'Our readers are practicing mechanical engineers evaluating software — not tire-kickers.' },
              { icon: Shield, title: 'Clear affiliate disclosure', body: 'We disclose every commercial relationship openly. Trust is the product.' },
            ].map((f) => (
              <div key={f.title} className="rounded-2xl border border-border bg-card p-6">
                <f.icon className="h-7 w-7 text-primary" />
                <h3 className="mt-4 font-display text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials teaser */}
      <section className="mx-auto max-w-[90rem] px-5 py-20">
        <div className="mb-4 text-center">
          <h2 className="font-display text-3xl font-bold sm:text-4xl">Illustrative sponsorship scenarios</h2>
        </div>
        <div className="mx-auto mb-10 max-w-2xl rounded-xl border border-amber-500/30 bg-amber-500/5 px-5 py-4 text-center">
          <p className="text-sm leading-relaxed text-muted-foreground">
            The scenarios below are <span className="font-semibold text-foreground">illustrative examples</span> of the
            outcomes a sponsorship is designed to drive &mdash; not verified testimonials or measured results from
            named companies. We do not claim that any organization listed has endorsed or sponsored MechEngi 10X.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {sponsorTestimonials.map((t) => (
            <div key={t.company} className="rounded-2xl border border-border bg-card p-6">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 font-display text-sm font-bold text-primary">
                  {t.logo}
                </span>
                <div>
                  <p className="font-display font-semibold">{t.company}</p>
                  <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{t.author}</p>
                </div>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-foreground/90">“{t.quote}”</p>
              <div className="mt-4 flex gap-4">
                {t.results.map((r) => (
                  <div key={r.metric}>
                    <p className="font-display text-lg font-bold text-primary">{r.value}</p>
                    <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{r.metric}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="mt-8 text-center">
          <Link to="/sponsor/testimonials" className="font-mono text-xs uppercase tracking-wider text-primary hover:underline">
            Read full case studies →
          </Link>
        </div>
      </section>

      {/* Inquiry CTA */}
      <section id="inquiry" className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-2xl px-5 py-20 text-center">
          <h2 className="font-display text-3xl font-bold sm:text-4xl">Ready to reach engineers?</h2>
          <p className="mx-auto mt-3 max-w-md text-muted-foreground">
            Tell us about your tool and goals. We'll reply with a tailored proposal.
          </p>
          <Link
            to="/sponsor/featured-tool"
            className="glow-primary mt-7 inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
          >
            Start an inquiry <ArrowRight className="h-4 w-4" />
          </Link>
          <p className="mt-4 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            Or read our <Link to="/sponsor/terms" className="text-primary hover:underline">sponsorship terms</Link>
          </p>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
