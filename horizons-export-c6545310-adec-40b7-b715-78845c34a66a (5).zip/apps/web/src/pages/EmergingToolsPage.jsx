import { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Search, ExternalLink, Sparkles, FlaskConical, ArrowRight, AlertTriangle } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import {
  emergingTools,
  emergingToolStatuses,
  emergingToolCategories,
} from '@/data/emergingTools';

const statusStyles = {
  ga: { label: 'Generally Available', cls: 'border-green-500/30 bg-green-500/10 text-green-400' },
  'public-beta': { label: 'Public Beta', cls: 'border-amber-500/30 bg-amber-500/10 text-amber-400' },
  'early-access': { label: 'Early Access', cls: 'border-primary/30 bg-primary/10 text-primary' },
};

const categoryLabel = {
  'coding-agent': 'Terminal Coding Agent',
  'agentic-ide': 'Agentic IDE',
  'autonomous-agent': 'Autonomous Agent',
};

export default function EmergingToolsPage() {
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [cat, setCat] = useState('all');

  const filtered = useMemo(() => {
    let list = emergingTools;
    if (status !== 'all') list = list.filter((t) => t.status === status);
    if (cat !== 'all') list = list.filter((t) => t.category === cat);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.vendor.toLowerCase().includes(q) ||
          t.tagline.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q),
      );
    }
    return list;
  }, [status, cat, query]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Emerging & Developing AI Tools for Engineers 2026 — MechEngi 10X</title>
        <meta
          name="description"
          content="A tracked list of new and actively developing AI tools for engineers — Claude Code, OpenAI Codex CLI, Gemini CLI, Google Jules, Devin, and Windsurf. Real availability status, pricing, and last-verified dates. No invented ratings."
        />
      </Helmet>

      <SiteHeader />

      {/* Header */}
      <section className="border-b border-border bg-card/20 py-12">
        <div className="mx-auto max-w-[72rem] px-5">
          <nav className="mb-4 flex items-center gap-1.5 font-mono text-xs text-muted-foreground">
            <Link to="/" className="hover:text-foreground">Home</Link>
            <span>/</span>
            <span className="text-foreground">Emerging AI Tools</span>
          </nav>

          <div className="flex items-start gap-3">
            <span className="mt-1 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/20">
              <FlaskConical className="h-5 w-5 text-primary" />
            </span>
            <div>
              <span className="font-mono text-xs uppercase tracking-widest text-primary">Actively Developing</span>
              <h1 className="mt-1 font-display text-3xl font-extrabold sm:text-4xl lg:text-5xl">
                Emerging AI Tools for Engineers
              </h1>
              <p className="mt-3 max-w-2xl text-base text-muted-foreground sm:text-lg">
                New and rapidly evolving AI coding agents, agentic IDEs, and autonomous software engineers. Each tool is
                labeled with its <span className="text-foreground">real availability</span> and a{' '}
                <span className="text-foreground">last-verified date</span>. We do not score these tools — they are too
                new to rate honestly.
              </p>
            </div>
          </div>

          {/* Honesty note */}
          <div className="mt-6 flex items-start gap-2.5 rounded-xl border border-amber-500/20 bg-amber-500/5 px-4 py-3 text-sm text-amber-200/90">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
            <p>
              Developing tools change quickly — pricing, features, and availability may shift between verifications.
              Status shown here was confirmed on the listed <strong>last-verified</strong> date. Always confirm on the
              vendor’s official site before purchasing or relying on a capability.
            </p>
          </div>

          {/* Search */}
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <div className="relative max-w-md flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search emerging AI tools…"
                className="h-11 w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          </div>

          {/* Status filter */}
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Status:</span>
            {emergingToolStatuses.map((s) => (
              <button
                key={s.id}
                onClick={() => setStatus(s.id)}
                className={`rounded-full border px-3 py-1.5 font-mono text-xs transition-colors ${
                  status === s.id
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/30 hover:text-foreground'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>

          {/* Category filter */}
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Type:</span>
            {emergingToolCategories.map((c) => (
              <button
                key={c.id}
                onClick={() => setCat(c.id)}
                className={`rounded-full border px-3 py-1.5 font-mono text-xs transition-colors ${
                  cat === c.id
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/30 hover:text-foreground'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Results */}
      <section className="mx-auto max-w-[90rem] px-5 py-10">
        <p className="mb-6 font-mono text-xs text-muted-foreground">
          {filtered.length} emerging tool{filtered.length !== 1 ? 's' : ''} found
        </p>

        {filtered.length > 0 ? (
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((tool) => {
              const st = statusStyles[tool.status];
              return (
                <article
                  key={tool.slug}
                  className="group flex flex-col rounded-2xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5"
                >
                  <div className="flex items-start gap-3">
                    <span className="text-3xl">{tool.logoEmoji}</span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[10px] ${st.cls}`}>
                          <Sparkles className="h-2.5 w-2.5" /> {st.label}
                        </span>
                        <span className="rounded-full border border-border px-2 py-0.5 font-mono text-[10px] text-muted-foreground">
                          {categoryLabel[tool.category]}
                        </span>
                      </div>
                      <h2 className="mt-1.5 font-display text-lg font-bold leading-snug group-hover:text-primary">
                        {tool.name}
                      </h2>
                      <p className="text-xs text-muted-foreground">{tool.vendor}</p>
                    </div>
                  </div>

                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{tool.tagline}</p>
                  <p className="mt-2 line-clamp-3 text-xs leading-relaxed text-muted-foreground/80">
                    {tool.description}
                  </p>

                  {/* Key features */}
                  <ul className="mt-3 space-y-1.5">
                    {tool.keyFeatures.slice(0, 3).map((f, i) => (
                      <li key={i} className="flex items-start gap-1.5 text-xs">
                        <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                        {f}
                      </li>
                    ))}
                  </ul>

                  {/* Pricing + verified */}
                  <div className="mt-4 grid grid-cols-2 gap-2 border-t border-border pt-3">
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Pricing</p>
                      <p className="mt-0.5 text-xs text-foreground">
                        {tool.pricing.free ? (
                          <span className="text-green-400">Free tier available</span>
                        ) : (
                          `From $${tool.pricing.paidFrom}/mo`
                        )}
                      </p>
                      <p className="mt-0.5 text-[10px] leading-snug text-muted-foreground/80">
                        {tool.pricing.freeLabel || tool.pricing.paidLabel}
                      </p>
                    </div>
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Last verified</p>
                      <p className="mt-0.5 font-mono text-xs text-foreground">{tool.lastVerified}</p>
                      <p className="mt-0.5 text-[10px] leading-snug text-muted-foreground/80">
                        Confirm on vendor site
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 flex gap-2">
                    <a
                      href={tool.officialUrl}
                      target="_blank"
                      rel="noopener noreferrer sponsored"
                      className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-primary py-2 font-mono text-xs text-primary-foreground transition-opacity hover:opacity-90"
                    >
                      Visit official site <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="py-20 text-center">
            <p className="font-display text-xl font-semibold">No emerging tools match</p>
            <p className="mt-2 text-muted-foreground">Try adjusting your search or filters.</p>
            <button
              onClick={() => { setQuery(''); setStatus('all'); setCat('all'); }}
              className="mt-4 rounded-xl bg-primary px-6 py-2 font-medium text-primary-foreground"
            >
              Clear filters
            </button>
          </div>
        )}
      </section>

      {/* Context + cross-links */}
      <section className="border-t border-border bg-card/20 py-12">
        <div className="mx-auto max-w-[72rem] px-5">
          <h2 className="font-display text-xl font-bold">How we treat developing tools</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            <div className="rounded-xl border border-border bg-card p-4">
              <p className="font-display text-sm font-semibold text-primary">No invented ratings</p>
              <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                These tools are too new to score. We show verified status, pricing, and capabilities instead of
                fabricated MechEngi Scores or review counts.
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-4">
              <p className="font-display text-sm font-semibold text-primary">Status you can trust</p>
              <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                Each entry is labeled Generally Available, Public Beta, or Early Access — confirmed against the vendor’s
                official site on the last-verified date.
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-4">
              <p className="font-display text-sm font-semibold text-primary">Re-verified regularly</p>
              <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                Developing tools change fast. We re-check status and pricing periodically and update the last-verified
                date when we do.
              </p>
            </div>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { to: '/ai-tools', label: 'Reviewed AI Tools', desc: 'Scored, in-depth AI tool profiles' },
              { to: '/compare', label: 'Compare Tools', desc: 'Side-by-side feature comparisons' },
              { to: '/advisor', label: 'AI Advisor', desc: 'Ask for a recommendation' },
              { to: '/wizard', label: 'Find a Tool', desc: '3-step recommendation wizard' },
            ].map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="group flex flex-col rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:bg-primary/5"
              >
                <p className="font-display font-semibold group-hover:text-primary">{l.label}</p>
                <p className="mt-1 text-xs text-muted-foreground">{l.desc}</p>
                <ArrowRight className="mt-2 h-4 w-4 text-muted-foreground opacity-0 transition-all group-hover:translate-x-1 group-hover:text-primary group-hover:opacity-100" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
