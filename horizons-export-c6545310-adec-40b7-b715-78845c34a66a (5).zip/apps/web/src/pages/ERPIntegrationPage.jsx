import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import {
  Workflow,
  Webhook,
  KeyRound,
  ArrowRight,
  ArrowLeftRight,
  ShieldAlert,
  Download,
  Check,
  Loader2,
  Send,
  Info,
  ShieldCheck,
  Code2,
  Wrench,
  Bell,
  FileDown,
} from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import pb from '@/lib/pocketbaseClient';

const inputCls =
  'min-h-[44px] w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary';

function Field({ label, children }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Consultation inquiry form — writes to PocketBase consultation_inquiries */
/* ------------------------------------------------------------------ */

function ConsultationForm() {
  const [form, setForm] = useState({
    company_name: '',
    contact_name: '',
    email: '',
    phone: '',
    cad_tools: '',
    erp_system: '',
    integration_platform: 'undecided',
    message: '',
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await pb.collection('consultation_inquiries').create(form);
      setDone(true);
    } catch (err) {
      setError(err?.response?.message || err?.message || 'Submission failed. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
          <Check className="h-7 w-7 text-primary" />
        </div>
        <h3 className="mt-5 font-display text-xl font-bold">Consultation request received</h3>
        <p className="mx-auto mt-3 max-w-sm text-sm text-muted-foreground">
          Thanks, {form.contact_name || 'there'}. Our engineering automation team will review your request and reply to
          <span className="text-foreground"> {form.email}</span> to schedule the call.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <a
            href="/downloads/cad-to-erp-integration-checklist.md"
            download
            className="inline-flex items-center gap-2 rounded-xl border border-border px-5 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary"
          >
            <Download className="h-4 w-4" /> Download the checklist
          </a>
          <Link to="/resources" className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
            Browse the resource library
          </Link>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 sm:p-8">
      <h3 className="font-display text-xl font-bold">Book an architectural consultation</h3>
      <p className="mt-1 text-sm text-muted-foreground">
        Tell us about your CAD and ERP stack. We'll reply to schedule a call.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label="Company name *">
          <input required value={form.company_name} onChange={set('company_name')} className={inputCls} />
        </Field>
        <Field label="Contact name *">
          <input required value={form.contact_name} onChange={set('contact_name')} className={inputCls} />
        </Field>
        <Field label="Work email *">
          <input required type="email" value={form.email} onChange={set('email')} className={inputCls} />
        </Field>
        <Field label="Phone">
          <input value={form.phone} onChange={set('phone')} className={inputCls} />
        </Field>
        <Field label="CAD / design tools in use">
          <input placeholder="e.g. SOLIDWORKS, AutoCAD, NX" value={form.cad_tools} onChange={set('cad_tools')} className={inputCls} />
        </Field>
        <Field label="ERP system">
          <input placeholder="e.g. SAP, Oracle, Epicor, in-house" value={form.erp_system} onChange={set('erp_system')} className={inputCls} />
        </Field>
      </div>

      <div className="mt-4">
        <Field label="Preferred middleware gateway">
          <select value={form.integration_platform} onChange={set('integration_platform')} className={inputCls}>
            <option value="undecided">Undecided — help me choose</option>
            <option value="n8n">n8n</option>
            <option value="make">Make</option>
            <option value="zapier">Zapier</option>
            <option value="custom-rest-api">Custom REST API (Node.js / FastAPI)</option>
          </select>
        </Field>
      </div>

      <div className="mt-4">
        <Field label="What are you trying to connect?">
          <textarea
            rows={4}
            value={form.message}
            onChange={set('message')}
            placeholder="Data objects to sync, volumes, current manual process, timeline…"
            className={`${inputCls} resize-none`}
          />
        </Field>
      </div>

      {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

      <button
        type="submit"
        disabled={busy}
        className="glow-primary mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60"
      >
        {busy ? <><Loader2 className="h-4 w-4 animate-spin" /> Sending…</> : <><Send className="h-4 w-4" /> Request consultation</>}
      </button>
      <p className="mt-3 text-center font-mono text-[10px] text-muted-foreground">
        No live ERP connection is created by this form — it books a consultation with our team.
      </p>
    </form>
  );
}

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

const GATEWAYS = [
  {
    icon: Wrench,
    name: 'n8n',
    tagline: 'Self-hostable, code-friendly automation',
    points: [
      'Run on your own infrastructure for data residency and VPN access to on-premise ERP',
      'Generic HTTP/webhook nodes plus custom JavaScript steps when mapping logic gets complex',
      'Per-execution pricing model — evaluate cost at your real transaction volume',
    ],
  },
  {
    icon: Wrench,
    name: 'Make',
    tagline: 'Visual scenario builder',
    points: [
      'Drag-and-drop scenarios with visual branching for retry and error routes',
      'Operation-based pricing — predictable for steady, moderate volumes',
      'Native HTTP, webhook, and data-structure modules for schema validation',
    ],
  },
  {
    icon: Wrench,
    name: 'Zapier',
    tagline: 'Fastest to set up, largest app catalogue',
    points: [
      'Broad catalogue of pre-built ERP and form connectors',
      'Task-based pricing — best for low-volume, quick-to-market bridges',
      'Formatter and Filter steps for light transformation before ERP writes',
    ],
  },
  {
    icon: Code2,
    name: 'Custom REST API',
    tagline: 'Node.js or Python FastAPI service',
    points: [
      'Full control over OAuth 2.0 token handling, retry queues, and audit logging',
      'Own the idempotency and reconciliation logic instead of trusting a platform default',
      'Requires a named owner for hosting, monitoring, and security review',
    ],
  },
];

const MAPPING_ROWS = [
  { web: 'company_name', erp: 'Customer_Account', note: 'Deduplicate against existing accounts before create' },
  { web: 'selected_cad_tool', erp: 'Asset_Tag', note: 'Map free text to a controlled vocabulary / picklist' },
  { web: 'project_budget', erp: 'Opportunity_Value', note: 'Validate currency and decimal precision at the boundary' },
];

const RELIABILITY = [
  {
    icon: ShieldAlert,
    title: 'Automated retry queues',
    body: 'Exponential backoff with jitter for transient ERP API failures, a capped retry limit, and a dead-letter queue for records that exhaust retries — nothing is silently dropped.',
  },
  {
    icon: ArrowLeftRight,
    title: 'Schema validation checks',
    body: 'Every inbound payload is validated against the mapping contract before it touches the ERP. Malformed records are rejected early, logged with the reason, and routed for manual fix.',
  },
  {
    icon: Bell,
    title: 'Slack / email failure alerts',
    body: 'Instant notifications when an ERP API call fails or returns an authorization error (401/403), plus queue-depth thresholds so a growing backlog never goes unnoticed.',
  },
  {
    icon: Info,
    title: 'Audit logging',
    body: 'Every request logged with timestamp, source, payload hash, outcome, and latency — retained per your compliance policy, with a daily reconciliation of source vs. ERP record counts.',
  },
];

const EBOM_MBOM_ROWS = [
  { ebom: 'CAD assembly tree (eBOM)', mbom: 'ERP item master + BOM levels', note: 'Flatten/transform the design tree — do not mirror it 1:1 into manufacturing levels' },
  { ebom: 'Part number (CAD file property)', mbom: 'ERP item number', note: 'Enforce one numbering scheme (intelligent or sequential) at the boundary — never both' },
  { ebom: 'CAD revision / PDM version', mbom: 'ERP revision + ECO/ECN reference', note: 'Revision locks must survive the transfer — an ERP item never silently overwrites a released revision' },
  { ebom: 'Sub-assembly (design grouping)', mbom: 'Phantom / non-stocked item', note: 'Design groupings that are never built as units become phantom items in the mBOM' },
  { ebom: 'Raw material / stock size', mbom: 'Purchased item + unit of measure', note: 'Classify make-vs-buy and validate UoM (each vs kg vs m) before the ERP write' },
];

const EBOM_MBOM_PILLARS = [
  {
    title: 'Part numbering discipline',
    body: 'Decide once whether item numbers are intelligent (meaning embedded in the digits), semi-intelligent (class + sequence), or sequential with attributes carried as data. The bridge must enforce that scheme at the boundary — a CAD property that does not match the scheme is rejected and routed for manual numbering, never auto-invented.',
  },
  {
    title: 'Revision control that survives the transfer',
    body: 'Every eBOM revision maps to an ERP revision with an ECO/ECN reference. Released revisions are locked: the middleware can create a new revision, but never overwrite a released one. Where-used and affected-items reports travel with the change so planning knows what a revision bump touches.',
  },
  {
    title: 'eBOM → mBOM transformation rules',
    body: 'The mBOM is a manufacturing view, not a copy of the design tree: phantom items for design groupings, make-vs-buy classification per item, consumable and process steps added, and unit-of-measure validation on every line. These rules live in an explicit, versioned transformation table — not in tribal knowledge.',
  },
];

export default function ERPIntegrationPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>CAD-to-ERP Integration Architecture & Consulting — n8n, Make, Zapier & Custom APIs | MechEngi 10X</title>
        <meta
          name="description"
          content="Engineering automation architecture for connecting web leads and CAD workflows to your ERP via n8n, Make, Zapier, or a custom REST API. Webhook listeners, OAuth 2.0, schema mapping, retries, and Slack/email failure alerts. Free CAD-to-ERP integration checklist."
        />
      </Helmet>

      <SiteHeader />

      {/* Hero */}
      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-20 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Workflow className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Engineering Automation Service</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            Bridge your CAD workflows and web leads <span className="text-primary">straight into your ERP</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            We design and build automated CAD-to-ERP data bridges on n8n, Make, Zapier, or a custom Node.js / Python
            FastAPI service — with webhook listeners, OAuth 2.0 authentication, schema mapping, retry queues, and
            failure alerts.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a
              href="/downloads/cad-to-erp-integration-checklist.md"
              download
              className="glow-primary inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
            >
              <FileDown className="h-4 w-4" /> Download the free checklist
            </a>
            <a href="#consult" className="rounded-xl border border-border px-8 py-3 font-semibold transition-colors hover:border-primary/40 hover:text-primary">
              Book a consultation
            </a>
          </div>

          {/* Honesty banner */}
          <div className="mx-auto mt-10 flex max-w-2xl items-start justify-center gap-3 rounded-xl border border-amber-500/30 bg-amber-500/5 px-5 py-3 text-left">
            <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">Honest status:</span> this page describes our
              architecture and consulting offering. We do not currently operate a live ERP connection, webhook
              listener, OAuth integration, retry queue, or alert system on this site — everything below is the
              reference architecture we design, build, and hand over for your stack.
            </p>
          </div>
        </div>
      </section>

      {/* Step 2 — Middleware gateway selection */}
      <section className="mx-auto max-w-[90rem] px-5 py-20">
        <div className="mb-12 text-center">
          <p className="font-mono text-xs uppercase tracking-wider text-primary">Step 1 — Middleware Gateway</p>
          <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Choose your gateway: n8n, Make, Zapier, or custom REST API</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            The right platform depends on your volumes, data residency needs, and how much of the logic you want to own.
            We help you choose — then build on whichever fits.
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {GATEWAYS.map((g) => (
            <div key={g.name} className="rounded-2xl border border-border bg-card p-6">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-muted">
                  <g.icon className="h-5 w-5 text-primary" />
                </span>
                <div>
                  <h3 className="font-display text-lg font-semibold">{g.name}</h3>
                  <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{g.tagline}</p>
                </div>
              </div>
              <ul className="mt-4 space-y-2.5">
                {g.points.map((p) => (
                  <li key={p} className="flex items-start gap-2.5 text-sm">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    <span className="text-foreground/90">{p}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* Webhook + OAuth architecture */}
      <section className="border-y border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-20">
          <div className="mb-12 text-center">
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Step 2 — Ingress & Authentication</p>
            <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Webhook listener + OAuth 2.0, done properly</h2>
          </div>
          <div className="grid gap-6 lg:grid-cols-2">
            <div className="rounded-2xl border border-border bg-card p-7">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                  <Webhook className="h-5 w-5 text-primary" />
                </span>
                <h3 className="font-display text-lg font-semibold">Webhook listener</h3>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                A dedicated HTTPS endpoint per source system captures incoming POST requests. Requests are
                authenticated (HMAC signature or shared secret), validated against the payload schema, and
                acknowledged immediately — heavy processing happens asynchronously so senders never time out.
              </p>
              <ul className="mt-4 space-y-2 text-sm text-foreground/90">
                <li className="flex items-start gap-2.5"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> Idempotency keys so duplicate deliveries are safely ignored</li>
                <li className="flex items-start gap-2.5"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> Rate limiting and maximum payload size at the boundary</li>
                <li className="flex items-start gap-2.5"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> Works on n8n / Make / Zapier webhook triggers or a custom FastAPI route</li>
              </ul>
            </div>
            <div className="rounded-2xl border border-border bg-card p-7">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                  <KeyRound className="h-5 w-5 text-primary" />
                </span>
                <h3 className="font-display text-lg font-semibold">OAuth 2.0 authentication</h3>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                Authorization-code flow (with PKCE where the ERP supports it) against your ERP's API. Tokens live in a
                secrets manager — never in scenario exports or code — with automated refresh before expiry and a
                documented re-authorisation runbook for credential rotation.
              </p>
              <ul className="mt-4 space-y-2 text-sm text-foreground/90">
                <li className="flex items-start gap-2.5"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> Least-privilege scopes for the integration user</li>
                <li className="flex items-start gap-2.5"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> Refresh-token rotation handled by the gateway, not a person</li>
                <li className="flex items-start gap-2.5"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> 401/403 responses trigger alerts, not silent failures</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Step 3 — Schema mapping */}
      <section className="mx-auto max-w-[90rem] px-5 py-20">
        <div className="mb-12 text-center">
          <p className="font-mono text-xs uppercase tracking-wider text-primary">Step 3 — Data Schema Mapping & Transformation</p>
          <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Translate web parameters to ERP fields</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Every bridge starts with an explicit, versioned mapping table. Here is a real example from our reference
            architecture:
          </p>
        </div>
        <div className="mx-auto max-w-4xl overflow-hidden rounded-2xl border border-border bg-card">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  <th className="px-5 py-3 text-left">Web parameter</th>
                  <th className="px-5 py-3 text-left">ERP field</th>
                  <th className="px-5 py-3 text-left">Transformation rule</th>
                </tr>
              </thead>
              <tbody>
                {MAPPING_ROWS.map((r) => (
                  <tr key={r.web} className="border-b border-border last:border-0">
                    <td className="px-5 py-3.5 font-mono text-xs text-primary">{r.web}</td>
                    <td className="px-5 py-3.5 font-mono text-xs text-accent">{r.erp}</td>
                    <td className="px-5 py-3.5 text-muted-foreground">{r.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="border-t border-border bg-muted/20 px-5 py-3 font-mono text-[10px] text-muted-foreground">
            Illustrative mapping — your ERP's field names and validation rules will differ. We build the mapping table
            with your team during the consultation.
          </p>
        </div>
      </section>

      {/* Step 3b — eBOM to mBOM transformation */}
      <section className="mx-auto max-w-[90rem] px-5 py-20">
        <div className="mb-12 text-center">
          <p className="font-mono text-xs uppercase tracking-wider text-primary">Step 3b — eBOM → mBOM Transformation</p>
          <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">From the design tree to a manufacturing BOM — without losing part numbers or revisions</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            "CAD-to-ERP" is more than moving records. The hard part is transforming the engineering BOM into a
            manufacturing BOM while part numbering and revision control stay intact. This is the layer we design
            into every bridge:
          </p>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {EBOM_MBOM_PILLARS.map((p) => (
            <div key={p.title} className="rounded-2xl border border-border bg-card p-6">
              <h3 className="font-display text-lg font-semibold">{p.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.body}</p>
            </div>
          ))}
        </div>
        <div className="mx-auto mt-10 max-w-4xl overflow-hidden rounded-2xl border border-border bg-card">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  <th className="px-5 py-3 text-left">eBOM source</th>
                  <th className="px-5 py-3 text-left">mBOM / ERP target</th>
                  <th className="px-5 py-3 text-left">Transformation rule</th>
                </tr>
              </thead>
              <tbody>
                {EBOM_MBOM_ROWS.map((r) => (
                  <tr key={r.ebom} className="border-b border-border last:border-0">
                    <td className="px-5 py-3.5 font-mono text-xs text-primary">{r.ebom}</td>
                    <td className="px-5 py-3.5 font-mono text-xs text-accent">{r.mbom}</td>
                    <td className="px-5 py-3.5 text-muted-foreground">{r.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="border-t border-border bg-muted/20 px-5 py-3 font-mono text-[10px] text-muted-foreground">
            Illustrative transformation rules — your ERP's item master structure and numbering policy will differ. We
            build the versioned transformation table with your team during the consultation.
          </p>
        </div>
      </section>

      {/* Step 4 — Error handling & audit logging */}
      <section className="border-y border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-20">
          <div className="mb-12 text-center">
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Step 4 — Error Handling & Audit Logging</p>
            <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Fail-safe sync loops</h2>
            <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
              A bridge is only production-ready when it fails loudly and recovers on its own. This is the reliability
              layer we design into every integration:
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            {RELIABILITY.map((r) => (
              <div key={r.title} className="rounded-2xl border border-border bg-card p-6">
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                    <r.icon className="h-5 w-5 text-primary" />
                  </span>
                  <h3 className="font-display text-lg font-semibold">{r.title}</h3>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{r.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lead magnet */}
      <section className="mx-auto max-w-[90rem] px-5 py-20">
        <div className="mx-auto grid max-w-4xl gap-8 rounded-2xl border border-primary/40 bg-primary/5 p-8 sm:p-10 lg:grid-cols-[1.4fr_1fr] lg:items-center">
          <div>
            <div className="flex items-center gap-2">
              <FileDown className="h-5 w-5 text-primary" />
              <p className="font-mono text-xs uppercase tracking-wider text-primary">Free download · No sign-up</p>
            </div>
            <h2 className="mt-3 font-display text-2xl font-bold sm:text-3xl">
              The Complete CAD-to-ERP Integration Checklist for Manufacturing Teams
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              A vendor-neutral, 9-section checklist covering scope, gateway selection, webhook design, OAuth 2.0,
              schema mapping, retries, alerting, security, and rollout testing. Work through it with your engineering,
              IT, and operations leads before writing a line of integration code.
            </p>
          </div>
          <div className="flex flex-col items-start gap-3 lg:items-center">
            <a
              href="/downloads/cad-to-erp-integration-checklist.md"
              download
              className="glow-primary inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
            >
              <Download className="h-4 w-4" /> Download checklist (.md)
            </a>
            <p className="font-mono text-[10px] text-muted-foreground">Markdown · ~6 KB · opens in any text editor</p>
          </div>
        </div>
      </section>

      {/* Consulting CTA + form */}
      <section id="consult" className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-20">
          <div className="mx-auto mb-10 max-w-2xl text-center">
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Talk to our team</p>
            <h2 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Architectural consultation</h2>
            <p className="mt-4 text-lg leading-relaxed text-foreground/90">
              Need help selecting or building a CAD-to-ERP automated bridge? Book an architectural consultation with
              our engineering automation team.
            </p>
          </div>
          <div className="mx-auto max-w-2xl">
            <ConsultationForm />
          </div>
          <div className="mx-auto mt-10 max-w-2xl text-center">
            <p className="text-sm text-muted-foreground">
              Prefer to explore on your own first?{' '}
              <Link to="/resources" className="text-primary hover:underline">Browse the free resource library</Link>
              {' '}or{' '}
              <Link to="/calculators" className="text-primary hover:underline">open the engineering calculators</Link>.
            </p>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
