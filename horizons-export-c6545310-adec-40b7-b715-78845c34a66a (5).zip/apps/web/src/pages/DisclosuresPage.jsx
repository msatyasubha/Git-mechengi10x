import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { HandCoins, ShieldCheck, Scale, ArrowRight, Mail } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

const POINTS = [
  {
    icon: HandCoins,
    title: 'Referral Commissions',
    body: 'mechengi10x.com may earn a referral commission when you purchase through select software vendor links. This comes at no additional cost to you — the price you pay is identical to visiting the vendor directly.',
  },
  {
    icon: ShieldCheck,
    title: 'Zero Influence on Rankings',
    body: 'Affiliate relationships have zero influence on tool rankings, MechEngi Scores, benchmark results, or editorial reviews. A tool can carry an affiliate link and still receive a low score or a critical review.',
  },
  {
    icon: Scale,
    title: 'Sponsored Listings Are Labelled',
    body: 'Any sponsored or paid placement is explicitly labelled "Sponsored" or "Partner Listing" and is excluded from organic MechEngi Score rankings. Sponsorship never buys a score change or the removal of a limitation.',
  },
];

export default function DisclosuresPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Affiliate & Commercial Transparency Disclosures — MechEngi 10X</title>
        <meta name="description" content="Clear disclosure that mechengi10x.com may receive referral commissions from select software vendor links at no additional cost to users, with zero influence on tool rankings, benchmark scores, or editorial reviews." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 sm:py-20">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <HandCoins className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Commercial Transparency</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-3xl font-bold leading-tight sm:text-4xl md:text-5xl">
            Affiliate &amp; Commercial Transparency Disclosures
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            We are reader-supported. Transparency about how MechEngi 10X is funded — and the firewall between that
            funding and our editorial output — is part of every page.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
        <div className="grid gap-5 sm:grid-cols-3">
          {POINTS.map((p) => {
            const Icon = p.icon;
            return (
              <div key={p.title} className="rounded-2xl border border-border bg-card p-6">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <Icon className="h-5 w-5" />
                </span>
                <h2 className="mt-4 font-display text-lg font-bold">{p.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.body}</p>
              </div>
            );
          })}
        </div>

        <div className="mt-12">
          <h2 className="font-display text-xl font-bold text-foreground">Technology &amp; Education Partners</h2>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
            The following organizations are listed here at the request of the site operator as technology and
            education partners. These relationships are <span className="font-semibold text-foreground">user-supplied
            and not independently verified</span> by MechEngi 10X as active paid partnerships. We publish no claim
            that any of these organizations is a current paid sponsor. Where a commercial relationship exists, it
            does not determine our editorial scores, rankings, or recommendations.
          </p>
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { company: 'Onshape', note: 'Cloud-native CAD (PTC). Listed as a technology partner.' },
              { company: 'SimScale', note: 'Cloud simulation. Listed as a technology partner.' },
              { company: 'n8n', note: 'Workflow automation. Listed as a technology partner.' },
              { company: 'Keyence', note: 'Vision & measurement systems. Listed as a technology partner.' },
              { company: 'Make', note: 'No-code automation. Listed as a technology partner.' },
              { company: 'Coursera', note: 'Engineering learning paths. Listed as an education partner.' },
            ].map((p) => (
              <div key={p.company} className="rounded-2xl border border-border bg-card p-5">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-display text-base font-bold">{p.company}</p>
                  <span className="rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 font-mono text-[9px] uppercase tracking-wider text-primary">
                    Commercial Partner
                  </span>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{p.note}</p>
                <p className="mt-3 rounded-lg border border-border bg-muted/30 px-3 py-2 font-mono text-[10px] leading-relaxed text-muted-foreground">
                  Editorial Scores Maintained Independently · Status: user-supplied, unverified
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-12 max-w-2xl space-y-6 text-foreground/80 leading-relaxed">
          <div>
            <h2 className="font-display text-xl font-bold text-foreground">How affiliate links appear</h2>
            <p className="mt-3 text-sm">
              Affiliate links are styled as primary call-to-action buttons (e.g. &ldquo;Try Tool&rdquo;) and carry the
              HTML attribute <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">rel=&quot;sponsored&quot;</code>.
              Editorial links within review text point to a tool&rsquo;s canonical documentation or homepage and are not
              affiliate links where possible. A short disclosure line appears next to every affiliate CTA.
            </p>
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-foreground">What affiliate revenue funds</h2>
            <p className="mt-3 text-sm">
              Commissions help fund independent research, hands-on tool testing, benchmark development, and platform
              maintenance. They do not move a single score, ranking, or verdict.
            </p>
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-foreground">Engineering disclaimer</h2>
            <p className="mt-3 text-sm">
              Calculators, sample scripts, and reviews provide preliminary engineering estimates and capability
              assessments. They are not a substitute for certified analytical software or licensed professional
              engineering review.
            </p>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-start gap-3 rounded-2xl border border-border bg-card p-6 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-lg font-bold">Questions about our commercial relationships?</h2>
            <p className="mt-1 text-sm text-muted-foreground">We answer every question about how we are funded.</p>
          </div>
          <a
            href="mailto:hello@mechengi10x.com"
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
          >
            <Mail className="h-4 w-4" /> hello@mechengi10x.com
          </a>
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/methodology" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
            100-point evaluation framework <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/editorial-policy" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
            Editorial guidelines <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/corrections" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
            Corrections policy <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
