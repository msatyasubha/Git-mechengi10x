import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { PlayCircle, Clock, ArrowRight } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { videos, videoCategories, getVideosByCategory } from '@/data/videos';

export default function VideosPage() {
  const [cat, setCat] = useState('all');
  const filtered = getVideosByCategory(cat);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Video Topic Library — CAD, AI & Simulation | MechEngi 10X</title>
        <meta name="description" content="Explore engineering video topics covering AI, CAD, simulation and automation, with links to search YouTube for related videos." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <PlayCircle className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Video Library</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            Explore engineering video topics
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            Browse topic outlines across AI, CAD, simulation, and automation. Each topic links to a YouTube search,
            not a specific video; durations and channel attribution are not verified.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="flex flex-wrap gap-2">
          {videoCategories.map((c) => (
            <button
              key={c.id}
              onClick={() => setCat(c.id)}
              className={`rounded-full border px-4 py-1.5 font-mono text-xs uppercase tracking-wider transition-colors ${
                cat === c.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-foreground/40 hover:text-foreground'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 pb-20">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((v) => (
            <Link
              key={v.slug}
              to={`/videos/${v.slug}`}
              className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all hover:-translate-y-1 hover:border-primary/40"
            >
              <div className="relative flex h-44 items-center justify-center bg-gradient-to-br from-secondary to-background">
                <PlayCircle className="h-12 w-12 text-primary/70 transition-transform group-hover:scale-110" />
                <span className="absolute bottom-3 right-3 rounded bg-background/80 px-2 py-0.5 font-mono text-[10px] text-foreground backdrop-blur">
                  Topic outline
                </span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <p className="font-mono text-[10px] uppercase tracking-wider text-primary">{v.category}</p>
                <h2 className="mt-2 font-display text-base font-bold leading-snug group-hover:text-primary">{v.title}</h2>
                <p className="mt-2 flex-1 text-sm text-muted-foreground line-clamp-2">{v.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
