import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Workflow, AlertTriangle, ListChecks, ArrowRight, ArrowLeft, ScanLine, FileCheck2, Eye } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

/*
 * AI-Assisted Drawing Review & GD&T Verification Pipeline
 *
 * This page is a CONCEPTUAL REFERENCE design, not a shipped, tested, or
 * validated integration. None of the described stages — CAD/DWG extraction,
 * the Python GD&T rule engine, multimodal LLM vision inspection, or the PDF
 * audit report — are implemented or verified to work end-to-end on this site.
 * Applicability depends on the visitor's source files, CAD/PDM setup, chosen
 * model and API, and organization standards. Treat every checkpoint below as
 * a verification question to answer for your own environment, not a completed
 * validation. Standard references (ISO 1101, ASME Y14.5) are named as common
 * examples; confirm the applicable revision before relying on them.
 */

const PIPELINE_STAGES = [
  {
    icon: ScanLine,
    title: 'CAD Macro / DWG Extractor',
    desc: 'A script (e.g. a SOLIDWORKS VBA macro, a FreeCAD Python script, or a DWG/DXF parser) reads the 2D drawing and exports structured data: view list, dimension entities, title-block attributes, and GD&T feature control frames. Whether this is feasible depends on your CAD version, file format, and whether the drawing is parametric or a flat export.',
    caveat: 'Extraction coverage varies by CAD format and release; some annotations may not be exposed by the API.',
  },
  {
    icon: FileCheck2,
    title: 'Python GD&T Rule Engine',
    desc: 'A Python layer parses the extracted annotations and applies rule checks — for example, flagging dimensions with no tolerance, feature control frames missing datum references, or title-block fields that do not match the PDM record. This is a reference architecture; the rules must be authored to match your organization\'s standards and tolerance policy.',
    caveat: 'Rule correctness is your responsibility; a generic engine cannot certify compliance on its own.',
  },
  {
    icon: Eye,
    title: 'Multimodal LLM Vision Inspection',
    desc: 'A vision-capable multimodal LLM reviews rendered drawing images or extracted annotation context to surface non-compliant formatting, ambiguous callouts, or inconsistencies a pure rule engine may miss. Model selection matters: use a current vision-capable model and confirm its current availability, vision support, and data-handling policy on the provider\'s official documentation before sending any drawing data.',
    caveat: 'LLM vision output is advisory and can be wrong — it must not be treated as a certified inspection result.',
  },
  {
    icon: FileCheck2,
    title: 'PDF QA Audit Report',
    desc: 'Findings from the extraction, rule engine, and vision pass are consolidated into a review report (e.g. a PDF or spreadsheet) for a human reviewer to triage. This is an illustrative output format, not a generated artifact on this site.',
    caveat: 'The report is a review aid, not an approval record.',
  },
];

const CHECKPOINTS = [
  'Are all dimensions constrained — i.e. are there any dangling or unannotated dimensions on each sheet? (Define what "complete" means for your drawing template before counting.)',
  'Do title-block attributes (material, revision, part number) match the corresponding PDM record for this revision? (Requires your PDM to expose those fields.)',
  'Are feature control frames syntactically valid — do they reference defined datums and use permitted material condition modifiers per the standard you apply?',
  'Which GD&T standard revision governs this drawing (e.g. ISO 1101 or ASME Y14.5), and are the callouts consistent with that revision?',
  'Has the vision-model output been reviewed by a person, and were false positives/negatives logged?',
  'Is the source drawing a parametric CAD file or a flat DWG/DXF export? Extraction feasibility differs between them.',
  'Are sensitive drawings being sent to a third-party model API, and is that permitted by your organization\'s data policy?',
];

const DISCLAIMER =
  'This page describes a conceptual reference pipeline. The CAD extraction, Python GD&T rule engine, multimodal LLM vision inspection, and PDF audit report stages are not implemented, integrated, or validated on this site, and no end-to-end drawing-review automation is claimed to work. Applicability depends on your source files, CAD/PDM setup, chosen model and API, and organization standards. AI vision checks and script utilities can assist drawing reviews by surfacing non-compliant formatting and possible datum inconsistencies, but they do not certify compliance and do not replace qualified human engineering review or physical tolerance stack-up analysis. Standard references such as ISO 1101 and ASME Y14.5 are named as common examples — confirm the applicable revision and your organization\'s requirements before relying on them.';

export default function AiDrawingQaGdtWorkflowPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>AI-Assisted Drawing Review &amp; GD&T Verification Pipeline (2026) — MechEngi 10X</title>
        <meta
          name="description"
          content="A conceptual reference pipeline for AI-assisted 2D drawing QA and GD&T verification: CAD/DWG extraction, a Python GD&T rule engine, multimodal LLM vision inspection, and a review report. Illustrative architecture and verification questions — not a shipped or validated integration."
        />
        <link rel="canonical" href="https://mechengi10x.com/workflows/ai-drawing-qa-gdt" />
        <meta property="og:type" content="article" />
        <meta property="og:url" content="https://mechengi10x.com/workflows/ai-drawing-qa-gdt" />
        <meta property="og:title" content="AI-Assisted Drawing Review & GD&T Verification Pipeline (2026)" />
        <meta property="og:description" content="A conceptual reference pipeline for AI-assisted 2D drawing QA and GD&T verification — CAD/DWG extraction, a Python rule engine, multimodal LLM vision inspection, and a review report. Illustrative architecture and verification questions, not a shipped or validated integration." />
      </Helmet>

      <SiteHeader />

      {/* Breadcrumb */}
      <div className="border-b border-border bg-card/30 py-3 sm:py-4">
        <div className="mx-auto flex max-w-[72rem] flex-wrap items-center gap-1.5 px-4 font-mono text-xs text-muted-foreground sm:px-5">
          <Link to="/" className="hover:text-foreground">Home</Link>
          <span>/</span>
          <Link to="/workflows" className="hover:text-foreground">Workflow Library</Link>
          <span>/</span>
          <span className="truncate text-foreground">AI Drawing QA &amp; GD&amp;T</span>
        </div>
      </div>

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Workflow className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Conceptual Workflow Guide</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-3xl font-bold leading-tight sm:text-4xl md:text-5xl">
            AI-Assisted Drawing Review &amp; GD&amp;T Verification Pipeline
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            A reference architecture for combining CAD/DWG extraction, a Python GD&amp;T rule engine, and a
            vision-capable multimodal LLM to assist 2D engineering drawing QA. This is a conceptual guide —
            the stages are not implemented or validated here, and applicability depends on your source files,
            CAD/PDM setup, model choice, and organization standards.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
        {/* Problem & scope */}
        <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
          <div className="space-y-4">
            <h2 className="font-display text-xl font-bold sm:text-2xl">Problem &amp; Scope</h2>
            <p className="text-sm leading-relaxed text-foreground/85">
              2D engineering drawing QA involves checking dimension constraints, title-block attributes, and
              Geometric Dimensioning &amp; Tolerancing (GD&amp;T) callouts. Manual review is detail-heavy and
              depends on drawing complexity, template discipline, and the standards a given organization applies.
              This page outlines how extraction, rule-based checks, and vision-capable AI could assist that review —
              as a reference design, not a working product.
            </p>
            <p className="text-sm leading-relaxed text-muted-foreground">
              We do not claim a specific per-sheet review time, a zero-dangling-annotation result, PDM
              synchronization, full standards compliance, or a working automated pipeline. Those outcomes depend
              entirely on your environment and would need to be measured by you.
            </p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-5">
            <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              Reference architecture
            </p>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              The proposed pipeline is a sequence of assisting stages. None are wired together on this site.
            </p>
            <ol className="mt-3 space-y-2 text-sm">
              <li className="flex items-start gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" /><span className="font-medium text-foreground">CAD Macro / DWG Extractor</span> → structured annotation data</li>
              <li className="flex items-start gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" /><span className="font-medium text-foreground">Python GD&amp;T Rule Engine</span> → rule-based flags</li>
              <li className="flex items-start gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" /><span className="font-medium text-foreground">Multimodal LLM Vision Inspection</span> → advisory findings</li>
              <li className="flex items-start gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" /><span className="font-medium text-foreground">PDF QA Audit Report</span> → human review</li>
            </ol>
          </div>
        </div>

        {/* Pipeline stages */}
        <div className="mt-14 space-y-6">
          <h2 className="font-display text-xl font-bold sm:text-2xl">Pipeline Stages (Conceptual)</h2>
          {PIPELINE_STAGES.map((stage, i) => {
            const Icon = stage.icon;
            return (
              <article key={i} className="rounded-2xl border border-border bg-card p-6 sm:p-7">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="min-w-0">
                    <span className="rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-cad">
                      Stage {i + 1}
                    </span>
                    <h3 className="mt-2 flex items-center gap-2 font-display text-lg font-bold sm:text-xl">
                      <Icon className="h-5 w-5 text-primary" /> {stage.title}
                    </h3>
                  </div>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-foreground/85">{stage.desc}</p>
                <p className="mt-3 flex items-start gap-2 rounded-lg border border-amber-500/25 bg-amber-500/5 px-3 py-2 text-xs leading-relaxed text-muted-foreground">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-400" />
                  {stage.caveat}
                </p>
              </article>
            );
          })}
        </div>

        {/* Verification questions */}
        <div className="mt-14">
          <h2 className="flex items-center gap-2 font-display text-xl font-bold sm:text-2xl">
            <ListChecks className="h-5 w-5 text-primary" /> Verification Questions
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            These are questions to answer for your own environment — not completed validations or guaranteed
            outcomes. Treat them as a starting checklist you must run and verify yourself.
          </p>
          <ul className="mt-4 space-y-2.5 rounded-2xl border border-border bg-card p-5">
            {CHECKPOINTS.map((c) => (
              <li key={c} className="flex items-start gap-2 text-sm">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                <span className="text-foreground/85">{c}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Standards & model selection */}
        <div className="mt-14 grid gap-6 lg:grid-cols-2">
          <div className="rounded-2xl border border-border bg-card p-6">
            <h3 className="font-display text-lg font-bold">Standards references</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              GD&amp;T is governed by standards such as ISO 1101 (Geometrical Product Specifications —
              geometrical tolerancing) and ASME Y14.5 (Dimensioning and Tolerancing). These are named as common
              examples only. Confirm the applicable standard <em>and revision</em> for your industry, customer,
              and drawing template before relying on any rule — revisions differ and your organization may
              mandate a specific edition. Do not treat the names here as a current-requirement statement.
            </p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-6">
            <h3 className="font-display text-lg font-bold">Model selection</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              The vision-inspection stage requires a current vision-capable multimodal model. Model names and
              capabilities change frequently and we do not assert a specific model here. Before sending any
              drawing data, confirm the current model lineup, its vision support, context limits, and
              data-handling policy on the provider\'s official documentation (for example, Anthropic\'s model
              and privacy documentation). Do not send confidential or export-controlled drawings to a
              third-party API without employer approval and appropriate data-protection controls.
            </p>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-14 flex items-start gap-2.5 rounded-xl border border-amber-500/25 bg-amber-500/5 px-4 py-4">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
          <p className="text-xs leading-relaxed text-muted-foreground">
            <span className="font-semibold text-foreground">Disclaimer: </span>
            {DISCLAIMER}
          </p>
        </div>

        {/* Related workflows */}
        <div className="mt-12 rounded-2xl border border-border bg-card p-6 text-center">
          <h2 className="font-display text-lg font-bold">Related engineering workflows</h2>
          <p className="mx-auto mt-2 max-w-xl text-sm text-muted-foreground">
            Browse the full workflow library for CAD drawing QA, CAD-to-ERP BOM integration, and FEA mesh
            convergence templates.
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-3">
            <Link
              to="/workflows"
              className="inline-flex items-center gap-2 rounded-xl border border-primary/40 bg-primary/10 px-5 py-2.5 text-sm font-semibold text-primary transition-all hover:bg-primary/20 active:scale-[0.98]"
            >
              View workflow library <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/workflows/solidworks-bom-n8n"
              className="inline-flex items-center gap-2 rounded-xl border border-border px-5 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
            >
              SOLIDWORKS BOM → n8n guide <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

        <div className="mt-10">
          <Link
            to="/workflows"
            className="inline-flex min-h-[44px] items-center gap-2 font-mono text-sm text-muted-foreground hover:text-primary"
          >
            <ArrowLeft className="h-4 w-4" /> Back to workflow library
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
