import { useState, useRef, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Send, Zap, Bot, User, Loader2, RefreshCw, LogIn, Mail, AlertCircle, X, SlidersHorizontal, ChevronDown, FileDown } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import MarkdownMessage from '@/components/advisor/MarkdownMessage';
import { useAuth } from '@/hooks/use-auth';
import { useIntegratedAi } from '@/hooks/use-integrated-ai';
import pb from '@/lib/pocketbaseClient';
import { exportAdvisorTranscript } from '@/lib/exportUtils';

const starters = [
  'What\'s the best free CAD tool for a mechanical engineer just starting out?',
  'I need to run FEA for my product design. ANSYS vs SimScale — which makes more sense?',
  'I\'m a team of 5 engineers. What project management tool should we use?',
  'Compare ChatGPT and Claude for writing engineering documentation.',
  'I\'m an engineering student in India with a ₹1,000/month budget. Which CAD and simulation tools can I actually afford?',
  'What AI tools save the most time for mechanical engineers?',
];

function Message({ msg, isStreamingTail }) {
  const isUser = msg.role === 'user';
  const hasText = typeof msg.content === 'string' && msg.content.length > 0;
  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${isUser ? 'bg-primary' : 'bg-card border border-border'}`}>
        {isUser ? <User className="h-4 w-4 text-primary-foreground" /> : <Bot className="h-4 w-4 text-primary" />}
      </div>
      <div className={`max-w-[min(100%,42rem)] rounded-2xl px-4 py-3.5 text-sm leading-relaxed sm:max-w-[85%] ${isUser ? 'bg-primary text-primary-foreground' : 'bg-card border border-border text-foreground'}`}>
        {hasText ? (
          <MarkdownMessage content={msg.content} isUser={isUser} isStreamingTail={isStreamingTail} />
        ) : isStreamingTail ? (
          <div className="flex items-center gap-2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin text-primary" />
            <span className="font-mono text-xs">Thinking…</span>
          </div>
        ) : (
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        )}
        {msg.images?.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {msg.images.map((url, j) => (
              <img key={j} src={url} alt="" loading="lazy" className="max-h-48 rounded-lg border border-border" />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ErrorBanner({ error, onDismiss, onRetry }) {
  if (!error) return null;
  return (
    <div className="mx-4 mb-2 flex shrink-0 items-start gap-3 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm">
      <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
      <div className="min-w-0 flex-1">
        <p className="font-medium text-foreground">{error.message}</p>
        <p className="mt-1 text-xs text-muted-foreground">
          Your question is still in the chat — you can edit it or try sending again.
        </p>
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            className="mt-2 font-mono text-xs text-primary hover:underline"
          >
            Try again
          </button>
        )}
      </div>
      <button
        type="button"
        onClick={onDismiss}
        className="rounded p-1 text-muted-foreground hover:text-foreground"
        aria-label="Dismiss"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

const CONSTRAINT_OPTIONS = {
  os: ['Any', 'Windows', 'macOS', 'Linux', 'Cloud (browser)'],
  deployment: ['Any', 'Cloud / SaaS', 'On-premise', 'Hybrid', 'Self-hosted / open-source'],
  license: ['Any', 'Free / open-source', 'Free tier OK', 'Subscription', 'Perpetual / one-time', 'Student / education'],
  teamSize: ['Solo', '2–5', '6–20', '20+', 'Enterprise'],
  budget: ['Free only', '< $20/mo', '$20–100/mo', '$100–500/mo', '$500+/mo', 'INR budget (state in message)'],
  priority: ['Best overall', 'Lowest cost', 'Fastest to learn', 'Most features', 'Best performance', 'Best collaboration'],
};

function ConstraintPanel({ constraints, setConstraints, onApply, disabled }) {
  const [open, setOpen] = useState(false);
  const activeCount = Object.entries(constraints).filter(([k, v]) => v && v !== 'Any' && (k !== 'budget' || v !== 'Free only' ? true : false)).length;
  const setOne = (key, val) => setConstraints((p) => ({ ...p, [key]: val }));
  return (
    <div className="mb-2 rounded-xl border border-border bg-muted/20">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs font-medium text-muted-foreground hover:text-foreground"
      >
        <SlidersHorizontal className="h-3.5 w-3.5 text-primary" />
        Technical constraints
        {activeCount > 0 && (
          <span className="rounded-full bg-primary/15 px-2 py-0.5 font-mono text-[10px] text-primary">{activeCount} set</span>
        )}
        <ChevronDown className={`ml-auto h-3.5 w-3.5 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="border-t border-border p-3">
          <p className="mb-3 text-[11px] leading-relaxed text-muted-foreground">
            Add multi-variable constraints so the Advisor gives specific recommendations instead of broad suggestions.
            Constraints are appended to your next message.
          </p>
          <div className="grid gap-3 sm:grid-cols-2">
            {Object.entries(CONSTRAINT_OPTIONS).map(([key, opts]) => (
              <div key={key}>
                <label className="mb-1 block font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  {key === 'os' ? 'OS requirement' : key === 'teamSize' ? 'Team size' : key.charAt(0).toUpperCase() + key.slice(1)}
                </label>
                <select
                  value={constraints[key] || 'Any'}
                  disabled={disabled}
                  onChange={(e) => setOne(key, e.target.value)}
                  className="h-9 w-full rounded-lg border border-border bg-card px-2 text-xs focus:border-primary focus:outline-none disabled:opacity-50"
                >
                  {opts.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            ))}
          </div>
          <button
            type="button"
            disabled={disabled}
            onClick={onApply}
            className="mt-3 rounded-lg border border-primary/30 bg-primary/10 px-3 py-1.5 font-mono text-[11px] text-primary hover:bg-primary/20 disabled:opacity-40"
          >
            Apply to next message
          </button>
        </div>
      )}
    </div>
  );
}

function buildConstraintSuffix(c) {
  const parts = [];
  if (c.os && c.os !== 'Any') parts.push(`OS requirement: ${c.os}`);
  if (c.deployment && c.deployment !== 'Any') parts.push(`Deployment: ${c.deployment}`);
  if (c.license && c.license !== 'Any') parts.push(`License model: ${c.license}`);
  if (c.teamSize && c.teamSize !== 'Any') parts.push(`Team size: ${c.teamSize}`);
  if (c.budget && c.budget !== 'Free only') parts.push(`Budget: ${c.budget}`);
  else if (c.budget === 'Free only') parts.push('Budget: free tools only');
  if (c.priority && c.priority !== 'Best overall') parts.push(`Priority: ${c.priority}`);
  if (!parts.length) return '';
  return `\n\n[Technical constraints — factor these into your recommendation and only suggest tools that genuinely match: ${parts.join('; ')}]`;
}

function ChatUI({ verified }) {
  const { messages, isStreaming, isLoadingHistory, sendMessage, clearMessages, lastError, clearError } = useIntegratedAi();
  const [input, setInput] = useState('');
  const [lastFailedPrompt, setLastFailedPrompt] = useState('');
  const [constraints, setConstraints] = useState({ os: 'Any', deployment: 'Any', license: 'Any', teamSize: 'Any', budget: 'Any', priority: 'Best overall' });
  const [constraintsApplied, setConstraintsApplied] = useState(false);
  const bottomRef = useRef(null);
  const scrollRef = useRef(null);
  const stickToBottomRef = useRef(true);
  const textareaRef = useRef(null);
  const scrollRafRef = useRef(0);

  // Keep the user pinned to the latest tokens without smooth-scroll thrashing the page.
  useEffect(() => {
    if (!stickToBottomRef.current || !scrollRef.current) return;
    if (scrollRafRef.current) cancelAnimationFrame(scrollRafRef.current);
    scrollRafRef.current = requestAnimationFrame(() => {
      const el = scrollRef.current;
      if (!el) return;
      el.scrollTop = el.scrollHeight;
    });
    return () => {
      if (scrollRafRef.current) cancelAnimationFrame(scrollRafRef.current);
    };
  }, [messages, lastError, isStreaming]);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    stickToBottomRef.current = distanceFromBottom < 80;
  };

  const handleSend = async (overrideText) => {
    const raw = (overrideText ?? input).trim();
    if (!raw || isStreaming) return;
    if (!verified) return;
    const text = constraintsApplied ? raw + buildConstraintSuffix(constraints) : raw;
    setInput('');
    setConstraintsApplied(false);
    clearError?.();
    setLastFailedPrompt(text);
    stickToBottomRef.current = true;
    try {
      await sendMessage(text);
      setLastFailedPrompt('');
    } catch {
      // errors surface via lastError / toast inside the hook
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const lastIdx = messages.length - 1;

  return (
    <div className="flex h-full min-h-0 w-full flex-1 flex-col overflow-hidden rounded-2xl border border-border bg-card">
      {/* Chat header */}
      <div className="flex shrink-0 items-center justify-between border-b border-border px-5 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full border border-primary/30 bg-primary/10">
            <Zap className="h-4 w-4 text-primary" />
          </div>
          <div>
            <p className="font-display text-sm font-semibold">MechEngi AI Advisor</p>
            <p className="font-mono text-[10px] text-muted-foreground">Engineering tools expert</p>
          </div>
        </div>
        {messages.length > 0 && (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => exportAdvisorTranscript(messages)}
              className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 font-mono text-xs text-muted-foreground hover:border-primary/40 hover:text-primary"
            >
              <FileDown className="h-3 w-3" /> Export PDF
            </button>
            <button
              type="button"
              onClick={() => { clearMessages(); clearError?.(); setLastFailedPrompt(''); }}
              className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 font-mono text-xs text-muted-foreground hover:border-foreground/40 hover:text-foreground"
            >
              <RefreshCw className="h-3 w-3" /> New chat
            </button>
          </div>
        )}
      </div>

      {/* Messages — only this pane scrolls; composer stays pinned below */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden overscroll-contain p-5"
      >
        {isLoadingHistory ? (
          <div className="flex h-full min-h-[280px] flex-col items-center justify-center gap-3 text-muted-foreground">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
            <p className="font-mono text-xs">Loading conversation…</p>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex h-full min-h-[280px] flex-col items-center justify-center text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10">
              <Bot className="h-8 w-8 text-primary" />
            </div>
            <h3 className="mt-4 font-display text-xl font-bold">Ask the MechEngi Advisor</h3>
            <p className="mt-2 max-w-sm text-sm text-muted-foreground">
              Get personalized engineering tool recommendations based on your workflow, team size, and budget.
            </p>
            <div className="mt-6 flex w-full max-w-md flex-col gap-2">
              {starters.map((s) => (
                <button
                  key={s}
                  type="button"
                  disabled={!verified || isStreaming}
                  onClick={() => handleSend(s)}
                  className="rounded-xl border border-border bg-muted/30 px-4 py-2.5 text-left text-sm text-muted-foreground transition-colors hover:border-primary/30 hover:text-foreground disabled:opacity-50"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-5">
            {messages.map((m, i) => (
              <Message
                key={i}
                msg={m}
                isStreamingTail={isStreaming && i === lastIdx && m.role === 'assistant'}
              />
            ))}
            <div ref={bottomRef} className="h-px w-full shrink-0" aria-hidden />
          </div>
        )}
      </div>

      <ErrorBanner
        error={lastError}
        onDismiss={() => clearError?.()}
        onRetry={lastFailedPrompt ? () => handleSend(lastFailedPrompt) : undefined}
      />

      {/* Input — always pinned at bottom of chat card, never covered by long answers */}
      <div className="shrink-0 border-t border-border bg-card p-3 sm:p-4">
        <ConstraintPanel
          constraints={constraints}
          setConstraints={setConstraints}
          disabled={!verified || isStreaming}
          onApply={() => setConstraintsApplied(true)}
        />
        {constraintsApplied && (
          <p className="mb-2 rounded-md bg-primary/10 px-2.5 py-1 font-mono text-[10px] text-primary">
            Constraints will be attached to your next message.
          </p>
        )}
        <div className="flex items-end gap-2 sm:gap-3">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={verified ? 'Ask about tools, pricing, comparisons…' : 'Verify your email to start chatting…'}
            rows={1}
            disabled={!verified}
            className="min-h-12 max-h-[120px] flex-1 resize-none rounded-xl border border-border bg-muted/30 px-4 py-3 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:opacity-60"
          />
          <button
            type="button"
            onClick={() => handleSend()}
            disabled={!verified || !input.trim() || isStreaming}
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-all hover:opacity-90 active:scale-[0.95] disabled:opacity-40"
            aria-label="Send message"
          >
            {isStreaming ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </button>
        </div>
        <p className="mt-2 text-center font-mono text-[10px] text-muted-foreground">
          AI Advisor gives general guidance — verify tool pricing before purchasing.
        </p>
      </div>
    </div>
  );
}

function LoginPrompt() {
  return (
    <div className="flex h-full min-h-0 flex-1 flex-col items-center justify-center overflow-y-auto rounded-2xl border border-border bg-card p-8 text-center sm:p-12">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-primary/30 bg-primary/10">
        <LogIn className="h-8 w-8 text-primary" />
      </div>
      <h3 className="mt-5 font-display text-2xl font-bold">Sign in to chat with the AI Advisor</h3>
      <p className="mt-3 max-w-sm text-muted-foreground">
        Create a free account to get personalized engineering tool recommendations, save your conversation history, and access exclusive guides.
      </p>
      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <Link
          to="/signup"
          className="rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
        >
          Create Free Account
        </Link>
        <Link
          to="/login"
          className="rounded-xl border border-border px-8 py-3 font-semibold transition-colors hover:border-primary/40 hover:text-primary"
        >
          Sign In
        </Link>
      </div>
      <p className="mt-4 font-mono text-xs text-muted-foreground">
        Free forever · No credit card required
      </p>
    </div>
  );
}

function VerifyEmailPrompt({ email }) {
  const [status, setStatus] = useState(''); // '', 'sending', 'sent', 'error'
  const [error, setError] = useState('');

  const resend = async () => {
    if (!email) return;
    setStatus('sending');
    setError('');
    try {
      await pb.collection('users').requestVerification(email);
      setStatus('sent');
    } catch (err) {
      setStatus('error');
      setError(err?.message || 'Could not send verification email. Please try again.');
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col items-center justify-center overflow-y-auto rounded-2xl border border-border bg-card p-8 text-center sm:p-12">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-accent/40 bg-accent/10">
        <Mail className="h-8 w-8 text-accent" />
      </div>
      <h3 className="mt-5 font-display text-2xl font-bold">Verify your email to chat</h3>
      <p className="mt-3 max-w-md text-muted-foreground">
        We sent a verification link{email ? ` to ${email}` : ''}. Open it, then refresh this page to unlock the AI Advisor.
      </p>
      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <button
          type="button"
          onClick={resend}
          disabled={status === 'sending' || status === 'sent'}
          className="rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60"
        >
          {status === 'sending' ? 'Sending…' : status === 'sent' ? 'Email sent' : 'Resend verification email'}
        </button>
        <button
          type="button"
          onClick={() => window.location.reload()}
          className="rounded-xl border border-border px-8 py-3 font-semibold transition-colors hover:border-primary/40 hover:text-primary"
        >
          I verified — refresh
        </button>
      </div>
      {status === 'sent' && (
        <p className="mt-4 text-sm text-primary">Check your inbox (and spam folder) for the link.</p>
      )}
      {status === 'error' && error && (
        <p className="mt-4 text-sm text-destructive">{error}</p>
      )}
    </div>
  );
}

export default function AdvisorPage() {
  const { user } = useAuth();
  const verified = !!user?.verified;

  return (
    <div className="flex min-h-[100dvh] flex-col bg-background">
      <Helmet>
        <title>AI Advisor — MechEngi 10X Engineering Tool Recommendations</title>
        <meta name="description" content="Chat with our AI Advisor to get personalized engineering software tool recommendations based on your discipline, team size, and budget." />
      </Helmet>

      <SiteHeader />

      <div className="mx-auto flex w-full max-w-[72rem] flex-1 flex-col px-5 py-6 sm:py-8 min-h-0">
        {/* Page header — shrink so chat claims remaining viewport */}
        <div className="mb-4 shrink-0 sm:mb-6">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Zap className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">AI-Powered</p>
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Engineering Tool Advisor</h1>
          <p className="mt-2 text-muted-foreground">
            Describe your engineering workflow and get honest, specific tool recommendations in seconds.
          </p>
        </div>

        <div className="flex min-h-0 flex-1 flex-col gap-6 md:flex-row md:items-stretch">
          {/* Main chat — fixed height band so composer never leaves the viewport */}
          <div className="flex h-[min(70vh,720px)] min-h-[420px] max-h-[min(70vh,720px)] flex-1 flex-col overflow-hidden md:h-[min(72vh,760px)] md:max-h-[min(72vh,760px)]">
            {!user ? (
              <LoginPrompt />
            ) : !verified ? (
              <VerifyEmailPrompt email={user.email} />
            ) : (
              <ChatUI verified={verified} />
            )}
          </div>

          {/* Sidebar */}
          <div className="w-full shrink-0 space-y-4 md:w-72 md:self-start">
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">What I can help with</h3>
              <ul className="mt-3 space-y-2">
                {[
                  'CAD software selection',
                  'FEA / CFD tool comparison',
                  'AI tools for engineers',
                  'Project management setup',
                  'Learning platform picks',
                  'Budget vs premium tradeoffs',
                  'Free tool alternatives',
                  'Team size considerations',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Browse instead</h3>
              <div className="mt-3 flex flex-col gap-2">
                <Link to="/tools" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">
                  → Tools Directory
                </Link>
                <Link to="/courses" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">
                  → Premium Courses
                </Link>
                <Link to="/forum" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">
                  → Community Forum
                </Link>
                <Link to="/compare" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">
                  → Tool Comparisons
                </Link>
                <Link to="/guides" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">
                  → Engineering Guides
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
