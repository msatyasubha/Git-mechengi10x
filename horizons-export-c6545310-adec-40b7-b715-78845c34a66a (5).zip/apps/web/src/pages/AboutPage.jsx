import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Shield, Award, Users, CheckCircle, BarChart2, Zap } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { SCORE_CATEGORIES } from '@/data/methodology';

const externalEvaluation = {
  overall: 8.8,
  overallLabel: 'Excellent',
  received: 'September 2026',
  dimensions: [
    { name: 'Editorial Transparency', score: 9.5, note: 'Clear separation between affiliate links and review scores, with strict vendor-independence rules.' },
    { name: 'Content Quality & Depth', score: 9.2, note: 'High-value, engineer-authored reviews covering practical CAD, FEA/CFD, AI, and automation workflows rather than generic marketing specs.' },
    { name: 'Scoring Methodology', score: 9.0, note: 'Transparent 7-criterion weighted scoring matrix (usefulness, features, value, ease of use, integration, reliability, community).' },
    { name: 'Interactive Utilities & AI Advisor', score: 8.5, note: 'The AI Engineering Advisor and embedded online calculators provide instant, tailored workflow assistance.' },
    { name: 'UI / UX & Navigation', score: 8.0, note: 'Clean, fast-loading, structured directory layout with clear category filters and quarterly-updated pricing data.' },
  ],
};

// Supplied strategic (investor-oriented) assessment — NOT an official
// valuation, due-diligence report, or independent investor research.
// Market-size, AOV, and per-lead figures quoted in the commentary are the
// assessment's own estimates and are NOT verified by MechEngi 10X.
const investorScorecard = {
  received: 'September 2026',
  dimensions: [
    { name: 'Market Potential & Niche Fit', score: 8.8, note: 'The assessment sees a large addressable audience of engineers and engineering teams evaluating software purchases. Its claims about market size and subscription order values are its own estimates — we publish no market-size or revenue figures.' },
    { name: 'Product & UX Design', score: 8.5, note: 'Clean, fast, developer-friendly UI with clear categorization across AI, CAD, FEA, and Automation.' },
    { name: 'Content Quality & Rigor', score: 9.2, note: 'Hands-on, engineer-authored content that avoids surface-level marketing fluff.' },
    { name: 'Moat & Defensibility', score: 6.5, note: 'Needs stronger user network effects — verified user reviews, benchmark databases, and macro repositories. We agree this is our weakest area and are addressing it (see the strategic moves below).' },
    { name: 'Monetization Scalability', score: 7.5, note: 'Good foundation, but the assessment recommends moving beyond low-margin affiliate links toward B2B vendor lead generation and consulting. We have added an enterprise quote / VAR introduction request flow — with no claims of reseller partnerships, guaranteed lead values, or completed sales.' },
  ],
  moves: [
    {
      title: 'High-ticket B2B lead generation',
      status: 'Live',
      desc: 'Enterprise quote / VAR introduction request buttons on heavy CAD, FEA, and PLM tool pages, routed by our team to the vendor’s sales channel. We claim no reseller partnerships, no guaranteed lead values, and no completed enterprise sales.',
    },
    {
      title: 'Open hardware benchmark initiative',
      status: 'Live — community-run, no published results',
      desc: 'A downloadable, MIT-licensed open 1,000-part assembly benchmark for FreeCAD that engineers run on their own workstation hardware. We publish no benchmark numbers, rankings, or vendor comparisons — all results are self-reported community data.',
    },
    {
      title: 'Automation macro & script repository',
      status: 'Live — submissions moderated',
      desc: 'A searchable library of team-written automation scripts plus community submissions. Submissions are labelled unverified and reviewed before publication — no fabricated contributors, download counts, or ratings.',
    },
  ],
};

const principles = [
  { icon: Shield, title: 'Vendor Independence', desc: 'We do not accept sponsorship, paid placements, or "partner" arrangements that influence our scoring. Every tool is evaluated on its own merits.' },
  { icon: Award, title: 'Documented Testing', desc: 'Hands-on testing is identified when performed. Numeric scores remain unavailable until reproducible benchmark evidence exists.' },
  { icon: CheckCircle, title: 'Transparent Criteria', desc: 'Our scoring criteria, weights, and methodology are published here and updated when we change them. No hidden factors.' },
  { icon: Users, title: 'Community Reviews', desc: 'Community submissions are moderated and presented separately from editorial assessments.' },
  { icon: BarChart2, title: 'Information Updates', desc: 'Software changes over time. Confirm current pricing and capabilities with the vendor before making a decision.' },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>About MechEngi 10X — Editorial Policy & Review Methodology</title>
        <meta name="description" content="Learn about MechEngi 10X's editorial policy, review methodology, MechEngi Score system, and our commitment to independent, vendor-neutral engineering tool reviews." />
      </Helmet>

      <SiteHeader />

      {/* Hero */}
      <div className="border-b border-border bg-card/30 py-12">
        <div className="mx-auto max-w-[72rem] px-5">
          <div className="flex items-center gap-2 mb-3">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Zap className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Who We Are</p>
          </div>
          <h1 className="font-display text-3xl font-bold sm:text-4xl">About MechEngi 10X</h1>
          <p className="mt-3 max-w-2xl text-lg text-muted-foreground leading-relaxed">
            MechEngi 10X is an independent engineering tool discovery and review platform built by engineers, for engineers. Our goal is to cut through vendor marketing noise and give you honest, criteria-driven evaluations of the software tools that shape modern engineering practice.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-[72rem] px-5 py-12 space-y-16">

        {/* Mission */}
        <section>
          <h2 className="font-display text-2xl font-bold mb-4">Mission &amp; Scope</h2>
          <div className="prose-like max-w-3xl space-y-4 text-foreground/80 leading-relaxed">
            <p className="text-lg text-foreground">
              Our mission is to eliminate guesswork in software selection, CAD automation, and technical workflow optimization. We provide structured software comparisons, practical macro/automation code frameworks, and transparent tool evaluations based strictly on verifiable technical specifications and documented engineering workflows.
            </p>
            <p>
              MechEngi 10X is operated by an independent editorial team of practising engineers. We are not a
              registered certification body, and we claim no company registration, professional accreditation,
              industry partnership, or third-party endorsement we have not earned. Information on this site is a mix
              of independently researched editorial content and vendor-provided specifications (pricing, file
              formats, API documentation) that we label with its source and verification date where possible. All
              correspondence is handled through <a href="mailto:hello@mechengi10x.com" className="text-primary hover:underline">hello@mechengi10x.com</a>.
            </p>
            <p>
              Every year, engineering teams waste thousands of dollars on software tools that do not fit their workflow — because the information available at purchase time is dominated by vendor marketing, affiliate sites with no hands-on experience, and review platforms that prioritize breadth over depth.
            </p>
            <p>
              MechEngi 10X exists to fix that. We evaluate engineering tools the way engineers evaluate anything: with a defined methodology, measurable criteria, honest assessment of trade-offs, and transparent disclosure of how we reached our conclusions.
            </p>
            <p>
              We cover seven categories — AI Tools, CAD & Design, Simulation, Automation, Engineering Management, Learning, and Software Engineering — with plans to expand as the engineering software landscape evolves.
            </p>
          </div>
        </section>

        {/* Editorial Independence */}
        <section>
          <h2 className="font-display text-2xl font-bold mb-4">Editorial Independence</h2>
          <p className="max-w-3xl text-foreground/80 leading-relaxed">
            Commercial relationships, affiliate links, or sponsorships do not dictate our research, scoring, or editorial assessments. All software tools, macros, and platforms are evaluated against our standardized 100-point MechEngi Score framework. Sponsored listings or paid placements are strictly labelled as &quot;Sponsored&quot; or &quot;Partner Listing&quot; and are excluded from organic MechEngi Score rankings.
          </p>
        </section>

        {/* Editorial Policy */}
        <section>
          <h2 className="font-display text-2xl font-bold mb-2">Editorial Policy</h2>
          <p className="mb-8 text-muted-foreground max-w-2xl">Our editorial process is designed to protect the independence of our reviews from commercial pressures.</p>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {principles.map((p) => {
              const Icon = p.icon;
              return (
                <div key={p.title} className="rounded-xl border border-border bg-card p-5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 mb-3">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-display font-bold mb-2">{p.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
                </div>
              );
            })}
          </div>
          <div className="mt-6 rounded-xl border border-amber-500/20 bg-amber-500/5 p-5">
            <p className="text-sm text-amber-400 font-semibold mb-1">Affiliate Disclosure</p>
            <p className="text-sm text-muted-foreground">
              MechEngi 10X uses affiliate links on "Try Tool" and "Get [Tool]" buttons. If you purchase a product through one of these links, we may earn a commission at no additional cost to you. Affiliate relationships never influence our scores, rankings, or editorial content. A tool can have an affiliate link and still receive a low score if it does not deserve a high one.
            </p>
          </div>
        </section>

        {/* Score Methodology */}
        <section id="methodology">
          <h2 className="font-display text-2xl font-bold mb-2">MechEngi 10X Score Methodology</h2>
          <p className="mb-8 text-muted-foreground max-w-2xl">
            Our published framework has eight weighted categories totaling 100 points. Tools are marked Not Yet Rated until reproducible benchmark evidence exists. Some older reviews discuss different qualitative topics; those topics are not scores under this framework and cannot be converted into a weighted rating.
          </p>
          <div className="space-y-4">
            {SCORE_CATEGORIES.map((cat) => (
              <div key={cat.name} className="rounded-xl border border-border bg-card p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-display font-bold">{cat.name}</h3>
                      <span className="rounded-full bg-primary/10 px-2.5 py-0.5 font-mono text-xs font-semibold text-primary">
                        {cat.weight}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{cat.summary}</p>
                  </div>
                  <div className="w-full mt-3">
                    <div className="h-1.5 w-full rounded-full bg-muted">
                      <div
                        className="h-full rounded-full bg-primary transition-all"
                        style={{ width: `${cat.max}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 rounded-xl border border-border bg-muted/30 p-5">
            <h3 className="font-display font-semibold mb-2">How the Score is Calculated</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              The framework specifies a maximum for each category; scores are published only when backed by documented, reproducible benchmark data. No tool has completed that process yet. See the full <a href="/methodology" className="text-primary hover:underline">evaluation methodology</a> and current evidence status.
            </p>
          </div>
        </section>

        {/* External Evaluation Snapshot */}
        <section id="external-evaluation">
          <h2 className="font-display text-2xl font-bold mb-2">External Evaluation Snapshot</h2>
          <p className="mb-8 max-w-2xl text-muted-foreground leading-relaxed">
            In {externalEvaluation.received}, an external evaluation of MechEngi 10X was shared with our team and rated
            the platform <span className="font-semibold text-foreground">{externalEvaluation.overall} / 10 ({externalEvaluation.overallLabel})</span> as an
            engineering software discovery and upskilling platform. We reproduce it below for transparency. It is an
            unsolicited assessment — not an official third-party certification, ranking, or award — and we did not
            commission or pay for it. This historical assessment refers to an earlier seven-criterion model; our current
            eight-category methodology above is the source of truth.
          </p>
          <div className="rounded-xl border border-border bg-card p-6">
            <div className="mb-6 flex flex-wrap items-baseline gap-x-3 gap-y-1 border-b border-border pb-5">
              <span className="font-display text-3xl font-extrabold text-primary">{externalEvaluation.overall} / 10</span>
              <span className="font-display text-lg font-semibold">{externalEvaluation.overallLabel}</span>
              <span className="ml-auto font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                Overall — external evaluation, {externalEvaluation.received}
              </span>
            </div>
            <div className="space-y-5">
              {externalEvaluation.dimensions.map((d) => (
                <div key={d.name}>
                  <div className="mb-1.5 flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                    <h3 className="font-display text-sm font-bold">{d.name}</h3>
                    <span className="font-mono text-xs font-semibold text-primary">{d.score.toFixed(1)} / 10</span>
                  </div>
                  <div className="mb-2 h-1.5 w-full rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${d.score * 10}%` }}
                    />
                  </div>
                  <p className="text-sm leading-relaxed text-muted-foreground">{d.note}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Investor Valuation Scorecard (supplied strategic assessment) */}
        <section id="investor-scorecard">
          <h2 className="font-display text-2xl font-bold mb-2">Investor Valuation Scorecard</h2>
          <p className="mb-8 max-w-3xl text-muted-foreground leading-relaxed">
            In {investorScorecard.received}, an investor-oriented strategic assessment of MechEngi 10X was shared with
            our team. We reproduce its scorecard below for transparency. It is a <span className="text-foreground">supplied
            internal strategic assessment</span> — not an official valuation, not due diligence, and not independent
            investor research. We did not commission or pay for it. Any market-size, order-value, or per-lead figures
            referenced by the assessment are its own estimates and are <span className="text-foreground">not verified by
            MechEngi 10X</span>; we publish no revenue, valuation, or lead-value numbers of our own.
          </p>
          <div className="rounded-xl border border-border bg-card p-6">
            <div className="mb-6 border-b border-border pb-5">
              <span className="font-display text-lg font-semibold">Supplied strategic assessment — {investorScorecard.received}</span>
              <span className="ml-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber-400">
                Not an official valuation
              </span>
            </div>
            <div className="space-y-5">
              {investorScorecard.dimensions.map((d) => (
                <div key={d.name}>
                  <div className="mb-1.5 flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                    <h3 className="font-display text-sm font-bold">{d.name}</h3>
                    <span className="font-mono text-xs font-semibold text-primary">{d.score.toFixed(1)} / 10</span>
                  </div>
                  <div className="mb-2 h-1.5 w-full rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${d.score * 10}%` }}
                    />
                  </div>
                  <p className="text-sm leading-relaxed text-muted-foreground">{d.note}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Strategic moves with honest implementation status */}
          <div className="mt-6 rounded-xl border border-border bg-muted/30 p-5">
            <h3 className="font-display font-semibold mb-2">The assessment’s three strategic moves — where we actually stand</h3>
            <div className="space-y-4">
              {investorScorecard.moves.map((m) => (
                <div key={m.title} className="rounded-lg border border-border bg-card p-4">
                  <div className="flex flex-wrap items-baseline gap-2">
                    <h4 className="font-display text-sm font-bold">{m.title}</h4>
                    <span className="rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-primary">
                      {m.status}
                    </span>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{m.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact */}
        <section id="contact">
          <h2 className="font-display text-2xl font-bold mb-4">Contact</h2>
          <div className="rounded-xl border border-border bg-card p-6 max-w-lg">
            <p className="text-muted-foreground mb-4">
              For editorial inquiries, tool submission requests, corrections, or partnership questions, reach us at:
            </p>
            <div className="space-y-3">
              <div>
                <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-1">General Inquiries</p>
                <p className="font-semibold text-primary">hello@mechengi10x.com</p>
              </div>
              <div>
                <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-1">Tool Submissions</p>
                <p className="font-semibold text-primary">hello@mechengi10x.com</p>
              </div>
              <div>
                <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground mb-1">Editorial Corrections</p>
                <p className="font-semibold text-primary">hello@mechengi10x.com</p>
              </div>
            </div>
            <p className="mt-4 text-xs text-muted-foreground">
              We aim to respond as promptly as we can. Tool submissions are reviewed on a rolling basis — we evaluate approximately 5–10 new tools per month.
            </p>
          </div>
        </section>

      </div>

      <SiteFooter />
    </div>
  );
}
