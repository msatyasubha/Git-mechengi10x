import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useSearchParams } from 'react-router-dom';
import { Clock, ArrowRight } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { guides } from '@/data/guides';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const monthYear = (d) => {
  const [y, m] = d.split('-');
  return `${MONTHS[Number(m) - 1]} ${y}`;
};

const catOptions = [
  { id: 'all', label: 'All Guides' },
  { id: 'ai', label: 'AI Tools' },
  { id: 'cad', label: 'CAD & Design' },
  { id: 'simulation', label: 'Simulation' },
  { id: 'automation', label: 'Automation' },
  { id: 'management', label: 'Management' },
  { id: 'learning', label: 'Learning' },
];

function GuideArticle({ guide, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);

  // Simple markdown-like rendering: split on ## headers and render paragraphs
  const renderContent = (content) => {
    const lines = content.trim().split('\n');
    const elements = [];
    let key = 0;
    let currentParagraph = [];

    const flushParagraph = () => {
      if (currentParagraph.length > 0) {
        elements.push(
          <p key={key++} className="mt-3 leading-relaxed text-foreground/80">
            {currentParagraph.join(' ')}
          </p>
        );
        currentParagraph = [];
      }
    };

    for (const line of lines) {
      if (line.startsWith('## ')) {
        flushParagraph();
        elements.push(
          <h3 key={key++} className="mt-6 font-display text-lg font-bold">
            {line.replace('## ', '')}
          </h3>
        );
      } else if (line.startsWith('### ')) {
        flushParagraph();
        elements.push(
          <h4 key={key++} className="mt-4 font-display text-base font-semibold">
            {line.replace('### ', '')}
          </h4>
        );
      } else if (line.startsWith('**') && line.endsWith('**')) {
        flushParagraph();
        elements.push(
          <p key={key++} className="mt-3 font-semibold">
            {line.replace(/\*\*/g, '')}
          </p>
        );
      } else if (line.startsWith('- ')) {
        flushParagraph();
        elements.push(
          <p key={key++} className="mt-1.5 flex items-start gap-2 text-sm text-foreground/80">
            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
            {line.replace('- ', '')}
          </p>
        );
      } else if (line.trim() === '') {
        flushParagraph();
      } else {
        currentParagraph.push(line);
      }
    }
    flushParagraph();
    return elements;
  };

  return (
    <article className="overflow-hidden rounded-2xl border border-border bg-card transition-all">
      <button
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        className="flex w-full items-start gap-4 p-6 text-left"
      >
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${guide.category}`}>
              {guide.category}
            </span>
            {guide.featured && (
              <span className="rounded-full bg-accent/15 px-2.5 py-0.5 font-mono text-[10px] text-accent">Featured</span>
            )}
          </div>
          <h2 className="mt-2 font-display text-xl font-bold leading-snug">{guide.title}</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{guide.excerpt}</p>
          <div className="mt-3 flex items-center gap-3 font-mono text-xs text-muted-foreground">
            <Clock className="h-3.5 w-3.5" />
            <span>{guide.readTime} min read</span>
            <span>·</span>
            <span>Published {monthYear(guide.date)}</span>
            <span>·</span>
            <span>{guide.author}</span>
          </div>
        </div>
        <div className="mt-1 shrink-0 rounded-lg border border-border px-3 py-1.5 font-mono text-[11px] font-medium text-primary">
          {open ? 'Close ↑' : 'Read guide →'}
        </div>
      </button>

      <div hidden={!open} className="border-t border-border px-6 pb-6 pt-4">
          <div className="space-y-0">
            {renderContent(guide.content)}
          </div>
          <div className="mt-6 flex flex-wrap gap-2">
            {guide.tags.map((t) => (
              <span key={t} className="rounded-full border border-border px-3 py-1 font-mono text-xs text-muted-foreground">
                #{t}
              </span>
            ))}
          </div>
      </div>
    </article>
  );
}

export default function GuidesPage() {
  const [params, setParams] = useSearchParams();
  const activeCat = params.get('cat') || 'all';
  const openSlug = params.get('open');

  // A direct guide link should remain reachable even if an older category
  // filter is present in the URL.
  const linkedGuide = guides.find((guide) => guide.slug === openSlug);
  const filtered = activeCat === 'all' ? guides : guides.filter((g) => g.category === activeCat || g.slug === linkedGuide?.slug);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Tool Guides &amp; Reviews — MechEngi 10X</title>
        <meta name="description" content="In-depth guides, comparisons, and reviews to help mechanical engineers choose the best software tools for their workflow." />
      </Helmet>

      <SiteHeader />

      {/* Header */}
      <div className="border-b border-border bg-card/30 py-10">
        <div className="mx-auto max-w-[72rem] px-5">
          <h1 className="font-display text-3xl font-bold sm:text-4xl">Engineering Guides</h1>
          <p className="mt-2 text-muted-foreground">
            In-depth articles to help you choose, configure, and get the most out of engineering tools.
          </p>
          <p className="mt-3 max-w-3xl text-xs leading-relaxed text-muted-foreground">
            Some guides include historical prices, examples, or performance claims that have not been independently benchmarked. Confirm current details with primary sources and independently verify engineering work.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            {catOptions.map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  const next = new URLSearchParams(params);
                  if (c.id === 'all') next.delete('cat');
                  else next.set('cat', c.id);
                  setParams(next);
                }}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                  activeCat === c.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[72rem] px-5 py-10">
        <p className="mb-6 font-mono text-xs text-muted-foreground">
          {filtered.length} guide{filtered.length !== 1 ? 's' : ''}
        </p>
        <div className="flex flex-col gap-4">
          {filtered.map((g) => (
            <GuideArticle key={`${g.slug}:${openSlug || ''}`} guide={g} defaultOpen={openSlug === g.slug} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="py-20 text-center">
            <p className="font-display text-xl font-semibold">No guides in this category yet.</p>
            <p className="mt-2 text-muted-foreground">Try another category to explore more guides.</p>
          </div>
        )}

        {/* AI advisor CTA */}
        <div className="mt-12 rounded-2xl border border-primary/20 bg-primary/5 p-8 text-center">
          <p className="font-display text-xl font-bold">Want a personalized recommendation?</p>
          <p className="mt-2 text-muted-foreground">Our AI Advisor can narrow down the right tool based on your specific workflow in minutes.</p>
          <a href="/advisor" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground hover:opacity-90">
            Talk to AI Advisor <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
