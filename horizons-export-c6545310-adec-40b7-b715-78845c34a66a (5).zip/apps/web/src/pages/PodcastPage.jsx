import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Mic, Play, ArrowRight } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { podcastEpisodes, podcastCategories, getEpisodesByCategory } from '@/data/podcast';

export default function PodcastPage() {
  const [cat, setCat] = useState('all');
  const [query, setQuery] = useState('');
  let filtered = getEpisodesByCategory(cat);
  if (query.trim()) {
    const q = query.toLowerCase();
    filtered = filtered.filter(
      (e) =>
        e.title.toLowerCase().includes(q) ||
        e.description.toLowerCase().includes(q) ||
        e.guest.toLowerCase().includes(q),
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Podcast Topics — Tools & Careers | MechEngi 10X</title>
        <meta name="description" content="Explore topic outlines on engineering software, AI, CAD, simulation and careers. Audio and guest details are not verified on this site." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Mic className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Podcast</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            The 10X Engineer Podcast
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            Explore proposed topics on engineering tools and careers. Audio is not available here, and guest details
            and outcomes have not been independently verified; the text is a topic outline rather than a transcript.
          </p>

        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap gap-2">
            {podcastCategories.map((c) => (
              <button
                key={c.id}
                onClick={() => setCat(c.id)}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs uppercase tracking-wider transition-colors ${
                  cat === c.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-foreground/40 hover:text-foreground'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search episodes…"
            className="min-h-[44px] w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary sm:w-64"
          />
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 pb-20">
        <div className="space-y-3">
          {filtered.map((e) => (
            <Link
              key={e.slug}
              to={`/podcast/${e.slug}`}
              className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-4 transition-colors hover:border-primary/40 sm:p-5"
            >
              <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Play className="h-6 w-6" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  <span>Topic {String(e.number).padStart(2, '0')}</span>
                  <span>·</span>
                  <span>{e.category}</span>
                </div>
                <h2 className="mt-1 truncate font-display font-semibold group-hover:text-primary">{e.title}</h2>
                <p className="mt-1 line-clamp-1 text-sm text-muted-foreground">{e.description}</p>
              </div>
              <ArrowRight className="hidden h-5 w-5 shrink-0 text-muted-foreground sm:block" />
            </Link>
          ))}
          {filtered.length === 0 && (
            <div className="rounded-2xl border border-border bg-card p-12 text-center text-sm text-muted-foreground">
              No episodes match your search.
            </div>
          )}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
