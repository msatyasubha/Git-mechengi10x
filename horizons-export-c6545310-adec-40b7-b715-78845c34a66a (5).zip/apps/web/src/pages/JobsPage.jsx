import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Briefcase, MapPin, Clock, ExternalLink, Search, Building2, DollarSign, Globe, IndianRupee, TrendingUp, ArrowRight, AlertTriangle } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

const jobListings = [
  {
    id: 1,
    title: 'Senior Mechanical Design Engineer',
    company: 'SpaceX',
    location: 'Hawthorne, CA',
    type: 'Full-time',
    category: 'cad',
    salary: '$120k–$160k',
    tags: ['SOLIDWORKS', 'GD&T', 'FEA', 'Aerospace'],
    description: 'Design and develop mechanical systems for launch vehicles. Hands-on work from concept through flight hardware. Strong CAD and FEA skills required.',
    posted: '2 days ago',
    url: 'https://www.spacex.com/careers/',
    featured: true,
  },
  {
    id: 2,
    title: 'FEA / Simulation Engineer',
    company: 'Tesla',
    location: 'Fremont, CA',
    type: 'Full-time',
    category: 'simulation',
    salary: '$110k–$150k',
    tags: ['ANSYS', 'Nonlinear FEA', 'Python', 'Structural'],
    description: 'Conduct advanced structural and thermal simulations for electric vehicle components. Collaborate with design engineers to optimize parts for performance and manufacturability.',
    posted: '3 days ago',
    url: 'https://www.tesla.com/careers/',
    featured: true,
  },
  {
    id: 3,
    title: 'Robotics Automation Engineer',
    company: 'Boston Dynamics',
    location: 'Waltham, MA',
    type: 'Full-time',
    category: 'automation',
    salary: '$115k–$155k',
    tags: ['ROS', 'Python', 'Motion Planning', 'Control Systems'],
    description: 'Develop automation pipelines and motion planning algorithms for advanced robotic systems. Experience with simulation environments and real hardware deployment required.',
    posted: '5 days ago',
    url: 'https://bostondynamics.com/careers/',
    featured: true,
  },
  {
    id: 4,
    title: 'AI/ML Engineer — Engineering Applications',
    company: 'Autodesk',
    location: 'San Francisco, CA (Hybrid)',
    type: 'Full-time',
    category: 'ai',
    salary: '$130k–$175k',
    tags: ['Machine Learning', 'Generative Design', 'Python', 'CAD'],
    description: 'Apply AI and ML to engineering design workflows. Work on generative design, design automation, and intelligent recommendation systems inside Fusion 360.',
    posted: '1 week ago',
    url: 'https://www.autodesk.com/careers/',
    featured: false,
  },
  {
    id: 5,
    title: 'CFD Engineer — Thermal Management',
    company: 'Apple',
    location: 'Cupertino, CA',
    type: 'Full-time',
    category: 'simulation',
    salary: '$130k–$170k',
    tags: ['ANSYS Fluent', 'CFD', 'Thermal', 'Python'],
    description: 'Design and validate thermal management solutions for Apple silicon and product enclosures. Deep expertise in CFD and thermal simulation required.',
    posted: '1 week ago',
    url: 'https://www.apple.com/careers/',
    featured: false,
  },
  {
    id: 6,
    title: 'Manufacturing Process Engineer',
    company: 'General Motors',
    location: 'Detroit, MI',
    type: 'Full-time',
    category: 'automation',
    salary: '$90k–$120k',
    tags: ['Lean Manufacturing', 'Six Sigma', 'AutoCAD', 'PLC'],
    description: 'Optimize manufacturing processes for electric vehicle production lines. Implement automation and continuous improvement initiatives.',
    posted: '1 week ago',
    url: 'https://www.gm.com/careers/',
    featured: false,
  },
  {
    id: 7,
    title: 'Structural Analysis Engineer',
    company: 'Lockheed Martin',
    location: 'Fort Worth, TX',
    type: 'Full-time',
    category: 'simulation',
    salary: '$100k–$140k',
    tags: ['NASTRAN', 'CATIA', 'Aerospace', 'Fatigue Analysis'],
    description: 'Perform structural analysis on defense and aerospace structures from preliminary design through certification. Clearance eligibility required.',
    posted: '2 weeks ago',
    url: 'https://www.lockheedmartin.com/careers/',
    featured: false,
  },
  {
    id: 8,
    title: 'CAD Designer — Medical Devices',
    company: 'Medtronic',
    location: 'Minneapolis, MN (Hybrid)',
    type: 'Full-time',
    category: 'cad',
    salary: '$80k–$110k',
    tags: ['SOLIDWORKS', 'GD&T', 'FDA', 'Medical Device'],
    description: 'Design and develop mechanical components for implantable and surgical devices. ISO 13485 and FDA design control experience is a plus.',
    posted: '2 weeks ago',
    url: 'https://www.medtronic.com/careers/',
    featured: false,
  },
  {
    id: 9,
    title: 'Engineering Program Manager',
    company: 'Amazon',
    location: 'Seattle, WA (Hybrid)',
    type: 'Full-time',
    category: 'management',
    salary: '$130k–$180k',
    tags: ['Project Management', 'Agile', 'Cross-functional', 'Hardware'],
    description: "Lead technical programs from concept through production for Amazon's devices and robotics hardware. Strong engineering background required alongside PM skills.",
    posted: '2 weeks ago',
    url: 'https://www.amazon.jobs/',
    featured: false,
  },
  {
    id: 10,
    title: 'Mechanical Engineer — Onshape Admin',
    company: 'PTC Inc.',
    location: 'Boston, MA (Remote)',
    type: 'Full-time',
    category: 'cad',
    salary: '$95k–$130k',
    tags: ['Onshape', 'FeatureScript', 'Cloud CAD', 'PLM'],
    description: 'Work with enterprise customers to deploy and optimize Onshape implementations. Build custom FeatureScript features and develop CAD automation workflows.',
    posted: '3 weeks ago',
    url: 'https://www.ptc.com/careers/',
    featured: false,
  },
  {
    id: 11,
    title: 'Junior Simulation Engineer',
    company: 'SimScale GmbH',
    location: 'Munich, Germany (Remote)',
    type: 'Full-time',
    category: 'simulation',
    salary: '€60k–€80k',
    tags: ['CFD', 'FEA', 'OpenFOAM', 'Python'],
    description: 'Support customers running structural and fluid simulations on the SimScale platform. Develop validation benchmarks and create technical content.',
    posted: '3 weeks ago',
    url: 'https://www.simscale.com/careers/',
    featured: false,
  },
  {
    id: 12,
    title: 'Automation Developer — Engineering Workflows',
    company: 'Siemens',
    location: 'Plano, TX (Hybrid)',
    type: 'Full-time',
    category: 'automation',
    salary: '$100k–$135k',
    tags: ['Python', 'NX API', 'Teamcenter', 'PLM Integration'],
    description: 'Develop automation tools and integrations for CAD/PLM engineering workflows using Siemens NX, Teamcenter, and Python scripting.',
    posted: '3 weeks ago',
    url: 'https://jobs.siemens.com/',
    featured: false,
  },
  {
    id: 13,
    title: 'Technical Learning Designer — Engineering',
    company: 'Coursera',
    location: 'Remote',
    type: 'Full-time',
    category: 'learning',
    salary: '$90k–$120k',
    tags: ['Instructional Design', 'Engineering Education', 'E-learning', 'STEM'],
    description: 'Design and develop technical engineering courses in partnership with university instructors. Background in mechanical or civil engineering preferred.',
    posted: '1 month ago',
    url: 'https://careers.coursera.org/',
    featured: false,
  },
  {
    id: 14,
    title: 'Engineering AI Product Manager',
    company: 'Ansys',
    location: 'Canonsburg, PA (Hybrid)',
    type: 'Full-time',
    category: 'ai',
    salary: '$120k–$155k',
    tags: ['AI', 'Product Management', 'Simulation', 'ML'],
    description: 'Define and drive AI features for ANSYS simulation products. Partner with engineering and data science teams to bring ML-powered simulation capabilities to market.',
    posted: '1 month ago',
    url: 'https://www.ansys.com/careers/',
    featured: false,
  },
  {
    id: 15,
    title: 'Mechanical Engineer — Consumer Products',
    company: 'Dyson',
    location: 'Chicago, IL',
    type: 'Full-time',
    category: 'cad',
    salary: '$85k–$115k',
    tags: ['Fusion 360', 'Consumer Products', 'Prototyping', 'DFM'],
    description: 'Design and develop mechanisms for next-generation Dyson products. Ownership from concept through DFM, rapid prototyping, and mass production.',
    posted: '1 month ago',
    url: 'https://www.dyson.com/careers/',
    featured: false,
  },
];

const categoryOptions = [
  { id: 'all', label: 'All Categories' },
  { id: 'ai', label: 'AI Tools' },
  { id: 'cad', label: 'CAD & Design' },
  { id: 'simulation', label: 'Simulation' },
  { id: 'automation', label: 'Automation' },
  { id: 'management', label: 'Management' },
  { id: 'learning', label: 'Learning' },
];

const typeOptions = ['All Types', 'Full-time', 'Part-time', 'Contract', 'Remote'];

const jobBoards = [
  { name: 'LinkedIn Engineering Jobs', url: 'https://www.linkedin.com/jobs/mechanical-engineer-jobs/', description: 'Largest professional network with thousands of ME job listings' },
  { name: 'Indeed — Mechanical Engineering', url: 'https://www.indeed.com/q-mechanical-engineer-jobs.html', description: 'Aggregate of all major job boards — best for volume searching' },
  { name: 'EngineerJobs.com', url: 'https://www.engineerjobs.com/', description: 'Specialized engineering job board across all disciplines' },
  { name: 'ASME Career Center', url: 'https://jobs.asme.org/', description: "American Society of Mechanical Engineers' official job board" },
  { name: 'Glassdoor Engineering', url: 'https://www.glassdoor.com/Job/mechanical-engineer-jobs-SRCH_KO0,20.htm', description: 'Jobs with salary data and company reviews' },
  { name: 'AngelList / Wellfound', url: 'https://wellfound.com/jobs', description: 'Best for startup engineering roles and equity-compensated positions' },
];

// India-focused engineering job discovery platforms. These are real, verifiable
// boards — we link out to live searches rather than inventing listings,
// employers, salaries, or availability.
const indiaJobBoards = [
  { name: 'Naukri.com — Mechanical Engineering', url: 'https://www.naukri.com/mechanical-engineer-jobs', description: "India's largest job portal — thousands of ME/CAD/simulation roles across Bengaluru, Pune, Chennai, Hyderabad, Gurugram and more" },
  { name: 'LinkedIn Jobs — India', url: 'https://www.linkedin.com/jobs/search/?geoRegion=102713980&keywords=mechanical%20engineer', description: 'LinkedIn filtered to India — strong for product design, CAE and R&D roles at OEMs and startups' },
  { name: 'Indeed — India', url: 'https://www.indeed.co.in/mechanical-engineer-jobs', description: 'Aggregated India listings across automotive, aerospace, manufacturing and HVAC' },
  { name: 'Foundit (Monster India)', url: 'https://www.foundit.in/monster/job-search?query=mechanical-engineer', description: 'Formerly Monster India — broad engineering and manufacturing coverage' },
  { name: 'Shine.com — Engineering', url: 'https://www.shine.com/job-search/mechanical-engineer-jobs', description: 'Indian board with CAD, PLM and design-engineer listings' },
  { name: 'Government Jobs — UPSC / DRDO / ISRO', url: 'https://www.govtjobs.com/engineering-jobs', description: 'Public-sector engineering recruitment (DRDO, ISRO, BHEL, BEL, NPCIL) — check official portals for current notifications' },
];

// Real Indian salary research platforms. We do not publish salary numbers —
// we point visitors to live, verifiable sources so they can look up current
// ranges for their role, city and experience level.
const indiaSalaryResources = [
  { name: 'AmbitionBox — Engineering Salaries', url: 'https://www.ambitionbox.com/profile/mechanical-engineer-salary', description: 'India-specific company reviews and salary ranges by role, city and experience' },
  { name: 'Glassdoor — India Salaries', url: 'https://www.glassdoor.co.in/Salaries/mechanical-engineer-salary-SRCH_KO0,20.htm', description: 'Self-reported Indian salaries with company and location filters' },
  { name: 'Levels.fyi — Software & Hardware', url: 'https://www.levels.fyi/t/software-engineer/locations/india', description: 'Verified compensation for software, hardware and DevOps roles in India' },
  { name: 'Payscale — India', url: 'https://www.payscale.com/research/IN/Job=Mechanical_Engineer/Salary', description: 'Median pay by experience level for Indian mechanical engineers' },
];

// Indicative India CTC bands (₹ LPA) synthesised from public self-reported
// aggregates (AmbitionBox, Glassdoor India, Payscale India). Not offers —
// always verify live on those sources for your city, industry and employer.
const indiaSalaryBands = [
  { role: 'Entry-level ME (0–2 yrs)', range: '≈ ₹3–7 LPA' },
  { role: 'Mid-level (3–7 yrs)', range: '≈ ₹7–15 LPA' },
  { role: 'Senior Engineer', range: '≈ ₹12–25 LPA' },
  { role: 'Lead / Principal', range: '≈ ₹20–40 LPA' },
  { role: 'Engineering Manager', range: '≈ ₹18–45 LPA' },
];

// Reputable India education & training pathways — resources, not endorsements.
// type: free | paid | certification | degree
const indiaEducationResources = [
  {
    name: 'NPTEL (IIT / IISc)',
    url: 'https://nptel.ac.in/',
    type: 'free',
    disciplines: 'ME, CAD/CAM, FEA, manufacturing, thermal, control',
    note: 'Free university-level video courses; optional paid certification exams',
  },
  {
    name: 'SWAYAM',
    url: 'https://swayam.gov.in/',
    type: 'free',
    disciplines: 'Engineering degrees & electives across AICTE disciplines',
    note: 'Govt of India MOOC platform — free learning, optional certificates',
  },
  {
    name: 'IITs / NITs / IIITs (B.Tech / M.Tech)',
    url: 'https://www.education.gov.in/en/higher-education',
    type: 'degree',
    disciplines: 'Mechanical, aerospace, production, mechatronics, CS',
    note: 'Premier public engineering degrees via JEE / GATE admissions',
  },
  {
    name: 'IISc Bangalore',
    url: 'https://www.iisc.ac.in/',
    type: 'degree',
    disciplines: 'Research M.Tech / Ph.D. in mechanical & interdisciplinary eng.',
    note: 'Research-focused postgraduate and doctoral programmes',
  },
  {
    name: 'GATE (IIT)',
    url: 'https://gate.iitkgp.ac.in/',
    type: 'certification',
    disciplines: 'ME, AE, XE, PI and related papers',
    note: 'National exam for M.Tech / PSU recruitment pathways',
  },
  {
    name: 'Autodesk Learning & Certification',
    url: 'https://www.autodesk.com/certification',
    type: 'certification',
    disciplines: 'AutoCAD, Inventor, Fusion 360, CFD',
    note: 'Vendor certifications — free learning content + paid exams',
  },
  {
    name: 'Dassault Systèmes / SOLIDWORKS Education',
    url: 'https://www.solidworks.com/support/academic-resource-center',
    type: 'paid',
    disciplines: 'SOLIDWORKS, CATIA, SIMULIA (FEA)',
    note: 'Academic & professional CAD/CAE training paths from the vendor',
  },
  {
    name: 'Coursera — Engineering',
    url: 'https://www.coursera.org/browse/physical-science-and-engineering',
    type: 'paid',
    disciplines: 'CAD, robotics, ML for engineers, project management',
    note: 'University-partnered courses; audit free, certificates paid',
  },
  {
    name: 'edX — Engineering & MIT OCW',
    url: 'https://www.edx.org/learn/engineering',
    type: 'free',
    disciplines: 'Mechanics, materials, systems engineering',
    note: 'Free audit options; verified certificates are paid',
  },
  {
    name: 'Skill India / NCVET',
    url: 'https://www.skillindia.gov.in/',
    type: 'certification',
    disciplines: 'Manufacturing, CNC, welding, industrial skills',
    note: 'Govt skill programmes and recognised vocational certifications',
  },
];

const eduTypeStyles = {
  free: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400',
  paid: 'border-amber-500/30 bg-amber-500/10 text-amber-400',
  certification: 'border-primary/30 bg-primary/10 text-primary',
  degree: 'border-violet-500/30 bg-violet-500/10 text-violet-300',
};

const indiaHubs = [
  'Bengaluru', 'Pune', 'Chennai', 'Hyderabad', 'Gurugram', 'Noida',
  'Mumbai', 'Ahmedabad', 'Coimbatore', 'Remote (India)',
];

// Role-specific quick-search links that drop the user straight onto a live,
// verifiable India-filtered results page on a real board. We link to searches,
// never to fabricated individual listings.
const indiaRoleSearches = [
  { role: 'Mechanical Design Engineer', naukri: 'https://www.naukri.com/design-engineer-jobs', linkedin: 'https://www.linkedin.com/jobs/search/?geoRegion=102713980&keywords=mechanical%20design%20engineer' },
  { role: 'CAD Engineer (SOLIDWORKS / Creo)', naukri: 'https://www.naukri.com/cad-engineer-jobs', linkedin: 'https://www.linkedin.com/jobs/search/?geoRegion=102713980&keywords=CAD%20engineer%20solidworks' },
  { role: 'CAE / FEA Engineer', naukri: 'https://www.naukri.com/cae-engineer-jobs', linkedin: 'https://www.linkedin.com/jobs/search/?geoRegion=102713980&keywords=FEA%20CAE%20engineer' },
  { role: 'CFD Engineer', naukri: 'https://www.naukri.com/cfd-engineer-jobs', linkedin: 'https://www.linkedin.com/jobs/search/?geoRegion=102713980&keywords=CFD%20engineer' },
  { role: 'Automation / Robotics Engineer', naukri: 'https://www.naukri.com/automation-engineer-jobs', linkedin: 'https://www.linkedin.com/jobs/search/?geoRegion=102713980&keywords=automation%20robotics%20engineer' },
  { role: 'Manufacturing / Production Engineer', naukri: 'https://www.naukri.com/production-engineer-jobs', linkedin: 'https://www.linkedin.com/jobs/search/?geoRegion=102713980&keywords=manufacturing%20production%20engineer' },
  { role: 'PLM / Teamcenter Consultant', naukri: 'https://www.naukri.com/plm-engineer-jobs', linkedin: 'https://www.linkedin.com/jobs/search/?geoRegion=102713980&keywords=PLM%20Teamcenter' },
  { role: 'Software / DevOps Engineer', naukri: 'https://www.naukri.com/software-engineer-jobs', linkedin: 'https://www.linkedin.com/jobs/search/?geoRegion=102713980&keywords=software%20engineer' },
];

function JobCard({ job }) {
  return (
    <div className={`flex flex-col rounded-xl border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 ${job.featured ? 'border-primary/20 bg-primary/[0.03]' : 'border-border'}`}>
      {job.featured && (
        <div className="mb-3 flex items-center gap-1.5">
          <span className="rounded-full bg-accent/15 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-accent">Featured</span>
        </div>
      )}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-display text-lg font-bold leading-snug">{job.title}</h3>
          <div className="mt-1 flex flex-wrap items-center gap-3 font-mono text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><Building2 className="h-3 w-3" />{job.company}</span>
            <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{job.location}</span>
            <span className="flex items-center gap-1"><Clock className="h-3 w-3" />Curated · verify on source</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1.5">
          <span className={`rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider badge-${job.category}`}>
            {categoryOptions.find(c => c.id === job.category)?.label || job.category}
          </span>
          {job.salary && (
            <span className="flex items-center gap-1 font-mono text-xs text-green-400">
              <DollarSign className="h-3 w-3" />{job.salary}
            </span>
          )}
        </div>
      </div>

      <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{job.description}</p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {job.tags.map(tag => (
          <Link key={tag} to={`/tools?q=${encodeURIComponent(tag)}`} className="rounded-full border border-border bg-muted/40 px-2.5 py-0.5 font-mono text-[10px] text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary">
            {tag}
          </Link>
        ))}
      </div>

      <div className="mt-4 flex items-center justify-between">
        <span className={`rounded-full border px-3 py-0.5 font-mono text-[10px] ${
          job.type === 'Full-time' ? 'border-blue-500/30 text-blue-400' : 'border-border text-muted-foreground'
        }`}>{job.type}</span>
        <a
          href={job.url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
        >
          Apply Now <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>
    </div>
  );
}

export default function JobsPage() {
  const [searchParams] = useSearchParams();
  const [query, setQuery] = useState('');
  const [activeCat, setActiveCat] = useState('all');
  const [region, setRegion] = useState(() => searchParams.get('region') === 'india' ? 'india' : 'all'); // 'all' | 'remote' | 'india'

  const filtered = useMemo(() => {
    let list = jobListings;
    if (activeCat !== 'all') list = list.filter(j => j.category === activeCat);
    // "Remote" filters the existing curated listings by their stated location —
    // we do not invent remote roles, only surface ones already marked Remote.
    if (region === 'remote') list = list.filter(j => /remote/i.test(j.location));
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(j =>
        j.title.toLowerCase().includes(q) ||
        j.company.toLowerCase().includes(q) ||
        j.location.toLowerCase().includes(q) ||
        j.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    return list;
  }, [activeCat, region, query]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Jobs — India & Global Mechanical, CAD, Simulation & AI Careers | MechEngi 10X</title>
        <meta name="description" content="Find engineering jobs in India and worldwide. Browse curated mechanical, CAD, simulation, automation and AI roles, plus India job boards (Naukri, LinkedIn India, Indeed India) and role-specific quick searches." />
      </Helmet>

      <SiteHeader />

      {/* Header */}
      <div className="relative border-b border-border bg-card/30 py-14">
        <div className="pointer-events-none absolute inset-0 opacity-30">
          <div className="dot-grid h-full w-full" />
        </div>
        <div className="relative mx-auto max-w-[72rem] px-5">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Briefcase className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Career Opportunities</p>
          </div>
          <h1 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Engineering Jobs</h1>
          <p className="mt-2 text-muted-foreground max-w-xl">
            Curated job listings for mechanical, simulation, CAD, automation and AI engineers — plus dedicated India job search across Naukri, LinkedIn India and more.
          </p>
          <p className="mt-1 font-mono text-[11px] text-muted-foreground/80">
            The global listings below are curated examples drawn from public company career pages to illustrate typical role types, employers, and skill demands — they are not live vacancies and may be filled, expired, or removed. Always open the source career page to confirm the role is current before applying. India results open live searches on real boards.
          </p>

          {/* Search */}
          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center max-w-2xl">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search jobs by title, company, or skill…"
                className="h-11 w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          </div>

          {/* Category filter */}
          <div className="mt-4 flex flex-wrap gap-2">
            {categoryOptions.map(c => (
              <button
                key={c.id}
                onClick={() => setActiveCat(c.id)}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                  activeCat === c.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>

          {/* Region tabs — prominent Global / India / Remote switcher */}
          <div className="mt-6">
            <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">Job region</p>
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'all', label: 'Global Jobs', sub: 'Curated worldwide listings', icon: Globe },
                { id: 'india', label: 'India Jobs', sub: 'Naukri, LinkedIn India & more', icon: IndianRupee },
                { id: 'remote', label: 'Remote', sub: 'Work-from-anywhere roles', icon: Globe },
              ].map(r => {
                const Icon = r.icon;
                const active = region === r.id;
                return (
                  <button
                    key={r.id}
                    onClick={() => setRegion(r.id)}
                    className={`flex items-center gap-2.5 rounded-xl border px-4 py-2.5 text-left transition-all active:scale-[0.98] ${
                      active
                        ? 'border-primary bg-primary/10 text-primary shadow-lg shadow-primary/10'
                        : 'border-border bg-card text-muted-foreground hover:border-primary/30 hover:text-foreground'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="flex flex-col">
                      <span className="font-display text-sm font-bold leading-tight">{r.label}</span>
                      <span className="font-mono text-[10px] leading-tight opacity-80">{r.sub}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          {/* Job listings / India discovery */}
          <div>
            {region === 'india' ? (
              <div className="space-y-6">
                <div className="rounded-2xl border border-primary/20 bg-primary/5 p-5">
                  <div className="flex items-center gap-2">
                    <IndianRupee className="h-5 w-5 text-primary" />
                    <h2 className="font-display text-lg font-bold">Engineering jobs in India</h2>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    We don&rsquo;t host India-specific job listings directly. Instead, here are the
                    main platforms Indian mechanical, CAD, simulation and automation engineers use to
                    find roles &mdash; tap any to run a live search. Always verify the posting on the
                    source board before applying.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {indiaHubs.map(h => (
                      <span key={h} className="rounded-full border border-border bg-muted/40 px-3 py-1 font-mono text-[10px] text-muted-foreground">
                        <MapPin className="mr-1 inline h-3 w-3" />{h}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Role-specific quick search — drops user onto live India results */}
                <div className="rounded-2xl border border-border bg-card p-5">
                  <div className="flex items-center gap-2">
                    <Search className="h-4 w-4 text-primary" />
                    <h3 className="font-display font-semibold">Quick search by role</h3>
                  </div>
                  <p className="mt-1.5 text-xs text-muted-foreground">
                    Pick your role to open a live, India-filtered results page on Naukri or LinkedIn. Each link runs a real-time search on the source board.
                  </p>
                  <div className="mt-4 flex flex-col gap-2.5">
                    {indiaRoleSearches.map(r => (
                      <div key={r.role} className="flex flex-col gap-2 rounded-lg border border-border p-3 sm:flex-row sm:items-center sm:justify-between">
                        <span className="text-sm font-medium">{r.role}</span>
                        <div className="flex flex-wrap gap-2">
                          <a
                            href={r.naukri}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1.5 rounded-lg border border-primary/30 bg-primary/5 px-3 py-1.5 font-mono text-[11px] text-primary transition-colors hover:bg-primary/10 active:scale-[0.98]"
                          >
                            Naukri <ExternalLink className="h-3 w-3" />
                          </a>
                          <a
                            href={r.linkedin}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 font-mono text-[11px] text-muted-foreground transition-colors hover:border-primary/30 hover:text-primary active:scale-[0.98]"
                          >
                            LinkedIn India <ExternalLink className="h-3 w-3" />
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  {indiaJobBoards.map(board => (
                    <a
                      key={board.name}
                      href={board.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group flex flex-col rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-display text-sm font-semibold group-hover:text-primary">{board.name}</p>
                        <ExternalLink className="h-3.5 w-3.5 shrink-0 text-primary opacity-60 group-hover:opacity-100" />
                      </div>
                      <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{board.description}</p>
                    </a>
                  ))}
                </div>

                <div className="rounded-2xl border border-border bg-card p-5">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-accent" />
                    <h3 className="font-display font-semibold">Research Indian engineering salaries</h3>
                  </div>
                  <p className="mt-1.5 text-xs text-muted-foreground">
                    Salary ranges in India vary widely by city, industry and experience &mdash; we don&rsquo;t
                    publish numbers here. Use these live sources to look up current pay for your role:
                  </p>
                  <div className="mt-4 flex flex-col gap-3">
                    {indiaSalaryResources.map(r => (
                      <a
                        key={r.name}
                        href={r.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group flex items-start gap-3 rounded-lg border border-border p-3 transition-all hover:border-primary/30 hover:bg-primary/5"
                      >
                        <ExternalLink className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary opacity-60 group-hover:opacity-100" />
                        <div>
                          <p className="text-sm font-medium group-hover:text-primary">{r.name}</p>
                          <p className="mt-0.5 text-xs text-muted-foreground">{r.description}</p>
                        </div>
                      </a>
                    ))}
                  </div>
                </div>

                <p className="font-mono text-[11px] text-muted-foreground">
                  India salary note: compensation is typically quoted in INR per annum (CTC including
                  variable pay and bonuses). Cost of living differs sharply between metros and Tier-2
                  cities &mdash; compare CTC against take-home pay, not headline figures.
                </p>
              </div>
            ) : (
              <>
                {/* Curated-listings disclaimer */}
                <div className="mb-5 flex items-start gap-2.5 rounded-xl border border-amber-500/25 bg-amber-500/5 px-4 py-3">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    <span className="font-semibold text-foreground">Curated examples, not live vacancies.</span> These
                    listings illustrate typical engineering roles and employers; they may be filled, expired, or no
                    longer posted. Posting dates are not shown because we cannot verify them — open the source career
                    page to confirm the role is currently open.
                  </p>
                </div>
                {/* India quick-access banner — visible on Global & Remote views */}
                <button
                  onClick={() => { setRegion('india'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="mb-5 flex w-full items-center gap-3 rounded-xl border border-primary/20 bg-primary/[0.04] p-4 text-left transition-all hover:border-primary/40 hover:bg-primary/[0.07] active:scale-[0.99]"
                >
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/15">
                    <IndianRupee className="h-5 w-5 text-primary" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-display text-sm font-bold text-foreground">Looking for engineering jobs in India?</span>
                    <span className="mt-0.5 block text-xs text-muted-foreground">Search Naukri, LinkedIn India, Indeed India, Foundit, Shine &amp; government portals — plus role-specific quick searches and salary research.</span>
                  </span>
                  <span className="hidden shrink-0 items-center gap-1 rounded-lg bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground sm:flex">
                    View India Jobs <ArrowRight className="h-3.5 w-3.5" />
                  </span>
                </button>
                <p className="mb-5 font-mono text-xs text-muted-foreground">
                  {filtered.length} position{filtered.length !== 1 ? 's' : ''} found
                  {region === 'remote' && <span className="ml-1 text-primary">· remote only</span>}
                </p>
                {filtered.length > 0 ? (
                  <div className="flex flex-col gap-4">
                    {filtered.map(job => <JobCard key={job.id} job={job} />)}
                  </div>
                ) : (
                  <div className="rounded-xl border border-border py-20 text-center">
                    <p className="font-display text-xl font-semibold">No jobs match your search</p>
                    <p className="mt-2 text-muted-foreground">Try adjusting the filters or search terms.</p>
                    <button
                      onClick={() => { setQuery(''); setActiveCat('all'); setRegion('all'); }}
                      className="mt-4 rounded-xl bg-primary px-6 py-2 font-medium text-primary-foreground"
                    >
                      Clear filters
                    </button>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-5">
            {/* Job boards */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Top Engineering Job Boards</h3>
              <p className="mt-1.5 text-xs text-muted-foreground">Search thousands more listings on these platforms:</p>
              <div className="mt-4 flex flex-col gap-3">
                {jobBoards.map(board => (
                  <a
                    key={board.name}
                    href={board.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-start gap-3 rounded-lg border border-border p-3 transition-all hover:border-primary/30 hover:bg-primary/5"
                  >
                    <ExternalLink className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary opacity-60 group-hover:opacity-100" />
                    <div>
                      <p className="text-sm font-medium group-hover:text-primary">{board.name}</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">{board.description}</p>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {/* India job boards */}
            <div className="rounded-2xl border border-primary/20 bg-primary/[0.03] p-5">
              <div className="flex items-center gap-2">
                <IndianRupee className="h-4 w-4 text-primary" />
                <h3 className="font-display font-semibold">India Job Boards</h3>
              </div>
              <p className="mt-1.5 text-xs text-muted-foreground">Looking for roles in India? Search these platforms:</p>
              <div className="mt-4 flex flex-col gap-2.5">
                {indiaJobBoards.slice(0, 4).map(board => (
                  <a
                    key={board.name}
                    href={board.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-start gap-2.5 rounded-lg border border-border bg-card p-2.5 transition-all hover:border-primary/30"
                  >
                    <ExternalLink className="mt-0.5 h-3 w-3 shrink-0 text-primary opacity-60 group-hover:opacity-100" />
                    <p className="text-xs font-medium group-hover:text-primary">{board.name}</p>
                  </a>
                ))}
                <button
                  onClick={() => { setRegion('india'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="mt-1 rounded-lg border border-primary/30 bg-primary/5 px-3 py-2 text-center font-mono text-[11px] text-primary hover:bg-primary/10"
                >
                  View all India resources →
                </button>
              </div>
            </div>

            {/* Salary guide — US */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">US Engineering Salary Ranges</h3>
              <div className="mt-4 space-y-3">
                {[
                  { role: 'Entry-level ME', range: '$65k–$85k' },
                  { role: 'Mid-level (3–7 yrs)', range: '$90k–$125k' },
                  { role: 'Senior Engineer', range: '$120k–$165k' },
                  { role: 'Principal Engineer', range: '$155k–$210k' },
                  { role: 'Engineering Manager', range: '$140k–$200k' },
                ].map(s => (
                  <div key={s.role} className="flex items-center justify-between gap-3 border-b border-border pb-2.5 last:border-0 last:pb-0">
                    <span className="min-w-0 text-sm text-muted-foreground">{s.role}</span>
                    <span className="shrink-0 font-mono text-xs font-semibold text-green-400">{s.range}</span>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[10px] leading-relaxed text-muted-foreground">US national median ranges. Varies significantly by location, industry, and company size.</p>
            </div>

            {/* Salary guide — India */}
            <div className="rounded-2xl border border-primary/20 bg-primary/[0.03] p-5">
              <div className="flex items-center gap-2">
                <IndianRupee className="h-4 w-4 shrink-0 text-primary" />
                <h3 className="font-display font-semibold">India Engineering Salary Ranges (CTC)</h3>
              </div>
              <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
                Indicative annual CTC bands in ₹ lakhs per annum (LPA), drawn from public self-reported
                aggregates on AmbitionBox, Glassdoor India and Payscale. Not job offers — confirm live
                figures for your city, role and employer.
              </p>
              <div className="mt-4 space-y-3">
                {indiaSalaryBands.map(s => (
                  <div key={s.role} className="flex items-center justify-between gap-3 border-b border-border pb-2.5 last:border-0 last:pb-0">
                    <span className="min-w-0 text-sm text-muted-foreground">{s.role}</span>
                    <span className="shrink-0 font-mono text-xs font-semibold text-green-400">{s.range}</span>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[10px] leading-relaxed text-muted-foreground">
                Compensation varies widely by city (e.g. Bengaluru / Pune / Chennai vs smaller hubs),
                experience, industry (auto, aerospace, core manufacturing, product/tech), employer type
                (MNC, PSU, startup) and role (design, CAE, manufacturing, software). CTC often includes
                benefits and variable pay. Software / AI roles in India typically sit higher than core ME
                bands — check Levels.fyi and AmbitionBox for those tracks.
              </p>
              <div className="mt-3 flex flex-col gap-1.5">
                {indiaSalaryResources.map(r => (
                  <a
                    key={r.name}
                    href={r.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center gap-1.5 font-mono text-[10px] text-primary hover:underline"
                  >
                    <ExternalLink className="h-2.5 w-2.5 shrink-0 opacity-70" />
                    <span className="truncate">{r.name}</span>
                  </a>
                ))}
              </div>
            </div>

            {/* India education & training */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-center gap-2">
                <Building2 className="h-4 w-4 shrink-0 text-accent" />
                <h3 className="font-display font-semibold">India Education &amp; Training</h3>
              </div>
              <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
                Reputable pathways for mechanical, CAD/CAE, manufacturing and software engineers in India.
                Listed as resources only — not endorsements. Labels mark free learning, paid programmes,
                certifications and degree routes.
              </p>
              <div className="mt-4 flex flex-col gap-3">
                {indiaEducationResources.map(item => (
                  <a
                    key={item.name}
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group block rounded-xl border border-border bg-muted/20 p-3 transition-all hover:border-primary/35 hover:bg-primary/[0.04]"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <p className="text-sm font-medium leading-snug group-hover:text-primary">{item.name}</p>
                      <span className={`shrink-0 rounded-full border px-2 py-0.5 font-mono text-[9px] uppercase tracking-wide ${eduTypeStyles[item.type]}`}>
                        {item.type}
                      </span>
                    </div>
                    <p className="mt-1.5 text-[11px] leading-relaxed text-muted-foreground">{item.disciplines}</p>
                    <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground/90">{item.note}</p>
                  </a>
                ))}
              </div>
              <p className="mt-3 text-[10px] leading-relaxed text-muted-foreground">
                Always verify fees, eligibility and current intake on the official site. Prefer free/open
                courses (NPTEL, SWAYAM, OCW) when budget-constrained; vendor certs help for CAD/CAE tools;
                degrees and GATE remain the main academic / PSU routes in India.
              </p>
            </div>

            {/* Skills in demand */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Most In-Demand Skills</h3>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {['ANSYS', 'SOLIDWORKS', 'Python', 'FEA', 'CFD', 'Fusion 360', 'GD&T', 'CATIA', 'OpenFOAM', 'ROS', 'Six Sigma', 'Agile', 'MATLAB', 'Machine Learning'].map(skill => (
                  <span key={skill} className="rounded-full border border-border bg-muted/40 px-3 py-1 font-mono text-[10px] text-muted-foreground">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
