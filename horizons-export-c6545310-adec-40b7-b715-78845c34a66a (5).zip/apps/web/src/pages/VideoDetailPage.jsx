import { Helmet } from 'react-helmet';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, PlayCircle, ArrowRight, FileText } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { getVideoBySlug, videos, youtubeSearchUrl } from '@/data/videos';

export default function VideoDetailPage() {
  const { slug } = useParams();
  const v = getVideoBySlug(slug);

  if (!v) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet><title>Video not found — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
        <SiteHeader />
        <div className="mx-auto max-w-md px-5 py-32 text-center">
          <h1 className="font-display text-2xl font-bold">Video not found</h1>
          <Link to="/videos" className="mt-4 inline-block text-primary hover:underline">← Back to videos</Link>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const related = videos.filter((x) => x.category === v.category && x.slug !== v.slug).slice(0, 4);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{v.title} — Engineering Video Topic | MechEngi 10X</title>
        <meta name="description" content={`Explore ${v.title}: an engineering topic outline and a YouTube search for related videos.`} />
        <meta name="robots" content="noindex, follow" />
        <link rel="canonical" href={`https://mechengi10x.com/videos/${v.slug}`} />
      </Helmet>

      <SiteHeader />

      <div className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="grid gap-10 lg:grid-cols-[1fr_20rem]">
          <div>
            <Link to="/videos" className="inline-flex items-center gap-1.5 font-mono text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-3.5 w-3.5" /> All videos
            </Link>

            {/* Poster player — opens the YouTube search for the topic */}
            <a
              href={youtubeSearchUrl(v.title)}
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-6 flex aspect-video items-center justify-center rounded-2xl border border-border bg-gradient-to-br from-secondary to-background transition-all hover:border-primary/40"
            >
              <div className="flex flex-col items-center gap-3">
                <PlayCircle className="h-16 w-16 text-primary/80 transition-transform group-hover:scale-110" />
                <span className="rounded-lg bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground">Search YouTube</span>
              </div>
            </a>

            <p className="mt-6 text-sm text-muted-foreground">This link opens search results, not a specific video. The outline below is not a verified transcript.</p>

            <h1 className="mt-4 font-display text-3xl font-bold leading-tight">{v.title}</h1>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{v.description}</p>

            {/* Transcript */}
            <div className="mt-8 rounded-2xl border border-border bg-card p-6">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                <h2 className="font-display text-lg font-semibold">Topic outline</h2>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{v.transcript}</p>
            </div>
          </div>

          {/* Sidebar — related videos */}
          <aside>
            <h3 className="font-display font-semibold">Related topics</h3>
            <div className="mt-4 flex flex-col gap-3">
              {related.map((r) => (
                <Link key={r.slug} to={`/videos/${r.slug}`} className="group flex gap-3 rounded-xl border border-border bg-card p-3 transition-colors hover:border-primary/40">
                  <PlayCircle className="mt-0.5 h-8 w-8 shrink-0 text-primary/60" />
                  <div className="min-w-0">
                    <p className="line-clamp-2 text-sm font-medium group-hover:text-primary">{r.title}</p>
                    <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Topic outline</p>
                  </div>
                </Link>
              ))}
            </div>
            <Link to="/courses" className="mt-6 flex items-center justify-between rounded-xl border border-primary/30 bg-primary/5 p-4 hover:border-primary/40">
              <span className="text-sm font-medium">Go deeper with a course</span>
              <ArrowRight className="h-4 w-4 text-primary" />
            </Link>
          </aside>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
