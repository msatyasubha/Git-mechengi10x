import { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useSearchParams } from 'react-router-dom';
import {
  Building2,
  Handshake,
  Send,
  Loader2,
  Check,
  ShieldCheck,
  Info,
  Users,
} from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import pb from '@/lib/pocketbaseClient';
import { tools, categoryLabel } from '@/data/tools';

const inputCls =
  'min-h-[44px] w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary';

function Field({ label, children }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}

// Heavy CAD / FEA / PLM categories where enterprise licensing and VAR channels
// are the normal purchasing route.
const ENTERPRISE_CATEGORIES = ['cad', 'simulation', 'management'];

const SEAT_OPTIONS = ['1–5 seats', '6–20 seats', '21–100 seats', '100+ seats', 'Not sure yet'];
const TIMELINE_OPTIONS = ['Immediate', 'This quarter', 'Next 2–6 months', 'Researching / budgeting'];

export default function EnterpriseQuotePage() {
  const [params] = useSearchParams();
  const preselectedSlug = params.get('tool') || '';

  const enterpriseTools = useMemo(
    () => tools.filter((t) => ENTERPRISE_CATEGORIES.includes(t.category)),
    [],
  );
  const preselected = enterpriseTools.find((t) => t.slug === preselectedSlug) || null;

  const [form, setForm] = useState({
    company_name: '',
    contact_name: '',
    email: '',
    phone: '',
    tool_slug: preselected?.slug || '',
    seats: SEAT_OPTIONS[0],
    timeline: TIMELINE_OPTIONS[0],
    message: '',
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const selectedTool = enterpriseTools.find((t) => t.slug === form.tool_slug) || null;

  const onSubmit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await pb.collection('enterprise_quote_inquiries').create({
        ...form,
        tool_name: selectedTool?.name || '',
      });
      setDone(true);
    } catch (err) {
      setError(err?.response?.message || err?.message || 'Submission failed. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Request an Enterprise CAD / FEA Quote or VAR Introduction | MechEngi 10X</title>
        <meta
          name="description"
          content="Request enterprise pricing, multi-seat licensing, or a value-added reseller (VAR) introduction for heavy CAD, FEA, and PLM tools through MechEngi 10X. Our team routes your request to the right sales channel."
        />
      </Helmet>

      <SiteHeader />

      {/* Hero */}
      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-16 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Building2 className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">B2B Licensing Assistance</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            Request an enterprise quote or <span className="text-primary">VAR introduction</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            Multi-seat CAD, FEA, and PLM licensing is rarely a checkout button. Tell us what you are equipping and we
            will route your request to the right channel — the vendor's enterprise sales team or a value-added
            reseller where that is the normal purchasing route.
          </p>

          <div className="mx-auto mt-10 flex max-w-2xl items-start justify-center gap-3 rounded-xl border border-amber-500/30 bg-amber-500/5 px-5 py-3 text-left">
            <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
            <p className="text-sm leading-relaxed text-muted-foreground">
              <span className="font-semibold text-foreground">Honest status:</span> this is a request-routing service
              operated by our small team. We are not a software reseller, we do not hold exclusive vendor
              partnerships, we have no completed enterprise sales to point to yet, and we cannot guarantee quote
              outcomes, pricing, or response times from vendors. We do not publish lead values or revenue figures.
            </p>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-[90rem] px-5 py-14">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            {
              icon: Handshake,
              title: '1 · You submit the request',
              body: 'Company, tool, seat count, and timeline. No obligation, no cost, no credit card.',
            },
            {
              icon: Users,
              title: '2 · We route it',
              body: 'We identify the right channel for your region and stack — direct enterprise sales or a VAR — and forward your request.',
            },
            {
              icon: Info,
              title: '3 · You deal directly',
              body: 'Pricing, negotiation, and the contract stay between you and the vendor or reseller. We are an introduction, not a broker.',
            },
          ].map((s) => (
            <div key={s.title} className="rounded-2xl border border-border bg-card p-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                <s.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Form */}
      <section className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-16">
          <div className="mx-auto mb-10 max-w-2xl text-center">
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Enterprise request</p>
            <h2 className="mt-2 font-display text-3xl font-bold">Tell us what you are equipping</h2>
            <p className="mt-4 text-lg leading-relaxed text-foreground/90">
              One form, routed by our team. We'll confirm where your request was sent as soon as we can.
            </p>
          </div>

          <div className="mx-auto max-w-2xl">
            {done ? (
              <div className="rounded-2xl border border-border bg-card p-8 text-center">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
                  <Check className="h-7 w-7 text-primary" />
                </div>
                <h3 className="mt-5 font-display text-xl font-bold">Enterprise request received</h3>
                <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  Thanks, {form.contact_name || 'there'}. Our team will review your request and reply to{' '}
                  <span className="text-foreground">{form.email}</span> to confirm where it was
                  routed. Pricing and contracting will happen directly between you and the vendor or reseller.
                </p>
                <div className="mt-6 flex flex-wrap justify-center gap-3">
                  <Link to="/tools" className="rounded-xl border border-border px-5 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">
                    Back to the tools directory
                  </Link>
                  <Link to="/stack-consulting" className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
                    Explore stack consulting
                  </Link>
                </div>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 sm:p-8">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="Company name *">
                    <input required value={form.company_name} onChange={set('company_name')} className={inputCls} />
                  </Field>
                  <Field label="Contact name *">
                    <input required value={form.contact_name} onChange={set('contact_name')} className={inputCls} />
                  </Field>
                  <Field label="Work email *">
                    <input required type="email" value={form.email} onChange={set('email')} className={inputCls} />
                  </Field>
                  <Field label="Phone">
                    <input value={form.phone} onChange={set('phone')} className={inputCls} />
                  </Field>
                </div>

                <div className="mt-4">
                  <Field label="Tool you are quoting *">
                    <select required value={form.tool_slug} onChange={set('tool_slug')} className={inputCls}>
                      <option value="">Select a tool…</option>
                      {['cad', 'simulation', 'management'].map((cat) => (
                        <optgroup key={cat} label={categoryLabel[cat]}>
                          {enterpriseTools
                            .filter((t) => t.category === cat)
                            .map((t) => (
                              <option key={t.slug} value={t.slug}>{t.name}</option>
                            ))}
                        </optgroup>
                      ))}
                      <optgroup label="Other">
                        <option value="other-or-multi">Other / multiple tools — describe below</option>
                      </optgroup>
                    </select>
                  </Field>
                </div>

                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <Field label="Approximate seats">
                    <select value={form.seats} onChange={set('seats')} className={inputCls}>
                      {SEAT_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </Field>
                  <Field label="Purchase timeline">
                    <select value={form.timeline} onChange={set('timeline')} className={inputCls}>
                      {TIMELINE_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
                    </select>
                  </Field>
                </div>

                <div className="mt-4">
                  <Field label="Anything else we should know?">
                    <textarea
                      rows={4}
                      value={form.message}
                      onChange={set('message')}
                      placeholder="Existing licenses, integrations, training needs, procurement constraints, preferred region…"
                      className={`${inputCls} resize-none`}
                    />
                  </Field>
                </div>

                {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

                <button
                  type="submit"
                  disabled={busy}
                  className="glow-primary mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60"
                >
                  {busy ? <><Loader2 className="h-4 w-4 animate-spin" /> Sending…</> : <><Send className="h-4 w-4" /> Request enterprise quote / VAR introduction</>}
                </button>
                <p className="mt-3 text-center font-mono text-[10px] text-muted-foreground">
                  Free, no-obligation request routed by our team. We are not a reseller and guarantee no pricing or outcomes.
                </p>
              </form>
            )}
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
