import { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import pb from '@/lib/pocketbaseClient';
import HomeHero from '@/components/home/HomeHero';
import HomeAdvisorQuiz from '@/components/home/HomeAdvisorQuiz';
import HomeCategoryShowcase from '@/components/home/HomeCategoryShowcase';
import HomeUseCases from '@/components/home/HomeUseCases';
import HomeAIToolsCTA from '@/components/home/HomeAIToolsCTA';
import HomeEmergingTools from '@/components/home/HomeEmergingTools';
import HomeTrendingTools from '@/components/home/HomeTrendingTools';
import HomeFeaturedTools from '@/components/home/HomeFeaturedTools';
import HomeTrust from '@/components/home/HomeTrust';
import HomeVerificationStatus from '@/components/home/HomeVerificationStatus';
import HomeDecisionExample from '@/components/home/HomeDecisionExample';
import HomeFreeTools from '@/components/home/HomeFreeTools';
import HomeAdvisorCTA from '@/components/home/HomeAdvisorCTA';
import HomeSpinWheelSection from '@/components/home/HomeSpinWheelSection';
import HomeJobsTeaser from '@/components/home/HomeJobsTeaser';
import HomeGuides from '@/components/home/HomeGuides';
import HomeFreeToolsTeaser from '@/components/home/HomeFreeToolsTeaser';
import HomeExploreMore from '@/components/home/HomeExploreMore';
import HomePhase3Section from '@/components/home/HomePhase3Section';
import HomeNewsletter from '@/components/home/HomeNewsletter';

export default function HomePage() {
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) {
      localStorage.setItem('mechengi_ref_code', ref);
      pb.collection('affiliate_clicks')
        .create({ referral_code: ref, source: 'homepage' })
        .catch(() => {});
    }
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Engineering Software & AI Tools: Compare CAD, FEA & More | MechEngi 10X</title>
        <meta
          name="description"
          content="Explore engineering software across CAD, simulation, AI and automation. Compare tools, browse practical workflows and see our transparent evaluation framework."
        />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebSite',
          name: 'MechEngi 10X',
          url: 'https://mechengi10x.com',
          description: 'Independent AI and engineering tool discovery platform for mechanical engineers.',
          potentialAction: {
            '@type': 'SearchAction',
            target: 'https://mechengi10x.com/tools?q={search_term_string}',
            'query-input': 'required name=search_term_string',
          },
        }) }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'Organization',
          name: 'MechEngi 10X',
          url: 'https://mechengi10x.com',
          email: 'hello@mechengi10x.com',
          description: 'Independent engineering tool discovery and review platform built by engineers, for engineers.',
          sameAs: [],
        }) }} />
      </Helmet>

      <SiteHeader />

      <HomeHero />
      <HomeAdvisorQuiz />
      <HomeCategoryShowcase />
      <HomeUseCases />
      <HomeAIToolsCTA />
      <HomeEmergingTools />
      <HomeTrendingTools />
      <HomeFeaturedTools />
      <HomeTrust />
      <HomeVerificationStatus />
      <HomeDecisionExample />
      <HomeFreeTools />
      <HomeAdvisorCTA />
      <HomeSpinWheelSection />
      <HomeJobsTeaser />
      <HomeGuides />
      <HomeFreeToolsTeaser />
      <HomeExploreMore />
      <HomePhase3Section />
      <HomeNewsletter />

      <SiteFooter />
    </div>
  );
}
