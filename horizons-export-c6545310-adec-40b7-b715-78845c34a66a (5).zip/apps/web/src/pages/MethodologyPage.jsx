import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import {
  Target,
  Microscope,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Mail,
} from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { SCORE_CATEGORIES, SCORE_TOTAL } from '@/data/methodology';

const SECTIONS = [
  {
    icon: Target,
    title: 'Selection & Benchmarking',
    body: 'How we select mechanical engineering tools, CAD suites, and simulation software for review. We start from real engineering workflows — product design, FEA sign-off, CFD, automation, and CAD-to-ERP handoff — and shortlist tools that practitioners actually deploy, including free and open-source options. Selection is independent of affiliate relationships; a tool earns a review on engineering merit, not on commission.',
    points: [
      'Workflow-first shortlist, not vendor marketing',
      'Free and open-source tools evaluated alongside commercial ones',
      'Category coverage across AI, CAD, simulation, automation, management, and learning',
    ],
  },
  {
    icon: Microscope,
    title: 'Technical Evaluation Criteria',
    body: 'Our technical bar is format interoperability and API flexibility. We verify neutral-format support (STEP, IGES, Parasolid, DXF/DWG), document the scripting surface (SOLIDWORKS VBA, C#, Python, REST APIs, FeatureScript), and assess rule-matrix QA performance. Where we have not run a hands-on benchmark, we say so; the shop-floor benchmark framework is published but no comparative results are claimed.',
    points: [
      'Format interoperability: STEP, IGES, Parasolid, DXF, DWG',
      'API flexibility: SOLIDWORKS VBA, C#, Python, REST APIs, n8n webhooks',
      'Rule-matrix QA: can the tool be driven and validated by rules?',
    ],
  },
  {
    icon: ShieldCheck,
    title: 'Editorial Independence',
    body: 'Our reviews are unbiased. Affiliate links may earn us a commission at no extra cost to you, but that relationship never moves a tool\u2019s MechEngi Score, rating, or ranking. Scores are derived from the eight criteria below and from documented vendor capabilities — never from sponsorship. Sponsored placements are always labelled, and sponsorship never buys a score change.',
    points: [
      'Scores are independent of affiliate relationships',
      'Sponsored content is always disclosed and labelled',
      'Affiliate disclosure is repeated in the site footer on every page',
    ],
  },
  {
    icon: AlertTriangle,
    title: 'Engineering Safety & Disclaimers',
    body: 'Engineering design verification has hard limits. Our calculators and reviews provide preliminary engineering estimates and capability assessments — they are not a substitute for certified analytical software or licensed professional engineering review. Final verification must be performed using certified tools and, where required, signed off by a licensed professional engineer. We never present a sample script as production-ready.',
    points: [
      'Calculators give preliminary estimates, not certified results',
      'Sample automation scripts are illustrative drafts, not production-ready',
      'Final sign-off requires certified software and licensed PE review',
    ],
  },
];

function CategoryCard({ c }) {
  return (
    <div className="flex flex-col rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/40">
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-display text-base font-bold leading-tight">{c.name}</h3>
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 font-mono text-xs font-bold text-primary">
          {c.max}
        </span>
      </div>
      <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-accent">{c.weight} · max {c.max} pts</p>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{c.summary}</p>
      <p className="mt-3 text-sm leading-relaxed text-foreground/80">{c.description}</p>
      <p className="mt-3 rounded-lg border border-border bg-muted/30 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
        <span className="font-semibold text-foreground">How it&rsquo;s verified: </span>
        {c.howVerified}
      </p>
    </div>
  );
}

function SectionCard({ s }) {
  const Icon = s.icon;
  return (
    <div className="flex flex-col overflow-hidden rounded-2xl border border-border bg-card">
      <div className="flex items-center gap-3 border-b border-border bg-secondary/60 px-6 py-4">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent/15 text-accent">
          <Icon className="h-5 w-5" />
        </span>
        <h3 className="font-display text-base font-bold text-foreground">{s.title}</h3>
      </div>
      <div className="flex flex-1 flex-col p-6">
        <p className="text-sm leading-relaxed text-muted-foreground">{s.body}</p>
        <ul className="mt-4 space-y-2">
          {s.points.map((p, i) => (
            <li key={i} className="flex items-start gap-2 text-sm">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <span className="text-foreground/85">{p}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default function MethodologyPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Our 100-Point Tool Evaluation Framework — MechEngi 10X</title>
        <meta
          name="description"
          content="Our 100-point MechEngi Score framework: eight weighted categories — Engineering Effectiveness, Reliability, API Extensibility, TCO, Security, Industry Adoption, UX, and Documentation — each with a documented verification method."
        />
      </Helmet>

      <SiteHeader />

      {/* Hero */}
      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 sm:py-20">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Microscope className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Editorial &amp; Engineering Standards</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-3xl font-bold leading-tight sm:text-4xl md:text-5xl">
            Our 100-Point Tool Evaluation Framework
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            Every tool is assessed across eight weighted categories that sum to {SCORE_TOTAL} points. The framework is
            published and transparent; the per-category scores are <span className="font-semibold text-foreground">not</span>{' '}
            displayed until documented, reproducible benchmark data exists. We do not invent partial scores.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#categories" className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]">
              The eight categories <ArrowRight className="h-4 w-4" />
            </a>
            <a href="#sections" className="inline-flex items-center gap-2 rounded-xl border border-border px-5 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">
              Methodology sections
            </a>
          </div>
        </div>
      </section>

      {/* Eight-point criteria */}
      <section id="categories" className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
        <div className="mb-10 max-w-2xl">
          <p className="font-mono text-xs uppercase tracking-wider text-primary">100-point framework</p>
          <h2 className="mt-2 font-display text-2xl font-bold sm:text-3xl">Eight weighted evaluation categories</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            Each category carries a fixed maximum weight. Together they total {SCORE_TOTAL} points. A summary card for
            each explains what it measures and exactly how the score is verified — or marked &ldquo;Not yet rated&rdquo;
            when evidence is absent.
          </p>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {SCORE_CATEGORIES.map((c) => (
            <CategoryCard key={c.id} c={c} />
          ))}
        </div>

        {/* Honest-state callout */}
        <div className="mt-8 flex items-start gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/5 px-6 py-5">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
          <p className="text-sm leading-relaxed text-muted-foreground">
            <span className="font-semibold text-foreground">No benchmark data published yet.</span> The framework above
            is live and transparent, but no tool has completed hands-on benchmark testing. Until documented results
            exist, every tool&rsquo;s score breakdown renders an explicit &ldquo;Not Yet Rated — Awaiting Benchmark
            Data&rdquo; state. We do not assign speculative numeric scores.
          </p>
        </div>
      </section>

      {/* Rating types & sources */}
      <section id="rating-sources" className="border-t border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
          <div className="mb-10 max-w-2xl">
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Rating transparency</p>
            <h2 className="mt-2 font-display text-2xl font-bold sm:text-3xl">How ratings are classified &amp; sourced</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              MechEngi 10X editorial ratings are based on our stated evaluation criteria. Industry mentions,
              third-party ratings, and verified user reviews are presented separately and never blended into a
              single &ldquo;score&rdquo; to imply more evidence than exists.
            </p>
          </div>
          <div className="overflow-hidden rounded-2xl border border-border">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Rating type</th>
                  <th className="hidden px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground sm:table-cell">What it means</th>
                  <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">How we present it</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { type: 'Editorial rating (MechEngi Score)', meaning: 'Our assessment against the 8-criteria framework', present: 'Shown only when benchmark-backed; otherwise &ldquo;Not Yet Rated&rdquo;' },
                  { type: 'Verified user review', meaning: 'Submitted by a signed-in user with a work email, passed moderation', present: 'Displayed separately on the tool page, clearly labelled &ldquo;community review&rdquo;' },
                  { type: 'Third-party rating', meaning: 'A rating originating from another platform', present: 'Never displayed as our own; attributed to its source or omitted' },
                  { type: 'Indexed industry mention', meaning: 'A tool appearing in industry lists, directories, or articles', present: 'Never presented as a customer review or endorsement' },
                ].map((row) => (
                  <tr key={row.type} className="border-b border-border last:border-0">
                    <td className="px-4 py-3.5 text-sm font-medium text-foreground">{row.type}</td>
                    <td className="hidden px-4 py-3.5 text-sm text-muted-foreground sm:table-cell">{row.meaning}</td>
                    <td className="px-4 py-3.5 text-sm text-muted-foreground">{row.present}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-6 rounded-2xl border border-border bg-card p-5">
            <h3 className="font-display text-base font-bold">Independence from commercial placements</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              Sponsored placements and affiliate links are always labelled (affiliate CTAs carry
              <code className="mx-1 rounded bg-muted px-1.5 py-0.5 font-mono text-xs">rel=&quot;sponsored&quot;</code>
              and a disclosure line). Sponsorship and affiliate relationships never move a MechEngi Score, ranking,
              or editorial recommendation. Editorial recommendations are generated independently of commercial
              placements. Ratings were last reviewed against this framework on the date shown on each tool page.
            </p>
          </div>
        </div>
      </section>

      {/* Current evidence status — honest scoreboard */}
      <section id="evidence-status" className="border-t border-border bg-card/20">
        <div className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
          <div className="mb-10 max-w-2xl">
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Live evidence status</p>
            <h2 className="mt-2 font-display text-2xl font-bold sm:text-3xl">Where the evidence actually stands today</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              We publish this scoreboard so readers can see exactly what is backed by evidence and what is still
              pending &mdash; rather than inferring credibility from confident-sounding copy. It is updated as work
              is completed.
            </p>
          </div>
          <div className="overflow-hidden rounded-2xl border border-border">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Claim type</th>
                  <th className="hidden px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground sm:table-cell">What it means</th>
                  <th className="px-4 py-3 text-left font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Status</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { claim: 'Evaluation framework (8 categories, 100 pts)', meaning: 'Public, weighted, reproducible', status: 'Published', tone: 'green' },
                  { claim: 'Tool directory entries (80+)', meaning: 'Vendor, category, pricing model, free-tier flag', status: 'Verified', tone: 'green' },
                  { claim: 'Vendor pricing figures', meaning: 'Recorded from vendor pages, dated, not live-verified', status: 'Recorded', tone: 'amber' },
                  { claim: 'Per-tool numeric MechEngi Scores', meaning: 'Awaiting hands-on benchmark data', status: 'Not yet rated', tone: 'amber' },
                  { claim: 'Hands-on benchmark results', meaning: 'No comparative results published', status: 'Not started', tone: 'muted' },
                  { claim: 'Peer-verified user reviews', meaning: 'Submissions collected & moderated; none verified yet', status: 'Pending', tone: 'amber' },
                  { claim: 'Independent security audit', meaning: 'Vendor-published docs only', status: 'Not started', tone: 'muted' },
                  { claim: 'Listed technology / education partners', meaning: 'User-supplied, not independently verified', status: 'Unverified', tone: 'muted' },
                ].map((row) => (
                  <tr key={row.claim} className="border-b border-border last:border-0">
                    <td className="px-4 py-3.5 text-sm font-medium text-foreground">{row.claim}</td>
                    <td className="hidden px-4 py-3.5 text-sm text-muted-foreground sm:table-cell">{row.meaning}</td>
                    <td className="px-4 py-3.5">
                      <span className={`rounded-full border px-2.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider ${
                        row.tone === 'green' ? 'border-green-500/30 bg-green-500/10 text-green-400' :
                        row.tone === 'amber' ? 'border-amber-500/30 bg-amber-500/10 text-amber-400' :
                        'border-border bg-muted/40 text-muted-foreground'
                      }`}>{row.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-4 font-mono text-[11px] leading-relaxed text-muted-foreground">
            &ldquo;Recorded&rdquo; pricing means we captured it from a vendor page on a stated date &mdash; always confirm
            current tiers on the vendor site before purchasing. &ldquo;Unverified&rdquo; partner listings are shown because the
            site operator supplied them; we make no claim that a paid relationship is active.
          </p>
        </div>
      </section>

      {/* Four section cards */}
      <section id="sections" className="border-t border-border bg-card/20">
        <div className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
          <div className="mb-10 max-w-2xl">
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Methodology</p>
            <h2 className="mt-2 font-display text-2xl font-bold sm:text-3xl">Engineering Tool Evaluation &amp; Testing Methodology</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              The full methodology spans how we select tools, the technical bar they must clear, how we keep reviews
              independent, and the engineering safety limits of everything we publish.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            {SECTIONS.map((s) => (
              <SectionCard key={s.title} s={s} />
            ))}
          </div>
        </div>
      </section>

      {/* Related policy pages */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
          <div className="mb-10 max-w-2xl">
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Related Policies</p>
            <h2 className="mt-2 font-display text-2xl font-bold sm:text-3xl">Editorial, commercial &amp; corrections</h2>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            <Link to="/editorial-policy" className="group rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/40">
              <ShieldCheck className="h-6 w-6 text-primary" />
              <h3 className="mt-3 font-display text-lg font-bold">Editorial Guidelines</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">Our mandate against paid reviews, sponsored rankings, and our testing workflow.</p>
              <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary">Read <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" /></span>
            </Link>
            <Link to="/disclosures" className="group rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/40">
              <AlertTriangle className="h-6 w-6 text-primary" />
              <h3 className="mt-3 font-display text-lg font-bold">Commercial Disclosures</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">How affiliate commissions work and why they never influence scores or rankings.</p>
              <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary">Read <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" /></span>
            </Link>
            <Link to="/corrections" className="group rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/40">
              <CheckCircle2 className="h-6 w-6 text-primary" />
              <h3 className="mt-3 font-display text-lg font-bold">Corrections Policy</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">How to report an inaccuracy and how we verify and publish corrections.</p>
              <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary">Read <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" /></span>
            </Link>
          </div>
        </div>
      </section>

      {/* Engineering disclaimer band */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-12">
          <div className="flex flex-col items-start gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/5 px-6 py-5 sm:flex-row sm:items-center">
            <AlertTriangle className="h-5 w-5 shrink-0 text-amber-400" />
            <p className="text-sm leading-relaxed text-muted-foreground">
              <span className="font-semibold text-foreground">Engineering disclaimer:</span> Calculators and tools
              provide preliminary engineering estimates. Final verification should be performed using certified
              analytical software or licensed professional engineering review. Questions? Email{' '}
              <a href="mailto:hello@mechengi10x.com" className="text-primary hover:underline">hello@mechengi10x.com</a>.
            </p>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
