import { useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import {
  Terminal,
  Search,
  Copy,
  Check,
  Download,
  ChevronDown,
  ChevronRight,
  ShieldAlert,
  ShieldCheck,
  Send,
  Loader2,
  Info,
  Code2,
} from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import pb from '@/lib/pocketbaseClient';
import { macroLibrary, macroTargets } from '@/data/macroLibrary';

const inputCls =
  'min-h-[44px] w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary';

function Field({ label, children }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}

function downloadText(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function MacroCard({ macro }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const targetLabel = macroTargets.find((t) => t.id === macro.target)?.label || macro.target;

  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(macro.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      // clipboard unavailable — user can still select the text manually
    }
  };

  return (
    <div className="flex flex-col rounded-2xl border border-border bg-card p-5">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className="rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-primary">
          {targetLabel}
        </span>
        {macro.tags.map((t) => (
          <span key={t} className="rounded-full border border-border px-2.5 py-0.5 font-mono text-[10px] text-muted-foreground">
            {t}
          </span>
        ))}
      </div>
      <h3 className="font-display text-base font-bold leading-snug">{macro.title}</h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">{macro.desc}</p>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 font-mono text-xs text-muted-foreground hover:border-primary/40 hover:text-primary"
        >
          {open ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
          {open ? 'Hide code' : 'View code'}
        </button>
        <button
          type="button"
          onClick={copyCode}
          className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 font-mono text-xs text-muted-foreground hover:border-primary/40 hover:text-primary"
        >
          {copied ? <Check className="h-3 w-3 text-green-400" /> : <Copy className="h-3 w-3" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
        <button
          type="button"
          onClick={() => downloadText(macro.code, `mechengi_${macro.id}.txt`, 'text/plain')}
          className="flex items-center gap-1.5 rounded-lg border border-primary/30 bg-primary/10 px-3 py-1.5 font-mono text-xs text-primary hover:bg-primary/20"
        >
          <Download className="h-3 w-3" /> Download
        </button>
      </div>

      {open && (
        <pre className="mt-3 max-h-[420px] overflow-auto rounded-xl border border-border bg-muted/30 p-4 font-mono text-xs leading-relaxed text-foreground/90">
          <code>{macro.code}</code>
        </pre>
      )}
      <p className="mt-3 font-mono text-[10px] text-muted-foreground">
        Team-reviewed draft · MIT-style use · test before production use
      </p>
    </div>
  );
}

function SubmitForm() {
  const [form, setForm] = useState({
    title: '',
    target: 'freecad',
    description: '',
    code: '',
    author_name: '',
    author_email: '',
    license: 'as-is',
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      // status is intentionally omitted — submissions always start as pending
      await pb.collection('macro_submissions').create(form);
      setDone(true);
    } catch (err) {
      setError(err?.response?.message || err?.message || 'Submission failed. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
          <Check className="h-7 w-7 text-primary" />
        </div>
        <h3 className="mt-5 font-display text-xl font-bold">Submission received — pending review</h3>
        <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
          Thanks, {form.author_name || 'engineer'}. Your script is stored as an{' '}
          <span className="text-foreground">unverified, pending</span> submission. Our team reviews every submission
          for basic correctness and safety before anything is published — if it is accepted we will credit you with the
          license you chose.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 sm:p-8">
      <h3 className="font-display text-xl font-bold">Submit a script or macro</h3>
      <p className="mt-1 text-sm text-muted-foreground">
        Share a working automation script with the community. Submissions are reviewed by our team before publication —
        nothing is published automatically.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <Field label="Title *">
          <input required value={form.title} onChange={set('title')} placeholder="e.g. Batch export drawings to PDF" className={inputCls} />
        </Field>
        <Field label="Target application *">
          <select required value={form.target} onChange={set('target')} className={inputCls}>
            {macroTargets.map((t) => (
              <option key={t.id} value={t.id}>{t.label}</option>
            ))}
          </select>
        </Field>
        <Field label="Your name">
          <input value={form.author_name} onChange={set('author_name')} placeholder="How should we credit you?" className={inputCls} />
        </Field>
        <Field label="Your email">
          <input type="email" value={form.author_email} onChange={set('author_email')} placeholder="you@company.com" className={inputCls} />
        </Field>
      </div>

      <div className="mt-4">
        <Field label="License you grant *">
          <select value={form.license} onChange={set('license')} className={inputCls}>
            <option value="as-is">As-is, free to use (no formal license)</option>
            <option value="mit">MIT License</option>
            <option value="public-domain">Public domain / CC0</option>
          </select>
        </Field>
      </div>

      <div className="mt-4">
        <Field label="What it does *">
          <textarea
            required
            rows={3}
            value={form.description}
            onChange={set('description')}
            placeholder="One or two sentences: inputs, outputs, and what to check before running it."
            className={`${inputCls} resize-none`}
          />
        </Field>
      </div>

      <div className="mt-4">
        <Field label="Code *">
          <textarea
            required
            rows={8}
            value={form.code}
            onChange={set('code')}
            placeholder="Paste the full Python / VBA source here…"
            className={`${inputCls} resize-y font-mono text-xs`}
          />
        </Field>
      </div>

      {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

      <button
        type="submit"
        disabled={busy}
        className="glow-primary mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60"
      >
        {busy ? <><Loader2 className="h-4 w-4 animate-spin" /> Submitting…</> : <><Send className="h-4 w-4" /> Submit for review</>}
      </button>
      <p className="mt-3 text-center font-mono text-[10px] text-muted-foreground">
        Submissions start as unverified/pending and are never auto-published.
      </p>
    </form>
  );
}

export default function MacroLibraryPage() {
  const [q, setQ] = useState('');
  const [target, setTarget] = useState('all');

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    return macroLibrary.filter((m) => {
      if (target !== 'all' && m.target !== target) return false;
      if (!query) return true;
      return (
        m.title.toLowerCase().includes(query) ||
        m.desc.toLowerCase().includes(query) ||
        m.tags.some((t) => t.toLowerCase().includes(query)) ||
        m.target.includes(query)
      );
    });
  }, [q, target]);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Automation Macro & Script Repository — FreeCAD, Fusion 360, SOLIDWORKS | MechEngi 10X</title>
        <meta
          name="description"
          content="A searchable library of free automation scripts and macros for FreeCAD, Fusion 360, and SOLIDWORKS: batch exports, backups, renames, and reports. Copy, download, or submit your own for community review."
        />
      </Helmet>

      <SiteHeader />

      {/* Header */}
      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-14">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <Terminal className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Free · Community-driven</p>
          </div>
          <h1 className="mt-2 font-display text-3xl font-bold sm:text-4xl">Automation macro &amp; script repository</h1>
          <p className="mt-3 max-w-2xl text-muted-foreground">
            A searchable library of copy-paste automation code for CAD and engineering tools — batch exports, backups,
            renames, and reports. Every entry below was written and reviewed by the MechEngi 10X team; community
            submissions are reviewed before publication.
          </p>

          <div className="mt-6 flex max-w-3xl items-start gap-3 rounded-xl border border-amber-500/30 bg-amber-500/5 px-5 py-3">
            <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
            <p className="text-sm leading-relaxed text-muted-foreground">
              <span className="font-semibold text-foreground">Draft code, not audited code.</span> Scripts are starting
              points reviewed for basic correctness only. Read every line, follow the QA &amp; verification guidelines
              below, run on copies of your data first, and verify outputs before production use. Community submissions
              are labelled unverified until moderated — we never publish ratings, download counts, or contributor
              claims we cannot verify.
            </p>
          </div>
        </div>
      </section>

      {/* Script QA & verification guidelines */}
      <section className="border-b border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-12">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10">
              <ShieldCheck className="h-3.5 w-3.5 text-primary" />
            </span>
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Script QA &amp; Verification Guidelines</p>
          </div>
          <h2 className="mt-2 font-display text-2xl font-bold sm:text-3xl">Before any script touches a real model</h2>
          <p className="mt-3 max-w-2xl text-muted-foreground">
            A broken macro can silently corrupt a CAD model — under-constrained sketches drift, unit mismatches scale
            every dimension, and a half-finished batch run leaves a folder of half-processed files. Work through this
            checklist before running any script — ours or your own — on data that matters:
          </p>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: 'Verify sketch constraint states',
                body: 'Run batch edits only on fully constrained sketches. Under-constrained geometry drifts silently when a parameter changes — check the constraint state before and after the run.',
              },
              {
                title: 'Lock and validate units',
                body: 'Confirm the document unit scheme before reading or writing any parameter. A mm/inch mismatch corrupts values silently — validate units in the script, not by eye.',
              },
              {
                title: 'Handle exceptions explicitly',
                body: 'Wrap batch routines in try/except (or On Error) so one bad file fails the run cleanly — without saving partial results or leaving documents open in a half-processed state.',
              },
              {
                title: 'Sandbox-test first',
                body: 'Run every new script on copied files in a sandbox folder. Never run an untested script against a production model vault — and never without a fresh backup.',
              },
              {
                title: 'Verify outputs against a reference',
                body: 'Compare the script\u2019s output (exports, renames, reports) against a known-good reference before trusting it. A script that runs without errors is not the same as a script that is correct.',
              },
              {
                title: 'Pin and record your CAD version',
                body: 'Record the CAD version the script was tested against. APIs change between releases — re-verify on every upgrade before the script re-enters your workflow.',
              },
            ].map((g) => (
              <div key={g.title} className="rounded-2xl border border-border bg-card p-5">
                <h3 className="font-display text-sm font-bold sm:text-base">{g.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{g.body}</p>
              </div>
            ))}
          </div>
          <p className="mt-6 max-w-2xl rounded-xl border border-border bg-muted/20 px-4 py-3 font-mono text-[11px] leading-relaxed text-muted-foreground">
            Honest status: no script in this repository is labelled production-ready or verified. Team-written entries
            are drafts reviewed for basic correctness only; community submissions stay unverified until moderated. A
            script only earns a tested label after it has actually been run and reviewed — and none has.
          </p>
        </div>
      </section>

      {/* Library */}
      <section className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search scripts by name, tag, or use case…"
              className="h-11 w-full rounded-xl border border-border bg-card pl-10 pr-4 text-sm placeholder:text-muted-foreground focus:border-primary focus:outline-none"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setTarget('all')}
              className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                target === 'all' ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'
              }`}
            >
              All
            </button>
            {macroTargets.filter((t) => t.id !== 'other').map((t) => (
              <button
                key={t.id}
                onClick={() => setTarget(t.id)}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs transition-colors ${
                  target === t.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-primary/30'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {filtered.length > 0 ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((m) => <MacroCard key={m.id} macro={m} />)}
          </div>
        ) : (
          <div className="rounded-xl border border-border py-20 text-center">
            <p className="font-display text-lg font-semibold">No scripts match your search</p>
            <button onClick={() => { setQ(''); setTarget('all'); }} className="mt-4 rounded-lg border border-border px-5 py-2 text-sm hover:border-primary/50">
              Clear filters
            </button>
          </div>
        )}

        {/* Related tools */}
        <div className="mt-10 flex flex-wrap gap-2">
          <Link
            to="/macro-generator"
            className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 font-mono text-[11px] text-muted-foreground hover:border-primary/30 hover:text-primary"
          >
            <Code2 className="h-3 w-3" /> Configure a generated macro instead
          </Link>
          <Link
            to="/resources"
            className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5 font-mono text-[11px] text-muted-foreground hover:border-primary/30 hover:text-primary"
          >
            Resource library
          </Link>
        </div>
      </section>

      {/* Community submissions */}
      <section className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-16">
          <div className="mx-auto mb-10 max-w-2xl text-center">
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Community submissions</p>
            <h2 className="mt-2 font-display text-3xl font-bold">Share your automation code</h2>
            <p className="mt-4 text-lg leading-relaxed text-foreground/90">
              Have a script that saves your team hours every week? Submit it. Accepted scripts are published with your
              credit and your chosen license — after human review, never automatically.
            </p>
          </div>
          <div className="mx-auto max-w-2xl">
            <SubmitForm />
          </div>
          <div className="mx-auto mt-10 flex max-w-2xl items-start gap-3 rounded-xl border border-border bg-muted/20 px-5 py-4">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
            <p className="text-sm leading-relaxed text-muted-foreground">
              <span className="font-medium text-foreground">Honest status:</span> this repository launched with
              team-written scripts only. There are no community-published entries yet — we do not fabricate
              contributors, download counts, or ratings. The first accepted community submissions will appear here
              after moderation, clearly labelled with their author and license.
            </p>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
