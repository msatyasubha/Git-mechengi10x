import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { MessageSquare, Plus, Loader2, LogIn, Eye, Reply, Pin } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbaseClient';

const categories = [
  { id: 'all', label: 'All' },
  { id: 'general', label: 'General' },
  { id: 'ai-tools', label: 'AI Tools' },
  { id: 'cad', label: 'CAD' },
  { id: 'simulation', label: 'Simulation' },
  { id: 'automation', label: 'Automation' },
  { id: 'management', label: 'Management' },
  { id: 'jobs', label: 'Jobs' },
  { id: 'courses', label: 'Courses' },
];

const catBadge = {
  general: 'badge-management',
  'ai-tools': 'badge-ai',
  cad: 'badge-cad',
  simulation: 'badge-simulation',
  automation: 'badge-automation',
  management: 'badge-management',
  jobs: 'badge-learning',
  courses: 'badge-learning',
};

function timeAgo(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const s = Math.floor((Date.now() - d.getTime()) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  if (s < 604800) return `${Math.floor(s / 86400)}d ago`;
  return d.toLocaleDateString();
}

export default function ForumPage() {
  const { isAuthed, user } = useAuth();
  const [cat, setCat] = useState('all');
  const [threads, setThreads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [draft, setDraft] = useState({ title: '', body: '', category: 'general' });
  const [busy, setBusy] = useState(false);

  async function loadThreads() {
    setLoading(true);
    setError('');
    try {
      const filter = cat === 'all' ? '' : `category = "${cat}"`;
      const records = await pb.collection('forum_threads').getFullList({
        sort: '-pinned,-created',
        filter,
        expand: 'owner',
      });
      setThreads(records);
    } catch (err) {
      setError(err?.message || 'Could not load threads.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadThreads();
  }, [cat]);

  const submitThread = async (e) => {
    e.preventDefault();
    if (!draft.title.trim() || !draft.body.trim()) return;
    setBusy(true);
    try {
      await pb.collection('forum_threads').create({
        title: draft.title.trim(),
        body: draft.body.trim(),
        category: draft.category,
        owner: user.id,
        views: 0,
        pinned: false,
      });
      setDraft({ title: '', body: '', category: 'general' });
      setShowForm(false);
      loadThreads();
    } catch (err) {
      setError(err?.response?.message || err?.message || 'Could not post thread.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Community Forum — MechEngi 10X</title>
        <meta name="description" content="Discuss AI tools, CAD, simulation, automation, and engineering careers with the MechEngi 10X community." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-12">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" />
            <p className="font-mono text-xs uppercase tracking-wider text-primary">Community</p>
          </div>
          <h1 className="mt-1 font-display text-3xl font-bold sm:text-4xl">Engineering Community Forum</h1>
          <p className="mt-2 max-w-xl text-muted-foreground">
            Ask questions, share workflows, and compare notes with other mechanical engineers.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-[90rem] px-5 py-10">
        <div className="grid gap-8 lg:grid-cols-[1fr_18rem]">
          {/* Main */}
          <div>
            {/* Filter + new thread */}
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap gap-2">
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setCat(c.id)}
                    className={`rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-wider transition-colors ${
                      cat === c.id ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:border-foreground/40 hover:text-foreground'
                    }`}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
              {isAuthed ? (
                <button
                  onClick={() => setShowForm(!showForm)}
                  className="flex items-center gap-1.5 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90"
                >
                  <Plus className="h-4 w-4" /> New thread
                </button>
              ) : (
                <Link to="/login" className="flex items-center gap-1.5 rounded-xl border border-border px-4 py-2 text-sm font-medium hover:border-primary/40 hover:text-primary">
                  <LogIn className="h-4 w-4" /> Sign in to post
                </Link>
              )}
            </div>

            {/* New thread form */}
            {showForm && isAuthed && (
              <form onSubmit={submitThread} className="mb-6 rounded-2xl border border-border bg-card p-5">
                <input
                  value={draft.title}
                  onChange={(e) => setDraft({ ...draft, title: e.target.value })}
                  placeholder="Thread title"
                  maxLength={200}
                  className="mb-3 min-h-[44px] w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary"
                />
                <textarea
                  value={draft.body}
                  onChange={(e) => setDraft({ ...draft, body: e.target.value })}
                  placeholder="What do you want to discuss?"
                  rows={4}
                  maxLength={5000}
                  className="mb-3 w-full resize-none rounded-md border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary"
                />
                <div className="flex items-center justify-between">
                  <select
                    value={draft.category}
                    onChange={(e) => setDraft({ ...draft, category: e.target.value })}
                    className="min-h-[40px] rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-primary"
                  >
                    {categories.filter((c) => c.id !== 'all').map((c) => (
                      <option key={c.id} value={c.id}>{c.label}</option>
                    ))}
                  </select>
                  <button
                    type="submit"
                    disabled={busy || !draft.title.trim() || !draft.body.trim()}
                    className="flex items-center gap-2 rounded-xl bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-60"
                  >
                    {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} Post thread
                  </button>
                </div>
              </form>
            )}

            {error && <p className="mb-4 text-sm text-destructive">{error}</p>}

            {/* Thread list */}
            {loading ? (
              <div className="flex items-center gap-2 py-12 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Loading threads…
              </div>
            ) : threads.length === 0 ? (
              <div className="rounded-2xl border border-border bg-card p-12 text-center">
                <MessageSquare className="mx-auto h-10 w-10 text-muted-foreground" />
                <h3 className="mt-4 font-display text-lg font-semibold">No threads yet</h3>
                <p className="mt-2 text-sm text-muted-foreground">Be the first to start a discussion in this category.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {threads.map((t) => (
                  <Link
                    key={t.id}
                    to={`/forum/${t.id}`}
                    className="block rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/40"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          {t.pinned && <Pin className="h-3.5 w-3.5 text-accent" />}
                          <h3 className="truncate font-display font-semibold hover:text-primary">{t.title}</h3>
                        </div>
                        <p className="mt-1.5 line-clamp-2 text-sm text-muted-foreground">{t.body}</p>
                        <div className="mt-3 flex items-center gap-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                          {t.category && <span className={`rounded border px-1.5 py-0.5 ${catBadge[t.category] || 'badge-management'}`}>{t.category}</span>}
                          <span>by {t.expand?.owner?.name || t.expand?.owner?.email || 'engineer'}</span>
                          <span>{timeAgo(t.created)}</span>
                        </div>
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-2 text-muted-foreground">
                        <span className="flex items-center gap-1 font-mono text-[10px]"><Eye className="h-3 w-3" /> {t.views || 0}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <aside className="space-y-4">
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Forum guidelines</h3>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                <li>• Be respectful and constructive.</li>
                <li>• Share real workflows and results.</li>
                <li>• No self-promotion outside the Jobs category.</li>
                <li>• Cite sources for claims about tools.</li>
              </ul>
            </div>
            <div className="rounded-2xl border border-border bg-card p-5">
              <h3 className="font-display font-semibold">Related</h3>
              <div className="mt-3 flex flex-col gap-2">
                <Link to="/advisor" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">→ AI Advisor</Link>
                <Link to="/courses" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">→ Premium Courses</Link>
                <Link to="/guides" className="rounded-lg border border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary/30 hover:text-foreground">→ Engineering Guides</Link>
              </div>
            </div>
          </aside>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
