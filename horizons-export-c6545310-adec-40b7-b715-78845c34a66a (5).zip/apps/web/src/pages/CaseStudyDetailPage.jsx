import { Helmet } from 'react-helmet';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, TrendingUp, Quote, ArrowRight, Download } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { getCaseStudyBySlug, caseStudies } from '@/data/caseStudies';

export default function CaseStudyDetailPage() {
  const { slug } = useParams();
  const cs = getCaseStudyBySlug(slug);

  if (!cs) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet><title>Case study not found — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
        <SiteHeader />
        <div className="mx-auto max-w-md px-5 py-32 text-center">
          <h1 className="font-display text-2xl font-bold">Case study not found</h1>
          <Link to="/case-studies" className="mt-4 inline-block text-primary hover:underline">← Back to case studies</Link>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const others = caseStudies.filter((c) => c.slug !== cs.slug).slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{cs.title} — MechEngi 10X Case Study</title>
        <meta name="description" content={`Explore an engineering workflow example involving ${cs.tool}: the challenge, potential approach and reported results, which are not independently verified.`} />
        <meta name="robots" content="noindex, follow" />
        <link rel="canonical" href={`https://mechengi10x.com/case-studies/${cs.slug}`} />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[90rem] px-5 py-12">
          <nav className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
            <Link to="/case-studies" className="hover:text-foreground">Case Studies</Link>
            <span>/</span>
            <span className="text-foreground">{cs.client}</span>
          </nav>
          <div className="mt-6 grid gap-8 lg:grid-cols-[1.5fr_1fr]">
            <div>
              <span className="inline-flex rounded-md border border-primary/30 bg-primary/10 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-primary">
                {cs.industry}
              </span>
              <h1 className="mt-4 font-display text-3xl font-bold leading-tight sm:text-4xl">{cs.title}</h1>
              <div className="mt-4 flex flex-wrap items-center gap-4 font-mono text-xs text-muted-foreground">
                <span>Client: <span className="text-foreground">{cs.client}</span></span>
                <span>Tool: <Link to={`/tools/${cs.toolSlug}`} className="text-primary hover:underline">{cs.tool}</Link></span>
                <span>{cs.readTime} min read</span>
              </div>
            </div>
            <div className="rounded-2xl border border-border bg-card p-6">
              <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Headline results</p>
              <div className="mt-4 grid grid-cols-2 gap-4">
                {cs.results.map((r) => (
                  <div key={r.metric} className="rounded-xl border border-border bg-muted/30 p-3">
                    <p className="font-display text-xl font-bold text-primary">{r.value}</p>
                    <p className="mt-1 font-mono text-[9px] uppercase tracking-wider text-muted-foreground">{r.metric}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-5 py-12">
        <p className="mb-8 rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 text-sm leading-relaxed text-muted-foreground">
          <span className="font-semibold text-foreground">Evidence status:</span> The organizations, quotes, results and ROI figures on this page have not been independently verified. Treat this as a workflow example, not a verified case study or benchmark.
        </p>
        <div className="space-y-10">
          <div>
            <h2 className="font-display text-2xl font-bold">The challenge</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{cs.challenge}</p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold">The solution</h2>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{cs.solution}</p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold">Results</h2>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {cs.results.map((r) => (
                <div key={r.metric} className="flex items-center justify-between rounded-xl border border-border bg-card p-4">
                  <span className="text-sm text-muted-foreground">{r.metric}</span>
                  <span className="font-display text-xl font-bold text-primary">{r.value}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border border-primary/30 bg-primary/5 p-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <h2 className="font-display text-xl font-bold">ROI</h2>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-foreground/90">{cs.roi}</p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-6">
            <Quote className="h-6 w-6 text-accent" />
            <p className="mt-3 text-lg leading-relaxed text-foreground/90">“{cs.testimonial.quote}”</p>
            <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">— {cs.testimonial.author}</p>
          </div>
        </div>

        <div className="mt-10 rounded-xl border border-border bg-muted/30 p-5">
          <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Related resources</p>
          <div className="mt-3 flex flex-col gap-2">
            {cs.internalLinks.map((l) => (
              <Link key={l.to} to={l.to} className="flex items-center gap-2 text-sm text-primary hover:underline">
                <ArrowRight className="h-3.5 w-3.5" /> {l.text}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-12">
        <h2 className="font-display text-2xl font-bold">More case studies</h2>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {others.map((c) => (
            <Link key={c.slug} to={`/case-studies/${c.slug}`} className="group rounded-2xl border border-border bg-card p-5 transition-colors hover:border-primary/40">
              <p className="font-mono text-[10px] uppercase tracking-wider text-primary">{c.client}</p>
              <h3 className="mt-2 font-display font-semibold group-hover:text-primary">{c.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{c.challenge}</p>
            </Link>
          ))}
        </div>
        <div className="mt-8">
          <Link to="/case-studies" className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-3.5 w-3.5" /> All case studies
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
