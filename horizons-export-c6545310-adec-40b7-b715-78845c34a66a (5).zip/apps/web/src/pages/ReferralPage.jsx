import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Gift, LogIn, Loader2, Copy, Check, Users, DollarSign, TrendingUp } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbaseClient';

export default function ReferralPage() {
  const { user, isAuthed } = useAuth();
  const [aff, setAff] = useState(null);
  const [referrals, setReferrals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    async function load() {
      if (!isAuthed) {
        setLoading(false);
        return;
      }
      try {
        let records = await pb.collection('affiliates').getFullList({ sort: '-created' });
        let record = records[0];
        if (!record) {
          const base = (user?.email || 'eng').split('@')[0].replace(/[^a-z0-9]/gi, '').toLowerCase().slice(0, 6);
          const code = `ME10X-${base}-${Math.random().toString(36).slice(2, 6)}`.toUpperCase();
          record = await pb.collection('affiliates').create({
            referral_code: code,
            status: 'active',
            total_clicks: 0,
            total_signups: 0,
            total_conversions: 0,
            pending_balance: 0,
            paid_out: 0,
            currency: 'USD',
            owner: user.id,
          });
        }
        setAff(record);
        const r = await pb.collection('referrals').getFullList({ sort: '-created' }).catch(() => []);
        setReferrals(r);
      } catch (_) {
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [isAuthed, user]);

  const link = aff ? `${window.location.origin}/?ref=${aff.referral_code}` : '';
  const copyLink = () => {
    navigator.clipboard?.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Referral Program — Earn $10 per Signup, $50 per Course | MechEngi 10X</title>
        <meta name="description" content="Refer engineers to MechEngi 10X and earn $10 credit per signup and $50 per course sale. Track your referrals and payouts." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Gift className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Referral Program</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            Refer engineers. Earn rewards.
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            Get <span className="text-primary">$10 credit</span> for every engineer who signs up with your link,
            and <span className="text-primary">$50</span> for every premium course they buy. Payouts monthly.
          </p>
        </div>
      </section>

      {/* Rewards */}
      <section className="mx-auto max-w-[90rem] px-5 py-16">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            { icon: Users, title: '$10 per signup', body: 'Earn $10 credit for every new engineer who creates an account with your referral link.' },
            { icon: DollarSign, title: '$50 per course sale', body: 'Earn $50 for every premium course purchase made by someone you referred.' },
            { icon: TrendingUp, title: 'Monthly payouts', body: 'Cash out once your balance reaches $50. Payouts processed monthly.' },
          ].map((r) => (
            <div key={r.title} className="rounded-2xl border border-border bg-card p-6">
              <r.icon className="h-7 w-7 text-primary" />
              <h3 className="mt-4 font-display text-lg font-semibold">{r.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{r.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Dashboard / link */}
      <section className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-2xl px-5 py-16">
          {!isAuthed ? (
            <div className="rounded-2xl border border-border bg-card p-8 text-center">
              <LogIn className="mx-auto h-10 w-10 text-primary" />
              <h2 className="mt-4 font-display text-xl font-bold">Join the referral program</h2>
              <p className="mt-2 text-sm text-muted-foreground">Create an account to get your unique referral link.</p>
              <div className="mt-6 flex justify-center gap-3">
                <Link to="/signup" className="rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">Create account</Link>
                <Link to="/login" className="rounded-xl border border-border px-6 py-2.5 text-sm font-medium hover:border-primary/40 hover:text-primary">Sign in</Link>
              </div>
            </div>
          ) : loading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading your referral link…
            </div>
          ) : aff ? (
            <div className="rounded-2xl border border-border bg-card p-6">
              <h2 className="font-display text-xl font-bold">Your referral link</h2>
              <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                <input readOnly value={link} className="min-h-[44px] flex-1 rounded-md border border-input bg-background px-3 font-mono text-xs outline-none" />
                <button onClick={copyLink} className="flex items-center justify-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
                  {copied ? <><Check className="h-4 w-4" /> Copied</> : <><Copy className="h-4 w-4" /> Copy</>}
                </button>
              </div>
              <div className="mt-6 grid grid-cols-3 gap-4 border-t border-border pt-6">
                <div>
                  <p className="font-display text-2xl font-bold text-primary">{aff.total_signups || 0}</p>
                  <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Signups</p>
                </div>
                <div>
                  <p className="font-display text-2xl font-bold text-primary">{aff.total_conversions || 0}</p>
                  <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Conversions</p>
                </div>
                <div>
                  <p className="font-display text-2xl font-bold text-primary">${Number(aff.pending_balance || 0).toFixed(0)}</p>
                  <p className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Pending</p>
                </div>
              </div>
              <Link to="/affiliate" className="mt-6 inline-block text-sm font-medium text-primary hover:underline">Full affiliate dashboard →</Link>
            </div>
          ) : null}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
