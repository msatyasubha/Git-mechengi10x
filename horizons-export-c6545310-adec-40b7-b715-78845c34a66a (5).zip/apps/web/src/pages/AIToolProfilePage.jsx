import { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ExternalLink, CheckCircle, XCircle, ArrowLeft, ChevronRight, Zap, ArrowRight, Workflow } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { getAIProfileBySlug, getRelatedAIProfiles, aiToolProfileCategories } from '@/data/aiToolProfiles';
import { trackAffiliateClick } from '@/lib/analytics';
import pb from '@/lib/pocketbaseClient';
import RelatedWorkflowsWidget from '@/components/RelatedWorkflowsWidget';
import { useState } from 'react';

function NewsletterCTA() {
  const [email, setEmail] = useState('');
  const [state, setState] = useState('idle');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email) return;
    setState('loading');
    try {
      await pb.collection('newsletter_subscribers').create({ email, source: 'ai-tool-profile' });
      setState('success');
    } catch {
      setState('already');
    }
  };

  return (
    <div className="rounded-2xl border border-primary/20 bg-primary/5 p-6">
      <div className="flex items-center gap-2 mb-3">
        <Zap className="h-4 w-4 text-primary" />
        <span className="font-mono text-xs uppercase tracking-widest text-primary">Weekly Engineering Intelligence</span>
      </div>
      <h3 className="font-display text-lg font-bold">Get one practical AI idea every week</h3>
      <p className="mt-2 text-sm text-muted-foreground">Tool reviews, workflow tips, and engineering AI guides — delivered every Thursday. No spam, unsubscribe anytime.</p>
      {state === 'success' || state === 'already' ? (
        <p className="mt-4 text-sm text-green-400">{state === 'success' ? "You're in! Check your inbox." : "You're already subscribed!"}</p>
      ) : (
        <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
          <input
            type="email"
            required
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="your@email.com"
            className="h-10 flex-1 rounded-lg border border-border bg-card px-3 text-sm placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none"
          />
          <button
            type="submit"
            disabled={state === 'loading'}
            className="rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-50"
          >
            {state === 'loading' ? '...' : 'Subscribe'}
          </button>
        </form>
      )}
    </div>
  );
}

// Schema.org applicationCategory mapping for AI tool profiles. Derived from
// each profile's documented category — never assumed to be a DesignApplication.
const AI_PROFILE_CATEGORY_SCHEMA = {
  'ai-writing': 'BusinessApplication',
  'ai-coding': 'DeveloperApplication',
  'ai-research': 'BusinessApplication',
  'ai-image': 'DesignApplication',
  'ai-video': 'DesignApplication',
};

export default function AIToolProfilePage() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const profile = getAIProfileBySlug(slug);
  const related = profile ? getRelatedAIProfiles(profile) : [];

  useEffect(() => {
    if (profile) window.scrollTo(0, 0);
  }, [slug, profile]);

  if (!profile) {
    return (
      <div className="min-h-screen bg-background">
        <Helmet><title>Profile not found — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
        <SiteHeader />
        <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4">
          <p className="font-display text-2xl font-bold">Profile not found</p>
          <button onClick={() => navigate('/ai-tools')} className="text-primary hover:underline">Back to AI Tools</button>
        </div>
        <SiteFooter />
      </div>
    );
  }

  const catLabel = aiToolProfileCategories.find(c => c.id === profile.category)?.label || profile.category;

  // JSON-LD structured data
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": profile.seoTitle,
    "description": profile.metaDescription,
    "keywords": [profile.primaryKeyword, ...profile.secondaryKeywords].join(', '),
    "author": { "@type": "Organization", "name": "MechEngi 10X" },
    "publisher": { "@type": "Organization", "name": "MechEngi 10X", "url": "https://mechengi10x.com" },
    "url": `https://mechengi10x.com/ai-tools/${profile.slug}`,
    "mainEntityOfPage": `https://mechengi10x.com/ai-tools/${profile.slug}`,
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": profile.faq.map(item => ({
      "@type": "Question",
      "name": item.q,
      "acceptedAnswer": { "@type": "Answer", "text": item.a },
    })),
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://mechengi10x.com" },
      { "@type": "ListItem", "position": 2, "name": "AI Tools for Engineers", "item": "https://mechengi10x.com/ai-tools" },
      { "@type": "ListItem", "position": 3, "name": profile.name, "item": `https://mechengi10x.com/ai-tools/${profile.slug}` },
    ],
  };

  // SoftwareApplication structured data — only facts visible on the page.
  // No assumed operating system, no invented price or free status, no
  // availability field, and no fabricated operator/team author. The publisher
  // is the tool vendor (the organization that makes the software), not MechEngi 10X.
  const softwareSchema = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: profile.name,
    applicationCategory: AI_PROFILE_CATEGORY_SCHEMA[profile.category] || 'BusinessApplication',
    publisher: { '@type': 'Organization', name: profile.vendor },
    description: profile.tagline,
  };
  // Include offers only when a concrete numeric price is actually displayed on
  // the page. Free-only tools and contact-for-pricing tools omit offers rather
  // than fabricate a number, currency, or stock status.
  if (typeof profile.pricing?.paidFrom === 'number' && profile.pricing.paidFrom > 0) {
    softwareSchema.offers = {
      '@type': 'Offer',
      price: profile.pricing.paidFrom,
      priceCurrency: 'USD',
    };
  }

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>{profile.seoTitle} | MechEngi 10X</title>
        <meta name="description" content={profile.metaDescription} />
        <meta name="keywords" content={[profile.primaryKeyword, ...profile.secondaryKeywords].join(', ')} />
        <link rel="canonical" href={`https://mechengi10x.com/ai-tools/${profile.slug}`} />
        <meta property="og:title" content={`${profile.seoTitle} | MechEngi 10X`} />
        <meta property="og:description" content={profile.metaDescription} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={`https://mechengi10x.com/ai-tools/${profile.slug}`} />
      </Helmet>

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(softwareSchema) }} />

      <SiteHeader />

      {/* Breadcrumb */}
      <div className="border-b border-border bg-card/30 py-3">
        <div className="mx-auto flex max-w-[72rem] flex-wrap items-center gap-1.5 px-5 font-mono text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Home</Link>
          <ChevronRight className="h-3 w-3" />
          <Link to="/ai-tools" className="hover:text-foreground">AI Tools for Engineers</Link>
          <ChevronRight className="h-3 w-3" />
          <Link to={`/ai-tools?cat=${profile.category}`} className="hover:text-foreground">{catLabel}</Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground">{profile.name}</span>
        </div>
      </div>

      <div className="mx-auto max-w-[72rem] px-5 py-8 lg:py-12">
        <div className="grid gap-10 lg:grid-cols-[1fr_320px]">
          {/* Main content */}
          <main>
            {/* Tool header */}
            <header>
              <div className="flex flex-wrap items-start gap-4">
                <span className="text-4xl">{profile.logoEmoji}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 font-mono text-[10px] text-primary">{catLabel}</span>
                    {profile.badge && (
                      <span className="rounded-full bg-accent/15 px-2 py-0.5 font-mono text-[10px] text-accent">{profile.badge}</span>
                    )}
                  </div>
                  <h1 className="mt-1 font-display text-2xl font-extrabold sm:text-3xl lg:text-4xl">{profile.name}</h1>
                  <p className="text-sm text-muted-foreground">by {profile.vendor}</p>
                  {profile.lastUpdated && (
                    <p className="mt-1 font-mono text-[11px] text-muted-foreground">Last updated: {profile.lastUpdated}</p>
                  )}
                </div>
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-5">
                <div>
                  <p className="font-mono text-xs text-muted-foreground">Editorial Rating</p>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="font-display text-lg font-bold text-muted-foreground">Not Yet Rated</span>
                    <span className="font-mono text-[10px] text-muted-foreground">No fabricated ratings</span>
                  </div>
                </div>
                <div className="h-8 w-px bg-border" />
                <div>
                  <p className="font-mono text-xs text-muted-foreground">MechEngi Score</p>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="font-display text-lg font-bold text-muted-foreground">Not Yet Rated</span>
                    <span className="font-mono text-[10px] text-muted-foreground">Awaiting benchmark</span>
                  </div>
                </div>
              </div>

              <p className="mt-4 text-base leading-relaxed text-muted-foreground lg:text-lg">{profile.tagline}</p>
              <p className="mt-4 rounded-xl border border-border bg-muted/20 px-4 py-3 text-xs leading-relaxed text-muted-foreground">Model capabilities, pricing and product policies change. Examples and comparative claims are not independently benchmarked; confirm current details with the vendor and verify engineering outputs independently.</p>
            </header>

            {/* Intro */}
            <section className="mt-8 prose-custom">
              <h2 className="font-display text-xl font-bold mb-3">Overview</h2>
              <p className="text-foreground/80 leading-relaxed">{profile.intro}</p>
              <h3 className="mt-5 font-display text-lg font-bold mb-2">What Is {profile.name}?</h3>
              <p className="text-foreground/80 leading-relaxed">{profile.whatIsIt}</p>
            </section>

            {/* Verification & data safety */}
            {profile.safetyNote && (
              <section className="mt-8">
                <div className="rounded-xl border border-amber-500/25 bg-amber-500/5 p-5">
                  <h2 className="font-display text-base font-bold text-amber-400">Verification &amp; data safety</h2>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{profile.safetyNote}</p>
                </div>
              </section>
            )}

            {/* Key Features */}
            <section className="mt-8">
              <h2 className="font-display text-xl font-bold mb-4">Key Features for Engineers</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                {profile.keyFeatures.map((f, i) => (
                  <div key={i} className="rounded-xl border border-border bg-card p-4">
                    <p className="font-display text-sm font-semibold">{f.name}</p>
                    <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{f.desc}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Engineering Applications */}
            <section className="mt-8">
              <h2 className="font-display text-xl font-bold mb-4">Engineering Applications & Use Cases</h2>
              <div className="space-y-5">
                {profile.engineeringApplications.map((app, i) => (
                  <div key={i} className="rounded-xl border border-border bg-card p-5">
                    <h3 className="font-display text-base font-bold text-primary">{app.area}</h3>
                    <ul className="mt-3 space-y-1.5">
                      {app.examples.map((ex, j) => (
                        <li key={j} className="flex items-start gap-2 text-sm">
                          <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary/60" />
                          <span className="text-foreground/80">{ex}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>

            {/* Claude → SOLIDWORKS BOM workflow CTA (only on the Claude profile) */}
            {profile.slug === 'claude-for-engineering' && (
              <section className="mt-8">
                <div className="rounded-2xl border border-primary/25 bg-primary/5 p-6">
                  <div className="flex items-center gap-2">
                    <Workflow className="h-5 w-5 text-primary" />
                    <h2 className="font-display text-lg font-bold">Automate Engineering CAD Workflows</h2>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    Combine Claude with SOLIDWORKS VBA macros and n8n webhooks to automate BOM extraction and QA
                    verification &mdash; a copyable pipeline from assembly components to a reviewed Excel QA report.
                  </p>
                  <Link
                    to="/workflows/solidworks-bom-n8n"
                    className="mt-4 inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
                  >
                    View SOLIDWORKS &rarr; JSON &rarr; n8n Guide <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </section>
            )}

            {/* Pros & Cons */}
            <section className="mt-8">
              <h2 className="font-display text-xl font-bold mb-4">Pros & Cons for Engineers</h2>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-xl border border-green-500/20 bg-green-500/5 p-5">
                  <h3 className="flex items-center gap-2 font-display font-bold text-green-400">
                    <CheckCircle className="h-4 w-4" /> Advantages
                  </h3>
                  <ul className="mt-3 space-y-2">
                    {profile.pros.map((p, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-green-500" />
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-5">
                  <h3 className="flex items-center gap-2 font-display font-bold text-red-400">
                    <XCircle className="h-4 w-4" /> Limitations
                  </h3>
                  <ul className="mt-3 space-y-2">
                    {profile.cons.map((c, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-500" />
                        <span>{c}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </section>

            {/* Pricing */}
            <section className="mt-8">
              <h2 className="font-display text-xl font-bold mb-4">Pricing Plans</h2>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {profile.pricingDetail.map((plan, i) => (
                  <div key={i} className={`rounded-xl border p-4 ${i === 1 ? 'border-primary/40 bg-primary/5' : 'border-border bg-card'}`}>
                    <p className="font-display font-bold">{plan.tier}</p>
                    <p className="mt-1 font-mono text-lg font-semibold text-primary">{plan.price}</p>
                    <ul className="mt-3 space-y-1">
                      {plan.features.map((f, j) => (
                        <li key={j} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <span className="h-1 w-1 shrink-0 rounded-full bg-muted-foreground/60" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
              <a
                href={profile.affiliateUrl}
                target="_blank"
                rel="noopener noreferrer sponsored"
                onClick={() => trackAffiliateClick(profile.slug, profile.name, 'pricing-section')}
                className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 font-semibold text-primary-foreground transition-all hover:opacity-90"
              >
                Try {profile.name} <ExternalLink className="h-4 w-4" />
              </a>
              <p className="mt-2 text-center font-mono text-[10px] text-muted-foreground">Affiliate link — we earn a commission at no extra cost to you</p>
            </section>

            {/* Real-world examples */}
            {profile.realWorldExamples?.length > 0 && (
              <section className="mt-8">
                <h2 className="font-display text-xl font-bold mb-4">Real-World Engineering Examples</h2>
                <div className="space-y-4">
                  {profile.realWorldExamples.map((ex, i) => (
                    <div key={i} className="rounded-xl border border-border bg-card/60 p-5">
                      <h3 className="font-display font-semibold text-primary">{ex.title}</h3>
                      <p className="mt-2 text-sm leading-relaxed text-foreground/80">{ex.desc}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Alternatives */}
            {profile.alternatives?.length > 0 && (
              <section className="mt-8">
                <h2 className="font-display text-xl font-bold mb-4">Alternatives to Consider</h2>
                <div className="space-y-2">
                  {profile.alternatives.map((alt, i) => (
                    <Link key={i} to={`/ai-tools/${alt.slug}`} className="flex items-center justify-between rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/30 hover:bg-primary/5">
                      <div>
                        <p className="font-display font-semibold hover:text-primary">{alt.name}</p>
                        <p className="mt-0.5 text-xs text-muted-foreground">{alt.why}</p>
                      </div>
                      <ArrowRight className="h-4 w-4 text-muted-foreground" />
                    </Link>
                  ))}
                </div>
              </section>
            )}

            {/* Verdict */}
            <section className="mt-8">
              <h2 className="font-display text-xl font-bold mb-4">MechEngi 10X Verdict</h2>
              <div className="rounded-xl border border-primary/20 bg-primary/5 p-5">
                <div className="flex items-center gap-3 mb-3">
                  <span className="font-display text-2xl font-extrabold text-muted-foreground">Not Yet Rated</span>
                  <span className="font-mono text-xs text-muted-foreground">MechEngi Score — awaiting benchmark data</span>
                </div>
                <p className="text-foreground/80 leading-relaxed">{profile.verdict}</p>
              </div>
            </section>

            {/* FAQ */}
            <section className="mt-8">
              <h2 className="font-display text-xl font-bold mb-4">Frequently Asked Questions</h2>
              <div className="space-y-3">
                {profile.faq.map((item, i) => (
                  <div key={i} className="rounded-xl border border-border bg-card p-5">
                    <h3 className="font-display font-semibold">{item.q}</h3>
                    <p className="mt-2 text-sm leading-relaxed text-foreground/80">{item.a}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Internal links */}
            <section className="mt-8">
              <h3 className="font-display font-bold mb-3">Related Resources</h3>
              <div className="flex flex-wrap gap-2">
                {profile.internalLinks.map((link, i) => (
                  <Link key={i} to={link.to} className="rounded-lg border border-border bg-muted/40 px-3 py-1.5 font-mono text-xs text-muted-foreground transition-colors hover:border-primary/30 hover:text-primary">
                    {link.text}
                  </Link>
                ))}
              </div>
            </section>

            {/* Official sources */}
            {profile.officialSources?.length > 0 && (
              <section className="mt-8">
                <h3 className="font-display font-bold mb-3">Official references</h3>
                <ul className="space-y-2">
                  {profile.officialSources.map((src, i) => (
                    <li key={i}>
                      <a href={src.url} target="_blank" rel="noopener noreferrer" className="text-sm text-primary hover:underline">
                        {src.label}
                      </a>
                    </li>
                  ))}
                </ul>
                <p className="mt-2 font-mono text-[10px] text-muted-foreground">Factual product claims above are referenced to Anthropic's official documentation. Always confirm current details on the vendor's site.</p>
              </section>
            )}

            <div className="mt-8">
              <Link to="/ai-tools" className="flex items-center gap-2 font-mono text-sm text-muted-foreground hover:text-primary">
                <ArrowLeft className="h-4 w-4" /> Back to all AI Tool Profiles
              </Link>
            </div>
          </main>

          {/* Sidebar */}
          <aside className="lg:sticky lg:top-24 lg:h-fit space-y-5">
            {/* CTA card */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{profile.logoEmoji}</span>
                <div>
                  <p className="font-display font-bold">{profile.name}</p>
                  <p className="text-xs text-muted-foreground">{profile.vendor}</p>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                {profile.pricing.free ? (
                  <div className="rounded-lg bg-green-500/10 px-3 py-2 flex items-center justify-between">
                    <span className="font-mono text-xs text-green-400">Free tier available</span>
                    <span className="text-xs text-muted-foreground">{profile.pricing.freeLabel}</span>
                  </div>
                ) : null}
                {profile.pricing.paidFrom > 0 && (
                  <div className="rounded-lg bg-muted px-3 py-2 flex items-center justify-between">
                    <span className="font-mono text-xs">Paid from</span>
                    <span className="font-mono text-xs font-semibold">${profile.pricing.paidFrom}/mo</span>
                  </div>
                )}
                {profile.pricing.contactForPricing && (
                  <div className="rounded-lg bg-muted px-3 py-2 flex items-center justify-between">
                    <span className="font-mono text-xs">Commercial</span>
                    <span className="font-mono text-xs font-semibold text-muted-foreground">Contact vendor</span>
                  </div>
                )}
              </div>
              <a
                href={profile.affiliateUrl}
                target="_blank"
                rel="noopener noreferrer sponsored"
                onClick={() => trackAffiliateClick(profile.slug, profile.name, 'sidebar')}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 font-semibold text-primary-foreground transition-all hover:opacity-90"
              >
                Try {profile.name} <ExternalLink className="h-4 w-4" />
              </a>
              <p className="mt-2 text-center font-mono text-[10px] text-muted-foreground">Affiliate link</p>
              <Link
                to="/advisor"
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-border py-2.5 text-sm font-medium transition-colors hover:border-primary/40 hover:text-primary"
              >
                Ask AI Advisor for alternatives
              </Link>
            </div>

            {/* Newsletter */}
            <NewsletterCTA />

            {/* Related profiles */}
            {related.length > 0 && (
              <div className="rounded-2xl border border-border bg-card p-5">
                <p className="font-display font-bold mb-3">Related AI Tool Profiles</p>
                <div className="space-y-3">
                  {related.map(r => (
                    <Link key={r.slug} to={`/ai-tools/${r.slug}`} className="group flex items-center gap-3">
                      <span className="text-xl">{r.logoEmoji}</span>
                      <div className="min-w-0">
                        <p className="text-sm font-medium group-hover:text-primary leading-snug">{r.name}</p>
                        <p className="text-xs text-muted-foreground">MechEngi Score: Not Yet Rated</p>
                      </div>
                    </Link>
                  ))}
                </div>
                <Link to="/ai-tools" className="mt-4 flex items-center gap-1 font-mono text-xs text-primary hover:underline">
                  All AI Tool Profiles <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
            )}

            {/* Topic cluster */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <p className="font-display font-bold mb-3">AI Tools Topic Cluster</p>
              <div className="space-y-2">
                {[
                  { to: '/ai-tools', label: 'All AI Tool Profiles' },
                  { to: '/wizard', label: 'Find the Right AI Tool' },
                  { to: '/compare', label: 'Compare AI Tools' },
                  { to: '/guides', label: 'Engineering AI Guides' },
                ].map(l => (
                  <Link key={l.to} to={l.to} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary">
                    <ChevronRight className="h-3.5 w-3.5 shrink-0" />
                    {l.label}
                  </Link>
                ))}
              </div>
            </div>

            <RelatedWorkflowsWidget category={profile.category} />
          </aside>
        </div>

        {/* Related profiles grid */}
        {related.length > 0 && (
          <section className="mt-14">
            <h2 className="font-display text-2xl font-bold">More AI Tool Profiles</h2>
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {related.map(r => (
                <Link key={r.slug} to={`/ai-tools/${r.slug}`} className="group flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{r.logoEmoji}</span>
                    <div>
                      <p className="font-display font-bold group-hover:text-primary">{r.name}</p>
                      <p className="text-xs text-muted-foreground">{r.vendor}</p>
                    </div>
                  </div>
                  <p className="mt-3 flex-1 text-sm text-muted-foreground line-clamp-2">{r.tagline}</p>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="font-mono text-xs text-muted-foreground">MechEngi Score: Not Yet Rated</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 transition-all group-hover:translate-x-1 group-hover:text-primary group-hover:opacity-100" />
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>

      <SiteFooter />
    </div>
  );
}
