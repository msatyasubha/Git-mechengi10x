import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Check, Crown, ArrowRight, Sparkles, Shield } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { membershipPlans } from '@/data/membership';

export default function MembershipPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Premium Membership — Unlock Advanced Guides & Early Access | MechEngi 10X</title>
        <meta name="description" content="Join MechEngi 10X Premium: member-only advanced guides, early access to new reviews, priority AI Advisor, course discounts, and an ad-free reading experience. Basic $9.99/mo, Pro $29.99/mo." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-20 text-center">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <Crown className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Premium Membership</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-bold leading-tight sm:text-5xl">
            Go beyond the free reviews
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            Premium members get advanced guides, early access to new reviews, priority AI Advisor responses,
            course discounts, and an ad-free reading experience. Cancel anytime.
          </p>
        </div>
      </section>

      {/* Plans */}
      <section className="mx-auto max-w-[90rem] px-5 py-20">
        <div className="grid gap-6 lg:grid-cols-3">
          {membershipPlans.map((p) => (
            <div
              key={p.id}
              className={`relative flex flex-col rounded-2xl border bg-card p-7 ${
                p.popular ? 'border-primary/50 shadow-lg shadow-primary/10' : 'border-border'
              }`}
            >
              {p.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-1 font-mono text-[10px] uppercase tracking-wider text-primary-foreground">
                  Most Popular
                </span>
              )}
              <span className={`inline-flex w-fit rounded-md border px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider ${p.accent}`}>
                {p.name}
              </span>
              <p className="mt-4 text-sm text-muted-foreground">{p.tagline}</p>
              <div className="mt-5 flex items-baseline gap-1">
                {p.price ? (
                  <>
                    <span className="font-display text-4xl font-bold">${p.price}</span>
                    <span className="text-sm text-muted-foreground">{p.period}</span>
                  </>
                ) : (
                  <span className="font-display text-4xl font-bold">Custom</span>
                )}
              </div>

              <ul className="mt-6 flex-1 space-y-2.5">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    <span className="text-foreground/90">{f}</span>
                  </li>
                ))}
              </ul>

              {p.id === 'enterprise' ? (
                <Link
                  to="/sponsor"
                  className={`mt-7 flex items-center justify-center gap-2 rounded-xl px-5 py-3 font-semibold transition-all active:scale-[0.98] border border-border hover:border-primary/40 hover:text-primary`}
                >
                  {p.cta} <ArrowRight className="h-4 w-4" />
                </Link>
              ) : (
                <Link
                  to="/signup"
                  className={`mt-7 flex items-center justify-center gap-2 rounded-xl px-5 py-3 font-semibold transition-all active:scale-[0.98] ${
                    p.popular
                      ? 'glow-primary bg-primary text-primary-foreground hover:opacity-90'
                      : 'border border-border hover:border-primary/40 hover:text-primary'
                  }`}
                >
                  {p.cta} <ArrowRight className="h-4 w-4" />
                </Link>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* How billing works — honest checkout transparency */}
      <section className="mx-auto max-w-[72rem] px-5 py-12">
        <div className="flex flex-col items-start gap-3 rounded-2xl border border-border bg-card p-6 sm:flex-row sm:items-center">
          <Shield className="h-5 w-5 shrink-0 text-primary" />
          <div className="text-sm leading-relaxed text-muted-foreground">
            <span className="font-semibold text-foreground">How billing works:</span> Creating an account is free.
            Paid membership is activated separately — after you sign up, email{' '}
            <a href="mailto:hello@mechengi10x.com" className="text-primary hover:underline">hello@mechengi10x.com</a>{' '}
            with the plan you want and we&rsquo;ll confirm your tier and arrange payment directly. There is no automated
            checkout on the site yet, so you will never be charged by surprise. Confirmed prices are shown above and
            never move a MechEngi Score.
          </div>
        </div>
      </section>

      {/* Why join */}
      <section className="border-y border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-20">
          <div className="mb-12 text-center">
            <h2 className="font-display text-3xl font-bold sm:text-4xl">What members get</h2>
            <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
              Real, exclusive value — not a paywall around the free content.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: Sparkles, title: 'Advanced guides', body: 'Member-only deep dives beyond the free guides — workflows, templates, and worked examples.' },
              { icon: Crown, title: 'Early access', body: 'See new reviews and tool profiles before they go public, and shape what we cover next.' },
              { icon: ArrowRight, title: 'Priority Advisor', body: 'Pro members get faster, longer AI Advisor conversations with priority response.' },
              { icon: Check, title: 'Course discounts', body: 'Pro members get 20% off every premium course, plus member-exclusive monthly deep-dives.' },
            ].map((f) => (
              <div key={f.title} className="rounded-2xl border border-border bg-card p-6">
                <f.icon className="h-7 w-7 text-primary" />
                <h3 className="mt-4 font-display text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust & guarantee band */}
      <section className="border-y border-border bg-card/30">
        <div className="mx-auto max-w-[90rem] px-5 py-14">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="font-display text-2xl font-bold sm:text-3xl">Membership is risk-free</h2>
            <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
              The free directory, reviews, calculators, and AI Advisor stay free forever. Premium only unlocks more
              depth &mdash; never the core research engineers rely on.
            </p>
          </div>
          <div className="mx-auto mt-8 grid max-w-4xl gap-4 sm:grid-cols-3">
            {[
              { title: 'Cancel anytime', body: 'No annual lock-in. Upgrade, downgrade, or cancel from your profile whenever you want.' },
              { title: 'Scores stay independent', body: 'Membership revenue never moves a MechEngi Score. A paid tool can still rank low.' },
              { title: 'Free core, forever', body: 'Reviews, the directory, calculators, and the methodology remain free for every engineer.' },
            ].map((g) => (
              <div key={g.title} className="rounded-2xl border border-border bg-card p-5 text-center">
                <Check className="mx-auto h-6 w-6 text-primary" />
                <h3 className="mt-3 font-display text-sm font-bold">{g.title}</h3>
                <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{g.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-2xl px-5 py-16 text-center">
        <h2 className="font-display text-2xl font-bold sm:text-3xl">Not sure which plan?</h2>
        <p className="mx-auto mt-3 max-w-md text-muted-foreground">
          Ask the AI Advisor which membership fits your goals — or start free and upgrade anytime.
        </p>
        <Link to="/advisor" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3 font-semibold text-primary-foreground hover:opacity-90">
          Ask the Advisor <ArrowRight className="h-4 w-4" />
        </Link>
      </section>

      <SiteFooter />
    </div>
  );
}
