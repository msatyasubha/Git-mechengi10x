import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ShieldCheck, Ban, FlaskConical, Code2, ArrowRight, Mail } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';

const PRINCIPLES = [
  {
    icon: Ban,
    title: 'No Paid Positive Reviews',
    body: 'We do not accept payment for positive reviews, favourable scores, or the removal of criticism. Vendors cannot purchase a better MechEngi Score, a higher ranking, or a softer verdict. Any attempt to do so is refused and, where relevant, disclosed.',
  },
  {
    icon: ShieldCheck,
    title: 'No Sponsored Ranking Placements',
    body: 'Sponsored or partner listings are always labelled as such and are excluded from organic MechEngi Score rankings. Sponsorship never buys a score change, a ranking improvement, or the suppression of a limitation.',
  },
  {
    icon: FlaskConical,
    title: 'Direct Hands-On Testing (Where Stated)',
    body: 'Where we have performed direct hands-on testing, we label the result with the test date, method, and version. Where we have not yet run hands-on tests, we say so explicitly — we never present vendor claims or inferred capability as our own verified testing.',
  },
  {
    icon: Code2,
    title: 'Code & Spec Verification',
    body: 'Automation scripts, API examples, and file-format claims are checked against official vendor documentation. Sample code is published as illustrative drafts with clear safety limits — it is never presented as production-ready or validated unless it has actually been run and tested.',
  },
];

export default function EditorialPolicyPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Editorial Guidelines & Testing Integrity — MechEngi 10X</title>
        <meta name="description" content="Our editorial mandate for independent engineering software reviews: no paid positive reviews, no sponsored ranking placements, a documented testing and code-verification workflow, and explicit 'not yet rated' states where hands-on testing has not been performed." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 sm:py-20">
          <div className="mx-auto flex w-fit items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5">
            <ShieldCheck className="h-3.5 w-3.5 text-primary" />
            <span className="font-mono text-xs uppercase tracking-wider text-primary">Editorial Policy</span>
          </div>
          <h1 className="mx-auto mt-6 max-w-3xl font-display text-3xl font-bold leading-tight sm:text-4xl md:text-5xl">
            Editorial Guidelines &amp; Testing Integrity
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            MechEngi 10X exists to give practising engineers vendor-neutral guidance. Our editorial mandate is
            independence: scores, rankings, and reviews are derived from documented evidence and stated testing — never
            from commercial relationships.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-16 sm:py-20">
        <div className="grid gap-5 sm:grid-cols-2">
          {PRINCIPLES.map((p) => {
            const Icon = p.icon;
            return (
              <div key={p.title} className="rounded-2xl border border-border bg-card p-6">
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" />
                  </span>
                  <h2 className="font-display text-lg font-bold">{p.title}</h2>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.body}</p>
              </div>
            );
          })}
        </div>

        <div className="mt-12 max-w-2xl">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">Our Testing Workflow</h2>
          <ol className="mt-5 space-y-4">
            {[
              'Selection starts from real engineering workflows — product design, FEA sign-off, CFD, automation, and CAD-to-ERP handoff — not vendor marketing.',
              'Claims are checked against official vendor documentation (API references, pricing pages, format support matrices) and labelled with a verification date.',
              'Where hands-on testing is performed, the method, version, and date are recorded alongside the result. Where it is not, the field is marked "Not yet rated" or "Not documented".',
              'Sample code and automation scripts are published as illustrative drafts with explicit safety limits and are never claimed to be production-ready or validated unless actually tested.',
              'Aggregate star ratings and review counts are not presented as fact. Community reviews require a professional email and pass through moderation before they appear.',
            ].map((step, i) => (
              <li key={i} className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-primary/10 font-mono text-sm font-bold text-primary">
                  {i + 1}
                </span>
                <span className="text-sm leading-relaxed text-foreground/85">{step}</span>
              </li>
            ))}
          </ol>
        </div>

        <div className="mt-12 flex flex-col items-start gap-3 rounded-2xl border border-border bg-card p-6 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="font-display text-lg font-bold">Report an editorial concern</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Suspect a review was influenced by a commercial relationship? Tell us — we investigate every report.
            </p>
          </div>
          <a
            href="mailto:hello@mechengi10x.com"
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 active:scale-[0.98]"
          >
            <Mail className="h-4 w-4" /> hello@mechengi10x.com
          </a>
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/methodology" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
            100-point evaluation framework <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/disclosures" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
            Affiliate &amp; commercial disclosures <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/corrections" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline">
            Corrections policy <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
