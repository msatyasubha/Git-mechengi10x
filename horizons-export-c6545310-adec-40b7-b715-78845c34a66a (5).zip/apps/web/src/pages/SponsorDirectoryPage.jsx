import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import SiteHeader from '@/components/SiteHeader';
import SiteFooter from '@/components/SiteFooter';
import { sponsorshipPackages } from '@/data/sponsorshipPackages';

// Curated public showcase of partner companies. The sponsors PocketBase
// collection is owner-scoped, so the public directory is a marketing list.
const directory = [
  { company: 'Onshape', logo: 'OS', package: 'exclusive-review', blurb: 'Cloud-native CAD, reviewed hands-on by our engineering team.' },
  { company: 'SimScale', logo: 'SS', package: 'webinar-sponsorship', blurb: 'Cloud simulation webinar — full replay available.' },
  { company: 'n8n', logo: 'n8', package: 'featured-tool', blurb: 'Open-source workflow automation, featured in the Automation category.' },
  { company: 'Keyence', logo: 'KE', package: 'exclusive-review', blurb: 'Vision & measurement systems, independently scored.' },
  { company: 'Make', logo: 'MK', package: 'featured-tool', blurb: 'No-code automation, featured in the Automation category.' },
  { company: 'Coursera', logo: 'CO', package: 'featured-tool', blurb: 'Engineering learning paths, featured in Learning.' },
];

const pkgLabels = {
  'featured-tool': 'Featured Tool',
  'exclusive-review': 'Exclusive Review',
  'webinar-sponsorship': 'Webinar Sponsorship',
};

export default function SponsorDirectoryPage() {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Sponsor Directory — MechEngi 10X Partners</title>
        <meta name="description" content="Explore the MechEngi 10X partner directory. Listed relationships are user-supplied and have not been independently verified as active sponsorships." />
      </Helmet>

      <SiteHeader />

      <section className="dot-grid border-b border-border">
        <div className="mx-auto max-w-[72rem] px-5 py-16 text-center">
          <p className="font-mono text-xs uppercase tracking-wider text-primary">Transparency</p>
          <h1 className="mt-2 font-display text-4xl font-bold sm:text-5xl">Our sponsor directory</h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            The organizations listed below are named here at the request of the site operator as technology and
            education partners. These relationships are <span className="font-semibold text-foreground">user-supplied
            and not independently verified</span> by MechEngi 10X as active paid sponsorships. We publish no claim
            that any of these organizations is a current paid sponsor. Where a commercial relationship exists, it
            does not determine our editorial scores, rankings, or recommendations.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-[90rem] px-5 py-16">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {directory.map((s) => (
              <div key={s.company} className="rounded-2xl border border-border bg-card p-6">
              <div className="flex items-center gap-3">
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 font-display text-base font-bold text-primary">
                  {s.logo}
                </span>
                <div>
                  <p className="font-display text-lg font-semibold">{s.company}</p>
                  <span className="font-mono text-[10px] uppercase tracking-wider text-accent">{pkgLabels[s.package]}</span>
                </div>
              </div>
              <p className="mt-4 text-sm text-muted-foreground">{s.blurb}</p>
              <p className="mt-3 rounded-lg border border-border bg-muted/30 px-3 py-2 font-mono text-[10px] leading-relaxed text-muted-foreground">
                Status: user-supplied, unverified · Editorial Scores Maintained Independently
              </p>
            </div>
          ))}
        </div>

        <div className="mt-12 rounded-2xl border border-border bg-card/50 p-6 text-center">
          <p className="text-sm text-muted-foreground">Want to join the directory?</p>
          <Link to="/sponsor" className="mt-3 inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90">
            View sponsorship packages <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
