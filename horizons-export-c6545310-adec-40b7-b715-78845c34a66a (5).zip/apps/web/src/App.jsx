import React, { useEffect } from 'react';
import { Route, Routes, BrowserRouter as Router, Link, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import SiteHeader from './components/SiteHeader';
import SiteFooter from './components/SiteFooter';

import ScrollToTop from './components/ScrollToTop';
import { captureReferral } from './lib/referral';
import HomePage from './pages/HomePage';
import ToolsPage from './pages/ToolsPage';
import ToolDetailPage from './pages/ToolDetailPage';
import ComparePage from './pages/ComparePage';
import GuidesPage from './pages/GuidesPage';
import AdvisorPage from './pages/AdvisorPage';
import AuthPage from './pages/AuthPage';
import JobsPage from './pages/JobsPage';
import WizardPage from './pages/WizardPage';
import AboutPage from './pages/AboutPage';
import LegalPage from './pages/LegalPage';
import MethodologyPage from './pages/MethodologyPage';
import EditorialPolicyPage from './pages/EditorialPolicyPage';
import DisclosuresPage from './pages/DisclosuresPage';
import CorrectionsPage from './pages/CorrectionsPage';
import WorkflowsPage from './pages/WorkflowsPage';
import SolidworksBomWorkflowPage from './pages/SolidworksBomWorkflowPage';
import AiDrawingQaGdtWorkflowPage from './pages/AiDrawingQaGdtWorkflowPage';
import FreeToolsPage from './pages/FreeToolsPage';
import CalculatorsPage from './pages/CalculatorsPage';
import ResourceLibraryPage from './pages/ResourceLibraryPage';
import ERPIntegrationPage from './pages/ERPIntegrationPage';
import StackConsultingPage from './pages/StackConsultingPage';
import MacroGeneratorPage from './pages/MacroGeneratorPage';
import MacroLibraryPage from './pages/MacroLibraryPage';
import EnterpriseQuotePage from './pages/EnterpriseQuotePage';
import AIToolsPage from './pages/AIToolsPage';
import AIToolProfilePage from './pages/AIToolProfilePage';
import EmergingToolsPage from './pages/EmergingToolsPage';
import ComparisonDetailPage from './pages/ComparisonDetailPage';
import ReviewsPage from './pages/ReviewsPage';
import ReviewDetailPage from './pages/ReviewDetailPage';
import SponsorPage from './pages/SponsorPage';
import SponsorPackagePage from './pages/SponsorPackagePage';
import SponsorDashboardPage from './pages/SponsorDashboardPage';
import SponsorTermsPage from './pages/SponsorTermsPage';
import SponsorDirectoryPage from './pages/SponsorDirectoryPage';
import SponsorTestimonialsPage from './pages/SponsorTestimonialsPage';
import CoursesPage from './pages/CoursesPage';
import CourseDetailPage from './pages/CourseDetailPage';
import ForumPage from './pages/ForumPage';
import ThreadDetailPage from './pages/ThreadDetailPage';
import CaseStudiesPage from './pages/CaseStudiesPage';
import CaseStudyDetailPage from './pages/CaseStudyDetailPage';
import VideosPage from './pages/VideosPage';
import VideoDetailPage from './pages/VideoDetailPage';
import PodcastPage from './pages/PodcastPage';
import PodcastEpisodePage from './pages/PodcastEpisodePage';
import EventsPage from './pages/EventsPage';
import EventDetailPage from './pages/EventDetailPage';
import MembershipPage from './pages/MembershipPage';
import ProfilePage from './pages/ProfilePage';
import AffiliatePage from './pages/AffiliatePage';
import ReferralPage from './pages/ReferralPage';
import { Toaster } from '@/components/ui/toaster';
import { CurrencyProvider } from '@/contexts/CurrencyContext';

// Only known, public landing pages receive a site-wide canonical here. Detail
// pages define their canonical after validating their slug.
const PUBLIC_PAGES = new Set([
    '/', '/ai-tools', '/emerging-tools', '/reviews', '/compare', '/guides',
    '/advisor', '/jobs', '/wizard', '/about', '/methodology', '/editorial-policy',
    '/disclosures', '/corrections', '/workflows', '/workflows/solidworks-bom-n8n',
    '/workflows/ai-drawing-qa-gdt',
    '/legal', '/free-tools', '/calculators', '/resources', '/erp-integration',
    '/stack-consulting', '/macro-generator', '/macro-library', '/enterprise-quote',
    '/sponsor', '/sponsor/terms', '/sponsor/directory', '/sponsor/testimonials',
    '/courses', '/forum', '/case-studies', '/videos', '/podcast', '/events',
    '/membership', '/referral',
]);

function PageCanonical() {
    const { pathname, search } = useLocation();
    const canonicalPath = pathname.length > 1 ? pathname.replace(/\/+$/, '') : pathname;
    if (!PUBLIC_PAGES.has(canonicalPath)) return null;
    const tab = new URLSearchParams(search).get('tab');
    const policyQuery = canonicalPath === '/legal' && ['1', '2', '3'].includes(tab) ? `?tab=${tab}` : '';
    return <Helmet><link rel="canonical" href={`https://mechengi10x.com${canonicalPath}${policyQuery}`} /></Helmet>;
}

function NotFoundPage() {
    return (
        <div className="min-h-screen bg-background">
            <Helmet><title>Page not found — MechEngi 10X</title><meta name="robots" content="noindex, follow" /></Helmet>
            <SiteHeader />
            <main className="mx-auto max-w-md px-5 py-32 text-center">
                <h1 className="font-display text-2xl font-bold">Page not found</h1>
                <p className="mt-3 text-sm text-muted-foreground">This page may have moved or the address may be incorrect.</p>
                <Link to="/" className="mt-4 inline-block text-primary hover:underline">Return to the home page</Link>
            </main>
            <SiteFooter />
        </div>
    );
}

function App() {
    useEffect(() => {
        captureReferral();
    }, []);

    useEffect(() => {
        const onKey = (e) => {
            if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
                e.preventDefault();
                const el = document.querySelector('.search-bar');
                if (el) {
                    el.focus();
                } else {
                    window.location.href = '/tools';
                }
            }
        };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, []);

    return (
        <CurrencyProvider>
        <Router>
            <ScrollToTop />
            <PageCanonical />
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/tools" element={<ToolsPage />} />
                <Route path="/tools/:slug" element={<ToolDetailPage />} />
                <Route path="/ai-tools" element={<AIToolsPage />} />
                <Route path="/ai-tools/:slug" element={<AIToolProfilePage />} />
                <Route path="/emerging-tools" element={<EmergingToolsPage />} />
                <Route path="/reviews" element={<ReviewsPage />} />
                <Route path="/reviews/:slug" element={<ReviewDetailPage />} />
                <Route path="/compare" element={<ComparePage />} />
                <Route path="/comparisons/:slug" element={<ComparisonDetailPage />} />
                <Route path="/guides" element={<GuidesPage />} />
                <Route path="/advisor" element={<AdvisorPage />} />
                <Route path="/jobs" element={<JobsPage />} />
                <Route path="/wizard" element={<WizardPage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/methodology" element={<MethodologyPage />} />
                <Route path="/editorial-policy" element={<EditorialPolicyPage />} />
                <Route path="/disclosures" element={<DisclosuresPage />} />
                <Route path="/corrections" element={<CorrectionsPage />} />
                <Route path="/workflows" element={<WorkflowsPage />} />
                <Route path="/workflows/solidworks-bom-n8n" element={<SolidworksBomWorkflowPage />} />
                <Route path="/workflows/ai-drawing-qa-gdt" element={<AiDrawingQaGdtWorkflowPage />} />
                <Route path="/legal" element={<LegalPage />} />
                <Route path="/free-tools" element={<FreeToolsPage />} />
                <Route path="/calculators" element={<CalculatorsPage />} />
                <Route path="/resources" element={<ResourceLibraryPage />} />
                <Route path="/erp-integration" element={<ERPIntegrationPage />} />
                <Route path="/stack-consulting" element={<StackConsultingPage />} />
                <Route path="/macro-generator" element={<MacroGeneratorPage />} />
                <Route path="/macro-library" element={<MacroLibraryPage />} />
                <Route path="/enterprise-quote" element={<EnterpriseQuotePage />} />
                <Route path="/login" element={<AuthPage mode="login" />} />
                <Route path="/signup" element={<AuthPage mode="signup" />} />
                <Route path="/sponsor" element={<SponsorPage />} />
                <Route path="/sponsor/:slug" element={<SponsorPackagePage />} />
                <Route path="/sponsor/featured-tool" element={<SponsorPackagePage />} />
                <Route path="/sponsor/exclusive-review" element={<SponsorPackagePage />} />
                <Route path="/sponsor/webinar-sponsorship" element={<SponsorPackagePage />} />
                <Route path="/sponsor/dashboard" element={<SponsorDashboardPage />} />
                <Route path="/sponsor/terms" element={<SponsorTermsPage />} />
                <Route path="/sponsor/directory" element={<SponsorDirectoryPage />} />
                <Route path="/sponsor/testimonials" element={<SponsorTestimonialsPage />} />
                <Route path="/courses" element={<CoursesPage />} />
                <Route path="/courses/:slug" element={<CourseDetailPage />} />
                <Route path="/forum" element={<ForumPage />} />
                <Route path="/forum/:id" element={<ThreadDetailPage />} />
                <Route path="/case-studies" element={<CaseStudiesPage />} />
                <Route path="/case-studies/:slug" element={<CaseStudyDetailPage />} />
                <Route path="/videos" element={<VideosPage />} />
                <Route path="/videos/:slug" element={<VideoDetailPage />} />
                <Route path="/podcast" element={<PodcastPage />} />
                <Route path="/podcast/:slug" element={<PodcastEpisodePage />} />
                <Route path="/events" element={<EventsPage />} />
                <Route path="/events/:slug" element={<EventDetailPage />} />
                <Route path="/membership" element={<MembershipPage />} />
                <Route path="/profile" element={<ProfilePage />} />
                <Route path="/affiliate" element={<AffiliatePage />} />
                <Route path="/referral" element={<ReferralPage />} />
                <Route path="*" element={<NotFoundPage />} />
            </Routes>
            <Toaster />
        </Router>
        </CurrencyProvider>
    );
}

export default App;
