#!/usr/bin/env python
# MechEngi 10X CAD Benchmark Suite (Community Edition) — FreeCAD driver.
#
# A transparent, self-run timing harness for common CAD operations using
# FreeCAD. This script produces YOUR results on YOUR hardware. It publishes
# nothing and claims nothing about any vendor's relative performance.
#
# License: MIT (see LICENSE-NOTES.md). Provided as a community draft tool:
# reviewed for basic correctness, NOT independently audited.
#
# Usage:
#   freecadcmd benchmark_freecad.py [--size N] [--runs R] [--out FILE]
#
#   --size N   workload multiplier (default 50) — number of primitives etc.
#   --runs R   repetitions per test, median reported (default 3)
#   --out FILE append results as CSV rows to FILE

import time
import sys
import os
import csv
import statistics

try:
    import FreeCAD as App
    import Part
except ImportError:
    print("ERROR: This script must run inside FreeCAD (freecadcmd or the")
    print("FreeCAD Python console). See README.md for instructions.")
    sys.exit(1)


def parse_args(argv):
    opts = {"size": 50, "runs": 3, "out": None}
    i = 0
    while i < len(argv):
        if argv[i] == "--size" and i + 1 < len(argv):
            opts["size"] = int(argv[i + 1]); i += 2
        elif argv[i] == "--runs" and i + 1 < len(argv):
            opts["runs"] = int(argv[i + 1]); i += 2
        elif argv[i] == "--out" and i + 1 < len(argv):
            opts["out"] = argv[i + 1]; i += 2
        else:
            i += 1
    return opts


def timed(fn, runs):
    """Run fn() `runs` times, return the median elapsed milliseconds."""
    samples = []
    for _ in range(runs):
        t0 = time.perf_counter()
        fn()
        samples.append((time.perf_counter() - t0) * 1000.0)
    return statistics.median(samples)


def main():
    opts = parse_args(sys.argv)
    n = max(1, opts["size"])
    runs = max(1, opts["runs"])
    results = []

    doc_name = "BenchmarkDoc"

    # -- new_document ---------------------------------------------------
    def t_new():
        doc = App.newDocument(doc_name)
        App.closeDocument(doc.Name)
    results.append(("new_document", timed(t_new, runs)))

    doc = App.newDocument(doc_name)

    # -- primitive creation ---------------------------------------------
    def t_boxes():
        for i in range(n):
            doc.addObject("Part::Box", "Box%d" % i)
        doc.recompute()
    results.append(("box_create", timed(t_boxes, runs)))

    def t_cylinders():
        for i in range(n):
            c = doc.addObject("Part::Cylinder", "Cyl%d" % i)
            c.Radius = 5.0 + (i % 10)
            c.Height = 10.0 + (i % 20)
        doc.recompute()
    results.append(("cylinder_create", timed(t_cylinders, runs)))

    boxes = [o for o in doc.Objects if o.isDerivedFrom("Part::Box")]
    cylinders = [o for o in doc.Objects if o.isDerivedFrom("Part::Cylinder")]

    # -- boolean operations ----------------------------------------------
    pairs = min(len(boxes), len(cylinders))
    if pairs == 0:
        print("WARNING: no primitives created; skipping boolean tests.")

    def t_fuse():
        for i in range(0, pairs, max(1, pairs // 10)):
            Part.Shape.fuse(boxes[i].Shape, cylinders[i].Shape)
    if pairs:
        results.append(("boolean_fuse", timed(t_fuse, runs)))

    def t_cut():
        for i in range(0, pairs, max(1, pairs // 10)):
            Part.Shape.cut(boxes[i].Shape, cylinders[i].Shape)
    if pairs:
        results.append(("boolean_cut", timed(t_cut, runs)))

    # -- STEP export / import ---------------------------------------------
    step_path = os.path.abspath("benchmark_output.step")

    def t_step_export():
        Import = __import__("Import", fromlist=["export"])
        Import.export(doc.Objects, step_path)
    results.append(("step_export", timed(t_step_export, runs)))

    def t_step_import():
        doc2 = App.newDocument("BenchmarkImport")
        Import = __import__("Import", fromlist=["insert"])
        Import.insert(step_path, doc2.Name)
        App.closeDocument(doc2.Name)
    results.append(("step_import", timed(t_step_import, runs)))

    # -- tessellation -------------------------------------------------------
    def t_tessellate():
        for o in doc.Objects:
            if hasattr(o, "Shape") and not o.Shape.isNull():
                o.Shape.tessellate(0.5)
    results.append(("tessellation", timed(t_tessellate, runs)))

    # -- report -------------------------------------------------------------
    print("")
    print("MechEngi 10X CAD Benchmark Suite — FreeCAD driver (community draft)")
    print("FreeCAD version : %s" % App.Version())
    print("Workload size   : %d   Runs per test: %d (median reported)" % (n, runs))
    print("-" * 56)
    print("%-20s %12s" % ("TEST", "MEDIAN (ms)"))
    print("-" * 56)
    for name, ms in results:
        print("%-20s %12.1f" % (name, ms))
    print("-" * 56)
    print("Self-reported, unverified results. Label them as such if you share")
    print("them. See README.md for limitations.")

    if opts["out"]:
        new_file = not os.path.exists(opts["out"])
        with open(opts["out"], "a", newline="") as f:
            w = csv.writer(f)
            if new_file:
                w.writerow(["test", "median_ms", "size", "runs", "freecad_version"])
            for name, ms in results:
                w.writerow([name, round(ms, 2), n, runs, " ".join(App.Version()[:3])])
        print("Results appended to %s" % opts["out"])

    App.closeDocument(doc.Name)
    if os.path.exists(step_path):
        os.remove(step_path)


main()
