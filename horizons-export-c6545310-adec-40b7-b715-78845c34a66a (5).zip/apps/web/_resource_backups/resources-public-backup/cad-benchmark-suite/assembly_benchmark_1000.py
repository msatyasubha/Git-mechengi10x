#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
MechEngi 10X — Open 1,000-Part Assembly Benchmark (FreeCAD)
===========================================================

Builds a configurable N-part assembly (default: 1,000 parts) from parametric
primitives laid out on a grid, then times the phases that stress a CAD
workstation when working with large assemblies:

  1. assembly_build   — create N parametric solids with placements
  2. full_recompute   — force a full document recompute (the "rebuild")
  3. document_save    — save the assembly as .FCStd
  4. step_export      — export the whole assembly to STEP (AP214)
  5. tessellation     — triangulate every solid (display-mesh cost)

This is a COMMUNITY benchmark harness, not a published result. We publish no
numbers, rankings, or vendor comparisons from it. You run it on your own
hardware, record your own timings, and share them clearly labelled as
self-reported, unverified community results.

MIT License — see LICENSE-NOTES.md. FreeCAD is a trademark of the FreeCAD
project (LGPL-2.1+); this script is an independent community artifact.

Usage (from a shell with FreeCAD's Python console binary on PATH):

    freecadcmd assembly_benchmark_1000.py
    freecadcmd assembly_benchmark_1000.py --parts 1000 --runs 3 --out my_results.csv
    freecadcmd assembly_benchmark_1000.py --parts 500 --skip-export

Or from inside FreeCAD's Python console:

    exec(open("assembly_benchmark_1000.py").read())
"""

import argparse
import csv
import math
import os
import statistics
import time

import FreeCAD as App

try:
    import Import
except ImportError:  # older FreeCAD builds expose it under Part
    Import = None


PHASES = ["assembly_build", "full_recompute", "document_save", "step_export", "tessellation"]


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="MechEngi 10X open assembly benchmark (FreeCAD)")
    parser.add_argument("--parts", type=int, default=1000, help="number of parts in the assembly (default 1000)")
    parser.add_argument("--runs", type=int, default=3, help=" repetitions for recompute/tessellation phases (default 3)")
    parser.add_argument("--out", type=str, default="", help="optional CSV path to append results to")
    parser.add_argument("--skip-export", action="store_true", help="skip the STEP export phase (slow on low-end disks)")
    parser.add_argument("--keep", action="store_true", help="keep the generated .FCStd file instead of deleting it")
    return parser.parse_args(argv)


def build_assembly(doc, parts):
    """Create `parts` parametric solids (alternating boxes / cylinders) on a grid."""
    side = int(math.ceil(math.sqrt(parts)))
    objects = []
    for i in range(parts):
        if i % 2 == 0:
            obj = doc.addObject("Part::Box", "Part%04d_Box" % i)
            obj.Length = 20
            obj.Width = 10
            obj.Height = 5
        else:
            obj = doc.addObject("Part::Cylinder", "Part%04d_Cyl" % i)
            obj.Radius = 4
            obj.Height = 15
            obj.Angle = 360
        x = (i % side) * 30.0
        y = (i // side) * 30.0
        obj.Placement = App.Placement(App.Vector(x, y, 0.0), App.Rotation())
        objects.append(obj)
    return objects


def timed(fn):
    t0 = time.perf_counter()
    fn()
    return (time.perf_counter() - t0) * 1000.0


def main(argv=None):
    args = parse_args(argv)
    parts = max(1, args.parts)
    runs = max(1, args.runs)

    print("MechEngi 10X open assembly benchmark")
    print("  parts=%d  runs=%d  FreeCAD=%s" % (parts, runs, App.Version()))
    print("  Record your CPU, RAM, GPU, OS, and storage in the results template.")
    print("  Share results only as self-reported, unverified community data.\n")

    doc_name = "BenchmarkAssembly"
    doc = App.newDocument(doc_name)

    # Phase 1 — build (single pass; creating objects twice would duplicate work)
    t_build = timed(lambda: build_assembly(doc, parts))
    n_objects = len(doc.Objects)

    # Phase 2 — full forced recompute (repeated `runs` times)
    recompute_times = []
    for _ in range(runs):
        recompute_times.append(
            timed(lambda: doc.recompute(None, True))
        )

    # Phase 3 — document save (single pass; repeated saves hit the OS cache)
    fcstd_path = os.path.abspath("benchmark_assembly_%d.FCStd" % parts)
    t_save = timed(lambda: doc.saveAs(fcstd_path))

    # Phase 4 — STEP export (single pass; very disk- and size-sensitive)
    t_export = None
    if not args.skip_export:
        if Import is None:
            print("  NOTE: Import module unavailable — STEP export skipped.")
        else:
            step_path = os.path.abspath("benchmark_assembly_%d.step" % parts)
            solids = [o for o in doc.Objects if hasattr(o, "Shape")]
            t_export = timed(lambda: Import.export(solids, step_path))

    # Phase 5 — tessellation (repeated `runs` times)
    tess_times = []
    solids = [o for o in doc.Objects if hasattr(o, "Shape") and not o.Shape.isNull()]
    for _ in range(runs):
        def tessellate_all():
            for o in solids:
                o.Shape.tessellate(1.0)
        tess_times.append(timed(tessellate_all))

    rows = [
        ("assembly_build", t_build, 1),
        ("full_recompute", statistics.median(recompute_times), runs),
        ("document_save", t_save, 1),
        ("step_export", t_export if t_export is not None else float("nan"), 1),
        ("tessellation", statistics.median(tess_times), runs),
    ]

    print("\n%-16s %14s %6s" % ("phase", "median_ms", "runs"))
    for name, ms, n in rows:
        print("%-16s %14.1f %6d" % (name, ms, n))
    print("\n  objects created: %d" % n_objects)

    if args.out:
        write_csv(args.out, rows, parts)
        print("  results appended to %s" % args.out)

    # Cleanup
    App.closeDocument(doc.Name)
    if not args.keep:
        for path in (fcstd_path,):
            try:
                os.remove(path)
            except OSError:
                pass
    print("\nDone. Fill in your hardware details and share as SELF-REPORTED, UNVERIFIED results.")


def write_csv(path, rows, parts):
    exists = os.path.exists(path)
    with open(path, "a", newline="") as f:
        writer = csv.writer(f)
        if not exists:
            writer.writerow(["phase", "median_ms", "parts", "freecad_version"])
        for name, ms, _n in rows:
            writer.writerow([name, "%.1f" % ms, parts, ".".join(str(v) for v in App.Version()[:3])])


if __name__ == "__main__":
    main()
