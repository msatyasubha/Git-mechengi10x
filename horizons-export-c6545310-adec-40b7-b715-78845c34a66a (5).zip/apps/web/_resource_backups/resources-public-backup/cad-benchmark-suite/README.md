# MechEngi 10X CAD Benchmark Suite (Community Edition)

A small, transparent, reproducible benchmark harness for measuring CAD kernel
performance on **your own hardware** — using FreeCAD (free and open-source) as
the test driver.

## What this is

- A Python script (`benchmark_freecad.py`) that times common CAD operations
  (document creation, primitive modelling, boolean operations, STEP export,
  STEP import, and tessellation) at a configurable workload size.
- An **open 1,000-part assembly benchmark** (`assembly_benchmark_1000.py`)
  that programmatically builds a configurable N-part assembly (default 1,000)
  from parametric primitives and times the phases that stress a workstation
  on large assemblies: assembly build, full forced recompute (the "rebuild"),
  document save, STEP export, and tessellation of every solid.
- Results templates (`results-template.csv` and
  `assembly-results-template.csv`) for recording your own runs, including
  your CPU, RAM, GPU, OS, and storage.
- A **Shop-Floor Benchmark Framework**
  (`shop-floor-benchmark-framework.md` + `shop-floor-results-template.csv`)
  specifying identical stress tests for weldment modeling, nonlinear FEA on
  a thin-walled housing, 1,000-part BOM generation (eBOM → mBOM), drawing
  creation, full rebuild time, memory usage, and workflow friction — with
  the same honest rule: we have not run it and publish no results.
- This README with instructions, licensing, and verification status.

## What this is NOT

- **Not a published benchmark result.** We publish no numbers, no rankings,
  and no comparisons between CAD products from this suite. We do not claim any
  vendor's product is faster or slower.
- **Not a certified or industry-standard benchmark.** It is a simple,
  transparent timing harness that community members can run and share
  *their own* results, clearly labelled with their own hardware and versions.
- **Not affiliated with or endorsed by any CAD vendor**, including the
  FreeCAD project.

## Requirements

- FreeCAD 0.20 or newer (tested against the 0.20/1.0 Python API surface).
- Python as bundled with FreeCAD (no extra packages needed).
- A few minutes of CPU time; larger `--size` values take longer.

## How to run

From a shell with FreeCAD's Python on PATH:

```bash
# default workload (size 50)
freecadcmd benchmark_freecad.py

# with options
freecadcmd benchmark_freecad.py --size 100 --runs 3 --out results.csv
```

### Open 1,000-part assembly benchmark

```bash
# default: 1,000 parts, 3 repetitions of recompute/tessellation
freecadcmd assembly_benchmark_1000.py

# custom workload, CSV output, skip the (slow) STEP export phase
freecadcmd assembly_benchmark_1000.py --parts 2000 --runs 5 --out my_results.csv --skip-export
```

The assembly is generated entirely by the script (alternating boxes and
cylinders on a grid) — no proprietary or third-party model files are needed
or included. Phases measured:

| Phase | Operation |
|-------|------------|
| `assembly_build` | Create N parametric solids with placements |
| `full_recompute` | Force a full document recompute (rebuild) |
| `document_save` | Save the assembly as `.FCStd` |
| `step_export` | Export the whole assembly to STEP (AP214) |
| `tessellation` | Triangulate every solid (display-mesh cost) |

Or from inside FreeCAD's Python console:

```python
exec(open("benchmark_freecad.py").read())
```

The script prints a table of timings and (optionally) appends rows to a CSV.

## What is measured

| Test | Operation |
|------|-----------|
| `new_document` | Create a new document |
| `box_create` | Create N parametric boxes |
| `cylinder_create` | Create N parametric cylinders |
| `boolean_fuse` | Fuse pairs of solids |
| `boolean_cut` | Cut pairs of solids |
| `step_export` | Export the document to STEP |
| `step_import` | Import the exported STEP back |
| `tessellation` | Triangulate all shapes |

Each test reports the median of `--runs` repetitions in milliseconds.

## Recording and sharing your results

1. Copy `results-template.csv` to your own file.
2. Fill in your hardware (CPU, RAM, OS), FreeCAD version, and the workload
   size you used.
3. Append the rows the script printed.
4. If you share them (forum, community), label them as **self-reported,
   unverified community results** — not as MechEngi 10X benchmarks.

## Licensing / source notes

- `benchmark_freecad.py` and `results-template.csv`: released under the
  **MIT License** (see `LICENSE-NOTES.md`). Free to use, modify, and
  redistribute.
- FreeCAD is a trademark of the FreeCAD project, licensed LGPL-2.1+. This
  suite is an independent community artifact and is not part of FreeCAD.
- No proprietary CAD software is included, required, or benchmarked by us.

## Verification status (honest label)

- **Script status:** draft/community tool — reviewed by the MechEngi 10X
  team for basic correctness, but **not independently audited**.
- **Results status:** none published. Any numbers you see from this suite
  elsewhere are self-reported by whoever ran them — verify by running it
  yourself.
- **Known limitations:** timings include Python interpreter overhead; STEP
  export/import times depend heavily on file size and disk speed; results
  are not comparable across FreeCAD versions or operating systems without
  caution.

---

Generated and maintained by MechEngi 10X. Questions or improvements? Open a
discussion on our community forum.
