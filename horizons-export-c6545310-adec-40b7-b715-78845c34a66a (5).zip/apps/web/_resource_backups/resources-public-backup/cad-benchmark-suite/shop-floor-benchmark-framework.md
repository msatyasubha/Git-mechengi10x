# MechEngi 10X Shop-Floor Benchmark Framework (Community Edition)

A documented, repeatable stress-test framework for comparing CAD/CAE tools on
**shop-floor-relevant workloads** — weldment modeling, nonlinear FEA on a
thin-walled housing, 1,000-part BOM generation, drawing creation, rebuild
time, memory usage, and workflow friction.

## What this is

- A precise workload specification (below) so that anyone can run the
  **identical stress test** across SOLIDWORKS, Fusion 360, Onshape, or any
  other CAD/CAE tool that supports the workload.
- A results template (`shop-floor-results-template.csv`) for recording your
  own runs — timings, peak memory, and friction notes.
- A methodology that separates hard numbers (seconds, MB) from qualitative
  friction notes, so nothing reads as a fabricated score.

## What this is NOT

- **Not a published benchmark result.** We have NOT run these tests and we
  publish no numbers, rankings, or tool-vs-tool comparisons from this
  framework. Any results you record are your own.
- **Not a certified or industry-standard benchmark.** It is a transparent,
  community-run methodology.
- **Not affiliated with or endorsed by any CAD vendor.** Tools that lack a
  workload capability are recorded as `not supported` — never scored down.

## Workload specifications

Run each workload exactly as specified. Record the median of at least 3 runs
on the same machine, with the tool version and hardware noted.

### W1 — Weldment modeling

- Create a 3D sketch frame per the reference geometry (6 m × 2 m × 2 m
  welded frame, 12 members, 4 node types).
- Insert structural members from the tool's structural profile library
  (equal-angle or square tube, nearest equivalent across tools).
- Apply end caps / trim / intersect at every joint.
- Generate the weldment **cut list** (member lengths, angles, quantities).
- Record: total modeling time (s), cut-list generation time (s), peak memory
  (MB), and friction notes (manual fixes, dialogs, unsupported operations).

### W2 — Nonlinear FEA on a thin-walled housing

- Model or import a thin-walled housing (1 mm wall, ~200 mm envelope).
- Set up a nonlinear static study: shell mesh, material nonlinearity
  (bilinear plasticity), large-deflection setting ON, contact on bolted
  flanges.
- Mesh, solve, and post-process (peak stress, convergence history).
- Record: setup time (s), mesh time (s), solve time (s), peak memory (MB),
  convergence failures, and friction notes.
- If the tool has no nonlinear capability in your license, record
  `not supported` — do not substitute a linear run.

### W3 — 1,000-part BOM generation (eBOM) and mBOM transformation

- Generate a 1,000-part assembly (see `assembly_benchmark_1000.py` for a
  FreeCAD reference generator; replicate the same structure in your tool).
- Export the engineering BOM (eBOM) with part numbers and revisions.
- Transform the eBOM into a manufacturing BOM (mBOM): apply make-vs-buy
  classification, phantom sub-assembly handling, and unit-of-measure checks.
- Record: assembly build time (s), eBOM export time (s), mBOM transformation
  time (s), peak memory (MB), and friction notes.

### W4 — Drawing creation

- Create a drawing of the W1 weldment or the W3 assembly: 3 standard views,
  1 section view, BOM table, and at least 3 GD&T feature-control frames.
- Record: total drawing creation time (s), number of manual dimension fixes,
  and friction notes (view generation failures, table formatting work).

### W5 — Full rebuild time

- Force a full rebuild / recompute of the W3 assembly after a parameter
  change on the root component.
- Record: rebuild time (s), peak memory (MB), and any errors or warnings.

### W6 — Memory usage

- Record peak resident memory (MB) for every phase above. Use your OS
  process monitor; note the measurement method in the results file.

### W7 — Workflow friction (qualitative, not a score)

- For each workload, note friction honestly: click count where practical,
  dialogs, workarounds, crashes, and anything the tool could not do.
- Friction notes are qualitative observations — they are NOT converted into
  a numeric score or ranking by us.

## Methodology rules

1. Same hardware, OS, and storage for every tool compared in one session.
2. Median of at least 3 runs per workload; discard the first warm-up run.
3. Record exact tool version and license tier — capabilities differ by tier.
4. `not supported` is a valid, honest result; never substitute a different
   workload to avoid it.
5. Never extrapolate or estimate a number you did not measure.

## Recording and sharing your results

1. Copy `shop-floor-results-template.csv` to your own file.
2. Fill in hardware, tool, version, and per-workload medians and memory.
3. If you share them, label them **self-reported, unverified community
  results** — not as MechEngi 10X benchmarks.

## Verification status (honest label)

- **Framework status:** published specification — reviewed by the MechEngi
  10X team for internal consistency, but **not run by us**.
- **Results status:** none published. We do not claim any tool is faster or
  slower on these workloads.
- **Known limitations:** timings include OS and interpreter overhead; cloud
  tools (e.g., Onshape) depend on network and server load; results are not
  comparable across hardware without normalization.

## Licensing

Released under the **MIT License** (see `LICENSE-NOTES.md`). Free to use,
modify, and redistribute. All product names are trademarks of their
respective owners; use here is descriptive only.
