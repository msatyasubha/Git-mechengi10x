# License notes — MechEngi 10X CAD Benchmark Suite (Community Edition)

## Code and templates

`benchmark_freecad.py` and `results-template.csv` are released under the
**MIT License**:

> Copyright (c) 2026 MechEngi 10X
>
> Permission is hereby granted, free of charge, to any person obtaining a copy
> of this software and associated documentation files (the "Software"), to
> deal in the Software without restriction, including without limitation the
> rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
> sell copies of the Software, and to permit persons to whom the Software is
> furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in
> all copies or substantial portions of the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
> IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
> FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
> LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
> FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
> DEALINGS IN THE SOFTWARE.

## Third-party software

- **FreeCAD** (https://www.freecad.org) — LGPL-2.1+, a trademark of the
  FreeCAD project. This suite is an independent community artifact; it is
  not part of FreeCAD and is not endorsed by the FreeCAD project.
- No proprietary CAD software is included in, required by, or distributed
  with this suite.

## Trademarks

All product names mentioned in this suite are trademarks of their respective
owners. Their use here is descriptive only, and implies no affiliation with,
or endorsement by, those owners.

## Verification status

This suite is a **community draft**: reviewed by the MechEngi 10X team for
basic correctness, not independently audited. No benchmark results are
published by us from this suite. Any results shared by community members are
self-reported and unverified.
