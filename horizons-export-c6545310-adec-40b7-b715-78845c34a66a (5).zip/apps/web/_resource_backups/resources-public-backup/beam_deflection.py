"""
Simply-supported beam deflection under a central point load.

Formula (Euler-Bernoulli, small deflection, prismatic beam):
    delta_max = P * L**3 / (48 * E * I)
    M_max     = P * L / 4   (bending moment at midspan)

Units: keep them consistent. Example below uses N, m, Pa (so E in Pa, I in m^4).

Source: Gere & Timoshenko, Mechanics of Materials.
Verify against your design code before sign-off.
"""

def beam_deflection_point_load(P, L, E, I):
    """Return (max_deflection_m, max_moment_Nm) for a simply-supported beam
    with a central point load P.

    Parameters
    ----------
    P : float  -> point load (N)
    L : float  -> span (m)
    E : float  -> Young's modulus (Pa)
    I : float  -> second moment of area (m^4)
    """
    if min(P, L, E, I) <= 0:
        raise ValueError("P, L, E, I must all be positive.")
    delta = (P * L**3) / (48 * E * I)
    moment = (P * L) / 4
    return delta, moment


if __name__ == "__main__":
    # Example: 1000 N load on a 1 m steel beam, E=200e9 Pa, I=1e-8 m^4
    d, M = beam_deflection_point_load(1000.0, 1.0, 200e9, 1e-8)
    print(f"Max deflection: {d:.6e} m")
    print(f"Max bending moment: {M:.3f} N.m")
