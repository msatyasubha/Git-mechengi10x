# Exporting Calculator Results to CAD & PLM

MechEngi 10X calculators export results in three formats: **CSV**, **JSON**, and
**PDF** (print-ready calculation record). This guide shows how to move those
exports into common engineering workflows.

## CSV → Spreadsheet / PLM note
1. Click **CSV** on any calculator result.
2. Open the downloaded `.csv` in Excel / LibreOffice Calc / Google Sheets.
3. Attach the file (or paste the rows) as a calculation note in your PLM system
   (Windchill, Teamcenter, Enovia, Aras) against the relevant part/ECO.
4. Keep the `# Generated` timestamp row so the note is traceable.

## JSON → API / automation
1. Click **JSON** to download a structured payload.
2. The payload includes `calculator`, `inputs`, `results`, `formula`, `source`,
   and a `disclaimer` field.
3. POST it to an internal API, a webhook, or an automation tool (n8n, Make,
   Zapier) to file it automatically. See the Automation Pipeline guide.

## PDF → design sign-off
1. Click **PDF** to open a print-ready calculation record.
2. In the print dialog, choose **Save as PDF**.
3. Attach the PDF to your design review package. The record includes the
   formula, plain-English explanation, source, and a verification disclaimer.

## STEP / IGES note
Calculator outputs are scalar engineering quantities (deflection, stress, flow
rate), not geometry. They are not exported as STEP/IGES. To document a result
against a CAD model, attach the CSV/JSON/PDF as a note on the part in your PLM
or CAD system (most CAD tools support arbitrary file attachments on parts).

---
MechEngi 10X — integration guide. Verify against your organisation's PLM and
document-control procedures.
