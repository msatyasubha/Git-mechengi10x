# The Complete CAD-to-ERP Integration Checklist for Manufacturing Teams

A practical, vendor-neutral checklist for planning a CAD/design-tool to ERP
data bridge — whether you build it on n8n, Make, Zapier, or a custom REST API
service. Work through it with your engineering, IT, and operations leads before
writing a single line of integration code.

> MechEngi 10X provides this checklist as reference architecture guidance.
> It is not a live integration, and it is not a substitute for your
> organisation's IT security and change-management review.

---

## 1. Scope & Objectives

- [ ] Name the exact business outcome (e.g., "quote requests from the web form
      become ERP opportunities without manual re-entry").
- [ ] List every data object that must move (leads, customers, parts, BOMs,
      opportunities, projects).
- [ ] Define what does NOT move (avoid scope creep into full PLM sync).
- [ ] Identify the systems of record: which database owns each field.
- [ ] Agree the success metric (hours saved per week, error rate, lead
      response time).

## 2. Middleware Gateway Selection

- [ ] Compare options against your constraints:
  - **n8n** — self-hostable, code-friendly, per-execution pricing model.
  - **Make** — visual scenarios, generous operation-based pricing.
  - **Zapier** — fastest to set up, largest app catalogue, highest per-task cost.
  - **Custom REST API (Node.js / FastAPI)** — full control, own the retry and
    audit logic, needs a hosting and maintenance owner.
- [ ] Confirm the platform supports your ERP's API (native connector, generic
      HTTP module, or custom code step).
- [ ] Check webhook ingress support (HTTPS endpoint, signature verification).
- [ ] Check OAuth 2.0 support (authorization-code flow, token refresh).
- [ ] Estimate monthly operation/task volume and cost at that volume.
- [ ] Decide hosting: cloud tenant vs. self-hosted (data residency, VPN access
      to on-premise ERP).

## 3. Webhook Listener Design

- [ ] Expose a dedicated HTTPS endpoint per source system (do not multiplex).
- [ ] Verify request authenticity (HMAC signature or shared secret header).
- [ ] Validate payload schema BEFORE processing (reject early, log the reason).
- [ ] Respond 2xx immediately; process asynchronously if work takes > 5 s.
- [ ] Add idempotency keys so duplicate deliveries are safely ignored.
- [ ] Rate-limit the endpoint and set a maximum payload size.

## 4. OAuth 2.0 Authentication

- [ ] Use the authorization-code flow with PKCE where the ERP supports it.
- [ ] Store tokens in a secrets manager — never in code, env files in git, or
      low-code scenario exports.
- [ ] Automate refresh-token rotation before expiry.
- [ ] Scope tokens to the minimum API permissions needed.
- [ ] Plan for token revocation (what happens to running syncs?).
- [ ] Document the re-authorisation runbook for credential expiry.

## 5. Data Schema Mapping

- [ ] Build an explicit field-mapping table. Example:

  | Web parameter        | ERP field          | Notes                          |
  | -------------------- | ------------------ | ------------------------------ |
  | `company_name`       | `Customer_Account` | Deduplicate against existing   |
  | `selected_cad_tool`  | `Asset_Tag`        | Controlled vocabulary          |
  | `project_budget`     | `Opportunity_Value`| Currency + decimal validation  |

- [ ] Define units and currency handling at the boundary (convert once, store
      canonical).
- [ ] Handle controlled vocabularies (map free-text to ERP picklists).
- [ ] Decide required vs. optional fields, and default values.
- [ ] Define the matching/deduplication rule (email? tax ID? exact name?).
- [ ] Version the mapping table and review it on every ERP upgrade.

### 5b. eBOM → mBOM Transformation, Part Numbering & Revision Control

- [ ] Decide the part numbering scheme once — intelligent, semi-intelligent
      (class + sequence), or sequential with attributes as data — and enforce
      it at the boundary. A CAD property that does not match the scheme is
      rejected and routed for manual numbering, never auto-invented.
- [ ] Transform the eBOM (engineering view) into the mBOM (manufacturing
      view): design groupings that are never built as units become phantom /
      non-stocked items; do not mirror the CAD assembly tree 1:1.
- [ ] Classify every item make-vs-buy at the boundary, and validate the unit
      of measure on every BOM line (each vs kg vs m) before the ERP write.
- [ ] Add manufacturing-only items (consumables, process steps, packaging)
      in the mBOM layer — they do not exist in the CAD tree.
- [ ] Map every eBOM revision to an ERP revision with an ECO/ECN reference.
- [ ] Lock released revisions: the bridge may create a new revision, but
      never overwrite a released one.
- [ ] Carry where-used / affected-items information with every revision
      change so planning sees what a bump touches.
- [ ] Version the eBOM → mBOM transformation table like any other mapping
      contract, and review it on every CAD or ERP upgrade.

## 6. Error Handling & Retries

- [ ] Classify errors: transient (retry) vs. permanent (route to a human).
- [ ] Exponential backoff with jitter; cap retries (e.g., 5 attempts).
- [ ] Dead-letter queue for records that exhaust retries.
- [ ] Never silently drop a record — every failure is visible somewhere.
- [ ] Reconciliation job: compare source count vs. ERP count daily.

## 7. Audit Logging & Alerting

- [ ] Log every request: timestamp, source, payload hash, outcome, latency.
- [ ] Retain logs per your compliance policy (GDPR/ISO 27001 if applicable).
- [ ] Alert on: ERP API failures, auth (401/403) errors, schema validation
      rejects, and queue depth thresholds.
- [ ] Choose alert channels: Slack webhook and/or email — with an on-call owner.
- [ ] Weekly summary report of synced, failed, and manually fixed records.

## 8. Security & Compliance

- [ ] Encrypt in transit (TLS) and at rest.
- [ ] Least-privilege API credentials for the integration user.
- [ ] PII minimisation: only move fields the ERP actually needs.
- [ ] Data processing agreement with any SaaS middleware vendor.
- [ ] Penetration-test the public webhook endpoint before go-live.

## 9. Testing & Rollout

- [ ] Test against a sandbox ERP instance, never production first.
- [ ] Test: happy path, malformed payload, duplicate delivery, ERP downtime,
      token expiry mid-run, oversized payload.
- [ ] Pilot with one team for two weeks before full rollout.
- [ ] Document rollback: how to disable the bridge without losing data.
- [ ] Assign a named owner for monitoring and quarterly review.

---

## Quick Reference: Failure Modes to Plan For

| Failure              | Symptom                    | First response              |
| -------------------- | -------------------------- | --------------------------- |
| ERP auth failure     | 401/403 in logs            | Re-authorise, check scopes  |
| Schema drift         | Validation rejects spike   | Re-map fields, version bump |
| Silent drops         | Counts don't reconcile     | Check dead-letter queue      |
| Duplicate records    | Repeated customers         | Fix idempotency/matching key |

---

MechEngi 10X — reference architecture checklist. Verify every item against your
ERP vendor's API documentation and your organisation's IT policies before use.
