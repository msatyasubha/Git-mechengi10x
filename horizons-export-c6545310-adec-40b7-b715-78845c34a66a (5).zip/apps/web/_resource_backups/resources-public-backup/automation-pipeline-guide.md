# Automation Pipeline Patterns for Calculator JSON

MechEngi 10X calculators emit a stable JSON payload. This guide shows reference
patterns for piping it into automation tools.

## Payload shape
```json
{
  "platform": "MechEngi 10X",
  "calculator": "Beam Deflection (simply-supported, central point load)",
  "generatedAt": "2026-09-09T00:00:00.000Z",
  "inputs": { "P": "1000", "L": "1", "E": "200000", "I": "1e-8" },
  "results": { "delta": 1.04e-5, "moment": 250 },
  "formula": "delta_max = P*L^3 / (48*E*I)",
  "source": "Gere & Timoshenko, Mechanics of Materials.",
  "disclaimer": "Verify against applicable design codes before sign-off."
}
```

## n8n
- **Webhook node** receives the POST (or use the **Read Binary File** node on the
  downloaded JSON).
- **Set node** maps `results.delta` and `results.moment` to your destination
  fields.
- **HTTP Request / Google Sheets / Postgres** node files the record.

## Make (Integromat)
- **Webhook** trigger → **JSON Parse** → **Add a Row** (Sheets) or **Create a
  record** (Airtable / Notion).

## Zapier
- **Webhooks by Zapier** catch hook → **Formatter** parse JSON → **Google
  Sheets** create row.

## Where to validate units
Always validate units **before** downstream use. The payload does not carry a
unit schema — confirm the calculator's stated units (shown in the UI and in the
`formula`/`source` fields) match your destination system's expectations. Reject
or flag records where `inputs` contain empty or non-numeric strings.

---
MechEngi 10X — integration guide. Patterns are reference only; adapt to your
automation platform's current node set.
