import { Buffer } from 'node:buffer';
import Pocketbase from 'pocketbase';

/**
 * Auth for Integrated AI that responds with the correct status + message
 * instead of falling through to the generic 500 error middleware.
 */
export async function integratedAiAuth(req, res, next) {
	const token = req.headers.authorization?.split(' ')?.[1];

	if (!token) {
		return res.status(401).json({
			message: 'Please sign in or create an account to use the chat.',
		});
	}

	try {
		const base64Decoded = Buffer.from(token, 'base64').toString('utf-8');
		const tokenData = JSON.parse(base64Decoded);

		if (!tokenData?.token || !tokenData?.record) {
			return res.status(401).json({
				message: 'Your session has expired. Please sign in again.',
			});
		}

		const pocketbaseClient = new Pocketbase('http://localhost:8090');
		pocketbaseClient.authStore.save(tokenData.token, tokenData.record);

		const collection =
			tokenData.record.collectionName ||
			tokenData.record.collectionId ||
			'users';

		const refreshed = await pocketbaseClient.collection(collection).authRefresh();

		if (!refreshed.record.verified) {
			return res.status(403).json({
				message:
					'Please verify your email to use the chat. Check your inbox for the verification link.',
				code: 'email_not_verified',
			});
		}

		req.pocketbaseUserId = refreshed.record.id;
		return next();
	} catch {
		return res.status(401).json({
			message: 'Your session has expired. Please sign in again.',
		});
	}
}
