import { Router } from 'express';
import { ContentBlockType, stream, uploadImagesToPocketBase } from '../api/integrated-ai.js';
import { SystemPrompt } from '../constants/prompts.js';
import { uploadFiles } from '../middleware/file-upload.js';
import { integratedAiRateLimit } from '../middleware/integrated-ai-rate-limit.js';
import { integratedAiAuth } from '../middleware/integrated-ai-auth.js';
import logger from '../utils/logger.js';

const router = Router();

// Login-required: custom auth responds with real 401/403 messages (not generic 500).
router.use(integratedAiAuth);

router.post('/stream', integratedAiRateLimit, uploadFiles({
	allowedMimeTypes: [
		'image/jpeg',
		'image/png',
		'image/webp',
	],
	fieldName: 'images',
}), async (req, res) => {
	try {
		const { message } = req.body;

		if (!message) {
			return res.status(400).json({ message: 'message is required' });
		}

		if (typeof message !== 'string') {
			return res.status(400).json({ message: 'message must be a string' });
		}

		let parsedMessage;
		try {
			parsedMessage = JSON.parse(message);
		} catch {
			return res.status(400).json({ message: 'message must be valid JSON' });
		}

		if (!Array.isArray(parsedMessage)) {
			return res.status(400).json({ message: 'message must be an array of content blocks' });
		}

		if (req.files?.length > 0) {
			const imageUrls = await uploadImagesToPocketBase({ images: req.files });
			imageUrls.forEach((url) => {
				parsedMessage.push({ type: ContentBlockType.Image, image: url });
			});
		}

		const sseStream = await stream({
			userId: req.pocketbaseUserId,
			systemPrompt: SystemPrompt,
			userMessage: parsedMessage,
		});

		res.status(200);
		res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
		res.setHeader('Cache-Control', 'no-cache, no-transform');
		res.setHeader('Connection', 'keep-alive');
		res.setHeader('X-Accel-Buffering', 'no');
		// Disable Express/proxy response buffering so tokens reach the browser immediately.
		if (typeof res.flushHeaders === 'function') {
			res.flushHeaders();
		}
		if (res.socket && typeof res.socket.setNoDelay === 'function') {
			res.socket.setNoDelay(true);
		}

		const onChunk = (chunk) => {
			if (res.writableEnded || res.destroyed) return;
			res.write(chunk);
			// compression / some proxies expose flush — call when present
			if (typeof res.flush === 'function') {
				res.flush();
			}
		};

		sseStream.on('data', onChunk);
		sseStream.on('end', () => {
			if (!res.writableEnded) {
				res.end();
			}
		});
		sseStream.on('error', (streamErr) => {
			logger.error('integrated-ai upstream stream error', streamErr);
			if (!res.headersSent) {
				return;
			}
			try {
				res.write(`data: ${JSON.stringify({ type: 'error', data: { content: streamErr.message || 'Stream interrupted.' } })}\n\n`);
			} catch {
				// ignore
			}
			if (!res.writableEnded) {
				res.end();
			}
		});

		res.on('close', () => {
			try {
				sseStream.off('data', onChunk);
				sseStream.destroy();
			} catch {
				// ignore
			}
		});
	} catch (err) {
		logger.error('integrated-ai stream failed', err);
		if (res.headersSent) {
			try {
				res.write(`data: ${JSON.stringify({ type: 'error', data: { content: err.message || 'Advisor temporarily unavailable.' } })}\n\n`);
				res.end();
			} catch {
				// ignore
			}
			return;
		}
		return res.status(503).json({
			message: err.message || 'The AI Advisor is temporarily unavailable. Please try again in a moment.',
		});
	}
});

export default router;
