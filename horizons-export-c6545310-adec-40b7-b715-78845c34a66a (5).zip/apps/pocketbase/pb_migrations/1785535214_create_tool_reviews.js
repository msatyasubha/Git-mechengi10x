/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    const collection = new Collection({
      type: "base",
      name: "tool_reviews",
      listRule: "",
      viewRule: "",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && @request.auth.id = owner",
      deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
      fields: [
        { name: "tool_slug", type: "text", required: true, max: 100 },
        { name: "rating", type: "number", required: true, min: 1, max: 5, onlyInt: true },
        { name: "title", type: "text", max: 200 },
        { name: "body", type: "text", max: 2000 },
        {
          name: "owner",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: users.id,
          cascadeDelete: true,
        },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
      indexes: [
        "CREATE INDEX idx_tool_reviews_slug ON tool_reviews (tool_slug)",
        "CREATE UNIQUE INDEX idx_tool_reviews_owner_slug ON tool_reviews (owner, tool_slug)",
      ],
    });
    app.save(collection);
  },
  (app) => {
    const collection = app.findCollectionByNameOrId("tool_reviews");
    app.delete(collection);
  }
);
