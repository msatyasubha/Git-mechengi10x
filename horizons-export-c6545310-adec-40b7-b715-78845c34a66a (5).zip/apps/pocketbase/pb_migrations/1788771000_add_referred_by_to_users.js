/// <reference path="../pb_data/types.d.ts" />

// Adds a `referred_by` text field to the `users` auth collection so a
// referral code captured on the landing page can be stored on the new
// account at signup. A PocketBase hook then attributes the signup to the
// matching affiliate (see pb_hooks/affiliate-conversion.pb.js).

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    if (users.fields.getByName("referred_by")) return;

    users.fields.add(
      new TextField({
        name: "referred_by",
        required: false,
        max: 50,
      }),
    );
    app.save(users);
  },
  (app) => {
    try {
      const users = app.findCollectionByNameOrId("users");
      users.fields.removeByName("referred_by");
      app.save(users);
    } catch (e) {
      if (e.message.includes("no rows in result set")) {
        console.log("users collection not found, skipping revert");
        return;
      }
      throw e;
    }
  },
);
