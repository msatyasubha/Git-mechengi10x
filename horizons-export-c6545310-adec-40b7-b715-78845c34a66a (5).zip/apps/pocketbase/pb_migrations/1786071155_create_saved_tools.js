/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    const collection = new Collection({
      type: "base",
      name: "saved_tools",
      listRule: "@request.auth.id != '' && @request.auth.id = owner",
      viewRule: "@request.auth.id != '' && @request.auth.id = owner",
      createRule: "@request.auth.id != ''",
      updateRule: null,
      deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
      fields: [
        { name: "tool_slug", type: "text", required: true, max: 200 },
        { name: "tool_type", type: "select", required: true, maxSelect: 1, values: ["tool", "ai-profile", "review"] },
        {
          name: "owner",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: users.id,
          cascadeDelete: true,
        },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
      ],
      indexes: [
        "CREATE UNIQUE INDEX idx_saved_tools_owner_slug ON saved_tools (owner, tool_slug)",
      ],
    });
    app.save(collection);
  },
  (app) => {
    const c = app.findCollectionByNameOrId("saved_tools");
    app.delete(c);
  }
);
