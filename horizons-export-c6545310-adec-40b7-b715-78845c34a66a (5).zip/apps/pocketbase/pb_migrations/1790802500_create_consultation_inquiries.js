/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // Public consultation booking submissions — anyone can submit, only
    // admins read. Used by the CAD-to-ERP integration consultation CTA.
    const inquiries = new Collection({
      type: "base",
      name: "consultation_inquiries",
      listRule: null,
      viewRule: null,
      createRule: "",
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: "company_name", type: "text", required: true, max: 200 },
        { name: "contact_name", type: "text", required: true, max: 200 },
        { name: "email", type: "email", required: true },
        { name: "phone", type: "text", max: 50 },
        { name: "cad_tools", type: "text", max: 500 },
        { name: "erp_system", type: "text", max: 500 },
        { name: "integration_platform", type: "select", maxSelect: 1, values: ["n8n", "make", "zapier", "custom-rest-api", "undecided"] },
        { name: "message", type: "text", max: 3000 },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
      ],
    });
    app.save(inquiries);
  },
  (app) => {
    try {
      app.delete(app.findCollectionByNameOrId("consultation_inquiries"));
    } catch (_) {}
  },
);
