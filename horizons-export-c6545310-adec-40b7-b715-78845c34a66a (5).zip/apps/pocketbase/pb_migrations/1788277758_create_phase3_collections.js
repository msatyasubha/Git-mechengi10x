/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    // ── event_registrations ──────────────────────────────────────────
    // Public create (anyone can register), owner can read their own,
    // nobody can update/delete via REST (managed server-side / by admin).
    let eventRegs;
    try {
      eventRegs = app.findCollectionByNameOrId("event_registrations");
    } catch (_) {
      eventRegs = new Collection({
        type: "base",
        name: "event_registrations",
        listRule: "@request.auth.id != '' && @request.auth.id = owner",
        viewRule: "@request.auth.id != '' && @request.auth.id = owner",
        createRule: "",
        updateRule: null,
        deleteRule: null,
        fields: [
          { name: "event_slug", type: "text", required: true, max: 200 },
          { name: "event_title", type: "text", max: 300 },
          { name: "full_name", type: "text", required: true, max: 200 },
          { name: "email", type: "email", required: true },
          { name: "company", type: "text", max: 200 },
          { name: "role", type: "text", max: 200 },
          { name: "consent", type: "bool" },
          {
            name: "owner",
            type: "relation",
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
      });
      app.save(eventRegs);
    }

    // ── affiliates ───────────────────────────────────────────────────
    // One record per user who opts into the affiliate program. Owner-scoped.
    let affiliates;
    try {
      affiliates = app.findCollectionByNameOrId("affiliates");
    } catch (_) {
      affiliates = new Collection({
        type: "base",
        name: "affiliates",
        listRule: "@request.auth.id != '' && @request.auth.id = owner",
        viewRule: "@request.auth.id != '' && @request.auth.id = owner",
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && @request.auth.id = owner",
        deleteRule: null,
        fields: [
          { name: "referral_code", type: "text", required: true, max: 50 },
          { name: "status", type: "select", maxSelect: 1, values: ["pending", "active", "paused"] },
          { name: "total_clicks", type: "number" },
          { name: "total_signups", type: "number" },
          { name: "total_conversions", type: "number" },
          { name: "pending_balance", type: "number" },
          { name: "paid_out", type: "number" },
          { name: "currency", type: "text", max: 10 },
          {
            name: "owner",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: [
          "CREATE UNIQUE INDEX idx_affiliates_code ON affiliates (referral_code)",
        ],
      });
      app.save(affiliates);
    }

    // ── affiliate_clicks ─────────────────────────────────────────────
    // Anonymous create (tracking pixel / link click), nobody reads via REST
    // except admin/server-side.
    let affClicks;
    try {
      affClicks = app.findCollectionByNameOrId("affiliate_clicks");
    } catch (_) {
      affClicks = new Collection({
        type: "base",
        name: "affiliate_clicks",
        listRule: null,
        viewRule: null,
        createRule: "",
        updateRule: null,
        deleteRule: null,
        fields: [
          { name: "referral_code", type: "text", required: true, max: 50 },
          { name: "tool_slug", type: "text", max: 200 },
          { name: "source", type: "text", max: 100 },
          { name: "ip_hash", type: "text", max: 100 },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        ],
        indexes: [
          "CREATE INDEX idx_aff_clicks_code ON affiliate_clicks (referral_code)",
        ],
      });
      app.save(affClicks);
    }

    // ── referrals ────────────────────────────────────────────────────
    // Tracks a referred signup/conversion. Owner = the referring affiliate.
    let referrals;
    try {
      referrals = app.findCollectionByNameOrId("referrals");
    } catch (_) {
      referrals = new Collection({
        type: "base",
        name: "referrals",
        listRule: "@request.auth.id != '' && @request.auth.id = owner",
        viewRule: "@request.auth.id != '' && @request.auth.id = owner",
        createRule: "@request.auth.id != ''",
        updateRule: null,
        deleteRule: null,
        fields: [
          { name: "referral_code", type: "text", required: true, max: 50 },
          { name: "referred_email", type: "email" },
          { name: "event_type", type: "select", maxSelect: 1, values: ["signup", "course_sale", "membership_sale"] },
          { name: "reward_amount", type: "number" },
          { name: "status", type: "select", maxSelect: 1, values: ["pending", "confirmed", "paid"] },
          {
            name: "owner",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        ],
      });
      app.save(referrals);
    }

    // ── user_badges ──────────────────────────────────────────────────
    // Gamification: badges earned by a user. Owner-scoped reads.
    let userBadges;
    try {
      userBadges = app.findCollectionByNameOrId("user_badges");
    } catch (_) {
      userBadges = new Collection({
        type: "base",
        name: "user_badges",
        listRule: "@request.auth.id != '' && @request.auth.id = owner",
        viewRule: "@request.auth.id != '' && @request.auth.id = owner",
        createRule: "@request.auth.id != ''",
        updateRule: null,
        deleteRule: null,
        fields: [
          { name: "badge_id", type: "text", required: true, max: 50 },
          { name: "points", type: "number" },
          {
            name: "owner",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        ],
        indexes: [
          "CREATE UNIQUE INDEX idx_user_badges_owner_badge ON user_badges (owner, badge_id)",
        ],
      });
      app.save(userBadges);
    }

    // ── memberships ──────────────────────────────────────────────────
    // Tracks a user's active membership tier. Owner-scoped. Real recurring
    // billing is handled by the subscriptions infrastructure; this collection
    // records the tier and status for dashboard display.
    let memberships;
    try {
      memberships = app.findCollectionByNameOrId("memberships");
    } catch (_) {
      memberships = new Collection({
        type: "base",
        name: "memberships",
        listRule: "@request.auth.id != '' && @request.auth.id = owner",
        viewRule: "@request.auth.id != '' && @request.auth.id = owner",
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.id != '' && @request.auth.id = owner",
        deleteRule: null,
        fields: [
          { name: "plan", type: "select", required: true, maxSelect: 1, values: ["basic", "pro", "enterprise"] },
          { name: "status", type: "select", maxSelect: 1, values: ["trialing", "active", "past_due", "canceled"] },
          { name: "started_at", type: "date" },
          { name: "renews_at", type: "date" },
          { name: "canceled_at", type: "date" },
          {
            name: "owner",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
      });
      app.save(memberships);
    }
  },
  (app) => {
    const names = [
      "event_registrations",
      "affiliates",
      "affiliate_clicks",
      "referrals",
      "user_badges",
      "memberships",
    ];
    for (const n of names) {
      try {
        app.delete(app.findCollectionByNameOrId(n));
      } catch (_) {}
    }
  },
);
