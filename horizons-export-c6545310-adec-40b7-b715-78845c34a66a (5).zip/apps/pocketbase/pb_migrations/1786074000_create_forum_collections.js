/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    // Forum threads — public read, auth to create, owner to mutate.
    const threads = new Collection({
      type: "base",
      name: "forum_threads",
      listRule: "",
      viewRule: "",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && @request.auth.id = owner",
      deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
      fields: [
        { name: "title", type: "text", required: true, max: 200 },
        { name: "body", type: "text", required: true, max: 5000 },
        { name: "category", type: "select", maxSelect: 1, values: ["general", "ai-tools", "cad", "simulation", "automation", "management", "jobs", "courses"] },
        { name: "pinned", type: "bool" },
        { name: "views", type: "number" },
        {
          name: "owner",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: users.id,
          cascadeDelete: true,
        },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(threads);

    // Forum posts (replies) — public read, auth to create, owner to delete.
    const posts = new Collection({
      type: "base",
      name: "forum_posts",
      listRule: "",
      viewRule: "",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && @request.auth.id = owner",
      deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
      fields: [
        { name: "body", type: "text", required: true, max: 5000 },
        {
          name: "thread",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: threads.id,
          cascadeDelete: true,
        },
        {
          name: "owner",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: users.id,
          cascadeDelete: true,
        },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(posts);
  },
  (app) => {
    try {
      app.delete(app.findCollectionByNameOrId("forum_posts"));
    } catch (_) {}
    try {
      app.delete(app.findCollectionByNameOrId("forum_threads"));
    } catch (_) {}
  },
);
