/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // Public enterprise quote / VAR introduction requests for heavy CAD & FEA
    // tools. Anyone can submit; only admins (superusers) can read. Same
    // lead-capture pattern as consultation_inquiries.
    const inquiries = new Collection({
      type: "base",
      name: "enterprise_quote_inquiries",
      listRule: null,
      viewRule: null,
      createRule: "",
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: "company_name", type: "text", required: true, max: 200 },
        { name: "contact_name", type: "text", required: true, max: 200 },
        { name: "email", type: "email", required: true },
        { name: "phone", type: "text", max: 50 },
        { name: "tool_slug", type: "text", max: 100 },
        { name: "tool_name", type: "text", max: 200 },
        { name: "seats", type: "text", max: 50 },
        { name: "timeline", type: "text", max: 100 },
        { name: "message", type: "text", max: 3000 },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
      ],
    });
    app.save(inquiries);
  },
  (app) => {
    try {
      app.delete(app.findCollectionByNameOrId("enterprise_quote_inquiries"));
    } catch (_) {}
  },
);
