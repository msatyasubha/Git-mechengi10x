/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    // Public inquiry form submissions — anyone can submit, only admins read.
    const inquiries = new Collection({
      type: "base",
      name: "sponsor_inquiries",
      listRule: null,
      viewRule: null,
      createRule: "",
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: "company_name", type: "text", required: true, max: 200 },
        { name: "contact_name", type: "text", required: true, max: 200 },
        { name: "email", type: "email", required: true },
        { name: "phone", type: "text", max: 50 },
        { name: "website", type: "url", max: 500 },
        { name: "company_description", type: "text", max: 2000 },
        { name: "interested_packages", type: "text", max: 500 },
        { name: "budget_range", type: "text", max: 100 },
        { name: "message", type: "text", max: 3000 },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
      ],
    });
    app.save(inquiries);

    // Admin-managed active sponsors. Owner relation gives a sponsor contact
    // dashboard access to their own record only.
    const sponsors = new Collection({
      type: "base",
      name: "sponsors",
      listRule: "@request.auth.id != '' && @request.auth.id = owner",
      viewRule: "@request.auth.id != '' && @request.auth.id = owner",
      createRule: null,
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: "company_name", type: "text", required: true, max: 200 },
        { name: "contact_name", type: "text", max: 200 },
        { name: "email", type: "email" },
        { name: "phone", type: "text", max: 50 },
        { name: "package_type", type: "select", maxSelect: 1, values: ["featured-tool", "exclusive-review", "webinar-sponsorship"] },
        { name: "investment_amount", type: "number" },
        { name: "start_date", type: "date" },
        { name: "end_date", type: "date" },
        { name: "payment_status", type: "select", maxSelect: 1, values: ["pending", "paid", "overdue", "refunded"] },
        { name: "performance_metrics", type: "json", maxSize: 5000000 },
        { name: "renewal_status", type: "select", maxSelect: 1, values: ["new", "active", "renewed", "churned"] },
        {
          name: "owner",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: users.id,
          cascadeDelete: true,
        },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(sponsors);
  },
  (app) => {
    try {
      app.delete(app.findCollectionByNameOrId("sponsor_inquiries"));
    } catch (_) {}
    try {
      app.delete(app.findCollectionByNameOrId("sponsors"));
    } catch (_) {}
  },
);
