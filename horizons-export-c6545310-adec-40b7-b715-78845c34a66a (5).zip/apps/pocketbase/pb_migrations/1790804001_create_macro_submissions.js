/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // Community macro & script submissions for the automation repository.
    // Anyone can submit, but nothing is publicly listable: submissions are
    // reviewed by our team before any publication, and the status field is
    // locked so a submitter cannot self-approve.
    const submissions = new Collection({
      type: "base",
      name: "macro_submissions",
      listRule: null,
      viewRule: null,
      createRule:
        "@request.body.status:isset = false || @request.body.status = 'pending'",
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: "title", type: "text", required: true, max: 200 },
        {
          name: "target",
          type: "select",
          required: true,
          maxSelect: 1,
          values: ["freecad", "fusion360", "solidworks-vba", "other"],
        },
        { name: "description", type: "text", required: true, max: 2000 },
        { name: "code", type: "text", required: true, max: 20000 },
        { name: "author_name", type: "text", max: 200 },
        { name: "author_email", type: "email" },
        {
          name: "license",
          type: "select",
          maxSelect: 1,
          values: ["mit", "public-domain", "as-is"],
        },
        {
          name: "status",
          type: "select",
          maxSelect: 1,
          values: ["pending", "approved", "rejected"],
        },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
      ],
    });
    app.save(submissions);
  },
  (app) => {
    try {
      app.delete(app.findCollectionByNameOrId("macro_submissions"));
    } catch (_) {}
  },
);
