/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    let col;
    try {
      col = app.findCollectionByNameOrId('newsletter_subscribers');
    } catch (_) {
      col = new Collection({
        type: 'base',
        name: 'newsletter_subscribers',
        listRule: null,
        viewRule: null,
        createRule: '',
        updateRule: null,
        deleteRule: null,
        fields: [
          { name: 'email', type: 'email', required: true },
          { name: 'name', type: 'text', max: 100 },
          { name: 'source', type: 'text', max: 50 },
          { name: 'created', type: 'autodate', onCreate: true, onUpdate: false },
        ],
        indexes: [
          'CREATE UNIQUE INDEX idx_newsletter_email ON newsletter_subscribers (email)',
        ],
      });
      app.save(col);
    }
  },
  (app) => {
    try {
      const col = app.findCollectionByNameOrId('newsletter_subscribers');
      app.delete(col);
    } catch (e) {
      if (e.message.includes('no rows in result set')) return;
      throw e;
    }
  },
);
