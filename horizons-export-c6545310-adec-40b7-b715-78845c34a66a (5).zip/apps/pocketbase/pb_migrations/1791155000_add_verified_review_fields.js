/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // Extend tool_reviews with the richer "Verified Community Review" fields:
    // professional identity, discipline, usage duration, pros/cons, feature
    // rating sliders, and a trust confirmation. All new fields are OPTIONAL
    // so existing rows remain valid. Work-email verification is enforced in
    // the form (client-side) rather than as a schema constraint, to avoid
    // invalidating pre-existing rows.
    const col = app.findCollectionByNameOrId("tool_reviews");

    const addIfMissing = (field) => {
      if (!col.fields.getByName(field.name)) {
        col.fields.add(field);
      }
    };

    addIfMissing(new TextField({ name: "full_name", max: 200 }));
    addIfMissing(new TextField({ name: "job_title", max: 200 }));
    addIfMissing(new EmailField({ name: "work_email" }));
    addIfMissing(
      new SelectField({
        name: "discipline",
        maxSelect: 1,
        values: [
          "mechanical",
          "piping-flow",
          "cad-management",
          "fea-cfd",
          "manufacturing",
          "other",
        ],
      }),
    );
    addIfMissing(
      new SelectField({
        name: "usage_duration",
        maxSelect: 1,
        values: ["under-6-months", "6-12-months", "1-3-years", "3-plus-years"],
      }),
    );
    addIfMissing(new TextField({ name: "pros", max: 2000 }));
    addIfMissing(new TextField({ name: "cons", max: 2000 }));
    addIfMissing(new NumberField({ name: "api_rating", min: 0, max: 5 }));
    addIfMissing(new NumberField({ name: "stability_rating", min: 0, max: 5 }));
    addIfMissing(
      new NumberField({ name: "pricing_transparency_rating", min: 0, max: 5 }),
    );
    addIfMissing(new BoolField({ name: "trust_confirmed" }));

    // Keep the existing moderation rules: only approved reviews are public,
    // and submitters can never set status themselves.
    app.save(col);
  },
  (app) => {
    const col = app.findCollectionByNameOrId("tool_reviews");
    [
      "full_name",
      "job_title",
      "work_email",
      "discipline",
      "usage_duration",
      "pros",
      "cons",
      "api_rating",
      "stability_rating",
      "pricing_transparency_rating",
      "trust_confirmed",
    ].forEach((name) => {
      if (col.fields.getByName(name)) col.fields.removeByName(name);
    });
    app.save(col);
  },
);
