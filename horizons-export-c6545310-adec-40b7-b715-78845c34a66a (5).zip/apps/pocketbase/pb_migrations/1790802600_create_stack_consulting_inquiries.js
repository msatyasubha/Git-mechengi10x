/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // Public lead-capture submissions for custom software stack consulting.
    // Anyone can submit; only admins (superusers) can read. Same pattern as
    // consultation_inquiries.
    const inquiries = new Collection({
      type: "base",
      name: "stack_consulting_inquiries",
      listRule: null,
      viewRule: null,
      createRule: "",
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: "contact_name", type: "text", required: true, max: 200 },
        { name: "email", type: "email", required: true },
        { name: "company", type: "text", max: 200 },
        { name: "role", type: "text", max: 200 },
        { name: "discipline", type: "text", max: 200 },
        { name: "current_stack", type: "text", required: true, max: 2000 },
        { name: "team_size", type: "text", max: 50 },
        { name: "budget_range", type: "text", max: 100 },
        { name: "goals", type: "text", max: 3000 },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
      ],
    });
    app.save(inquiries);
  },
  (app) => {
    try {
      app.delete(app.findCollectionByNameOrId("stack_consulting_inquiries"));
    } catch (_) {}
  },
);
