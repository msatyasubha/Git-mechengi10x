/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    // Moderation flow for community tool reviews:
    // - new `status` select field (pending / approved / rejected)
    // - public list/view only shows approved reviews
    // - submitters can never set status themselves (create/update rules guard it)
    // - existing rows are explicitly backfilled to "pending" (not auto-approved)
    const col = app.findCollectionByNameOrId("tool_reviews");

    if (!col.fields.getByName("status")) {
      col.fields.add(
        new SelectField({
          name: "status",
          maxSelect: 1,
          values: ["pending", "approved", "rejected"],
        }),
      );
    }

    col.listRule = "status = 'approved'";
    col.viewRule = "status = 'approved'";
    col.createRule =
      "@request.auth.id != '' && (@request.body.status:isset = false || @request.body.status = 'pending')";
    col.updateRule =
      "@request.auth.id != '' && @request.auth.id = owner && (@request.body.status:isset = false || @request.body.status = 'pending')";
    col.deleteRule = "@request.auth.id != '' && @request.auth.id = owner";
    app.save(col);

    // Backfill: every pre-moderation row becomes pending until an admin reviews it.
    const records = app.findRecordsByFilter("tool_reviews", "status != 'pending' && status != 'approved' && status != 'rejected'");
    for (const r of records) {
      r.set("status", "pending");
      app.save(r);
    }
  },
  (app) => {
    const col = app.findCollectionByNameOrId("tool_reviews");
    col.fields.removeByName("status");
    col.listRule = "";
    col.viewRule = "";
    col.createRule = "@request.auth.id != ''";
    col.updateRule = "@request.auth.id != '' && @request.auth.id = owner";
    col.deleteRule = "@request.auth.id != '' && @request.auth.id = owner";
    app.save(col);
  },
);
