/// <reference path="../pb_data/types.d.ts" />

// Sends an immediate confirmation email when an engineer registers for a
// webinar. Scheduled reminder sequences (1 week / 1 day before) are not
// supported by the platform (the instance hibernates when idle), so this
// hook handles the real-time confirmation only.

onRecordAfterCreateSuccess((e) => {
  const email = e.record.get("email");
  const name = e.record.get("full_name");
  const eventTitle = e.record.get("event_title");

  if (!email) {
    e.next();
    return;
  }

  const message = new MailerMessage({
    from: { name: "MechEngi 10X" },
    to: [{ address: email }],
    subject: `You're registered — ${eventTitle || "MechEngi 10X Webinar"}`,
    html: `
      <h2>You're registered, ${name || "there"}!</h2>
      <p>Thanks for registering for <strong>${eventTitle || "our webinar"}</strong>.</p>
      <p>We'll send a join link closer to the event date. You can also view your registered events anytime in your <a href="${$app.settings().meta.appURL}/profile">MechEngi 10X profile</a>.</p>
      <p>— The MechEngi 10X Team</p>
    `,
  });

  try {
    $app.newMailClient().send(message);
  } catch (err) {
    $app
      .logger()
      .error("event registration email failed", "to", email, "err", String(err));
  }

  e.next();
}, "event_registrations");
