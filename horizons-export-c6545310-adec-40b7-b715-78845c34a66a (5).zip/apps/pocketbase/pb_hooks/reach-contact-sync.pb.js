/// <reference path="../pb_data/types.d.ts" />

// Reach email-marketing sync — forwards new contact captures to Reach.
// Local PocketBase storage is always preserved: a failed Reach call is logged
// but never blocks the record from saving.

function reachSync(record, groupName, nameField) {
  const email = record.getString("email");
  if (!email) {
    // Reach requires an email — skip the sync when absent
    return;
  }

  const name = nameField ? record.getString(nameField) : "";

  try {
    $http.send({
      url: $os.getenv("REACH_API_URL") + "/api/public/v1/contacts",
      method: "POST",
      headers: {
        Authorization: "Bearer " + $os.getenv("REACH_API_TOKEN"),
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        groupName: groupName,
        contacts: [
          {
            email: email,
            name: name,
            surname: "",
            phone: record.getString("phone") || "",
          },
        ],
      }),
    });
  } catch (err) {
    $app.logger().error("Reach contact sync failed", "group", groupName, "err", String(err));
  }
}

// Newsletter sign-ups (homepage + AI tool profile pages)
onRecordAfterCreateSuccess((e) => {
  reachSync(e.record, "Hostinger AI Builder newsletter form", "name");
  e.next();
}, "newsletter_subscribers");

// Sponsorship inquiry form submissions
onRecordAfterCreateSuccess((e) => {
  reachSync(e.record, "Hostinger AI Builder sponsorship inquiry form", "contact_name");
  e.next();
}, "sponsor_inquiries");
