/// <reference path="../pb_data/types.d.ts" />

onRecordAfterCreateSuccess((e) => {
  const recipient = e.record.getString("email");
  const company = e.record.getString("company_name");
  const pkg = e.record.getString("interested_packages") || "a sponsorship package";

  const message = new MailerMessage({
    from:    { name: "MechEngi 10X Partnerships" },
    to:      [{ address: recipient }],
    subject: "We received your sponsorship inquiry",
    html:    `
      <h2>Thanks for your interest, ${company}!</h2>
      <p>We've received your inquiry about <strong>${pkg}</strong>. Our partnerships team will review it and
      reply with a tailored proposal as soon as we can.</p>
      <p>In the meantime, you can review our <a href="${$app.settings().meta.appURL}/sponsor/terms">sponsorship terms</a>
      or browse our <a href="${$app.settings().meta.appURL}/sponsor">package options</a>.</p>
      <p>— The MechEngi 10X Team</p>
    `,
  });

  try {
    $app.newMailClient().send(message);
  } catch (err) {
    $app.logger().error("sponsorship inquiry email failed", "to", recipient, "err", String(err));
  }

  e.next();
}, "sponsor_inquiries");
