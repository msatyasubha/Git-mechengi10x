/// <reference path="../pb_data/types.d.ts" />

// Affiliate conversion tracking.
//
// When a new user signs up with a `referred_by` referral code (captured on
// the landing page from the `?ref=` parameter and stored on the user record
// at signup), this hook:
//   1. looks up the affiliate that owns that referral code,
//   2. creates a `referrals` record (event_type = "signup", status "pending",
//      reward $10) owned by the referring affiliate's owner, and
//   3. increments the affiliate's total_signups and pending_balance.
//
// Runs server-side with superuser context, so PocketBase access rules on the
// `referrals` and `affiliates` collections (owner-scoped) do not block it.
// Failures are logged but never abort the user creation.

onRecordAfterCreateSuccess((e) => {
  const refCode = e.record.getString("referred_by");
  if (!refCode) {
    e.next();
    return;
  }

  try {
    let aff = null;
    try {
      aff = $app.findFirstRecordByData("affiliates", "referral_code", refCode);
    } catch (_) {
      // No affiliate matches this code — nothing to attribute.
    }
    if (!aff) {
      e.next();
      return;
    }

    const referralsCol = $app.findCollectionByNameOrId("referrals");
    const ref = new Record(referralsCol);
    ref.set("referral_code", refCode);
    ref.set("event_type", "signup");
    ref.set("reward_amount", 10);
    ref.set("status", "pending");
    ref.set("owner", aff.get("owner"));
    $app.save(ref);

    const curSignups = aff.getInt("total_signups") || 0;
    const curBalance = aff.getFloat("pending_balance") || 0;
    aff.set("total_signups", curSignups + 1);
    aff.set("pending_balance", curBalance + 10);
    $app.save(aff);
  } catch (err) {
    $app
      .logger()
      .error("affiliate conversion failed", "code", refCode, "err", String(err));
  }

  e.next();
}, "users");
